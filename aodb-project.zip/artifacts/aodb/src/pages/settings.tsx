import { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { useGetSettings, useUpdateSettings, useRunSimulatorTick, getGetSettingsQueryKey, getGetDashboardSummaryQueryKey, getListFlightsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { Database, Check, X, Play, RefreshCw, Shield, Wifi, WifiOff, Filter, AlertTriangle } from "lucide-react";

function IntegrationCard({ name, configured, description }: { name: string; configured: boolean; description: string }) {
  return (
    <Card className={`bg-card border-card-border ${configured ? "border-emerald-500/20" : ""}`}>
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-mono font-bold uppercase text-foreground">{name}</span>
          <Badge variant="outline" className={`text-[10px] font-mono uppercase px-1.5 py-0 ${configured ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/20" : "bg-slate-500/20 text-slate-400 border-slate-500/20"}`}>
            {configured ? <><Check className="h-2.5 w-2.5 mr-1 inline" />Configured</> : <><X className="h-2.5 w-2.5 mr-1 inline" />Not Configured</>}
          </Badge>
        </div>
        <p className="text-[11px] font-mono text-muted-foreground">{description}</p>
      </CardContent>
    </Card>
  );
}

export default function Settings() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const settingsQuery = useGetSettings({ query: { queryKey: getGetSettingsQueryKey() } });
  const settings = settingsQuery.data;

  const [airportIata, setAirportIata] = useState("");
  const [airportIcao, setAirportIcao] = useState("");
  const [airportName, setAirportName] = useState("");
  const [pollingInterval, setPollingInterval] = useState("60");
  const [notificationEmails, setNotificationEmails] = useState("");
  const [envMode, setEnvMode] = useState<"DEMO" | "LIVE">("DEMO");
  const [simResult, setSimResult] = useState<{ eventsGenerated: number; flightsUpdated: number; details: string[] } | null>(null);
  const [commercialOnlyMode, setCommercialOnlyMode] = useState<boolean | null>(null);

  useEffect(() => {
    if (settings) {
      setAirportIata(settings.airportIata);
      setAirportIcao(settings.airportIcao);
      setAirportName(settings.airportName);
      setPollingInterval(settings.pollingIntervalSeconds.toString());
      setNotificationEmails(settings.notificationEmails ?? "");
      setEnvMode(settings.environmentMode);
      if (commercialOnlyMode === null && settings.commercialOnlyMode !== undefined) {
        setCommercialOnlyMode(settings.commercialOnlyMode);
      }
    }
  }, [settings]);

  const toggleCommercialScope = useMutation({
    mutationFn: async (enabled: boolean) => {
      const res = await fetch("/api/settings/commercial-scope", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ commercialOnlyMode: enabled }),
      });
      if (!res.ok) throw new Error("Failed to update commercial scope");
      return res.json();
    },
    onSuccess: (_data, enabled) => {
      setCommercialOnlyMode(enabled);
      queryClient.invalidateQueries({ queryKey: getGetSettingsQueryKey() });
      queryClient.invalidateQueries({ queryKey: getListFlightsQueryKey() });
      toast({
        title: enabled ? "Commercial scope enabled" : "Commercial scope disabled",
        description: enabled
          ? "Ops board now shows commercial airline/cargo/charter flights only."
          : "Ops board now shows all flight types (GA, private, military included).",
      });
    },
    onError: () => { toast({ title: "Error", description: "Failed to update commercial scope.", variant: "destructive" }); },
  });

  const updateSettings = useUpdateSettings({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetSettingsQueryKey() });
        toast({ title: "Settings saved", description: "Configuration updated." });
      },
    },
  });

  const runSim = useRunSimulatorTick({
    mutation: {
      onSuccess: (result) => {
        setSimResult(result);
        queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
        queryClient.invalidateQueries({ queryKey: getListFlightsQueryKey() });
        toast({ title: "Simulator tick complete", description: `${result.eventsGenerated} events generated, ${result.flightsUpdated} flights updated.` });
      },
    },
  });

  return (
    <div className="p-6 space-y-6 max-w-3xl">
      <div>
        <div className="flex items-center gap-2 mb-1">
          <Database className="h-5 w-5 text-primary" />
          <h1 className="text-2xl font-mono font-bold text-foreground">Settings & Integrations</h1>
        </div>
        <p className="text-sm text-muted-foreground font-mono">Settings & Integrations (IT User)</p>
      </div>

      {/* Airport Info */}
      <Card className="bg-card border-card-border">
        <CardHeader className="pb-2 pt-4 px-4">
          <div className="flex items-center justify-between">
            <CardTitle className="text-xs font-mono uppercase tracking-wider text-muted-foreground">Airport Configuration</CardTitle>
            {settings && (
              <Badge variant="outline" className={`text-[10px] font-mono uppercase ${settings.environmentMode === "DEMO" ? "bg-amber-500/20 text-amber-300 border-amber-500/20" : "bg-emerald-500/20 text-emerald-300 border-emerald-500/20"}`}>
                {settings.environmentMode} MODE
              </Badge>
            )}
          </div>
        </CardHeader>
        <CardContent className="px-4 pb-4">
          {settingsQuery.isLoading ? <Skeleton className="h-32" /> : (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                updateSettings.mutate({
                  data: {
                    airportIata,
                    airportIcao,
                    airportName,
                    pollingIntervalSeconds: parseInt(pollingInterval),
                    notificationEmails: notificationEmails || null,
                    environmentMode: envMode,
                  },
                });
              }}
              className="space-y-4"
            >
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-1">
                  <Label className="text-xs font-mono uppercase text-muted-foreground">Airport IATA</Label>
                  <Input data-testid="input-iata" value={airportIata} onChange={(e) => setAirportIata(e.target.value.toUpperCase())} className="font-mono text-sm bg-background uppercase" placeholder="YLW" />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs font-mono uppercase text-muted-foreground">Airport ICAO</Label>
                  <Input data-testid="input-icao" value={airportIcao} onChange={(e) => setAirportIcao(e.target.value.toUpperCase())} className="font-mono text-sm bg-background uppercase" placeholder="CYLW" />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs font-mono uppercase text-muted-foreground">Environment Mode</Label>
                  <Select value={envMode} onValueChange={(v) => setEnvMode(v as "DEMO" | "LIVE")}>
                    <SelectTrigger data-testid="select-env-mode" className="font-mono text-sm bg-background">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="DEMO">DEMO</SelectItem>
                      <SelectItem value="LIVE">LIVE</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-1">
                <Label className="text-xs font-mono uppercase text-muted-foreground">Airport Name</Label>
                <Input data-testid="input-airport-name" value={airportName} onChange={(e) => setAirportName(e.target.value)} className="font-mono text-sm bg-background" placeholder="Kelowna International Airport" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <Label className="text-xs font-mono uppercase text-muted-foreground">FR24 Polling Interval (seconds)</Label>
                  <Input data-testid="input-polling" type="number" value={pollingInterval} onChange={(e) => setPollingInterval(e.target.value)} className="font-mono text-sm bg-background" />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs font-mono uppercase text-muted-foreground">Notification Emails</Label>
                  <Input data-testid="input-emails" value={notificationEmails} onChange={(e) => setNotificationEmails(e.target.value)} className="font-mono text-sm bg-background" placeholder="ops@airport.ca" />
                </div>
              </div>
              <Button type="submit" className="font-mono text-sm" disabled={updateSettings.isPending} data-testid="button-save-settings">
                {updateSettings.isPending ? "Saving..." : "Save Configuration"}
              </Button>
            </form>
          )}
        </CardContent>
      </Card>

      {/* Commercial Scope */}
      <Card className="bg-card border-card-border">
        <CardHeader className="pb-2 pt-4 px-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-sky-400" />
              <CardTitle className="text-xs font-mono uppercase tracking-wider text-muted-foreground">Operational Scope</CardTitle>
            </div>
            {commercialOnlyMode !== null && (
              <Badge variant="outline" className={`text-[10px] font-mono uppercase ${commercialOnlyMode ? "bg-sky-500/20 text-sky-300 border-sky-500/20" : "bg-amber-500/20 text-amber-300 border-amber-500/20"}`}>
                {commercialOnlyMode ? "Commercial Only" : "All Flight Types"}
              </Badge>
            )}
          </div>
        </CardHeader>
        <CardContent className="px-4 pb-4 space-y-3">
          {settingsQuery.isLoading ? <Skeleton className="h-20" /> : (
            <>
              <p className="text-xs font-mono text-muted-foreground">
                Controls which flights appear on the main Operations Board. When <strong className="text-foreground">Commercial Only</strong> is enabled,
                the board shows airline, cargo, and charter movements exclusively — general aviation, private aircraft, military,
                training, and helicopter operations are suppressed from the main board and visible in the ADS-B Review Queue only.
              </p>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => toggleCommercialScope.mutate(true)}
                  disabled={toggleCommercialScope.isPending || commercialOnlyMode === true}
                  className={`rounded-lg border p-3 text-left transition-all ${commercialOnlyMode === true ? "border-sky-500/40 bg-sky-500/10" : "border-border/30 bg-secondary/20 hover:bg-secondary/40"} disabled:opacity-50`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <Check className={`h-3.5 w-3.5 ${commercialOnlyMode === true ? "text-sky-400" : "text-muted-foreground"}`} />
                    <span className={`text-xs font-mono font-bold ${commercialOnlyMode === true ? "text-sky-300" : "text-foreground"}`}>Commercial Only</span>
                    {commercialOnlyMode === true && <Badge variant="outline" className="text-[9px] font-mono bg-sky-500/20 text-sky-300 border-sky-500/20 ml-auto">Active</Badge>}
                  </div>
                  <p className="text-[10px] font-mono text-muted-foreground">Airline · Cargo · Charter only. GA/private/military suppressed. Recommended for Commercial AODB MVP.</p>
                </button>
                <button
                  type="button"
                  onClick={() => toggleCommercialScope.mutate(false)}
                  disabled={toggleCommercialScope.isPending || commercialOnlyMode === false}
                  className={`rounded-lg border p-3 text-left transition-all ${commercialOnlyMode === false ? "border-amber-500/40 bg-amber-500/10" : "border-border/30 bg-secondary/20 hover:bg-secondary/40"} disabled:opacity-50`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <AlertTriangle className={`h-3.5 w-3.5 ${commercialOnlyMode === false ? "text-amber-400" : "text-muted-foreground"}`} />
                    <span className={`text-xs font-mono font-bold ${commercialOnlyMode === false ? "text-amber-300" : "text-foreground"}`}>All Flight Types</span>
                    {commercialOnlyMode === false && <Badge variant="outline" className="text-[9px] font-mono bg-amber-500/20 text-amber-300 border-amber-500/20 ml-auto">Active</Badge>}
                  </div>
                  <p className="text-[10px] font-mono text-muted-foreground">Show all aircraft including GA, private, training, military, and helicopters on the main board.</p>
                </button>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* Integration Status */}
      <div>
        <h2 className="text-xs font-mono uppercase tracking-wider text-muted-foreground mb-3">Integration Status</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {settingsQuery.isLoading ? (
            Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-20" />)
          ) : (
            <>
              <IntegrationCard
                name="Flightradar24 API"
                configured={settings?.fr24ApiConfigured ?? false}
                description="Live ADS-B position data for flight tracking. API key must be configured in environment secrets — never displayed in plain text."
              />
              <IntegrationCard
                name="RMS Webhook"
                configured={settings?.rmsWebhookConfigured ?? false}
                description="Resource Management System integration for stand, gate, and belt allocation events."
              />
              <IntegrationCard
                name="Billing API"
                configured={settings?.billingApiConfigured ?? false}
                description="Billing system integration for landing fee and AIF reconciliation."
              />
            </>
          )}
        </div>
      </div>

      {/* Simulator */}
      <Card className="bg-card border-card-border">
        <CardHeader className="pb-2 pt-4 px-4">
          <CardTitle className="text-xs font-mono uppercase tracking-wider text-muted-foreground">Ingestion Simulator (FR24 Demo)</CardTitle>
        </CardHeader>
        <CardContent className="px-4 pb-4 space-y-4">
          <p className="text-xs font-mono text-muted-foreground">
            Simulates a Flightradar24 polling tick. Advances up to 3 eligible flights to their next lifecycle state,
            generating ADS-B-like events and updating the movement board in real time.
          </p>
          <Button
            onClick={() => { setSimResult(null); runSim.mutate(); }}
            disabled={runSim.isPending}
            className="font-mono text-sm gap-2"
            data-testid="button-run-simulator"
          >
            {runSim.isPending ? (
              <><RefreshCw className="h-4 w-4 animate-spin" />Running Tick...</>
            ) : (
              <><Play className="h-4 w-4" />Run Ingestion Tick</>
            )}
          </Button>
          {simResult && (
            <div className="bg-secondary/30 rounded-lg p-4 border border-border/40 space-y-2">
              <div className="flex gap-4 font-mono text-xs">
                <span className="text-emerald-400 font-bold">{simResult.eventsGenerated} events generated</span>
                <span className="text-sky-400">{simResult.flightsUpdated} flights updated</span>
              </div>
              {simResult.details.map((d, i) => (
                <div key={i} className="text-xs font-mono text-muted-foreground">· {d}</div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Future-ready Note */}
      <Card className="bg-primary/5 border-primary/20">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Shield className="h-4 w-4 text-primary mt-0.5 shrink-0" />
            <div className="text-xs font-mono text-foreground/70 space-y-1">
              <div className="font-bold text-foreground/90">Future-Ready Architecture</div>
              <div>Designed for AWS deployment. Future integrations: Flightradar24 polling, RMS event sync, billing dispute defense, and Canadian airport data residency compliance.</div>
              <div className="text-muted-foreground mt-1">All credentials stored as environment secrets — never exposed in application code or UI.</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
