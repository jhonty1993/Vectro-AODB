import { useGetBillingReconciliation, useGetBillingSummary, getGetBillingReconciliationQueryKey, getGetBillingSummaryQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Banknote, AlertTriangle, CheckCircle2, Clock } from "lucide-react";
import type { BillingRecord } from "@workspace/api-client-react";

const RECON_COLORS: Record<string, string> = {
  PENDING: "bg-amber-500/20 text-amber-300 border-amber-500/30",
  RECONCILED: "bg-emerald-500/20 text-emerald-300 border-emerald-500/30",
  FLAGGED: "bg-red-500/20 text-red-300 border-red-500/30",
  DISPUTED: "bg-orange-500/20 text-orange-300 border-orange-500/30",
};

const FLAG_LABELS: Record<string, { label: string; color: string }> = {
  MISSING_LANDING_TIME: { label: "Missing Landing Time", color: "bg-red-500/20 text-red-300 border-red-500/20" },
  MTOW_MISMATCH: { label: "MTOW Mismatch", color: "bg-orange-500/20 text-orange-300 border-orange-500/20" },
  PAX_VARIANCE: { label: "Pax Variance", color: "bg-amber-500/20 text-amber-300 border-amber-500/20" },
  DIVERTED_FLIGHT: { label: "Diverted", color: "bg-purple-500/20 text-purple-300 border-purple-500/20" },
  TARIFF_MISMATCH: { label: "Tariff Mismatch", color: "bg-cyan-500/20 text-cyan-300 border-cyan-500/20" },
};

function formatTime(iso: string | null | undefined): string {
  if (!iso) return "—";
  try { return new Date(iso).toTimeString().slice(0, 8); } catch { return "—"; }
}

function formatCAD(val: number | null | undefined): string {
  if (val == null) return "—";
  return new Intl.NumberFormat("en-CA", { style: "currency", currency: "CAD" }).format(val);
}

export default function Billing() {
  const reconQuery = useGetBillingReconciliation({ query: { queryKey: getGetBillingReconciliationQueryKey() } });
  const summaryQuery = useGetBillingSummary({ query: { queryKey: getGetBillingSummaryQueryKey() } });

  const records = reconQuery.data ?? [];
  const summary = summaryQuery.data;

  return (
    <div className="p-6 space-y-6">
      <div>
        <div className="flex items-center gap-2 mb-1">
          <Banknote className="h-5 w-5 text-primary" />
          <h1 className="text-2xl font-mono font-bold text-foreground">Billing Reconciliation</h1>
        </div>
        <p className="text-sm text-muted-foreground font-mono">Finance — Billing Reconciliation (Finance User)</p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {summaryQuery.isLoading ? (
          Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-20" />)
        ) : (
          <>
            <Card className="bg-card border-card-border">
              <CardContent className="p-4">
                <div className="text-xs font-mono text-muted-foreground uppercase mb-1">Billable</div>
                <div className="text-2xl font-mono font-bold">{summary?.totalBillable ?? 0}</div>
              </CardContent>
            </Card>
            <Card className="bg-emerald-500/5 border-emerald-500/20">
              <CardContent className="p-4">
                <div className="text-xs font-mono text-emerald-400 uppercase mb-1 flex items-center gap-1"><CheckCircle2 className="h-3 w-3" />Reconciled</div>
                <div className="text-2xl font-mono font-bold text-emerald-400">{summary?.reconciled ?? 0}</div>
              </CardContent>
            </Card>
            <Card className="bg-red-500/5 border-red-500/20">
              <CardContent className="p-4">
                <div className="text-xs font-mono text-red-400 uppercase mb-1 flex items-center gap-1"><AlertTriangle className="h-3 w-3" />Flagged</div>
                <div className="text-2xl font-mono font-bold text-red-400">{summary?.flagged ?? 0}</div>
              </CardContent>
            </Card>
            <Card className="bg-card border-card-border">
              <CardContent className="p-4">
                <div className="text-xs font-mono text-muted-foreground uppercase mb-1">Landing Fees</div>
                <div className="text-lg font-mono font-bold text-foreground">{formatCAD(summary?.totalLandingFees)}</div>
              </CardContent>
            </Card>
            <Card className="bg-card border-card-border">
              <CardContent className="p-4">
                <div className="text-xs font-mono text-muted-foreground uppercase mb-1">AIF Total</div>
                <div className="text-lg font-mono font-bold text-foreground">{formatCAD(summary?.totalAif)}</div>
              </CardContent>
            </Card>
          </>
        )}
      </div>

      {/* Exception Flags Summary */}
      {summary && summary.exceptionTypes.length > 0 && (
        <Card className="bg-card border-card-border">
          <CardHeader className="pb-2 pt-4 px-4">
            <CardTitle className="text-xs font-mono uppercase tracking-wider text-muted-foreground">Exception Summary</CardTitle>
          </CardHeader>
          <CardContent className="px-4 pb-4 flex flex-wrap gap-2">
            {summary.exceptionTypes.map((ex) => (
              <div key={ex.flag} className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-xs font-mono ${FLAG_LABELS[ex.flag]?.color ?? "bg-muted"}`}>
                <AlertTriangle className="h-3 w-3" />
                <span>{FLAG_LABELS[ex.flag]?.label ?? ex.flag}</span>
                <span className="font-bold">({ex.count})</span>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Reconciliation Table */}
      <Card className="bg-card border-card-border">
        <CardHeader className="pb-2 pt-4 px-4">
          <CardTitle className="text-xs font-mono uppercase tracking-wider text-muted-foreground">Completed Arrivals — Billing Records</CardTitle>
        </CardHeader>
        <CardContent className="px-0 pb-0">
          <div className="overflow-x-auto">
            <table className="w-full text-xs font-mono">
              <thead>
                <tr className="border-b border-border text-muted-foreground">
                  {["Flight", "Airline", "Tail", "Type", "MTOW (kg)", "Engine", "Intl/Dom", "Landing Time", "Pax", "Landing Fee", "AIF", "Tariff", "Status", "Flags"].map((h) => (
                    <th key={h} className="px-3 py-2 text-left uppercase tracking-wider text-[10px] whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {reconQuery.isLoading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <tr key={i} className="border-b border-border/50">
                      {Array.from({ length: 14 }).map((_, j) => (
                        <td key={j} className="px-3 py-2"><Skeleton className="h-3 w-12" /></td>
                      ))}
                    </tr>
                  ))
                ) : records.length === 0 ? (
                  <tr><td colSpan={14} className="px-6 py-8 text-center text-muted-foreground">No billing records. Run the ingestion simulator to generate arrivals.</td></tr>
                ) : (
                  records.map((r: BillingRecord) => (
                    <tr key={r.id} data-testid={`billing-row-${r.id}`} className="border-b border-border/40 hover:bg-secondary/30">
                      <td className="px-3 py-2 font-bold text-foreground whitespace-nowrap">{r.flightNumber}</td>
                      <td className="px-3 py-2 text-muted-foreground">{r.airline}</td>
                      <td className="px-3 py-2 text-muted-foreground">{r.tailNumber ?? "—"}</td>
                      <td className="px-3 py-2 text-muted-foreground whitespace-nowrap">{r.aircraftType ?? "—"}</td>
                      <td className="px-3 py-2">{r.mtowKg ? r.mtowKg.toLocaleString() : "—"}</td>
                      <td className="px-3 py-2 text-muted-foreground">{r.engineType ?? "—"}</td>
                      <td className="px-3 py-2">
                        <Badge variant="outline" className={`text-[10px] uppercase font-mono px-1.5 py-0 ${r.isInternational ? "bg-blue-500/20 text-blue-300 border-blue-500/20" : "bg-slate-500/20 text-slate-300 border-slate-500/20"}`}>
                          {r.isInternational ? "INTL" : "DOM"}
                        </Badge>
                      </td>
                      <td className="px-3 py-2">{formatTime(r.landingTime)}</td>
                      <td className="px-3 py-2">{r.paxCount ?? "—"}</td>
                      <td className="px-3 py-2 text-emerald-400">{formatCAD(r.calculatedLandingFee)}</td>
                      <td className="px-3 py-2 text-sky-400">{formatCAD(r.aifEstimate)}</td>
                      <td className="px-3 py-2 text-muted-foreground">{r.tariffVersion ?? "—"}</td>
                      <td className="px-3 py-2">
                        <Badge variant="outline" className={`text-[10px] uppercase font-mono px-1.5 py-0 ${RECON_COLORS[r.reconciliationStatus] ?? ""}`}>
                          {r.reconciliationStatus}
                        </Badge>
                      </td>
                      <td className="px-3 py-2">
                        <div className="flex flex-wrap gap-1">
                          {(r.flags ?? []).map((flag: string) => (
                            <Badge key={flag} variant="outline" className={`text-[9px] font-mono px-1 py-0 ${FLAG_LABELS[flag]?.color ?? "bg-muted"}`}>
                              {FLAG_LABELS[flag]?.label ?? flag}
                            </Badge>
                          ))}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
