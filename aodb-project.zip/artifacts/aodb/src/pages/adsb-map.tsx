import "leaflet/dist/leaflet.css";
import { useState, useEffect, useRef, useCallback } from "react";
import { MapContainer, TileLayer, Circle, Marker, Popup, useMap } from "react-leaflet";
import L from "leaflet";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  RefreshCw, Plane, ArrowDown, ArrowUp, Wifi, WifiOff,
  AlertTriangle, Filter, Eye, EyeOff
} from "lucide-react";

// ── Constants ────────────────────────────────────────────────────────────────

const CYLW_LAT = 49.9561;
const CYLW_LON = -119.3778;
const NM_TO_M = 1852;
const REFRESH_INTERVAL_MS = 15_000;

const RANGE_RINGS: { nm: number; label: string; color: string; dash: string }[] = [
  { nm: 5,  label: "5 NM",  color: "#38bdf8", dash: "4 4" },
  { nm: 10, label: "10 NM", color: "#818cf8", dash: "6 4" },
  { nm: 25, label: "25 NM", color: "#a78bfa", dash: "8 6" },
  { nm: 50, label: "50 NM", color: "#6366f1", dash: "2 8" },
];

// ── Types ────────────────────────────────────────────────────────────────────

type Aircraft = {
  hex: string;
  callsign: string;
  registration: string | null;
  aircraftType: string | null;
  lat: number;
  lon: number;
  altBaro: number;
  groundSpeed: number;
  track: number;
  distanceFromAirportNm: number;
  seenSecondsAgo: number;
  lastSeen: string;
  inferredStatus: string;
  matchedFlightId: string | null;
  matchedFlightNumber: string | null;
  source: string;
};

type FetchState = "idle" | "loading" | "ok" | "error";

// ── Marker Icon Factory ───────────────────────────────────────────────────────

// Module-scope memoization: aircraft icons are pure functions of (track-rounded,
// status, matched). Without caching, this is invoked once per marker on every
// 1s countdown re-render, causing significant icon churn / Leaflet thrash.
const ICON_CACHE = new Map<string, L.DivIcon>();
function makeIcon(track: number, status: string, isMatched: boolean): L.DivIcon {
  const trackBucket = Math.round((track ?? 0) / 5) * 5;
  const key = `${trackBucket}|${status}|${isMatched ? 1 : 0}`;
  const cached = ICON_CACHE.get(key);
  if (cached) return cached;
  const icon = buildIcon(trackBucket, status, isMatched);
  ICON_CACHE.set(key, icon);
  return icon;
}

function buildIcon(track: number, status: string, isMatched: boolean): L.DivIcon {
  const isGround = status.startsWith("ON_GROUND");
  const isApproach = status === "APPROACH";

  const color = isGround
    ? "#64748b"
    : isMatched
    ? "#38bdf8"
    : isApproach
    ? "#fbbf24"
    : "#a78bfa";

  const size = isGround ? 14 : 20;
  const opacity = isGround ? 0.65 : 1;

  // Aircraft silhouette SVG pointing north (up) — rotated by track
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24" fill="${color}">
    <path d="M21 16v-2l-8-5V3.5c0-.83-.67-1.5-1.5-1.5S10 2.67 10 3.5V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5l8 2.5z"/>
  </svg>`;

  return L.divIcon({
    html: `<div style="
      width:${size}px;height:${size}px;
      transform:rotate(${track}deg);
      opacity:${opacity};
      display:flex;align-items:center;justify-content:center;
      filter: drop-shadow(0 0 3px ${color}60);
    ">${svg}</div>`,
    className: "",
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
    popupAnchor: [0, -(size / 2 + 6)],
  });
}

// Airport pin for CYLW
const airportIcon = L.divIcon({
  html: `<div style="
    width:12px;height:12px;
    background:#f97316;
    border:2px solid #fff;
    border-radius:50%;
    box-shadow: 0 0 8px #f9731680;
  "></div>`,
  className: "",
  iconSize: [12, 12],
  iconAnchor: [6, 6],
});

// ── Map Recenter helper ───────────────────────────────────────────────────────

function MapInit() {
  const map = useMap();
  useEffect(() => {
    map.setView([CYLW_LAT, CYLW_LON], 10);
  }, [map]);
  return null;
}

// ── Altitude color helper ─────────────────────────────────────────────────────

function altitudeColor(alt: number): string {
  if (alt <= 0) return "text-slate-400";
  if (alt < 5000) return "text-amber-400";
  if (alt < 15000) return "text-sky-400";
  return "text-emerald-400";
}

function formatAlt(alt: number): string {
  if (alt <= 0) return "GND";
  return alt.toLocaleString() + " ft";
}

function formatTime(iso: string | null | undefined): string {
  if (!iso) return "—";
  try {
    return new Date(iso).toLocaleTimeString("en-CA", {
      timeZone: "America/Vancouver",
      hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false,
    });
  } catch { return "—"; }
}

// ── Main Page ─────────────────────────────────────────────────────────────────

export default function AdsbMapPage() {
  const [aircraft, setAircraft] = useState<Aircraft[]>([]);
  const [fetchState, setFetchState] = useState<FetchState>("idle");
  const [lastRefresh, setLastRefresh] = useState<Date | null>(null);
  const [countdown, setCountdown] = useState(REFRESH_INTERVAL_MS / 1000);
  const [commercialOnly, setCommercialOnly] = useState(true);
  const [showRings, setShowRings] = useState(true);
  const [selectedRingFilter, setSelectedRingFilter] = useState<50 | 25 | 10>(50);
  const [selectedAc, setSelectedAc] = useState<string | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const countdownRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const fetchAircraft = useCallback(async () => {
    setFetchState("loading");
    try {
      const params = new URLSearchParams({
        radius: String(selectedRingFilter),
        commercial_only: String(commercialOnly),
      });
      const r = await fetch(`/api/sources/adsbexchange/nearby?${params}`);
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      const data = await r.json();
      setAircraft(data.aircraft ?? []);
      setLastRefresh(new Date());
      setFetchState("ok");
      setCountdown(REFRESH_INTERVAL_MS / 1000);
    } catch {
      setFetchState("error");
    }
  }, [commercialOnly, selectedRingFilter]);

  useEffect(() => {
    fetchAircraft();

    timerRef.current = setInterval(fetchAircraft, REFRESH_INTERVAL_MS);
    countdownRef.current = setInterval(() => {
      setCountdown((c) => Math.max(0, c - 1));
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      if (countdownRef.current) clearInterval(countdownRef.current);
    };
  }, [fetchAircraft]);

  const airborne = aircraft.filter((a) => !a.inferredStatus.startsWith("ON_GROUND"));
  const onGround = aircraft.filter((a) => a.inferredStatus.startsWith("ON_GROUND"));
  const matched = aircraft.filter((a) => a.matchedFlightNumber);
  const isDemo = aircraft[0]?.source?.includes("DEMO") ?? true;

  return (
    <div className="flex flex-col h-screen bg-background">

      {/* ── Top Status Bar ─────────────────────────────────────────────── */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 px-4 py-3 border-b border-border bg-card shrink-0">
        <div className="flex items-center gap-2 flex-1">
          <Plane className="h-4 w-4 text-sky-400" />
          <span className="font-mono font-bold text-sm text-foreground">ADS-B Live Map</span>
          <span className="text-muted-foreground/60 font-mono text-xs">CYLW/YLW · 49.9561°N 119.3778°W</span>

          {/* Status badges */}
          {isDemo ? (
            <Badge variant="outline" className="bg-amber-500/10 text-amber-300 border-amber-500/20 font-mono text-[10px] uppercase">
              <AlertTriangle className="h-2.5 w-2.5 mr-1" /> Demo
            </Badge>
          ) : (
            <Badge variant="outline" className="bg-emerald-500/10 text-emerald-300 border-emerald-500/20 font-mono text-[10px] uppercase">
              <Wifi className="h-2.5 w-2.5 mr-1" /> Live ADS-B
            </Badge>
          )}

          {/* Aircraft counts */}
          <div className="flex items-center gap-1 ml-2">
            <span className="text-xs font-mono text-sky-400 font-bold">{airborne.length}</span>
            <span className="text-[10px] font-mono text-muted-foreground/60">airborne</span>
            <span className="text-[10px] font-mono text-muted-foreground/40 mx-1">·</span>
            <span className="text-xs font-mono text-slate-400 font-bold">{onGround.length}</span>
            <span className="text-[10px] font-mono text-muted-foreground/60">on ground</span>
            <span className="text-[10px] font-mono text-muted-foreground/40 mx-1">·</span>
            <span className="text-xs font-mono text-emerald-400 font-bold">{matched.length}</span>
            <span className="text-[10px] font-mono text-muted-foreground/60">matched</span>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Radius filter */}
          <div className="flex items-center rounded border border-border overflow-hidden">
            {([10, 25, 50] as const).map((nm) => (
              <button
                key={nm}
                onClick={() => setSelectedRingFilter(nm)}
                className={`px-2.5 py-1 text-[10px] font-mono font-bold transition-colors ${
                  selectedRingFilter === nm
                    ? "bg-primary text-primary-foreground"
                    : "bg-background text-muted-foreground hover:text-foreground"
                }`}
              >
                {nm} NM
              </button>
            ))}
          </div>

          {/* Commercial only toggle */}
          <button
            onClick={() => setCommercialOnly((v) => !v)}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded border text-[10px] font-mono font-bold transition-colors ${
              commercialOnly
                ? "border-sky-500/40 bg-sky-500/10 text-sky-300"
                : "border-border bg-background text-muted-foreground"
            }`}
          >
            <Filter className="h-2.5 w-2.5" />
            Commercial Only
          </button>

          {/* Rings toggle */}
          <button
            onClick={() => setShowRings((v) => !v)}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded border text-[10px] font-mono font-bold transition-colors ${
              showRings
                ? "border-violet-500/40 bg-violet-500/10 text-violet-300"
                : "border-border bg-background text-muted-foreground"
            }`}
          >
            {showRings ? <Eye className="h-2.5 w-2.5" /> : <EyeOff className="h-2.5 w-2.5" />}
            Rings
          </button>

          {/* Refresh */}
          <Button
            size="sm"
            variant="outline"
            className="h-7 px-2 font-mono text-xs"
            onClick={fetchAircraft}
            disabled={fetchState === "loading"}
          >
            <RefreshCw className={`h-3 w-3 mr-1 ${fetchState === "loading" ? "animate-spin" : ""}`} />
            {fetchState === "loading" ? "..." : `${countdown}s`}
          </Button>
        </div>
      </div>

      {/* ── Main content: map + sidebar ─────────────────────────────────── */}
      <div className="flex flex-1 overflow-hidden">

        {/* Map */}
        <div className="flex-1 relative">
          {fetchState === "error" && (
            <div className="absolute inset-0 z-[9999] flex items-center justify-center bg-background/80">
              <div className="text-center space-y-2">
                <WifiOff className="h-8 w-8 text-red-400 mx-auto" />
                <div className="font-mono text-sm text-red-400">Failed to load ADS-B data</div>
                <Button size="sm" variant="outline" onClick={fetchAircraft}>Retry</Button>
              </div>
            </div>
          )}

          <MapContainer
            center={[CYLW_LAT, CYLW_LON]}
            zoom={10}
            style={{ width: "100%", height: "100%" }}
            zoomControl={true}
            attributionControl={true}
          >
            <MapInit />

            {/* Dark basemap */}
            <TileLayer
              url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://carto.com/">CARTO</a>'
              subdomains="abcd"
              maxZoom={19}
            />

            {/* Range rings */}
            {showRings && RANGE_RINGS.map(({ nm, label, color, dash }) => (
              nm <= selectedRingFilter && (
                <Circle
                  key={nm}
                  center={[CYLW_LAT, CYLW_LON]}
                  radius={nm * NM_TO_M}
                  pathOptions={{
                    color,
                    weight: 1,
                    opacity: 0.5,
                    fillOpacity: 0,
                    dashArray: dash,
                  }}
                />
              )
            ))}

            {/* Airport marker */}
            <Marker position={[CYLW_LAT, CYLW_LON]} icon={airportIcon}>
              <Popup>
                <div className="font-mono text-xs space-y-1 min-w-[160px]">
                  <div className="font-bold text-orange-300">CYLW / YLW</div>
                  <div className="text-slate-400">Kelowna International Airport</div>
                  <div>49.9561°N 119.3778°W</div>
                  <div>Elev: 1421 ft MSL</div>
                </div>
              </Popup>
            </Marker>

            {/* Aircraft markers */}
            {aircraft.map((ac) => (
              ac.lat && ac.lon ? (
                <Marker
                  key={`${ac.hex}|${ac.lastSeen}`}
                  position={[ac.lat, ac.lon]}
                  icon={makeIcon(ac.track, ac.inferredStatus, !!ac.matchedFlightNumber)}
                  eventHandlers={{
                    click: () => setSelectedAc(ac.hex === selectedAc ? null : ac.hex),
                  }}
                >
                  <Popup minWidth={220}>
                    <div className="font-mono text-xs space-y-2 min-w-[220px]">
                      {/* Header */}
                      <div className="flex items-center justify-between border-b border-slate-700 pb-1.5">
                        <div>
                          <span className="font-bold text-sky-300 text-sm">{ac.callsign || "——"}</span>
                          {ac.matchedFlightNumber && ac.matchedFlightNumber !== ac.callsign && (
                            <span className="text-slate-400 ml-1">({ac.matchedFlightNumber})</span>
                          )}
                        </div>
                        <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold uppercase ${
                          ac.inferredStatus.startsWith("ON_GROUND")
                            ? "bg-slate-700 text-slate-300"
                            : ac.inferredStatus === "APPROACH"
                            ? "bg-amber-900/60 text-amber-300"
                            : "bg-sky-900/60 text-sky-300"
                        }`}>
                          {ac.inferredStatus.replace(/_/g, " ")}
                        </span>
                      </div>

                      {/* Details grid */}
                      <div className="grid grid-cols-2 gap-x-3 gap-y-1">
                        <div><span className="text-slate-500">ICAO: </span><span className="text-slate-300 uppercase">{ac.hex}</span></div>
                        <div><span className="text-slate-500">Reg: </span><span className="text-slate-300">{ac.registration ?? "—"}</span></div>
                        <div><span className="text-slate-500">Type: </span><span className="text-slate-300">{ac.aircraftType ?? "—"}</span></div>
                        <div><span className="text-slate-500">Dist: </span><span className="text-slate-300">{ac.distanceFromAirportNm.toFixed(1)} NM</span></div>
                        <div>
                          <span className="text-slate-500">Alt: </span>
                          <span className={altitudeColor(ac.altBaro)}>{formatAlt(ac.altBaro)}</span>
                        </div>
                        <div><span className="text-slate-500">GS: </span><span className="text-slate-300">{ac.groundSpeed} kt</span></div>
                        <div><span className="text-slate-500">Track: </span><span className="text-slate-300">{ac.track}°</span></div>
                        <div><span className="text-slate-500">Seen: </span><span className="text-slate-300">{ac.seenSecondsAgo}s ago</span></div>
                      </div>

                      {/* Matched flight */}
                      {ac.matchedFlightNumber && (
                        <div className="border-t border-slate-700 pt-1.5 flex items-center gap-1.5">
                          {ac.matchedFlightNumber.match(/\d{3,4}[A-Z]?$/) ? (
                            <ArrowDown className="h-3 w-3 text-sky-400" />
                          ) : (
                            <ArrowUp className="h-3 w-3 text-indigo-400" />
                          )}
                          <span className="text-emerald-300">Matched → {ac.matchedFlightNumber}</span>
                        </div>
                      )}

                      {/* Source */}
                      <div className="text-[10px] text-slate-600 border-t border-slate-700 pt-1">
                        Source: {ac.source} · {formatTime(ac.lastSeen)}
                      </div>
                    </div>
                  </Popup>
                </Marker>
              ) : null
            ))}
          </MapContainer>

          {/* Map overlay: legend */}
          <div className="absolute bottom-8 left-3 z-[1000] bg-background/90 border border-border rounded p-2 font-mono text-[10px] space-y-1">
            <div className="text-muted-foreground/60 uppercase font-bold mb-1">Legend</div>
            <div className="flex items-center gap-1.5">
              <span style={{ display: "inline-block", width: 10, height: 10, background: "#38bdf8", borderRadius: "50%" }} />
              <span className="text-slate-400">Matched commercial</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span style={{ display: "inline-block", width: 10, height: 10, background: "#a78bfa", borderRadius: "50%" }} />
              <span className="text-slate-400">Unmatched airborne</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span style={{ display: "inline-block", width: 10, height: 10, background: "#fbbf24", borderRadius: "50%" }} />
              <span className="text-slate-400">On approach</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span style={{ display: "inline-block", width: 10, height: 10, background: "#64748b", borderRadius: "50%" }} />
              <span className="text-slate-400">On ground</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span style={{ display: "inline-block", width: 10, height: 10, background: "#f97316", borderRadius: "50%" }} />
              <span className="text-slate-400">CYLW airport</span>
            </div>
            {showRings && RANGE_RINGS.filter((r) => r.nm <= selectedRingFilter).map(({ nm, color }) => (
              <div key={nm} className="flex items-center gap-1.5">
                <span style={{ display: "inline-block", width: 14, height: 1, background: color, opacity: 0.6 }} />
                <span className="text-slate-400">{nm} NM ring</span>
              </div>
            ))}
          </div>
        </div>

        {/* ── Aircraft List Sidebar ── */}
        <div className="w-72 border-l border-border bg-card flex flex-col overflow-hidden shrink-0">
          <div className="px-3 py-2 border-b border-border">
            <div className="text-[11px] font-mono uppercase text-muted-foreground font-bold tracking-wider">
              Aircraft In Range · {aircraft.length} total
            </div>
            {lastRefresh && (
              <div className="text-[10px] font-mono text-muted-foreground/50 mt-0.5">
                Updated {lastRefresh.toLocaleTimeString("en-CA", { timeZone: "America/Vancouver", hour12: false })}
              </div>
            )}
          </div>

          <div className="flex-1 overflow-y-auto">
            {aircraft.length === 0 ? (
              <div className="p-4 text-center text-xs font-mono text-muted-foreground/60">
                {fetchState === "loading" ? "Loading..." : "No aircraft in range"}
              </div>
            ) : (
              aircraft
                .sort((a, b) => a.distanceFromAirportNm - b.distanceFromAirportNm)
                .map((ac) => {
                  const isGround = ac.inferredStatus.startsWith("ON_GROUND");
                  const isSelected = selectedAc === ac.hex;
                  return (
                    <div
                      key={`${ac.hex}|${ac.callsign}`}
                      onClick={() => setSelectedAc(isSelected ? null : ac.hex)}
                      className={`px-3 py-2.5 border-b border-border/40 cursor-pointer transition-colors font-mono text-xs ${
                        isSelected ? "bg-primary/10 border-l-2 border-l-primary" : "hover:bg-secondary/40"
                      }`}
                    >
                      <div className="flex items-center justify-between mb-0.5">
                        <span className={`font-bold ${isGround ? "text-slate-400" : "text-sky-300"}`}>
                          {ac.callsign || "——"}
                        </span>
                        <span className={`text-[10px] uppercase ${
                          isGround ? "text-slate-500" : "text-emerald-400"
                        }`}>
                          {ac.inferredStatus.startsWith("ON_GROUND_NEAR")
                            ? "ON STAND"
                            : ac.inferredStatus.replace(/_/g, " ")}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-muted-foreground/60 text-[10px]">
                        <span>{ac.aircraftType ?? "——"} · {ac.registration ?? "——"}</span>
                        <span>{ac.distanceFromAirportNm.toFixed(1)} NM</span>
                      </div>
                      <div className="flex items-center gap-3 mt-0.5 text-[10px]">
                        <span className={altitudeColor(ac.altBaro)}>{formatAlt(ac.altBaro)}</span>
                        <span className="text-muted-foreground/50">{ac.groundSpeed} kt</span>
                        <span className="text-muted-foreground/50">{ac.track}°</span>
                        {ac.matchedFlightNumber && (
                          <span className="text-emerald-400">→ {ac.matchedFlightNumber}</span>
                        )}
                      </div>
                    </div>
                  );
                })
            )}
          </div>

          {/* Sidebar footer */}
          <div className="px-3 py-2 border-t border-border text-[10px] font-mono text-muted-foreground/50 space-y-0.5">
            <div className="flex justify-between">
              <span>Airborne:</span>
              <span className="text-sky-400">{airborne.length}</span>
            </div>
            <div className="flex justify-between">
              <span>On Ground:</span>
              <span className="text-slate-400">{onGround.length}</span>
            </div>
            <div className="flex justify-between">
              <span>Matched:</span>
              <span className="text-emerald-400">{matched.length}</span>
            </div>
            <div className="flex justify-between">
              <span>Radius:</span>
              <span>{selectedRingFilter} NM</span>
            </div>
            <div className="flex justify-between">
              <span>Refresh:</span>
              <span>every {REFRESH_INTERVAL_MS / 1000}s</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
