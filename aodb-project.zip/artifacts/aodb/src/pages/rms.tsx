import { useState } from "react";
import { useGetRmsOutbox, useUpdateRmsAllocation, useListFlights, getGetRmsOutboxQueryKey, getListFlightsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Settings2, ArrowDown, ArrowUp, Check, X, Clock, RefreshCw } from "lucide-react";
import type { IntegrationOutboxEvent, FlightMovement } from "@workspace/api-client-react";

const STATUS_COLORS: Record<string, string> = {
  QUEUED: "bg-amber-500/20 text-amber-300 border-amber-500/30",
  SENT: "bg-emerald-500/20 text-emerald-300 border-emerald-500/30",
  FAILED: "bg-red-500/20 text-red-300 border-red-500/30",
  ACKNOWLEDGED: "bg-blue-500/20 text-blue-300 border-blue-500/30",
};

function formatDateTime(iso: string | null | undefined): string {
  if (!iso) return "—";
  try { return new Date(iso).toLocaleString("en-CA", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit", hour12: false }); } catch { return "—"; }
}

function AllocationDialog({ flight, onDone }: { flight: FlightMovement; onDone: () => void }) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [checkinCounters, setCheckinCounters] = useState(flight.checkinCounters ?? "");
  const [reason, setReason] = useState("");
  const [operator, setOperator] = useState("Ops Controller");

  const updateAllocation = useUpdateRmsAllocation({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListFlightsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetRmsOutboxQueryKey() });
        toast({ title: "Allocation updated", description: `${flight.flightNumber} resources assigned and sent to RMS.` });
        onDone();
      },
    },
  });

  return (
    <div className="space-y-3 mt-2">
      <div className="bg-secondary/30 rounded p-3 text-xs font-mono text-muted-foreground">
        <span className="text-foreground font-bold">{flight.flightNumber}</span> · {flight.airline} · {flight.direction === "ARR" ? `${flight.origin} → CYLW` : `CYLW → ${flight.destination}`}
      </div>
      <div className="grid grid-cols-1 gap-3">
        <div className="space-y-1">
          <Label className="text-xs font-mono uppercase text-muted-foreground">Check-in Counters</Label>
          <Input data-testid="input-checkin" value={checkinCounters} onChange={(e) => setCheckinCounters(e.target.value)} className="font-mono text-xs bg-background" placeholder="D14-D18" />
        </div>
      </div>
      <div className="space-y-1">
        <Label className="text-xs font-mono uppercase text-muted-foreground">Operator</Label>
        <Input data-testid="input-operator" value={operator} onChange={(e) => setOperator(e.target.value)} className="font-mono text-xs bg-background" />
      </div>
      <div className="space-y-1">
        <Label className="text-xs font-mono uppercase text-muted-foreground">Reason *</Label>
        <Textarea data-testid="textarea-reason" value={reason} onChange={(e) => setReason(e.target.value)} className="font-mono text-xs bg-background min-h-[60px]" placeholder="RMS allocation reason..." required />
      </div>
      <Button
        className="w-full font-mono text-xs"
        disabled={!reason.trim() || updateAllocation.isPending}
        data-testid="button-submit-allocation"
        onClick={() => {
          if (!reason.trim()) return;
          updateAllocation.mutate({
            data: {
              flightId: flight.id,
              checkinCounters: checkinCounters || undefined,
              reason,
              operator,
            },
          });
        }}
      >
        {updateAllocation.isPending ? "Sending to RMS..." : "Update Allocation & Send to RMS"}
      </Button>
    </div>
  );
}

export default function RmsPage() {
  const outboxQuery = useGetRmsOutbox({ query: { queryKey: getGetRmsOutboxQueryKey() } });
  const flightsQuery = useListFlights({}, { query: { queryKey: getListFlightsQueryKey() } });
  const [search, setSearch] = useState("");
  const [selectedFlight, setSelectedFlight] = useState<FlightMovement | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);

  const outboxEvents = outboxQuery.data ?? [];
  const flights = flightsQuery.data ?? [];

  const filteredFlights = flights.filter((f: FlightMovement) => {
    if (!search) return true;
    const q = search.toLowerCase();
    return f.flightNumber.toLowerCase().includes(q) || f.airline.toLowerCase().includes(q) || f.airlineIata.toLowerCase().includes(q);
  });

  const queuedCount = outboxEvents.filter((e: IntegrationOutboxEvent) => e.status === "QUEUED").length;
  const failedCount = outboxEvents.filter((e: IntegrationOutboxEvent) => e.status === "FAILED").length;

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center gap-2">
        <Settings2 className="h-5 w-5 text-primary" />
        <div>
          <h1 className="text-2xl font-mono font-bold text-foreground">RMS Integration</h1>
          <p className="text-sm text-muted-foreground font-mono">Resource Management System Integration (Ops User)</p>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <Card className="bg-card border-card-border">
          <CardContent className="p-4">
            <div className="text-xs font-mono text-muted-foreground uppercase mb-1">Total Events</div>
            <div className="text-2xl font-mono font-bold">{outboxEvents.length}</div>
          </CardContent>
        </Card>
        <Card className="bg-amber-500/5 border-amber-500/20">
          <CardContent className="p-4">
            <div className="text-xs font-mono text-amber-400 uppercase mb-1">Queued</div>
            <div className="text-2xl font-mono font-bold text-amber-400">{queuedCount}</div>
          </CardContent>
        </Card>
        <Card className="bg-red-500/5 border-red-500/20">
          <CardContent className="p-4">
            <div className="text-xs font-mono text-red-400 uppercase mb-1">Failed</div>
            <div className="text-2xl font-mono font-bold text-red-400">{failedCount}</div>
          </CardContent>
        </Card>
      </div>

      {/* Outbox Table */}
      <Card className="bg-card border-card-border">
        <CardHeader className="pb-2 pt-4 px-4">
          <CardTitle className="text-xs font-mono uppercase tracking-wider text-muted-foreground">RMS Outbox — Event Queue</CardTitle>
        </CardHeader>
        <CardContent className="px-0 pb-0">
          <div className="overflow-x-auto">
            <table className="w-full text-xs font-mono">
              <thead>
                <tr className="border-b border-border text-muted-foreground">
                  {["Flight", "Event Type", "Destination", "Status", "Created", "Sent"].map((h) => (
                    <th key={h} className="px-4 py-2 text-left uppercase tracking-wider text-[10px]">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {outboxQuery.isLoading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <tr key={i} className="border-b border-border/50">
                      {Array.from({ length: 6 }).map((_, j) => (
                        <td key={j} className="px-4 py-2"><Skeleton className="h-3 w-20" /></td>
                      ))}
                    </tr>
                  ))
                ) : outboxEvents.length === 0 ? (
                  <tr><td colSpan={6} className="px-4 py-8 text-center text-muted-foreground">No outbox events</td></tr>
                ) : (
                  outboxEvents.map((ev: IntegrationOutboxEvent) => (
                    <tr key={ev.id} data-testid={`outbox-event-${ev.id}`} className="border-b border-border/40">
                      <td className="px-4 py-2 font-bold text-foreground">{ev.flightNumber}</td>
                      <td className="px-4 py-2 text-muted-foreground">{ev.eventType.replace(/_/g, " ")}</td>
                      <td className="px-4 py-2">
                        <Badge variant="outline" className="text-[10px] font-mono uppercase px-1.5 py-0">
                          {ev.destination}
                        </Badge>
                      </td>
                      <td className="px-4 py-2">
                        <Badge variant="outline" className={`text-[10px] font-mono uppercase px-1.5 py-0 ${STATUS_COLORS[ev.status] ?? ""}`}>
                          {ev.status}
                        </Badge>
                      </td>
                      <td className="px-4 py-2 text-muted-foreground">{formatDateTime(ev.createdAt)}</td>
                      <td className="px-4 py-2 text-muted-foreground">{formatDateTime(ev.sentAt)}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Allocation Panel */}
      <Card className="bg-card border-card-border">
        <CardHeader className="pb-2 pt-4 px-4">
          <CardTitle className="text-xs font-mono uppercase tracking-wider text-muted-foreground">Stand / Gate / Belt Allocation</CardTitle>
        </CardHeader>
        <CardContent className="px-4 pb-4 space-y-3">
          <Input
            data-testid="input-search-flights"
            placeholder="Search flights to allocate..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="font-mono text-xs bg-background border-border h-8 w-64"
          />
          <div className="overflow-x-auto">
            <table className="w-full text-xs font-mono">
              <thead>
                <tr className="border-b border-border text-muted-foreground">
                  {["Dir", "Flight", "Airline", "Route", "Sched", "Counters", ""].map((h) => (
                    <th key={h} className="px-3 py-2 text-left uppercase tracking-wider text-[10px] whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {flightsQuery.isLoading ? (
                  Array.from({ length: 4 }).map((_, i) => (
                    <tr key={i} className="border-b border-border/50">
                      {Array.from({ length: 7 }).map((_, j) => (
                        <td key={j} className="px-3 py-2"><Skeleton className="h-3 w-12" /></td>
                      ))}
                    </tr>
                  ))
                ) : (
                  filteredFlights.slice(0, 12).map((f: FlightMovement) => (
                    <tr key={f.id} data-testid={`allocation-row-${f.id}`} className="border-b border-border/40">
                      <td className="px-3 py-2">
                        {f.direction === "ARR" ? <ArrowDown className="h-3.5 w-3.5 text-sky-400" /> : <ArrowUp className="h-3.5 w-3.5 text-indigo-400" />}
                      </td>
                      <td className="px-3 py-2 font-bold text-foreground">{f.flightNumber}</td>
                      <td className="px-3 py-2 text-muted-foreground">{f.airlineIata}</td>
                      <td className="px-3 py-2 text-muted-foreground whitespace-nowrap">{f.origin} → {f.destination}</td>
                      <td className="px-3 py-2">{new Date(f.scheduledTime).toTimeString().slice(0, 5)}</td>
                      <td className="px-3 py-2">{f.checkinCounters ?? <span className="text-muted-foreground">—</span>}</td>
                      <td className="px-3 py-2">
                        <Dialog open={dialogOpen && selectedFlight?.id === f.id} onOpenChange={(o) => { if (!o) { setDialogOpen(false); setSelectedFlight(null); } }}>
                          <DialogTrigger asChild>
                            <Button
                              size="sm"
                              variant="outline"
                              className="h-6 text-[10px] font-mono px-2"
                              data-testid={`button-allocate-${f.id}`}
                              onClick={() => { setSelectedFlight(f); setDialogOpen(true); }}
                            >
                              Assign
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="bg-card border-card-border max-w-sm">
                            <DialogHeader>
                              <DialogTitle className="font-mono text-sm">RMS Allocation — {f.flightNumber}</DialogTitle>
                            </DialogHeader>
                            {selectedFlight && <AllocationDialog flight={selectedFlight} onDone={() => { setDialogOpen(false); setSelectedFlight(null); }} />}
                          </DialogContent>
                        </Dialog>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
