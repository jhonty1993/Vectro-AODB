import { useState } from "react";
import { useParams, useLocation } from "wouter";
import {
  useGetFlight,
  useGetFlightEvents,
  useAddFlightEvent,
  getGetFlightQueryKey,
  getGetFlightEventsQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, ArrowDown, ArrowUp, Plus, AlertCircle, ChevronDown, ChevronRight, Banknote, RefreshCw, Pause, Trash2 } from "lucide-react";
import type { FlightEvent } from "@workspace/api-client-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import {
  apiGet, apiSend, formatCAD,
  CHARGE_STATUS_STYLE, ALERT_LEVEL_STYLE,
  type BillableCharge,
} from "@/lib/billing-api";
import { useRole, atLeast } from "@/lib/role";

const STATUS_COLORS: Record<string, string> = {
  SCHEDULED: "bg-slate-500/20 text-slate-300 border-slate-500/30",
  ESTIMATED: "bg-blue-500/20 text-blue-300 border-blue-500/30",
  AIRBORNE: "bg-sky-500/20 text-sky-300 border-sky-500/30",
  LANDED: "bg-emerald-500/20 text-emerald-300 border-emerald-500/30",
  ON_BLOCK: "bg-green-500/20 text-green-300 border-green-500/30",
  DEPARTED: "bg-indigo-500/20 text-indigo-300 border-indigo-500/30",
  CANCELLED: "bg-red-500/20 text-red-300 border-red-500/30",
  DIVERTED: "bg-orange-500/20 text-orange-300 border-orange-500/30",
  STAND_ASSIGNED: "bg-purple-500/20 text-purple-300 border-purple-500/30",
  GATE_ASSIGNED: "bg-violet-500/20 text-violet-300 border-violet-500/30",
  MANUAL_CORRECTION: "bg-amber-500/20 text-amber-300 border-amber-500/30",
  BILLING_EVENT: "bg-cyan-500/20 text-cyan-300 border-cyan-500/30",
};

function formatDateTime(iso: string | null | undefined): string {
  if (!iso) return "—";
  try {
    return new Date(iso).toLocaleString("en-CA", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit", hour12: false });
  } catch { return "—"; }
}

function FieldRow({ label, value }: { label: string; value: string | null | undefined }) {
  return (
    <div className="flex justify-between py-1.5 border-b border-border/40 last:border-0">
      <span className="text-xs font-mono text-muted-foreground uppercase tracking-wider">{label}</span>
      <span className="text-xs font-mono text-foreground">{value ?? "—"}</span>
    </div>
  );
}

function PayloadPanel({ payload }: { payload: Record<string, unknown> | null | undefined }) {
  const [open, setOpen] = useState(false);
  if (!payload) return null;
  return (
    <div className="mt-2">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-1 text-[10px] font-mono text-muted-foreground hover:text-foreground transition-colors"
      >
        {open ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
        Raw Payload
      </button>
      {open && (
        <pre className="mt-1 text-[10px] font-mono bg-background rounded p-2 overflow-x-auto border border-border/40 text-muted-foreground max-h-48 overflow-y-auto">
          {JSON.stringify(payload, null, 2)}
        </pre>
      )}
    </div>
  );
}

const EVENT_TYPES = [
  "SCHEDULED", "ESTIMATED", "AIRBORNE", "LANDED", "ON_BLOCK", "DEPARTED",
  "CANCELLED", "DIVERTED", "STAND_ASSIGNED", "GATE_ASSIGNED", "MANUAL_CORRECTION", "BILLING_EVENT",
];

export default function FlightDetail() {
  const params = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [eventOpen, setEventOpen] = useState(false);
  const [eventType, setEventType] = useState("MANUAL_CORRECTION");
  const [eventTime, setEventTime] = useState(new Date().toISOString().slice(0, 16));
  const [source, setSource] = useState("MANUAL");
  const [operator, setOperator] = useState("");
  const [reason, setReason] = useState("");

  const flightQuery = useGetFlight(params.id!, { query: { enabled: !!params.id, queryKey: getGetFlightQueryKey(params.id!) } });
  const eventsQuery = useGetFlightEvents(params.id!, { query: { enabled: !!params.id, queryKey: getGetFlightEventsQueryKey(params.id!) } });

  const addEventMutation = useAddFlightEvent({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetFlightQueryKey(params.id!) });
        queryClient.invalidateQueries({ queryKey: getGetFlightEventsQueryKey(params.id!) });
        setEventOpen(false);
        setReason("");
        toast({ title: "Event added", description: "Flight event recorded to immutable log." });
      },
    },
  });

  const flight = flightQuery.data;
  const events = eventsQuery.data ?? [];

  function handleAddEvent(e: React.FormEvent) {
    e.preventDefault();
    if (!reason.trim()) return;
    addEventMutation.mutate({
      id: params.id!,
      data: { eventType, eventTime: new Date(eventTime).toISOString(), source, operator: operator || undefined, reason },
    });
  }

  if (flightQuery.isLoading) {
    return (
      <div className="p-6 space-y-4">
        <Skeleton className="h-8 w-64" />
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <Skeleton className="h-96 lg:col-span-1" />
          <Skeleton className="h-96 lg:col-span-2" />
        </div>
      </div>
    );
  }

  if (!flight) {
    return (
      <div className="p-6">
        <div className="flex items-center gap-2 text-muted-foreground">
          <AlertCircle className="h-4 w-4" />
          <span className="font-mono text-sm">Flight not found</span>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div>
        <button
          onClick={() => navigate("/ops")}
          className="flex items-center gap-1.5 text-xs font-mono text-muted-foreground hover:text-foreground mb-3 transition-colors"
          data-testid="button-back"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          Operations Dashboard
        </button>
        <div className="flex items-center gap-3 flex-wrap">
          <h1 className="text-2xl font-mono font-bold text-foreground">{flight.flightNumber}</h1>
          <Badge variant="outline" className="font-mono text-xs uppercase flex items-center gap-1">
            {flight.direction === "ARR" ? <ArrowDown className="h-3 w-3 text-sky-400" /> : <ArrowUp className="h-3 w-3 text-indigo-400" />}
            {flight.direction}
          </Badge>
          <Badge variant="outline" className={`font-mono text-xs uppercase ${STATUS_COLORS[flight.status] ?? ""}`}>
            {flight.status.replace(/_/g, " ")}
          </Badge>
          <span className="text-sm text-muted-foreground font-mono">{flight.airline}</span>
          <span className="text-sm text-muted-foreground font-mono">{flight.origin} → {flight.destination}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Current Projection */}
        <div className="lg:col-span-1">
          <Card className="bg-card border-card-border">
            <CardHeader className="pb-2 pt-4 px-4">
              <CardTitle className="text-xs font-mono uppercase tracking-wider text-muted-foreground">Current Projection</CardTitle>
            </CardHeader>
            <CardContent className="px-4 pb-4">
              <FieldRow label="Flight No." value={flight.flightNumber} />
              <FieldRow label="Airline" value={`${flight.airline} (${flight.airlineIata})`} />
              <FieldRow label="Direction" value={flight.direction} />
              <FieldRow label="Origin" value={flight.origin} />
              <FieldRow label="Destination" value={flight.destination} />
              <FieldRow label="Scheduled" value={formatDateTime(flight.scheduledTime)} />
              <FieldRow label="Estimated" value={formatDateTime(flight.estimatedTime)} />
              <FieldRow label="Actual" value={formatDateTime(flight.actualTime)} />
              <FieldRow label="Tail No." value={flight.tailNumber} />
              <FieldRow label="Aircraft Type" value={flight.aircraftType} />
              <FieldRow label="Pax Count" value={flight.paxCount?.toString()} />
              <FieldRow label="Status" value={flight.status} />
              <FieldRow label="Delay" value={flight.delayMinutes != null ? `${flight.delayMinutes}m` : undefined} />
              <div className="flex justify-between py-1.5">
                <span className="text-xs font-mono text-muted-foreground uppercase tracking-wider">Data Quality</span>
                <div className="flex items-center gap-1.5">
                  <div className="w-16 h-1.5 bg-secondary rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${flight.dataQualityScore >= 80 ? "bg-emerald-400" : flight.dataQualityScore >= 60 ? "bg-amber-400" : "bg-red-400"}`}
                      style={{ width: `${flight.dataQualityScore}%` }}
                    />
                  </div>
                  <span className="text-xs font-mono text-foreground">{Math.round(flight.dataQualityScore)}%</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Event Timeline */}
        <div className="lg:col-span-2">
          <Card className="bg-card border-card-border">
            <CardHeader className="pb-2 pt-4 px-4">
              <div className="flex items-center justify-between">
                <CardTitle className="text-xs font-mono uppercase tracking-wider text-muted-foreground">
                  Immutable Event Log ({events.length} events)
                </CardTitle>
                <Dialog open={eventOpen} onOpenChange={setEventOpen}>
                  <DialogTrigger asChild>
                    <Button size="sm" variant="outline" className="h-7 text-xs font-mono gap-1" data-testid="button-add-event">
                      <Plus className="h-3.5 w-3.5" />
                      Add Event
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="bg-card border-card-border max-w-md">
                    <DialogHeader>
                      <DialogTitle className="font-mono text-sm">Add Lifecycle Event — {flight.flightNumber}</DialogTitle>
                    </DialogHeader>
                    <form onSubmit={handleAddEvent} className="space-y-3 mt-2">
                      <div className="space-y-1">
                        <Label className="text-xs font-mono uppercase text-muted-foreground">Event Type *</Label>
                        <Select value={eventType} onValueChange={setEventType}>
                          <SelectTrigger data-testid="select-event-type" className="font-mono text-xs bg-background">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {EVENT_TYPES.map((t) => (
                              <SelectItem key={t} value={t} className="font-mono text-xs">{t.replace(/_/g, " ")}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs font-mono uppercase text-muted-foreground">Event Time *</Label>
                        <Input
                          data-testid="input-event-time"
                          type="datetime-local"
                          value={eventTime}
                          onChange={(e) => setEventTime(e.target.value)}
                          className="font-mono text-xs bg-background"
                          required
                        />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs font-mono uppercase text-muted-foreground">Source *</Label>
                        <Input
                          data-testid="input-source"
                          value={source}
                          onChange={(e) => setSource(e.target.value)}
                          className="font-mono text-xs bg-background"
                          placeholder="MANUAL / ACARS / FR24 / ATC"
                          required
                        />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs font-mono uppercase text-muted-foreground">Operator</Label>
                        <Input
                          data-testid="input-operator"
                          value={operator}
                          onChange={(e) => setOperator(e.target.value)}
                          className="font-mono text-xs bg-background"
                          placeholder="Ops Controller Name"
                        />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs font-mono uppercase text-muted-foreground">Reason / Comment *</Label>
                        <Textarea
                          data-testid="textarea-reason"
                          value={reason}
                          onChange={(e) => setReason(e.target.value)}
                          className="font-mono text-xs bg-background min-h-[80px]"
                          placeholder="Required: describe the reason for this event..."
                          required
                        />
                      </div>
                      <Button
                        type="submit"
                        className="w-full font-mono text-xs"
                        disabled={addEventMutation.isPending || !reason.trim()}
                        data-testid="button-submit-event"
                      >
                        {addEventMutation.isPending ? "Adding..." : "Record Event"}
                      </Button>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent className="px-4 pb-4">
              {eventsQuery.isLoading ? (
                <div className="space-y-3">
                  {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-16" />)}
                </div>
              ) : events.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground text-sm font-mono">No events recorded</div>
              ) : (
                <div className="relative">
                  <div className="absolute left-2.5 top-0 bottom-0 w-px bg-border/60" />
                  <div className="space-y-0">
                    {[...events].sort((a, b) => new Date(b.eventTime).getTime() - new Date(a.eventTime).getTime()).map((event: FlightEvent) => (
                      <div key={event.id} data-testid={`event-${event.id}`} className="relative pl-8 pb-4">
                        <div className="absolute left-0 top-1.5 w-5 h-5 rounded-full bg-card border-2 border-primary/40 flex items-center justify-center">
                          <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                        </div>
                        <div className="bg-secondary/30 rounded-lg p-3 border border-border/30">
                          <div className="flex items-center gap-2 flex-wrap mb-1">
                            <Badge variant="outline" className={`text-[10px] uppercase font-mono px-1.5 py-0 ${STATUS_COLORS[event.eventType] ?? "bg-slate-500/20 text-slate-300 border-slate-500/30"}`}>
                              {event.eventType.replace(/_/g, " ")}
                            </Badge>
                            <span className="text-[10px] font-mono text-muted-foreground">{formatDateTime(event.eventTime)}</span>
                            <span className="text-[10px] font-mono bg-background px-1.5 py-0.5 rounded border border-border/40">{event.source}</span>
                            {event.operator && (
                              <span className="text-[10px] font-mono text-muted-foreground">· {event.operator}</span>
                            )}
                          </div>
                          {event.reason && (
                            <p className="text-xs text-foreground/80 font-mono">{event.reason}</p>
                          )}
                          <PayloadPanel payload={event.payload as Record<string, unknown> | null | undefined} />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      <LinkedCharges movementId={params.id!} />
    </div>
  );
}

function LinkedCharges({ movementId }: { movementId: string }) {
  const role = useRole();
  const canSeeBilling = atLeast(role, "finance");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const chargesQuery = useQuery({
    queryKey: ["billing", "movement-charges", movementId],
    queryFn: () => apiGet<BillableCharge[]>(`/billing/movements/${movementId}/charges`),
    enabled: canSeeBilling,
  });

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["billing", "movement-charges", movementId] });
    queryClient.invalidateQueries({ queryKey: ["billing"] });
  };

  const rate = useMutation({
    mutationFn: () => apiSend<BillableCharge>(`/billing/rate-movement/${movementId}`, "POST", {}),
    onSuccess: () => { toast({ title: "Charge rated", description: "Landing charge generated for this movement." }); invalidate(); },
    onError: (e: Error) => toast({ title: "Rating failed", description: e.message, variant: "destructive" }),
  });

  const action = useMutation({
    mutationFn: ({ id, kind, reason }: { id: string; kind: string; reason?: string }) =>
      apiSend<BillableCharge>(`/billing/charges/${id}/${kind}`, "POST", reason ? { reason } : {}),
    onSuccess: () => { toast({ title: "Charge updated" }); invalidate(); },
    onError: (e: Error) => toast({ title: "Action failed", description: e.message, variant: "destructive" }),
  });

  if (!canSeeBilling) return null;

  const charges = chargesQuery.data ?? [];

  return (
    <Card className="bg-card border-card-border">
      <CardHeader className="pb-2 pt-4 px-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-xs font-mono uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
            <Banknote className="h-3.5 w-3.5" /> Linked Charges ({charges.length})
          </CardTitle>
          {charges.length === 0 && (
            <Button size="sm" variant="outline" className="h-7 text-xs font-mono gap-1"
              disabled={rate.isPending} onClick={() => rate.mutate()}>
              <RefreshCw className={`h-3.5 w-3.5 ${rate.isPending ? "animate-spin" : ""}`} />
              Rate movement
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="px-4 pb-4">
        {chargesQuery.isLoading ? (
          <Skeleton className="h-16" />
        ) : charges.length === 0 ? (
          <p className="text-xs font-mono text-muted-foreground py-3">No charges generated for this movement yet.</p>
        ) : (
          <div className="space-y-2">
            {charges.map((c) => (
              <div key={c.id} className="flex items-center justify-between gap-3 rounded-lg border border-border p-3">
                <div className="min-w-0">
                  <div className="text-sm text-foreground truncate">{c.description}</div>
                  <div className="mt-1 flex items-center gap-2">
                    <Badge variant="outline" className={`font-mono text-[10px] ${CHARGE_STATUS_STYLE[c.status] ?? ""}`}>{c.status}</Badge>
                    {c.alertLevel !== "green" && (
                      <Badge variant="outline" className={`font-mono text-[10px] ${ALERT_LEVEL_STYLE[c.alertLevel] ?? ""}`}>{c.alertLevel}</Badge>
                    )}
                    <span className="font-mono text-sm text-foreground">{formatCAD(c.amount, c.currency)}</span>
                  </div>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  {c.status !== "held" && c.status !== "invoiced" && (
                    <Button size="icon" variant="ghost" className="h-7 w-7" title="Hold"
                      disabled={action.isPending}
                      onClick={() => action.mutate({ id: c.id, kind: "hold", reason: "Held from flight detail" })}>
                      <Pause className="h-3.5 w-3.5" />
                    </Button>
                  )}
                  {c.status !== "discarded" && c.status !== "invoiced" && (
                    <Button size="icon" variant="ghost" className="h-7 w-7 text-red-400" title="Discard"
                      disabled={action.isPending}
                      onClick={() => action.mutate({ id: c.id, kind: "discard", reason: "Discarded from flight detail" })}>
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  )}
                </div>
              </div>
            ))}
            <Link href="/billing/charges" className="inline-block text-[11px] font-mono text-primary hover:underline mt-1">
              Open billing charges →
            </Link>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
