import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import {
  Network,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  RefreshCw,
  ExternalLink,
  ChevronDown,
  ChevronRight,
  Info,
  ArrowRight,
  Radar,
  Plane,
  Shield,
  Eye,
  EyeOff,
  Lock,
  KeyRound,
  Wifi,
  WifiOff,
  Activity,
  Clock,
} from "lucide-react";

// ── Constants ──────────────────────────────────────────────────────────────

const YLW_ARRIVALS_EXAMPLE_URL =
  "https://kelprodylwfast01.blob.core.windows.net/$web/ylw/flights/arrivals.json";
const ADSBX_GLOBE_CYLW = "https://globe.adsbexchange.com/?airport=cylw";
const ADSBX_API_TEMPLATE =
  "GET https://adsbexchange-com1.p.rapidapi.com/v2/lat/{lat}/lon/{lon}/dist/{radius}/";

// ── Field mapping reference ────────────────────────────────────────────────

type MappingRow = {
  feedField: string;
  canonicalField: string | null;
  transformation: string;
  notes: string;
  required: boolean;
};

const FIELD_MAPPINGS: MappingRow[] = [
  { feedField: "AirlineCode", canonicalField: "airlineIata", transformation: "Direct copy", notes: "IATA 2-letter airline code (WS, AC, 8P).", required: true },
  { feedField: "FlightNumber", canonicalField: "flightNumber", transformation: 'AirlineCode + FlightNumber → "WS525"', notes: "Concatenate airline code with numeric flight number to form IATA flight ID.", required: true },
  { feedField: "ArrivalOrDeparture", canonicalField: "direction", transformation: '"Arrivals" → "ARR", "Departures" → "DEP"', notes: "Normalised to 3-letter canonical direction code.", required: true },
  { feedField: "HostAirportCode", canonicalField: "origin / destination", transformation: "ARR → destination; DEP → origin", notes: "Combined with ViaAirportCode to build the full route.", required: true },
  { feedField: "ViaAirportCode", canonicalField: "origin / destination", transformation: "ARR → origin; DEP → destination", notes: "The remote airport.", required: true },
  { feedField: "ScheduleTime", canonicalField: "scheduledTime", transformation: "ISO 8601 datetime (with TZ) → stored as-is", notes: "UTC-normalised on write.", required: true },
  { feedField: "EstimatedTime", canonicalField: "estimatedTime", transformation: "ISO 8601 datetime → delayMinutes computed", notes: "When > ScheduleTime, delayMinutes is set.", required: false },
  { feedField: "Status", canonicalField: "status", transformation: "See Status Mapping tab", notes: "Human-readable status mapped to canonical enum.", required: true },
  { feedField: "StatusRaw", canonicalField: "(event payload)", transformation: "Stored in flight_event.payload.statusRaw", notes: "Not projected — preserved in immutable log only.", required: false },
  { feedField: "TailNumber", canonicalField: "tailNumber", transformation: "Empty string → null; non-empty stored as-is", notes: "Cross-referenced against aircraft_registry for MTOW.", required: false },
  { feedField: "HostAirportCity", canonicalField: "(not mapped)", transformation: "Discarded", notes: "Redundant with HostAirportCode in AODB context.", required: false },
  { feedField: "ViaAirportCity", canonicalField: "(not mapped)", transformation: "Discarded", notes: "Informational only.", required: false },
];

const STATUS_MAPPINGS = [
  { feed: "ON TIME", canonical: "SCHEDULED", notes: "Before departure/arrival window" },
  { feed: "ON TIME", canonical: "ESTIMATED", notes: "EstimatedTime equals ScheduleTime" },
  { feed: "DELAYED", canonical: "ESTIMATED", notes: "EstimatedTime set later than ScheduleTime" },
  { feed: "IN FLIGHT", canonical: "AIRBORNE", notes: "FR24 overrides with precise position" },
  { feed: "LANDED", canonical: "LANDED", notes: "Touchdown confirmed via feed" },
  { feed: "ON BLOCK", canonical: "ON_BLOCK", notes: "Parked at gate" },
  { feed: "DEPARTED", canonical: "DEPARTED", notes: "Wheels-up confirmed" },
  { feed: "BOARDING", canonical: "SCHEDULED", notes: '"BOARDING" preserved in event payload' },
  { feed: "CANCELLED", canonical: "CANCELLED", notes: "Flight cancelled" },
  { feed: "DIVERTED", canonical: "DIVERTED", notes: "FR24 provides actual divert destination" },
];

// ── Helpers ────────────────────────────────────────────────────────────────

function conf(n: number): string {
  if (n >= 90) return "text-emerald-400";
  if (n >= 75) return "text-sky-400";
  if (n >= 60) return "text-amber-400";
  return "text-red-400";
}

function ConfBar({ value }: { value: number }) {
  return (
    <div className="flex items-center gap-1.5">
      <div className="w-16 h-1 bg-secondary rounded-full overflow-hidden">
        <div
          className={`h-full rounded-full ${value >= 90 ? "bg-emerald-400" : value >= 75 ? "bg-sky-400" : value >= 60 ? "bg-amber-400" : "bg-red-400"}`}
          style={{ width: `${value}%` }}
        />
      </div>
      <span className={`text-[10px] font-mono ${conf(value)}`}>{value}%</span>
    </div>
  );
}

function ConflictBadge({ conflict }: { conflict: string }) {
  const labels: Record<string, { label: string; color: string }> = {
    TAIL_MISMATCH: { label: "Tail Mismatch", color: "bg-red-500/20 text-red-300 border-red-500/20" },
    TYPE_MISMATCH: { label: "Type Mismatch", color: "bg-orange-500/20 text-orange-300 border-orange-500/20" },
    FR24_MISSING_ADSBX_PRESENT: { label: "FR24 Missing / ADSBX Present", color: "bg-amber-500/20 text-amber-300 border-amber-500/20" },
    NO_MOVEMENT_DATA: { label: "No Movement Data", color: "bg-red-500/20 text-red-300 border-red-500/20" },
    LARGE_DELAY_UNCONFIRMED: { label: "Large Delay Unconfirmed", color: "bg-orange-500/20 text-orange-300 border-orange-500/20" },
  };
  const cfg = labels[conflict] ?? { label: conflict, color: "bg-slate-500/20 text-slate-300 border-slate-500/20" };
  return (
    <Badge variant="outline" className={`text-[9px] font-mono uppercase px-1 py-0 ${cfg.color}`}>
      {cfg.label}
    </Badge>
  );
}

type SourceRow = {
  source: string;
  value: string | null;
  confidence: number;
  note?: string;
};

const SOURCE_LABELS: Record<string, { label: string; color: string }> = {
  AIRPORT_FEED: { label: "Airport Feed", color: "bg-sky-500/20 text-sky-300 border-sky-500/20" },
  FR24: { label: "FR24", color: "bg-violet-500/20 text-violet-300 border-violet-500/20" },
  ADSBX: { label: "ADS-B Exchange", color: "bg-emerald-500/20 text-emerald-300 border-emerald-500/20" },
  CIRIUM: { label: "Cirium", color: "bg-amber-500/20 text-amber-300 border-amber-500/20" },
};

function SourceBadge({ source }: { source: string }) {
  const cfg = SOURCE_LABELS[source] ?? { label: source, color: "bg-slate-500/20 text-slate-300 border-slate-500/20" };
  return <Badge variant="outline" className={`text-[9px] font-mono uppercase px-1.5 py-0 ${cfg.color}`}>{cfg.label}</Badge>;
}

// ── Source comparison row expand ───────────────────────────────────────────

function ComparisonRowExpand({ flightId }: { flightId: string }) {
  const { data, isLoading } = useQuery({
    queryKey: ["source-values", flightId],
    queryFn: async () => {
      const res = await fetch(`/api/sources/${flightId}/source-values`);
      return res.json() as Promise<{
        fields: Array<{ field: string; label: string; sources: SourceRow[]; winner: string; winnerReason: string }>;
      }>;
    },
    staleTime: 60_000,
  });

  if (isLoading) return <div className="px-4 py-3"><Skeleton className="h-24" /></div>;
  if (!data) return null;

  return (
    <div className="px-4 py-3 bg-background/60 border-t border-border/40">
      <div className="text-[10px] font-mono uppercase text-muted-foreground mb-2 tracking-wider">Per-field source values</div>
      <div className="overflow-x-auto">
        <table className="w-full text-[10px] font-mono">
          <thead>
            <tr className="border-b border-border/30">
              <th className="px-2 py-1 text-left text-muted-foreground uppercase tracking-wider">Field</th>
              {["Airport Feed", "FR24", "ADS-B Exchange", "Cirium"].map((s) => (
                <th key={s} className="px-2 py-1 text-left text-muted-foreground uppercase tracking-wider">{s}</th>
              ))}
              <th className="px-2 py-1 text-left text-muted-foreground uppercase tracking-wider">Winner</th>
            </tr>
          </thead>
          <tbody>
            {data.fields.map((f) => (
              <tr key={f.field} className="border-b border-border/20">
                <td className="px-2 py-1.5 text-foreground/80 font-bold">{f.label}</td>
                {(["AIRPORT_FEED", "FR24", "ADSBX", "CIRIUM"] as const).map((src) => {
                  const sv = f.sources.find((s) => s.source === src);
                  return (
                    <td key={src} className="px-2 py-1.5">
                      {sv ? (
                        sv.value ? (
                          <div>
                            <span className="text-foreground">{sv.value}</span>
                            <ConfBar value={sv.confidence} />
                            {sv.note && <div className="text-muted-foreground/60 text-[9px] mt-0.5 max-w-28">{sv.note}</div>}
                          </div>
                        ) : (
                          <span className="text-muted-foreground/50 italic">—</span>
                        )
                      ) : (
                        <span className="text-muted-foreground/40">N/A</span>
                      )}
                    </td>
                  );
                })}
                <td className="px-2 py-1.5">
                  <SourceBadge source={f.winner} />
                  <div className="text-muted-foreground/60 text-[9px] mt-0.5 max-w-32">{f.winnerReason}</div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ── Main Page ──────────────────────────────────────────────────────────────

export default function DataSources() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Feed inspection state (Field Mapping tab)
  const [arrivalsUrl, setArrivalsUrl] = useState("");
  const [feedRecords, setFeedRecords] = useState<Record<string, unknown>[] | null>(null);
  const [fetchedUrl, setFetchedUrl] = useState("");
  const [feedLoading, setFeedLoading] = useState(false);
  const [feedError, setFeedError] = useState<string | null>(null);
  const [fetchedAt, setFetchedAt] = useState<string | null>(null);
  const [expandedRaw, setExpandedRaw] = useState(false);

  // ADS-B Exchange config state
  const [adsbApiKey, setAdsbApiKey] = useState("");
  const [adsbApiKeySaved, setAdsbApiKeySaved] = useState(false);
  const [adsbProvider, setAdsbProvider] = useState("adsbexchange");
  const [adsbIcao, setAdsbIcao] = useState("CYLW");
  const [adsbLat, setAdsbLat] = useState("49.9561");
  const [adsbLon, setAdsbLon] = useState("-119.3778");
  const [adsbRadius, setAdsbRadius] = useState("25");
  const [adsbPolling, setAdsbPolling] = useState("60");
  const [adsbTestResult, setAdsbTestResult] = useState<{ success: boolean; mode: string; message: string; hint?: string; aircraftCount?: number } | null>(null);
  const [adsbSyncResult, setAdsbSyncResult] = useState<{ mode: string; syncId?: string; aircraftObserved?: number; matched?: number; unmatched?: number; message: string } | null>(null);

  // Comparison row expand
  const [expandedFlightId, setExpandedFlightId] = useState<string | null>(null);

  // FR24 Live config state
  const [fr24ApiKey, setFr24ApiKey] = useState("");
  const [fr24KeySaved, setFr24KeySaved] = useState(false);
  const [fr24KeyDialogOpen, setFr24KeyDialogOpen] = useState(false);
  const [fr24DialogKey, setFr24DialogKey] = useState("");
  const [fr24DialogShowKey, setFr24DialogShowKey] = useState(false);
  const [fr24TestResult, setFr24TestResult] = useState<{ success: boolean; mode: string; message: string; hint?: string; aircraftCount?: number } | null>(null);
  const [fr24SyncResult, setFr24SyncResult] = useState<{ mode: string; message: string; details?: string[]; eventsGenerated?: number; aircraftInResponse?: number } | null>(null);

  // FR24 config overrides (shown in form)
  const [fr24Polling, setFr24Polling] = useState("60");
  const [fr24HoursStart, setFr24HoursStart] = useState("06:00");
  const [fr24HoursEnd, setFr24HoursEnd] = useState("23:00");
  const [fr24Radius, setFr24Radius] = useState("50");

  // FR24 status query
  const fr24StatusQ = useQuery({
    queryKey: ["fr24-status"],
    queryFn: async () => {
      const res = await fetch("/api/sources/fr24/status");
      return res.json() as Promise<{
        configured: boolean;
        connectionStatus: "demo" | "configured" | "live" | "failed";
        lastSyncAt: string | null;
        lastSyncStatus: string | null;
        lastSyncCount: number | null;
        airportIata: string;
        airportIcao: string;
        pollingIntervalSeconds: number;
        operatingHoursStart: string;
        operatingHoursEnd: string;
        radiusNm: number;
      }>;
    },
    staleTime: 10_000,
    refetchInterval: 30_000,
  });

  const fr24ConfigMutation = useMutation({
    mutationFn: async (payload: { apiKey?: string; pollingIntervalSeconds?: number; operatingHoursStart?: string; operatingHoursEnd?: string; radiusNm?: number }) => {
      const res = await fetch("/api/sources/fr24/configure", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error(await res.text());
      return res.json() as Promise<{ saved: boolean; configured: boolean; connectionStatus: string }>;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["fr24-status"] });
      if (data.configured) setFr24KeySaved(true);
      toast({ title: "FR24 settings saved", description: data.configured ? "API key stored securely." : "Settings updated." });
    },
    onError: (err) => {
      toast({ title: "Save failed", description: err instanceof Error ? err.message : "Unknown error", variant: "destructive" });
    },
  });

  const fr24TestMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/sources/fr24/test-connection", { method: "POST" });
      return res.json() as Promise<{ success: boolean; mode: string; message: string; hint?: string; aircraftCount?: number }>;
    },
    onSuccess: (data) => {
      setFr24TestResult(data);
      queryClient.invalidateQueries({ queryKey: ["fr24-status"] });
    },
  });

  const fr24SyncMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/sources/fr24/sync", { method: "POST" });
      if (!res.ok) throw new Error(await res.text());
      return res.json() as Promise<{ mode: string; message: string; details?: string[]; eventsGenerated?: number; aircraftInResponse?: number }>;
    },
    onSuccess: (data) => {
      setFr24SyncResult(data);
      queryClient.invalidateQueries({ queryKey: ["fr24-status"] });
      queryClient.invalidateQueries({ queryKey: ["sources-comparison"] });
      toast({ title: "FR24 sync complete", description: data.message });
    },
    onError: (err) => {
      toast({ title: "Sync failed", description: err instanceof Error ? err.message : "Unknown error", variant: "destructive" });
    },
  });

  // Sync form state when FR24 status loads from server
  useEffect(() => {
    if (!fr24StatusQ.data) return;
    const d = fr24StatusQ.data;
    if (d.configured) setFr24KeySaved(true);
    setFr24Polling(String(d.pollingIntervalSeconds));
    setFr24HoursStart(d.operatingHoursStart);
    setFr24HoursEnd(d.operatingHoursEnd);
    setFr24Radius(String(d.radiusNm));
  }, [fr24StatusQ.data]);

  function handleSaveFr24() {
    const payload: Parameters<typeof fr24ConfigMutation.mutate>[0] = {
      pollingIntervalSeconds: parseInt(fr24Polling, 10),
      operatingHoursStart: fr24HoursStart,
      operatingHoursEnd: fr24HoursEnd,
      radiusNm: parseInt(fr24Radius, 10),
    };
    if (fr24ApiKey) payload.apiKey = fr24ApiKey;
    fr24ConfigMutation.mutate(payload);
    if (fr24ApiKey) { setFr24ApiKey(""); setFr24KeySaved(true); }
  }

  const fr24Status = fr24StatusQ.data;
  const connStatus = fr24Status?.connectionStatus ?? "demo";

  // Data queries
  const comparisonQ = useQuery({
    queryKey: ["sources-comparison"],
    queryFn: async () => {
      const res = await fetch("/api/sources/comparison");
      return res.json() as Promise<{
        summary: {
          totalFlights: number; fr24Coverage: number; adsbCoverage: number; bothCoverage: number;
          fr24MatchRate: number; adsbMatchRate: number; fr24AdsbAgreementRate: number; conflictCount: number; ciriumCoverage: number;
        };
        flights: Array<{
          flightId: string; flightNumber: string; direction: string; airline: string; airlineIata: string;
          origin: string; destination: string; status: string; delayMinutes: number | null;
          overallConfidence: number; conflicts: string[];
          sources: {
            feed: { status: string; confidence: number };
            fr24: { tailNumber: string | null; aircraftType: string | null; actualTime: string | null; confidence: number } | null;
            adsbx: { hex: string; callsign: string; registration: string | null; aircraftType: string | null; altBaro: number; groundSpeed: number; distanceFromAirportNm: number; lastSeen: string; inferredStatus: string; confidence: number } | null;
            cirium: { scheduledTime: string; confidence: number };
          };
        }>;
      }>;
    },
    staleTime: 30_000,
  });

  const reliabilityQ = useQuery({
    queryKey: ["sources-reliability"],
    queryFn: async () => {
      const res = await fetch("/api/sources/reliability");
      return res.json() as Promise<{
        overall: {
          totalFlights: number; fr24MatchCount: number; adsbxMatchCount: number; bothMatchCount: number;
          fr24MatchRate: number; adsbxMatchRate: number; fr24AdsbxAgreementRate: number;
          unmatchedAdsbxAircraft: number; ciriumCoverage: number;
        };
        byAirline: Array<{ airline: string; total: number; fr24: number; adsbx: number; both: number; avgConfidence: number }>;
      }>;
    },
    staleTime: 30_000,
  });

  // ADS-B status query
  const adsbStatusQ = useQuery({
    queryKey: ["adsb-status"],
    queryFn: async () => {
      const res = await fetch("/api/sources/adsb/status");
      return res.json() as Promise<{
        configured: boolean; keySource: "db" | "env" | "none";
        provider: string; connectionStatus: "demo" | "configured" | "live" | "failed";
        lastSyncAt: string | null; lastSyncStatus: string | null; lastSyncCount: number | null;
        airportIata: string; airportIcao: string;
        lat: number; lon: number; radiusNm: number; pollingIntervalSeconds: number;
        globeUrl: string; productionApiTemplate: string;
      }>;
    },
    staleTime: 10_000,
    refetchInterval: 30_000,
  });

  // Sync ADS-B form state from server
  useEffect(() => {
    if (!adsbStatusQ.data) return;
    const d = adsbStatusQ.data;
    setAdsbIcao(d.airportIcao);
    setAdsbLat(String(d.lat));
    setAdsbLon(String(d.lon));
    setAdsbRadius(String(d.radiusNm));
    setAdsbPolling(String(d.pollingIntervalSeconds));
    setAdsbProvider(d.provider);
    if (d.configured) setAdsbApiKeySaved(true);
  }, [adsbStatusQ.data]);

  const adsbConfigMutation = useMutation({
    mutationFn: async (payload: { apiKey?: string; provider?: string; radiusNm?: number; lat?: string; lon?: string; pollingIntervalSeconds?: number }) => {
      const res = await fetch("/api/sources/adsb/configure", {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error(await res.text());
      return res.json() as Promise<{ saved: boolean; configured: boolean; connectionStatus: string }>;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["adsb-status"] });
      if (adsbApiKey) { setAdsbApiKey(""); setAdsbApiKeySaved(true); }
      toast({ title: "ADS-B settings saved", description: data.configured ? "API key stored securely." : "Settings updated." });
    },
  });

  const adsbTestMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/sources/adsb/test-connection", { method: "POST" });
      return res.json() as Promise<{ success: boolean; mode: string; message: string; hint?: string; aircraftCount?: number }>;
    },
    onSuccess: (data) => {
      setAdsbTestResult(data);
      queryClient.invalidateQueries({ queryKey: ["adsb-status"] });
    },
  });

  const adsbSyncMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/sources/adsb/sync", { method: "POST" });
      return res.json() as Promise<{ mode: string; syncId: string; aircraftObserved: number; matched: number; unmatched: number; message: string }>;
    },
    onSuccess: (data) => {
      setAdsbSyncResult(data);
      queryClient.invalidateQueries({ queryKey: ["adsb-nearby", "adsb-unmatched", "sources-comparison", "adsb-status"] });
      toast({ title: `ADS-B sync complete (${data.mode})`, description: `${data.aircraftObserved} observed · ${data.matched} matched · ${data.unmatched} unmatched` });
    },
  });

  const nearbyQ = useQuery({
    queryKey: ["adsb-nearby"],
    queryFn: async () => {
      const res = await fetch("/api/sources/adsb/aircraft-nearby?limit=50");
      return res.json() as Promise<{
        aircraft: Array<{
          id: number; icaoHex: string; callsign: string | null; registration: string | null; aircraftType: string | null;
          altBaro: number | null; groundSpeed: number | null; track: number | null;
          lat: number | null; lon: number | null; distanceNm: number | null;
          lastSeenTs: string | null; inferredStatus: string | null; source: string;
          matchType: string; matchScore: number;
          matchedFlightNumber: string | null; matchedFlightId: string | null; seenSecondsAgo: number | null;
        }>;
        total: number; airportIcao: string; airportLat: number; airportLon: number;
      }>;
    },
    staleTime: 30_000,
    enabled: false,
  });

  const adsbUnmatchedQ = useQuery({
    queryKey: ["adsb-unmatched"],
    queryFn: async () => {
      const res = await fetch("/api/sources/adsb/unmatched");
      return res.json() as Promise<{
        unmatched: Array<{ id: number; icaoHex: string; callsign: string | null; registration: string | null; aircraftType: string | null; altBaro: number | null; groundSpeed: number | null; distanceNm: number | null; inferredStatus: string | null; source: string; lastSeenTs: string | null; reviewReason: string }>;
        total: number;
      }>;
    },
    staleTime: 30_000,
    enabled: false,
  });

  const syncMutation = adsbSyncMutation;

  async function fetchFeed(url: string) {
    if (!url.trim()) return;
    setFeedLoading(true);
    setFeedError(null);
    setFeedRecords(null);
    try {
      const res = await fetch("/api/feed/inspect", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ url }) });
      const payload = await res.json() as { data?: unknown[]; error?: string; fetchedAt?: string };
      if (!res.ok || payload.error) throw new Error(payload.error ?? `HTTP ${res.status}`);
      const data = Array.isArray(payload.data) ? payload.data : [payload.data];
      setFeedRecords(data as Record<string, unknown>[]);
      setFetchedUrl(url);
      setFetchedAt(payload.fetchedAt ?? null);
      toast({ title: "Feed loaded", description: `${data.length} records fetched.` });
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Unknown error";
      setFeedError(msg);
    } finally {
      setFeedLoading(false);
    }
  }

  const summary = comparisonQ.data?.summary;
  const reliability = reliabilityQ.data?.overall;

  return (
    <div className="p-6 space-y-5 max-w-7xl">
      <div>
        <div className="flex items-center gap-2 mb-1">
          <Network className="h-5 w-5 text-primary" />
          <h1 className="text-2xl font-mono font-bold text-foreground">Data Sources</h1>
        </div>
        <p className="text-sm text-muted-foreground font-mono">Multi-Source Integration & Field Mapping (IT User)</p>
      </div>

      <Tabs defaultValue="fr24">
        <TabsList className="font-mono text-xs bg-secondary flex-wrap h-auto gap-1">
          <TabsTrigger value="fr24" className="gap-1.5">
            {connStatus === "live" ? <Wifi className="h-3 w-3 text-emerald-400" /> : connStatus === "failed" ? <WifiOff className="h-3 w-3 text-red-400" /> : <Activity className="h-3 w-3 text-muted-foreground" />}
            FR24 Live
          </TabsTrigger>
          <TabsTrigger value="sources">Sources Overview</TabsTrigger>
          <TabsTrigger value="adsbx">ADS-B Exchange</TabsTrigger>
          <TabsTrigger value="comparison">Source Comparison</TabsTrigger>
          <TabsTrigger value="reliability">Reliability Metrics</TabsTrigger>
          <TabsTrigger value="fieldmap">Field Mapping</TabsTrigger>
          <TabsTrigger value="status">Status Mapping</TabsTrigger>
        </TabsList>

        {/* ── TAB: FR24 LIVE SETUP ──────────────────────────────────────── */}
        <TabsContent value="fr24" className="mt-4 space-y-4">
          {/* Status banner */}
          {fr24StatusQ.isLoading ? (
            <Skeleton className="h-16" />
          ) : (
            <Card className={
              connStatus === "live" ? "bg-emerald-500/10 border-emerald-500/30" :
              connStatus === "failed" ? "bg-red-500/10 border-red-500/30" :
              connStatus === "configured" ? "bg-sky-500/10 border-sky-500/30" :
              "bg-slate-500/10 border-slate-500/20"
            }>
              <CardContent className="p-4 flex items-start gap-3">
                {connStatus === "live" ? <Wifi className="h-5 w-5 text-emerald-400 mt-0.5 shrink-0" /> :
                 connStatus === "failed" ? <WifiOff className="h-5 w-5 text-red-400 mt-0.5 shrink-0" /> :
                 connStatus === "configured" ? <CheckCircle2 className="h-5 w-5 text-sky-400 mt-0.5 shrink-0" /> :
                 <Activity className="h-5 w-5 text-muted-foreground mt-0.5 shrink-0" />}
                <div className="flex-1 min-w-0">
                  <div className={`font-mono text-sm font-bold mb-0.5 ${
                    connStatus === "live" ? "text-emerald-300" :
                    connStatus === "failed" ? "text-red-300" :
                    connStatus === "configured" ? "text-sky-300" :
                    "text-muted-foreground"
                  }`}>
                    {connStatus === "live" ? "FR24 Live Sync Active" :
                     connStatus === "failed" ? "FR24 Connection Failed" :
                     connStatus === "configured" ? "FR24 Configured — Not Yet Tested" :
                     "Demo Mode — FR24 Not Configured"}
                  </div>
                  <div className="font-mono text-[11px] text-muted-foreground">
                    {connStatus === "live" ? `Airport: ${fr24Status?.airportIcao} (${fr24Status?.airportIata}) · Last sync: ${fr24Status?.lastSyncAt ? new Date(fr24Status.lastSyncAt).toLocaleTimeString() : "—"} · ${fr24Status?.lastSyncCount ?? 0} flights updated` :
                     connStatus === "failed" ? "API key is set but connection failed. Check the key and retry Test Connection." :
                     connStatus === "configured" ? "API key saved. Click Test FR24 Connection to verify." :
                     "Running with simulated demo data. Paste your FR24 API key below to enable live mode."}
                  </div>
                  {fr24Status?.lastSyncAt && connStatus !== "demo" && (
                    <div className="flex items-center gap-1.5 mt-1 text-[10px] font-mono text-muted-foreground/60">
                      <Clock className="h-3 w-3" />
                      Last sync: {new Date(fr24Status.lastSyncAt).toLocaleString()} · Status: {fr24Status.lastSyncStatus ?? "—"} · {fr24Status.lastSyncCount ?? 0} flights
                    </div>
                  )}
                </div>
                <Badge variant="outline" className={`text-[9px] font-mono uppercase shrink-0 ${
                  connStatus === "live" ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/30" :
                  connStatus === "failed" ? "bg-red-500/20 text-red-300 border-red-500/30" :
                  connStatus === "configured" ? "bg-sky-500/20 text-sky-300 border-sky-500/30" :
                  "bg-slate-500/20 text-slate-400 border-slate-500/20"
                }`}>
                  {connStatus === "live" ? "Live" : connStatus === "failed" ? "Failed" : connStatus === "configured" ? "Configured" : "Demo"}
                </Badge>
              </CardContent>
            </Card>
          )}

          {/* Prominent Enter API Key button (popup trigger) */}
          <Card className={connStatus === "demo" ? "bg-sky-500/10 border-sky-500/40" : "bg-card border-card-border"}>
            <CardContent className="p-4 flex items-center gap-4 flex-wrap">
              <div className="flex items-center gap-3 flex-1 min-w-0">
                <div className={`h-10 w-10 rounded-md flex items-center justify-center shrink-0 ${connStatus === "demo" ? "bg-sky-500/20" : "bg-emerald-500/20"}`}>
                  <KeyRound className={`h-5 w-5 ${connStatus === "demo" ? "text-sky-300" : "text-emerald-300"}`} />
                </div>
                <div className="min-w-0">
                  <div className={`font-mono text-sm font-bold ${connStatus === "demo" ? "text-sky-200" : "text-emerald-200"}`}>
                    {connStatus === "demo" ? "Enter your FR24 API Key" : "FR24 API Key Stored"}
                  </div>
                  <div className="font-mono text-[11px] text-muted-foreground">
                    {connStatus === "demo"
                      ? "Open the secure popup to paste your Flightradar24 Bearer token. Stored encrypted server-side, never echoed back."
                      : "A key is on file. Use Replace Key to rotate it."}
                  </div>
                </div>
              </div>
              <Button
                data-testid="button-open-fr24-key-dialog"
                size="lg"
                className={connStatus === "demo" ? "bg-sky-500 hover:bg-sky-400 text-slate-950 font-mono font-bold" : "font-mono"}
                variant={connStatus === "demo" ? "default" : "outline"}
                onClick={() => { setFr24DialogKey(""); setFr24DialogShowKey(false); setFr24KeyDialogOpen(true); }}
              >
                <KeyRound className="h-4 w-4 mr-2" />
                {connStatus === "demo" ? "Enter API Key" : "Replace Key"}
              </Button>
            </CardContent>
          </Card>

          {/* Security warning */}
          <Card className="bg-amber-500/5 border-amber-500/30">
            <CardContent className="p-4 flex items-start gap-3">
              <Lock className="h-4 w-4 text-amber-400 mt-0.5 shrink-0" />
              <div className="font-mono text-[11px] text-amber-200/80 leading-relaxed">
                <strong className="text-amber-300">Security — Paste your API key only into the secure field above.</strong>{" "}
                Never share your FR24 API key in chat, email, or any unsecured channel. The key is stored server-side in the
                database and is never returned or shown after saving. If the key is compromised, revoke it in the FR24 portal immediately.
              </div>
            </CardContent>
          </Card>

          {/* Config + Actions */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Left: API key + settings */}
            <Card className="bg-card border-card-border">
              <CardHeader className="pb-2 pt-4 px-4">
                <CardTitle className="text-xs font-mono uppercase tracking-wider text-muted-foreground">FR24 API Configuration</CardTitle>
              </CardHeader>
              <CardContent className="px-4 pb-4 space-y-3">
                {/* API Key */}
                <div className="space-y-1">
                  <Label className="text-xs font-mono uppercase text-muted-foreground">API Key / Bearer Token</Label>
                  {fr24KeySaved ? (
                    <div className="flex items-center gap-2">
                      <div className="flex-1 bg-background border border-border rounded px-3 py-1.5 text-xs font-mono text-muted-foreground flex items-center gap-2">
                        <Lock className="h-3 w-3 text-emerald-400" />
                        ••••••••••••••••••••••••••••••••
                      </div>
                      <Button size="sm" variant="outline" className="h-7 text-xs font-mono" onClick={() => { setFr24KeySaved(false); setFr24ApiKey(""); }}>
                        Replace
                      </Button>
                    </div>
                  ) : (
                    <Input
                      data-testid="input-fr24-key"
                      type="password"
                      value={fr24ApiKey}
                      onChange={(e) => setFr24ApiKey(e.target.value)}
                      className="font-mono text-xs bg-background"
                      placeholder="Paste your FR24 API key here (secure field)"
                      autoComplete="off"
                    />
                  )}
                  <div className="text-[10px] font-mono text-muted-foreground/60">
                    {fr24KeySaved ? "Key is stored securely. Use Replace to update." : "Key is hidden as you type and will be masked after saving."}
                  </div>
                </div>

                {/* Airport */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <Label className="text-xs font-mono uppercase text-muted-foreground">Airport ICAO</Label>
                    <Input value={fr24Status?.airportIcao ?? "CYLW"} readOnly className="font-mono text-xs bg-background/50 text-muted-foreground" />
                    <div className="text-[9px] font-mono text-muted-foreground/50">Change in Settings</div>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs font-mono uppercase text-muted-foreground">Airport IATA</Label>
                    <Input value={fr24Status?.airportIata ?? "YLW"} readOnly className="font-mono text-xs bg-background/50 text-muted-foreground" />
                  </div>
                </div>

                {/* Polling + hours + radius */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <Label className="text-xs font-mono uppercase text-muted-foreground">Polling Interval (s)</Label>
                    <Input data-testid="input-fr24-polling" type="number" value={fr24Polling} onChange={(e) => setFr24Polling(e.target.value)} className="font-mono text-xs bg-background" min={10} max={3600} />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs font-mono uppercase text-muted-foreground">Search Radius (nm)</Label>
                    <Input data-testid="input-fr24-radius" type="number" value={fr24Radius} onChange={(e) => setFr24Radius(e.target.value)} className="font-mono text-xs bg-background" min={5} max={250} />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs font-mono uppercase text-muted-foreground">Ops Hours Start</Label>
                    <Input data-testid="input-fr24-hours-start" type="time" value={fr24HoursStart} onChange={(e) => setFr24HoursStart(e.target.value)} className="font-mono text-xs bg-background" />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs font-mono uppercase text-muted-foreground">Ops Hours End</Label>
                    <Input data-testid="input-fr24-hours-end" type="time" value={fr24HoursEnd} onChange={(e) => setFr24HoursEnd(e.target.value)} className="font-mono text-xs bg-background" />
                  </div>
                </div>

                <Button
                  className="w-full font-mono text-xs gap-1.5"
                  onClick={handleSaveFr24}
                  disabled={fr24ConfigMutation.isPending}
                  data-testid="button-fr24-save"
                >
                  {fr24ConfigMutation.isPending ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : <CheckCircle2 className="h-3.5 w-3.5" />}
                  Save FR24 Settings
                </Button>
              </CardContent>
            </Card>

            {/* Right: Actions + results */}
            <div className="space-y-4">
              <Card className="bg-card border-card-border">
                <CardHeader className="pb-2 pt-4 px-4">
                  <CardTitle className="text-xs font-mono uppercase tracking-wider text-muted-foreground">Actions</CardTitle>
                </CardHeader>
                <CardContent className="px-4 pb-4 space-y-3">
                  <div className="space-y-1">
                    <div className="text-[11px] font-mono text-muted-foreground">Test the stored API key against the FR24 live endpoint and verify airport access.</div>
                    <Button
                      className="w-full font-mono text-xs gap-1.5"
                      variant="outline"
                      onClick={() => fr24TestMutation.mutate()}
                      disabled={fr24TestMutation.isPending}
                      data-testid="button-fr24-test"
                    >
                      {fr24TestMutation.isPending ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : <Wifi className="h-3.5 w-3.5" />}
                      Test FR24 Connection
                    </Button>
                  </div>
                  <div className="border-t border-border/30 pt-3 space-y-1">
                    <div className="text-[11px] font-mono text-muted-foreground">Trigger a manual FR24 sync now. Enriches flight movements with live tail numbers, aircraft types, and actual timestamps.</div>
                    <Button
                      className="w-full font-mono text-xs gap-1.5"
                      onClick={() => fr24SyncMutation.mutate()}
                      disabled={fr24SyncMutation.isPending}
                      data-testid="button-fr24-sync"
                    >
                      {fr24SyncMutation.isPending ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : <RefreshCw className="h-3.5 w-3.5" />}
                      Manual FR24 Sync {!fr24Status?.configured && "(Demo)"}
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Test result */}
              {fr24TestResult && (
                <Card className={fr24TestResult.success ? "bg-emerald-500/5 border-emerald-500/20" : fr24TestResult.mode === "demo" ? "bg-slate-500/10 border-slate-500/20" : "bg-red-500/5 border-red-500/20"}>
                  <CardContent className="p-4 space-y-1.5">
                    <div className="flex items-center gap-2">
                      {fr24TestResult.success ? <CheckCircle2 className="h-4 w-4 text-emerald-400" /> : fr24TestResult.mode === "demo" ? <Activity className="h-4 w-4 text-muted-foreground" /> : <XCircle className="h-4 w-4 text-red-400" />}
                      <span className={`font-mono text-xs font-bold ${fr24TestResult.success ? "text-emerald-300" : fr24TestResult.mode === "demo" ? "text-muted-foreground" : "text-red-300"}`}>
                        {fr24TestResult.mode === "live" ? "FR24 Live Connection Successful" : fr24TestResult.mode === "failed" ? "FR24 Connection Failed" : "Demo Mode Active"}
                      </span>
                    </div>
                    <div className="font-mono text-[11px] text-muted-foreground">{fr24TestResult.message}</div>
                    {fr24TestResult.aircraftCount !== undefined && (
                      <div className="font-mono text-[11px] text-sky-400">{fr24TestResult.aircraftCount} aircraft near {fr24Status?.airportIcao} in live response</div>
                    )}
                    {fr24TestResult.hint && (
                      <div className="font-mono text-[10px] text-amber-400/80 border-t border-border/30 pt-1.5 mt-1">{fr24TestResult.hint}</div>
                    )}
                  </CardContent>
                </Card>
              )}

              {/* Sync result */}
              {fr24SyncResult && (
                <Card className={fr24SyncResult.mode === "live" ? "bg-emerald-500/5 border-emerald-500/20" : fr24SyncResult.mode === "failed" ? "bg-red-500/5 border-red-500/20" : "bg-slate-500/10 border-slate-500/20"}>
                  <CardContent className="p-4 space-y-1.5">
                    <div className="flex items-center gap-2">
                      {fr24SyncResult.mode === "live" ? <CheckCircle2 className="h-4 w-4 text-emerald-400" /> : fr24SyncResult.mode === "demo" ? <Activity className="h-4 w-4 text-muted-foreground" /> : <XCircle className="h-4 w-4 text-red-400" />}
                      <span className={`font-mono text-xs font-bold ${fr24SyncResult.mode === "live" ? "text-emerald-300" : fr24SyncResult.mode === "demo" ? "text-muted-foreground" : "text-red-300"}`}>
                        {fr24SyncResult.mode === "live" ? "Live Sync Complete" : fr24SyncResult.mode === "demo" ? "Demo Sync Complete" : "Sync Failed"}
                      </span>
                      {fr24SyncResult.mode !== "failed" && <Badge variant="outline" className="text-[9px] font-mono uppercase bg-slate-500/20 text-slate-400 border-slate-500/20 ml-auto">{fr24SyncResult.mode}</Badge>}
                    </div>
                    <div className="font-mono text-[11px] text-muted-foreground">{fr24SyncResult.message}</div>
                    {fr24SyncResult.details && fr24SyncResult.details.map((d, i) => (
                      <div key={i} className="font-mono text-[10px] text-muted-foreground/70">· {d}</div>
                    ))}
                    {fr24SyncResult.aircraftInResponse !== undefined && (
                      <div className="font-mono text-[11px] text-sky-400">{fr24SyncResult.aircraftInResponse} aircraft in FR24 response · {fr24SyncResult.eventsGenerated} AODB flights enriched</div>
                    )}
                  </CardContent>
                </Card>
              )}
            </div>
          </div>

          {/* FR24 priority fields + billing note */}
          <Card className="bg-violet-500/5 border-violet-500/20">
            <CardHeader className="pb-2 pt-4 px-4">
              <CardTitle className="text-xs font-mono uppercase tracking-wider text-violet-400">FR24 as Preferred Source — Day-of-Operations Actuals</CardTitle>
            </CardHeader>
            <CardContent className="px-4 pb-4 space-y-3">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <div className="text-[10px] font-mono text-muted-foreground uppercase tracking-wider mb-1">FR24 wins for these fields</div>
                  {[
                    { field: "actualTime (ATA/ATD)", note: "Wheels-on / wheels-off events — most precise" },
                    { field: "tailNumber", note: "ADS-B transponder registration" },
                    { field: "aircraftType", note: "Actual operated type (may differ from Cirium plan)" },
                    { field: "status (AIRBORNE/LANDED)", note: "Real-time status from ADS-B tracking" },
                    { field: "diversion confirmation", note: "FR24 provides actual divert destination" },
                    { field: "estimatedTime (ETA/ETD)", note: "ATC estimated based on live position" },
                  ].map((f) => (
                    <div key={f.field} className="flex items-start gap-2">
                      <CheckCircle2 className="h-3 w-3 text-violet-400 mt-0.5 shrink-0" />
                      <div>
                        <code className="text-[10px] font-mono text-violet-300">{f.field}</code>
                        <div className="text-[9px] font-mono text-muted-foreground/60">{f.note}</div>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="space-y-1.5">
                  <div className="text-[10px] font-mono text-muted-foreground uppercase tracking-wider mb-1">FR24 does NOT replace</div>
                  {[
                    { field: "scheduledTime (STA/STD)", note: "Cirium remains authoritative for planned schedule" },
                    { field: "code-share identity", note: "Cirium resolves marketed vs. operating carrier" },
                    { field: "passenger count", note: "Not available from ADS-B sources" },
                  ].map((f) => (
                    <div key={f.field} className="flex items-start gap-2">
                      <XCircle className="h-3 w-3 text-muted-foreground/50 mt-0.5 shrink-0" />
                      <div>
                        <code className="text-[10px] font-mono text-muted-foreground">{f.field}</code>
                        <div className="text-[9px] font-mono text-muted-foreground/60">{f.note}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="border-t border-violet-500/20 pt-3">
                <div className="flex items-start gap-2">
                  <AlertTriangle className="h-3.5 w-3.5 text-amber-400 mt-0.5 shrink-0" />
                  <div className="font-mono text-[11px] text-amber-200/80 leading-relaxed">
                    <strong className="text-amber-300">Billing actuals:</strong> For revenue-impacting billing calculations (landing fees, ground time, etc.), use FR24-confirmed actual times or manually verified ops records.
                    Cirium schedule times (STA/STD) alone are <em>not sufficient</em> as the basis for billing actuals — they represent planned schedule, not confirmed movement events.
                    When FR24 is unavailable, ADS-B Exchange can corroborate, but manually verify any discrepancy before billing issuance.
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* API docs */}
          <Card className="bg-card border-card-border">
            <CardHeader className="pb-2 pt-4 px-4">
              <CardTitle className="text-xs font-mono uppercase tracking-wider text-muted-foreground">FR24 API Endpoints</CardTitle>
            </CardHeader>
            <CardContent className="px-4 pb-4 space-y-2">
              {[
                { method: "GET", path: "/api/sources/fr24/status", note: "Returns connection status, last sync time, config summary. Never returns the API key." },
                { method: "POST", path: "/api/sources/fr24/configure", note: "Saves API key and settings. Body: { apiKey, pollingIntervalSeconds, operatingHoursStart, operatingHoursEnd, radiusNm }." },
                { method: "POST", path: "/api/sources/fr24/test-connection", note: "Tests the stored key against FR24 live endpoint. Returns mode: demo | live | failed." },
                { method: "POST", path: "/api/sources/fr24/sync", note: "Triggers manual sync. Uses live FR24 API if key present; demo simulation otherwise. Enriches tailNumber, aircraftType, actualTime." },
              ].map((ep) => (
                <div key={ep.path} className="flex gap-2 font-mono text-[11px]">
                  <Badge variant="outline" className={`shrink-0 text-[9px] uppercase px-1.5 py-0 ${ep.method === "GET" ? "bg-sky-500/20 text-sky-300 border-sky-500/30" : "bg-violet-500/20 text-violet-300 border-violet-500/30"}`}>{ep.method}</Badge>
                  <code className="text-emerald-400 shrink-0">{ep.path}</code>
                  <span className="text-muted-foreground/70">{ep.note}</span>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── TAB: SOURCES OVERVIEW ─────────────────────────────────────── */}
        <TabsContent value="sources" className="mt-4 space-y-4">
          {/* Architecture */}
          <Card className="bg-primary/5 border-primary/20">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <Info className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                <div>
                  <div className="font-mono text-xs font-bold text-foreground/90 mb-2">Multi-Source Data Flow</div>
                  <div className="flex flex-wrap items-center gap-2">
                    {[
                      { label: "Cirium", sub: "STA/STD schedule", color: "bg-amber-500/20 text-amber-300 border-amber-500/30" },
                      null,
                      { label: "Airport Feed", sub: "Status/ETA overlay", color: "bg-sky-500/20 text-sky-300 border-sky-500/30" },
                      null,
                      { label: "FR24 ADS-B", sub: "Actual movement", color: "bg-violet-500/20 text-violet-300 border-violet-500/30" },
                      null,
                      { label: "ADS-B Exchange", sub: "Secondary verify", color: "bg-emerald-500/20 text-emerald-300 border-emerald-500/30" },
                      null,
                      { label: "Manual Ops", sub: "Override", color: "bg-red-500/20 text-red-300 border-red-500/30" },
                      null,
                      { label: "flight_events", sub: "Immutable log", color: "bg-orange-500/20 text-orange-300 border-orange-500/30" },
                      null,
                      { label: "flight_movements", sub: "Current projection", color: "bg-primary/20 text-primary border-primary/30" },
                    ].map((item, i) =>
                      item === null ? (
                        <ArrowRight key={i} className="h-3.5 w-3.5 text-muted-foreground" />
                      ) : (
                        <div key={i} className={`px-2.5 py-1.5 rounded border font-mono ${item.color}`}>
                          <div className="text-[11px] font-bold">{item.label}</div>
                          <div className="text-[9px] opacity-70 mt-0.5">{item.sub}</div>
                        </div>
                      )
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Source Priority Rules */}
          <Card className="bg-card border-card-border">
            <CardHeader className="pb-2 pt-4 px-4">
              <CardTitle className="text-xs font-mono uppercase tracking-wider text-muted-foreground">Source Priority Rules (Per-Field)</CardTitle>
            </CardHeader>
            <CardContent className="px-0 pb-0">
              <div className="overflow-x-auto">
                <table className="w-full text-xs font-mono">
                  <thead>
                    <tr className="border-b border-border text-muted-foreground">
                      {["Field", "Priority 1 (Winner)", "Priority 2", "Priority 3", "Priority 4", "Override"].map((h) => (
                        <th key={h} className="px-3 py-2 text-left uppercase tracking-wider text-[10px] whitespace-nowrap">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      { field: "STA / STD", p1: "CIRIUM", p2: "AIRPORT_FEED", p3: "FR24", p4: "—", override: "MANUAL" },
                      { field: "ETA / ETD", p1: "FR24", p2: "AIRPORT_FEED", p3: "CIRIUM", p4: "—", override: "MANUAL" },
                      { field: "ATA / ATD", p1: "FR24", p2: "ADSBX", p3: "AIRPORT_FEED", p4: "—", override: "MANUAL" },
                      { field: "Tail / Registration", p1: "FR24", p2: "ADSBX", p3: "—", p4: "—", override: "MANUAL" },
                      { field: "Aircraft Type", p1: "FR24", p2: "ADSBX", p3: "CIRIUM", p4: "—", override: "MANUAL" },
                      { field: "Flight Status", p1: "FR24", p2: "ADSBX", p3: "AIRPORT_FEED", p4: "CIRIUM", override: "MANUAL" },
                      { field: "ICAO Hex / Callsign", p1: "ADSBX", p2: "FR24", p3: "—", p4: "—", override: "MANUAL" },
                      { field: "Position / Altitude", p1: "ADSBX", p2: "FR24", p3: "—", p4: "—", override: "—" },
                    ].map((row) => (
                      <tr key={row.field} className="border-b border-border/40">
                        <td className="px-3 py-2 font-bold text-foreground">{row.field}</td>
                        {[row.p1, row.p2, row.p3, row.p4].map((src, i) => (
                          <td key={i} className="px-3 py-2">
                            {src !== "—" ? <SourceBadge source={src} /> : <span className="text-muted-foreground/40">—</span>}
                          </td>
                        ))}
                        <td className="px-3 py-2">
                          {row.override !== "—" ? (
                            <Badge variant="outline" className="text-[9px] font-mono bg-red-500/20 text-red-300 border-red-500/20 uppercase px-1.5 py-0">
                              {row.override}
                            </Badge>
                          ) : <span className="text-muted-foreground/40">—</span>}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>

          {/* 4 Source Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              {
                icon: <Plane className="h-4 w-4 text-amber-400" />,
                label: "Cirium",
                role: "Future Commercial Schedules",
                roleCls: "bg-amber-500/20 text-amber-300 border-amber-500/20",
                badge: { text: "Not Configured", cls: "bg-slate-500/20 text-slate-400 border-slate-500/20" },
                purpose: "Authoritative source for upcoming commercial flight schedules. Pulls STA/STD, airline, route, equipment, code-share relationships, and estimated/cancelled status. Polled every 10 minutes for the next 48 hours — commercial airline/cargo/charter only.",
                fields: ["flightNumber (IATA)", "scheduledTime (STA/STD)", "estimatedTime + cancelledStatus", "operatingCarrier / marketingCarrier", "Planned aircraftType (equipment)"],
                note: "Cirium role in Commercial MVP: build the future schedule. FR24 then confirms which flights actually operated. Requires Cirium FlightStatus or FlightInfoStatus API subscription.",
              },
              {
                icon: <Radar className="h-4 w-4 text-violet-400" />,
                label: "Flightradar24 (FR24)",
                role: "Live Day-of-Operations Actuals",
                roleCls: "bg-violet-500/20 text-violet-300 border-violet-500/20",
                badge: { text: "Not Configured", cls: "bg-slate-500/20 text-slate-400 border-slate-500/20" },
                purpose: "Primary source for live commercial movement truth. Matches aircraft to the Cirium commercial schedule by flight number, airline IATA, route, and ±2h time window. Non-commercial callsigns are excluded from the main board.",
                fields: ["actualDeparture (ATD) · wheels-off", "actualArrival (ATA) · wheels-on/landing", "tailNumber / registration", "aircraftType (actual operated)", "diversionConfirmed"],
                note: "FR24 role in Commercial MVP: confirm actual operations. Overrides feed status for all commercial movement events. Requires FR24 Business/Commercial API.",
              },
              {
                icon: <Eye className="h-4 w-4 text-emerald-400" />,
                label: "ADS-B Exchange",
                role: "Secondary Verification Only",
                roleCls: "bg-emerald-500/20 text-emerald-300 border-emerald-500/20",
                badge: { text: "Not Configured", cls: "bg-slate-500/20 text-slate-400 border-slate-500/20" },
                purpose: "Corroborates FR24 actuals for commercial flights already in the Cirium schedule. Does NOT create main board records from unmatched aircraft. GA, private, training, military, and helicopter transponders go to the ADS-B Review Queue only — not the ops board.",
                fields: ["ICAO hex (Mode S) · callsign", "Registration · aircraftType", "Alt, GS, track (live telemetry)", "Inferred status from trajectory", "matchType: exact / probable / possible / unmatched"],
                note: "ADS-B role in Commercial MVP: verify, not originate. Unmatched ADS-B aircraft appear in the Review Queue. Human promotion required to add them to the main board.",
              },
              {
                icon: <Network className="h-4 w-4 text-sky-400" />,
                label: "Airport JSON Feed",
                role: "Phase 2 — Status/ETA Overlay",
                roleCls: "bg-slate-500/20 text-slate-400 border-slate-500/20",
                badge: { text: "Future Phase", cls: "bg-slate-500/20 text-slate-400 border-slate-500/20" },
                purpose: "Passenger-facing status and estimated times from the airport ops system, overlaid on the commercial schedule. Allocation fields (stand, gate, belt) are excluded from the Commercial AODB MVP.",
                fields: ["scheduledTime / estimatedTime (display)", "Passenger status (Status field)", "TailNumber (when available)"],
                note: "Phase 2: Status and ETA overlay will be activated once the airport feed is configured. Stand, gate, and belt allocation are not carried in the Commercial AODB.",
              },
            ].map((src) => (
              <Card key={src.label} className="bg-card border-card-border">
                <CardHeader className="pb-2 pt-4 px-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {src.icon}
                      <CardTitle className="text-sm font-mono font-bold text-foreground">{src.label}</CardTitle>
                    </div>
                    <Badge variant="outline" className={`text-[10px] font-mono uppercase ${src.badge.cls}`}>{src.badge.text}</Badge>
                  </div>
                  <Badge variant="outline" className={`text-[10px] font-mono mt-1.5 w-fit ${src.roleCls}`}>{src.role}</Badge>
                </CardHeader>
                <CardContent className="px-4 pb-4 space-y-2">
                  <p className="text-[11px] font-mono text-muted-foreground leading-relaxed">{src.purpose}</p>
                  <div className="flex flex-wrap gap-1">
                    {src.fields.map((f) => (
                      <code key={f} className="text-[9px] font-mono bg-secondary px-1.5 py-0.5 rounded text-muted-foreground">{f}</code>
                    ))}
                  </div>
                  <div className="text-[10px] font-mono text-muted-foreground/60 border-t border-border/30 pt-2 mt-2">{src.note}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* ── TAB: ADS-B EXCHANGE ───────────────────────────────────────── */}
        <TabsContent value="adsbx" className="mt-4 space-y-4">

          {/* Status banner */}
          {adsbStatusQ.isLoading ? <Skeleton className="h-16" /> : adsbStatusQ.data && (() => {
            const cs = adsbStatusQ.data.connectionStatus;
            return (
              <Card className={cs === "live" ? "bg-emerald-500/10 border-emerald-500/30" : cs === "failed" ? "bg-red-500/10 border-red-500/30" : cs === "configured" ? "bg-sky-500/10 border-sky-500/30" : "bg-slate-500/10 border-slate-500/20"}>
                <CardContent className="p-4 flex items-center gap-3">
                  {cs === "live" ? <Wifi className="h-5 w-5 text-emerald-400 shrink-0" /> : cs === "failed" ? <WifiOff className="h-5 w-5 text-red-400 shrink-0" /> : cs === "configured" ? <CheckCircle2 className="h-5 w-5 text-sky-400 shrink-0" /> : <Activity className="h-5 w-5 text-muted-foreground shrink-0" />}
                  <div className="flex-1 min-w-0">
                    <div className={`font-mono text-sm font-bold ${cs === "live" ? "text-emerald-300" : cs === "failed" ? "text-red-300" : cs === "configured" ? "text-sky-300" : "text-muted-foreground"}`}>
                      {cs === "live" ? "ADS-B Live Sync Active" : cs === "failed" ? "ADS-B Connection Failed" : cs === "configured" ? "ADS-B Configured — Not Yet Tested" : "Demo Mode — ADS-B Not Configured"}
                    </div>
                    <div className="font-mono text-[11px] text-muted-foreground">
                      {cs === "live" ? `Provider: ${adsbStatusQ.data.provider} · Last sync: ${adsbStatusQ.data.lastSyncAt ? new Date(adsbStatusQ.data.lastSyncAt).toLocaleTimeString() : "—"} · ${adsbStatusQ.data.lastSyncCount ?? 0} aircraft` : cs === "failed" ? "Connection failed. Check your API key and subscription." : cs === "configured" ? "Key saved. Click Test ADS-B Connection to verify." : `Running demo mode with simulated aircraft near ${adsbStatusQ.data.airportIcao}. Configure a key to enable live data.`}
                    </div>
                  </div>
                  <Badge variant="outline" className={`text-[9px] font-mono uppercase shrink-0 ${cs === "live" ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/30" : cs === "failed" ? "bg-red-500/20 text-red-300 border-red-500/30" : cs === "configured" ? "bg-sky-500/20 text-sky-300 border-sky-500/30" : "bg-slate-500/20 text-slate-400 border-slate-500/20"}`}>
                    {cs === "live" ? "Live" : cs === "failed" ? "Failed" : cs === "configured" ? "Configured" : "Demo"}
                  </Badge>
                </CardContent>
              </Card>
            );
          })()}

          {/* Provider selector */}
          <Card className="bg-card border-card-border">
            <CardHeader className="pb-2 pt-4 px-4">
              <CardTitle className="text-xs font-mono uppercase tracking-wider text-muted-foreground">ADS-B Provider</CardTitle>
            </CardHeader>
            <CardContent className="px-4 pb-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {([
                  { id: "adsbexchange", label: "ADS-B Exchange", sub: "RapidAPI · Licensed commercial", recommended: true },
                  { id: "opensky", label: "OpenSky Network", sub: "Free tier · Research use · Lower update rate", recommended: false },
                  { id: "manual", label: "Manual ADS-B Import", sub: "Paste/upload raw observation JSON", recommended: false },
                ] as const).map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setAdsbProvider(p.id)}
                    className={`text-left rounded border p-3 transition-colors ${adsbProvider === p.id ? "border-sky-500/50 bg-sky-500/10" : "border-border bg-background/50 hover:border-border/60"}`}
                  >
                    <div className="flex items-center justify-between mb-0.5">
                      <div className="font-mono text-xs font-bold text-foreground">{p.label}</div>
                      {p.recommended && <span className="text-[9px] font-mono text-sky-400 uppercase">Recommended</span>}
                    </div>
                    <div className="font-mono text-[10px] text-muted-foreground">{p.sub}</div>
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Globe reference + Commercial terms */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card className="bg-emerald-500/5 border-emerald-500/20">
              <CardContent className="p-4 flex items-start gap-3">
                <Eye className="h-4 w-4 text-emerald-400 mt-0.5 shrink-0" />
                <div className="flex-1 min-w-0">
                  <div className="font-mono text-xs font-bold text-emerald-300 mb-1">Visual Reference — CYLW Globe</div>
                  <div className="font-mono text-[11px] text-emerald-200/70 mb-2">Live ADS-B globe for visual/manual validation. <strong>Not</strong> the production API — for human reference only.</div>
                  <div className="flex items-center gap-2">
                    <code className="text-[10px] font-mono bg-background/60 px-2 py-0.5 rounded border border-border/40 text-muted-foreground truncate">{ADSBX_GLOBE_CYLW}</code>
                    <a href={ADSBX_GLOBE_CYLW} target="_blank" rel="noopener noreferrer"><ExternalLink className="h-3.5 w-3.5 text-emerald-400 hover:text-emerald-300 shrink-0" /></a>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-amber-500/5 border-amber-500/20">
              <CardContent className="p-4 flex items-start gap-3">
                <Shield className="h-4 w-4 text-amber-400 mt-0.5 shrink-0" />
                <div className="font-mono text-[11px] text-amber-200/80 leading-relaxed">
                  <strong className="text-amber-300">Commercial terms:</strong> Production AODB ingestion requires a licensed API agreement with ADS-B Exchange. Globe link is visual-reference only. Key is stored server-side; never logged or echoed.
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Config + Actions */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card className="bg-card border-card-border">
              <CardHeader className="pb-2 pt-4 px-4">
                <CardTitle className="text-xs font-mono uppercase tracking-wider text-muted-foreground">ADS-B Configuration</CardTitle>
              </CardHeader>
              <CardContent className="px-4 pb-4 space-y-3">
                {/* API Key */}
                <div className="space-y-1">
                  <Label className="text-xs font-mono uppercase text-muted-foreground">API Key / RapidAPI Token</Label>
                  {adsbApiKeySaved ? (
                    <div className="flex items-center gap-2">
                      <div className="flex-1 bg-background border border-border rounded px-3 py-1.5 text-xs font-mono text-muted-foreground flex items-center gap-2">
                        <Lock className="h-3 w-3 text-emerald-400" />
                        ••••••••••••••••••••••••••
                      </div>
                      <Button size="sm" variant="outline" className="h-7 text-xs font-mono" onClick={() => { setAdsbApiKeySaved(false); setAdsbApiKey(""); }}>Replace</Button>
                    </div>
                  ) : (
                    <Input data-testid="input-adsbx-key" type="password" value={adsbApiKey} onChange={(e) => setAdsbApiKey(e.target.value)} className="font-mono text-xs bg-background" placeholder="Paste your RapidAPI or licensed ADS-B key" autoComplete="off" />
                  )}
                  <div className="text-[10px] font-mono text-muted-foreground/60">Stored server-side — never returned to browser. Set ADSBX_API_KEY secret as fallback.</div>
                </div>
                {/* Grid: ICAO, Radius, Lat, Lon, Polling */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <Label className="text-xs font-mono uppercase text-muted-foreground">Airport ICAO</Label>
                    <Input data-testid="input-adsbx-icao" value={adsbIcao} readOnly className="font-mono text-xs bg-background/50 text-muted-foreground" />
                    <div className="text-[9px] font-mono text-muted-foreground/50">Change in Settings</div>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs font-mono uppercase text-muted-foreground">Radius (nm)</Label>
                    <Input data-testid="input-adsbx-radius" type="number" value={adsbRadius} onChange={(e) => setAdsbRadius(e.target.value)} className="font-mono text-xs bg-background" min={5} max={250} />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs font-mono uppercase text-muted-foreground">Latitude</Label>
                    <Input data-testid="input-adsbx-lat" value={adsbLat} onChange={(e) => setAdsbLat(e.target.value)} className="font-mono text-xs bg-background" />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs font-mono uppercase text-muted-foreground">Longitude</Label>
                    <Input data-testid="input-adsbx-lon" value={adsbLon} onChange={(e) => setAdsbLon(e.target.value)} className="font-mono text-xs bg-background" />
                  </div>
                  <div className="space-y-1 col-span-2">
                    <Label className="text-xs font-mono uppercase text-muted-foreground">Polling Interval (s)</Label>
                    <Input data-testid="input-adsbx-polling" type="number" value={adsbPolling} onChange={(e) => setAdsbPolling(e.target.value)} className="font-mono text-xs bg-background" min={10} max={3600} />
                  </div>
                </div>
                <Button
                  className="w-full font-mono text-xs"
                  disabled={adsbConfigMutation.isPending}
                  onClick={() => {
                    const payload: Parameters<typeof adsbConfigMutation.mutate>[0] = {
                      provider: adsbProvider,
                      radiusNm: parseInt(adsbRadius, 10),
                      lat: adsbLat,
                      lon: adsbLon,
                      pollingIntervalSeconds: parseInt(adsbPolling, 10),
                    };
                    if (adsbApiKey) payload.apiKey = adsbApiKey;
                    adsbConfigMutation.mutate(payload);
                  }}
                >
                  {adsbConfigMutation.isPending ? <RefreshCw className="h-3.5 w-3.5 mr-2 animate-spin" /> : null}
                  Save ADS-B Settings
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-card border-card-border">
              <CardHeader className="pb-2 pt-4 px-4">
                <CardTitle className="text-xs font-mono uppercase tracking-wider text-muted-foreground">Actions</CardTitle>
              </CardHeader>
              <CardContent className="px-4 pb-4 space-y-3">
                {/* Endpoint reference */}
                <div className="bg-background rounded p-2.5 border border-border/40 space-y-1.5">
                  <div className="text-[9px] font-mono uppercase text-muted-foreground">Production Endpoint</div>
                  <code className="text-[10px] font-mono text-sky-400 break-all block">{ADSBX_API_TEMPLATE}</code>
                  <div className="text-[9px] font-mono text-muted-foreground/60 uppercase">Resolved ({adsbRadius}nm)</div>
                  <code className="text-[10px] font-mono text-emerald-400 break-all block">{ADSBX_API_TEMPLATE.replace("{lat}", adsbLat).replace("{lon}", adsbLon).replace("{radius}", adsbRadius)}</code>
                </div>
                <Button
                  className="w-full font-mono text-xs gap-2"
                  variant="outline"
                  disabled={adsbTestMutation.isPending}
                  onClick={() => { setAdsbTestResult(null); adsbTestMutation.mutate(); }}
                  data-testid="button-adsb-test"
                >
                  {adsbTestMutation.isPending ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : <Wifi className="h-3.5 w-3.5" />}
                  Test ADS-B Connection
                </Button>
                {adsbTestResult && (
                  <div className={`rounded p-2.5 border text-[11px] font-mono space-y-1 ${adsbTestResult.success ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-200" : adsbTestResult.mode === "demo" ? "bg-slate-500/10 border-slate-500/20 text-muted-foreground" : "bg-red-500/10 border-red-500/30 text-red-200"}`}>
                    <div className="font-bold">{adsbTestResult.success ? "Connected" : adsbTestResult.mode === "demo" ? "Demo Mode" : "Failed"}</div>
                    <div>{adsbTestResult.message}</div>
                    {adsbTestResult.hint && <div className="text-[10px] opacity-70">{adsbTestResult.hint}</div>}
                    {adsbTestResult.aircraftCount !== undefined && <div className="text-emerald-400 font-bold">{adsbTestResult.aircraftCount} aircraft returned</div>}
                  </div>
                )}
                <Button
                  className={`w-full font-mono text-xs gap-2 ${adsbStatusQ.data?.connectionStatus === "demo" ? "" : "bg-emerald-600 hover:bg-emerald-500 text-white"}`}
                  disabled={adsbSyncMutation.isPending}
                  onClick={() => { setAdsbSyncResult(null); adsbSyncMutation.mutate(); nearbyQ.refetch(); adsbUnmatchedQ.refetch(); }}
                  data-testid="button-adsbx-sync"
                >
                  {adsbSyncMutation.isPending ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : <Radar className="h-3.5 w-3.5" />}
                  {adsbStatusQ.data?.connectionStatus === "demo" ? "Manual ADS-B Sync (Demo)" : "Manual ADS-B Sync (Live)"}
                </Button>
                {adsbSyncResult && (
                  <div className={`rounded p-2.5 border text-[11px] font-mono space-y-0.5 ${adsbSyncResult.mode === "live" ? "bg-emerald-500/10 border-emerald-500/30" : "bg-slate-500/10 border-slate-500/20"}`}>
                    <div className="font-bold text-foreground">{adsbSyncResult.message}</div>
                    {adsbSyncResult.aircraftObserved !== undefined && (
                      <div className="flex gap-4 text-[10px] pt-1">
                        <span className="text-emerald-400">✓ {adsbSyncResult.matched} matched</span>
                        <span className="text-amber-400">⚠ {adsbSyncResult.unmatched} unmatched</span>
                        <span className="text-muted-foreground">{adsbSyncResult.aircraftObserved} total</span>
                      </div>
                    )}
                  </div>
                )}
                <Button
                  variant="ghost"
                  className="w-full font-mono text-xs gap-2 text-muted-foreground"
                  onClick={() => { nearbyQ.refetch(); adsbUnmatchedQ.refetch(); }}
                  disabled={nearbyQ.isFetching}
                  data-testid="button-query-nearby"
                >
                  {nearbyQ.isFetching ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : <Radar className="h-3.5 w-3.5" />}
                  Refresh Aircraft Table
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Nearby aircraft results */}
          {(nearbyQ.data && nearbyQ.data.aircraft.length > 0) && (
            <Card className="bg-card border-card-border">
              <CardHeader className="pb-2 pt-4 px-4">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xs font-mono uppercase tracking-wider text-muted-foreground">
                    Aircraft Near {nearbyQ.data.airportIcao} ({adsbRadius}nm) — {nearbyQ.data.total} observed
                  </CardTitle>
                  <Badge variant="outline" className={`text-[10px] font-mono uppercase ${adsbStatusQ.data?.connectionStatus === "live" ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/30" : "bg-amber-500/20 text-amber-300 border-amber-500/20"}`}>
                    {adsbStatusQ.data?.connectionStatus === "live" ? "Live" : "Demo"}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="px-0 pb-0">
                <div className="overflow-x-auto">
                  <table className="w-full text-xs font-mono">
                    <thead>
                      <tr className="border-b border-border text-muted-foreground">
                        {["ICAO Hex", "Callsign", "Reg / Tail", "Type", "Alt (ft)", "GS (kt)", "Hdg", "Dist (nm)", "Status", "Match", "Score", "Matched Flight"].map((h) => (
                          <th key={h} className="px-3 py-2 text-left uppercase tracking-wider text-[10px] whitespace-nowrap">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {nearbyQ.data.aircraft.map((ac) => (
                        <tr key={ac.id} className="border-b border-border/40 hover:bg-secondary/20">
                          <td className="px-3 py-2 font-bold text-emerald-400">{ac.icaoHex}</td>
                          <td className="px-3 py-2 font-bold">{ac.callsign ?? "—"}</td>
                          <td className="px-3 py-2 text-muted-foreground">{ac.registration ?? "—"}</td>
                          <td className="px-3 py-2 text-muted-foreground">{ac.aircraftType ?? "—"}</td>
                          <td className="px-3 py-2">{ac.altBaro !== null ? (ac.altBaro <= 50 ? <span className="text-emerald-400">GND</span> : ac.altBaro.toLocaleString()) : "—"}</td>
                          <td className="px-3 py-2">{ac.groundSpeed?.toFixed(0) ?? "—"}</td>
                          <td className="px-3 py-2 text-muted-foreground">{ac.track !== null ? `${ac.track.toFixed(0)}°` : "—"}</td>
                          <td className="px-3 py-2">{ac.distanceNm?.toFixed(1) ?? "—"}</td>
                          <td className="px-3 py-2">
                            <Badge variant="outline" className="text-[9px] font-mono uppercase px-1 py-0">
                              {(ac.inferredStatus ?? "UNKNOWN").replace(/_/g, " ")}
                            </Badge>
                          </td>
                          <td className="px-3 py-2">
                            <Badge variant="outline" className={`text-[9px] font-mono uppercase px-1 py-0 ${ac.matchType === "exact" ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/30" : ac.matchType === "probable" ? "bg-sky-500/20 text-sky-300 border-sky-500/30" : ac.matchType === "possible" ? "bg-amber-500/20 text-amber-300 border-amber-500/20" : "bg-red-500/10 text-red-400 border-red-500/20"}`}>
                              {ac.matchType}
                            </Badge>
                          </td>
                          <td className="px-3 py-2 text-muted-foreground">{ac.matchScore > 0 ? `${ac.matchScore}%` : "—"}</td>
                          <td className="px-3 py-2">{ac.matchedFlightNumber ? <span className="text-sky-400">{ac.matchedFlightNumber}</span> : <span className="text-amber-400/70">—</span>}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Unmatched review queue */}
          {(adsbUnmatchedQ.data && adsbUnmatchedQ.data.total > 0) && (
            <Card className="bg-amber-500/5 border-amber-500/30">
              <CardHeader className="pb-2 pt-4 px-4">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xs font-mono uppercase tracking-wider text-amber-400">
                    Unmatched ADS-B Review Queue — {adsbUnmatchedQ.data.total} aircraft
                  </CardTitle>
                  <Badge variant="outline" className="text-[10px] font-mono uppercase bg-amber-500/20 text-amber-300 border-amber-500/20">Needs Review</Badge>
                </div>
                <div className="text-[10px] font-mono text-muted-foreground/70 mt-1">
                  Aircraft observed near {adsbIcao} that do not match any scheduled Cirium/Airport Feed flight. May include VFR traffic, positioning flights, or data gaps.
                </div>
              </CardHeader>
              <CardContent className="px-0 pb-0">
                <div className="overflow-x-auto">
                  <table className="w-full text-xs font-mono">
                    <thead>
                      <tr className="border-b border-amber-500/20 text-muted-foreground">
                        {["ICAO Hex", "Callsign", "Reg", "Type", "Alt (ft)", "GS (kt)", "Dist (nm)", "Status", "Source", "Review Reason"].map((h) => (
                          <th key={h} className="px-3 py-2 text-left uppercase tracking-wider text-[10px] whitespace-nowrap">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {adsbUnmatchedQ.data.unmatched.map((obs) => (
                        <tr key={obs.id} className="border-b border-amber-500/10 hover:bg-amber-500/5">
                          <td className="px-3 py-2 font-bold text-amber-400">{obs.icaoHex}</td>
                          <td className="px-3 py-2">{obs.callsign ?? "—"}</td>
                          <td className="px-3 py-2 text-muted-foreground">{obs.registration ?? "—"}</td>
                          <td className="px-3 py-2 text-muted-foreground">{obs.aircraftType ?? "—"}</td>
                          <td className="px-3 py-2">{obs.altBaro !== null ? obs.altBaro.toLocaleString() : "—"}</td>
                          <td className="px-3 py-2">{obs.groundSpeed?.toFixed(0) ?? "—"}</td>
                          <td className="px-3 py-2">{obs.distanceNm?.toFixed(1) ?? "—"}</td>
                          <td className="px-3 py-2">
                            <Badge variant="outline" className="text-[9px] font-mono uppercase px-1 py-0">
                              {(obs.inferredStatus ?? "UNKNOWN").replace(/_/g, " ")}
                            </Badge>
                          </td>
                          <td className="px-3 py-2 text-muted-foreground/70 uppercase text-[10px]">{obs.source}</td>
                          <td className="px-3 py-2 text-amber-300/70">{obs.reviewReason}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* ── TAB: SOURCE COMPARISON ────────────────────────────────────── */}
        <TabsContent value="comparison" className="mt-4 space-y-4">
          {/* Summary stats */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            {comparisonQ.isLoading ? Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-20" />) : summary ? (
              <>
                <Card className="bg-card border-card-border"><CardContent className="p-3"><div className="text-[10px] font-mono text-muted-foreground uppercase mb-1">Total Flights</div><div className="text-2xl font-mono font-bold">{summary.totalFlights}</div></CardContent></Card>
                <Card className="bg-violet-500/5 border-violet-500/20"><CardContent className="p-3"><div className="text-[10px] font-mono text-violet-400 uppercase mb-1">FR24 Coverage</div><div className="text-xl font-mono font-bold text-violet-400">{summary.fr24MatchRate}%</div><div className="text-[10px] font-mono text-muted-foreground">{summary.fr24Coverage}/{summary.totalFlights}</div></CardContent></Card>
                <Card className="bg-emerald-500/5 border-emerald-500/20"><CardContent className="p-3"><div className="text-[10px] font-mono text-emerald-400 uppercase mb-1">ADS-B Coverage</div><div className="text-xl font-mono font-bold text-emerald-400">{summary.adsbMatchRate}%</div><div className="text-[10px] font-mono text-muted-foreground">{summary.adsbCoverage}/{summary.totalFlights}</div></CardContent></Card>
                <Card className="bg-sky-500/5 border-sky-500/20"><CardContent className="p-3"><div className="text-[10px] font-mono text-sky-400 uppercase mb-1">FR24 ∩ ADSBX</div><div className="text-xl font-mono font-bold text-sky-400">{summary.fr24AdsbAgreementRate}%</div><div className="text-[10px] font-mono text-muted-foreground">{summary.bothCoverage} both</div></CardContent></Card>
                <Card className={summary.conflictCount > 0 ? "bg-red-500/5 border-red-500/20" : "bg-card border-card-border"}><CardContent className="p-3"><div className={`text-[10px] font-mono uppercase mb-1 ${summary.conflictCount > 0 ? "text-red-400" : "text-muted-foreground"}`}>Conflicts</div><div className={`text-xl font-mono font-bold ${summary.conflictCount > 0 ? "text-red-400" : "text-foreground"}`}>{summary.conflictCount}</div></CardContent></Card>
              </>
            ) : null}
          </div>

          {/* Conflict rules legend */}
          <Card className="bg-card border-card-border">
            <CardHeader className="pb-1 pt-3 px-4"><CardTitle className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">Active Conflict Detection Rules</CardTitle></CardHeader>
            <CardContent className="px-4 pb-3 flex flex-wrap gap-2">
              {["FR24 missing but ADS-B Exchange shows aircraft near CYLW", "Cirium scheduled but neither FR24 nor ADS-B Exchange sees movement", "FR24 and ADS-B Exchange disagree on tail/type/callsign", "ADS-B Exchange shows aircraft over airport — no Cirium match", "Large delay unconfirmed by any movement source"].map((rule, i) => (
                <div key={i} className="text-[10px] font-mono text-muted-foreground bg-secondary/30 px-2 py-1 rounded border border-border/30">· {rule}</div>
              ))}
            </CardContent>
          </Card>

          {/* Comparison table */}
          <Card className="bg-card border-card-border">
            <CardHeader className="pb-2 pt-4 px-4">
              <CardTitle className="text-xs font-mono uppercase tracking-wider text-muted-foreground">Side-by-Side Source Comparison — Click row to expand per-field values</CardTitle>
            </CardHeader>
            <CardContent className="px-0 pb-0">
              <div className="overflow-x-auto">
                <table className="w-full text-xs font-mono">
                  <thead>
                    <tr className="border-b border-border text-muted-foreground">
                      {["Flight", "Route", "Status", "Confidence", "Feed Status", "FR24 Tail/Type", "ADSBX Hex/Reg", "ADSBX Alt/GS/Dist", "Conflicts"].map((h) => (
                        <th key={h} className="px-3 py-2 text-left uppercase tracking-wider text-[10px] whitespace-nowrap">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {comparisonQ.isLoading ? (
                      Array.from({ length: 6 }).map((_, i) => (
                        <tr key={i} className="border-b border-border/50">
                          {Array.from({ length: 9 }).map((_, j) => <td key={j} className="px-3 py-2"><Skeleton className="h-3 w-16" /></td>)}
                        </tr>
                      ))
                    ) : (comparisonQ.data?.flights ?? []).map((f) => (
                      <>
                        <tr
                          key={f.flightId}
                          data-testid={`comparison-row-${f.flightId}`}
                          className={`border-b border-border/40 cursor-pointer hover:bg-secondary/40 transition-colors ${expandedFlightId === f.flightId ? "bg-secondary/30" : ""}`}
                          onClick={() => setExpandedFlightId(expandedFlightId === f.flightId ? null : f.flightId)}
                        >
                          <td className="px-3 py-2 whitespace-nowrap">
                            <div className="font-bold text-foreground font-mono">{f.flightNumber}</div>
                            {(f as Record<string, unknown>).isCommercial !== undefined && (
                              <Badge variant="outline" className={`text-[8px] font-mono mt-0.5 px-1 py-0 ${(f as Record<string, unknown>).isCommercial ? "bg-sky-500/10 text-sky-400 border-sky-500/20" : "bg-slate-500/10 text-slate-500 border-slate-500/20"}`}>
                                {(f as Record<string, unknown>).isCommercial ? String((f as Record<string, unknown>).commercialClass ?? "commercial") : "non-commercial"}
                              </Badge>
                            )}
                          </td>
                          <td className="px-3 py-2 text-muted-foreground whitespace-nowrap text-[10px]">{f.origin} → {f.destination}</td>
                          <td className="px-3 py-2">
                            <Badge variant="outline" className="text-[9px] font-mono uppercase px-1 py-0">{f.status.replace(/_/g, " ")}</Badge>
                          </td>
                          <td className="px-3 py-2"><ConfBar value={f.overallConfidence} /></td>
                          <td className="px-3 py-2 text-[10px]">
                            <div>{f.sources.feed.status}</div>
                          </td>
                          <td className="px-3 py-2 text-[10px]">
                            {f.sources.fr24 ? (
                              <><div className="text-violet-400">{f.sources.fr24.tailNumber ?? "—"}</div><div className="text-muted-foreground">{f.sources.fr24.aircraftType ?? "—"}</div></>
                            ) : <span className="text-red-400/70 italic">missing</span>}
                          </td>
                          <td className="px-3 py-2 text-[10px]">
                            {f.sources.adsbx ? (
                              <><div className="text-emerald-400 font-mono">{f.sources.adsbx.hex}</div><div className="text-muted-foreground">{f.sources.adsbx.registration ?? "—"}</div></>
                            ) : <span className="text-amber-400/70 italic">missing</span>}
                          </td>
                          <td className="px-3 py-2 text-[10px]">
                            {f.sources.adsbx ? (
                              <><div>{f.sources.adsbx.altBaro === 0 ? "GND" : `${f.sources.adsbx.altBaro.toLocaleString()}ft`}</div><div className="text-muted-foreground">{f.sources.adsbx.groundSpeed}kt · {f.sources.adsbx.distanceFromAirportNm}nm</div></>
                            ) : <span className="text-muted-foreground/40">—</span>}
                          </td>
                          <td className="px-3 py-2">
                            <div className="flex flex-wrap gap-1">
                              {f.conflicts.length === 0 ? (
                                <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400/60" />
                              ) : f.conflicts.map((c) => <ConflictBadge key={c} conflict={c} />)}
                            </div>
                          </td>
                        </tr>
                        {expandedFlightId === f.flightId && (
                          <tr key={`${f.flightId}-expand`}>
                            <td colSpan={9} className="p-0">
                              <ComparisonRowExpand flightId={f.flightId} />
                            </td>
                          </tr>
                        )}
                      </>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── TAB: RELIABILITY ─────────────────────────────────────────── */}
        <TabsContent value="reliability" className="mt-4 space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {reliabilityQ.isLoading ? Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-28" />) : reliability ? (
              <>
                <Card className="bg-violet-500/5 border-violet-500/20">
                  <CardContent className="p-4">
                    <div className="text-[10px] font-mono text-violet-400 uppercase mb-2">FR24 Match Rate</div>
                    <div className="text-3xl font-mono font-bold text-violet-400">{reliability.fr24MatchRate}%</div>
                    <Progress value={reliability.fr24MatchRate} className="h-1 mt-2" />
                    <div className="text-[10px] font-mono text-muted-foreground mt-1">{reliability.fr24MatchCount}/{reliability.totalFlights} flights</div>
                  </CardContent>
                </Card>
                <Card className="bg-emerald-500/5 border-emerald-500/20">
                  <CardContent className="p-4">
                    <div className="text-[10px] font-mono text-emerald-400 uppercase mb-2">ADS-B Exchange Match Rate</div>
                    <div className="text-3xl font-mono font-bold text-emerald-400">{reliability.adsbxMatchRate}%</div>
                    <Progress value={reliability.adsbxMatchRate} className="h-1 mt-2" />
                    <div className="text-[10px] font-mono text-muted-foreground mt-1">{reliability.adsbxMatchCount}/{reliability.totalFlights} flights</div>
                  </CardContent>
                </Card>
                <Card className="bg-sky-500/5 border-sky-500/20">
                  <CardContent className="p-4">
                    <div className="text-[10px] font-mono text-sky-400 uppercase mb-2">FR24 ↔ ADS-B Agreement</div>
                    <div className="text-3xl font-mono font-bold text-sky-400">{reliability.fr24AdsbxAgreementRate}%</div>
                    <Progress value={reliability.fr24AdsbxAgreementRate} className="h-1 mt-2" />
                    <div className="text-[10px] font-mono text-muted-foreground mt-1">{reliability.bothMatchCount} both sources</div>
                  </CardContent>
                </Card>
                <Card className={reliability.unmatchedAdsbxAircraft > 0 ? "bg-amber-500/5 border-amber-500/20" : "bg-card border-card-border"}>
                  <CardContent className="p-4">
                    <div className="text-[10px] font-mono text-amber-400 uppercase mb-2">Unmatched ADS-B Aircraft</div>
                    <div className={`text-3xl font-mono font-bold ${reliability.unmatchedAdsbxAircraft > 0 ? "text-amber-400" : "text-foreground"}`}>{reliability.unmatchedAdsbxAircraft}</div>
                    <div className="text-[10px] font-mono text-muted-foreground mt-2">Near CYLW — ops review</div>
                  </CardContent>
                </Card>
              </>
            ) : null}
          </div>

          {/* Per-airline table */}
          <Card className="bg-card border-card-border">
            <CardHeader className="pb-2 pt-4 px-4">
              <CardTitle className="text-xs font-mono uppercase tracking-wider text-muted-foreground">Actual Movement Confidence by Airline</CardTitle>
            </CardHeader>
            <CardContent className="px-0 pb-0">
              <div className="overflow-x-auto">
                <table className="w-full text-xs font-mono">
                  <thead>
                    <tr className="border-b border-border text-muted-foreground">
                      {["Airline", "Total Flights", "FR24 Coverage", "ADS-B Coverage", "Both Sources", "Avg Confidence"].map((h) => (
                        <th key={h} className="px-4 py-2 text-left uppercase tracking-wider text-[10px] whitespace-nowrap">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {reliabilityQ.isLoading ? Array.from({ length: 4 }).map((_, i) => (
                      <tr key={i} className="border-b border-border/50">
                        {Array.from({ length: 6 }).map((_, j) => <td key={j} className="px-4 py-2"><Skeleton className="h-3 w-12" /></td>)}
                      </tr>
                    )) : (reliabilityQ.data?.byAirline ?? []).map((row) => (
                      <tr key={row.airline} className="border-b border-border/40">
                        <td className="px-4 py-2 font-bold text-foreground">{row.airline}</td>
                        <td className="px-4 py-2">{row.total}</td>
                        <td className="px-4 py-2">
                          <div className="flex items-center gap-2">
                            <span className="text-violet-400">{row.fr24}/{row.total}</span>
                            <ConfBar value={Math.round((row.fr24 / row.total) * 100)} />
                          </div>
                        </td>
                        <td className="px-4 py-2">
                          <div className="flex items-center gap-2">
                            <span className="text-emerald-400">{row.adsbx}/{row.total}</span>
                            <ConfBar value={Math.round((row.adsbx / row.total) * 100)} />
                          </div>
                        </td>
                        <td className="px-4 py-2 text-sky-400">{row.both}/{row.total}</td>
                        <td className="px-4 py-2"><ConfBar value={row.avgConfidence} /></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>

          {/* Cirium */}
          <Card className="bg-amber-500/5 border-amber-500/20">
            <CardContent className="p-4 flex items-start gap-3">
              <CheckCircle2 className="h-4 w-4 text-amber-400 mt-0.5" />
              <div className="font-mono text-[11px] text-amber-200/80 leading-relaxed">
                <strong className="text-amber-300">Cirium coverage: 100%</strong> — Cirium provides schedule data for all flights and is used as the
                authoritative STA/STD reference. Cirium does not provide actual movement data. Flights matched by both FR24 and ADS-B Exchange have
                the highest actual-movement confidence rating.
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── TAB: FIELD MAPPING ────────────────────────────────────────── */}
        <TabsContent value="fieldmap" className="mt-4 space-y-4">
          <Card className="bg-amber-500/5 border-amber-500/20">
            <CardContent className="p-4 flex items-start gap-3">
              <AlertTriangle className="h-4 w-4 text-amber-400 mt-0.5 shrink-0" />
              <div className="flex-1 min-w-0">
                <div className="font-mono text-xs font-bold text-amber-300 mb-1">Example feed only — replace with your airport's actual arrivals/departures URLs in production.</div>
                <div className="font-mono text-[11px] text-amber-200/70 mb-2">YLW arrivals used as structural reference. Configure your own feed URL and adapt mapping as needed.</div>
                <div className="flex flex-wrap items-center gap-2">
                  <code className="text-[10px] font-mono bg-background/60 px-2 py-0.5 rounded border border-border/40 text-muted-foreground break-all">{YLW_ARRIVALS_EXAMPLE_URL}</code>
                  <a href={YLW_ARRIVALS_EXAMPLE_URL} target="_blank" rel="noopener noreferrer"><ExternalLink className="h-3.5 w-3.5 text-amber-400" /></a>
                </div>
              </div>
              <Button size="sm" variant="outline" className="shrink-0 h-8 text-xs font-mono gap-1 border-amber-500/30 text-amber-300 hover:bg-amber-500/10" onClick={() => { setArrivalsUrl(YLW_ARRIVALS_EXAMPLE_URL); fetchFeed(YLW_ARRIVALS_EXAMPLE_URL); }} disabled={feedLoading} data-testid="button-load-example">
                {feedLoading ? <><RefreshCw className="h-3 w-3 animate-spin" />Loading...</> : "Load Example"}
              </Button>
            </CardContent>
          </Card>
          {feedError && <Card className="bg-red-500/5 border-red-500/20"><CardContent className="p-3 flex items-center gap-2"><AlertTriangle className="h-3.5 w-3.5 text-red-400" /><span className="text-xs font-mono text-red-300">{feedError}</span></CardContent></Card>}
          <div className="flex gap-2">
            <Input data-testid="input-arrivals-url" value={arrivalsUrl} onChange={(e) => setArrivalsUrl(e.target.value)} className="font-mono text-xs bg-background h-8" placeholder="Feed URL to inspect..." />
            <Button size="sm" className="h-8 text-xs font-mono" onClick={() => fetchFeed(arrivalsUrl)} disabled={!arrivalsUrl || feedLoading} data-testid="button-inspect-url">Inspect</Button>
          </div>
          {feedRecords && (
            <Card className="bg-card border-card-border">
              <CardHeader className="pb-2 pt-4 px-4">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xs font-mono uppercase tracking-wider text-muted-foreground">Detected Fields — {feedRecords.length} records</CardTitle>
                  <div className="flex gap-1.5">
                    <Badge variant="outline" className="text-[9px] font-mono bg-emerald-500/10 text-emerald-300 border-emerald-500/20"><CheckCircle2 className="h-2.5 w-2.5 mr-1" />{FIELD_MAPPINGS.filter(m => m.canonicalField !== "(not mapped)").length} mapped</Badge>
                    <Badge variant="outline" className="text-[9px] font-mono bg-slate-500/10 text-slate-400 border-slate-500/20">{FIELD_MAPPINGS.filter(m => m.canonicalField === "(not mapped)").length} discarded</Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="px-0 pb-0">
                <div className="overflow-x-auto">
                  <table className="w-full text-xs font-mono">
                    <thead>
                      <tr className="border-b border-border text-muted-foreground">
                        {["Feed Field", "Sample Value", "Canonical AODB Field", "Transformation", "Notes"].map((h) => (
                          <th key={h} className="px-3 py-2 text-left uppercase tracking-wider text-[10px] whitespace-nowrap">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {Array.from(new Set(feedRecords.flatMap(r => Object.keys(r)))).map((key) => {
                        const mapping = FIELD_MAPPINGS.find(m => m.feedField === key);
                        const sampleVal = feedRecords[0]?.[key];
                        return (
                          <tr key={key} className={`border-b border-border/40 ${mapping?.canonicalField === "(not mapped)" ? "opacity-50" : ""}`}>
                            <td className="px-3 py-2"><span className="font-bold text-foreground">{key}</span>{mapping?.required && <span className="ml-1.5 text-red-400 text-[9px] uppercase">req</span>}</td>
                            <td className="px-3 py-2 text-sky-400">{sampleVal === "" ? <span className="text-muted-foreground italic">empty</span> : sampleVal === null ? <span className="text-muted-foreground italic">null</span> : String(sampleVal)}</td>
                            <td className="px-3 py-2">{mapping ? mapping.canonicalField === "(not mapped)" ? <span className="text-muted-foreground italic">discarded</span> : <code className="text-emerald-400">{mapping.canonicalField}</code> : <span className="text-amber-400 italic">unknown</span>}</td>
                            <td className="px-3 py-2 text-muted-foreground text-[10px] max-w-40">{mapping?.transformation ?? "—"}</td>
                            <td className="px-3 py-2 text-muted-foreground text-[10px] max-w-48">{mapping?.notes ?? "Not in reference mapping."}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}
          {!feedRecords && !feedLoading && (
            <Card className="bg-card border-card-border">
              <CardContent className="px-0 pb-0">
                <div className="overflow-x-auto">
                  <table className="w-full text-xs font-mono">
                    <thead>
                      <tr className="border-b border-border text-muted-foreground">
                        {["Feed Field", "Canonical AODB Field", "Transformation", "Notes"].map((h) => (
                          <th key={h} className="px-3 py-2 text-left uppercase tracking-wider text-[10px] whitespace-nowrap">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {FIELD_MAPPINGS.map((m) => (
                        <tr key={m.feedField} className={`border-b border-border/40 ${m.canonicalField === "(not mapped)" ? "opacity-50" : ""}`}>
                          <td className="px-3 py-2"><span className="font-bold text-foreground">{m.feedField}</span>{m.required && <span className="ml-1.5 text-red-400 text-[9px] uppercase">req</span>}</td>
                          <td className="px-3 py-2">{m.canonicalField === "(not mapped)" ? <span className="text-muted-foreground italic">discarded</span> : <code className="text-emerald-400">{m.canonicalField}</code>}</td>
                          <td className="px-3 py-2 text-muted-foreground text-[10px] max-w-48">{m.transformation}</td>
                          <td className="px-3 py-2 text-muted-foreground text-[10px] max-w-56">{m.notes}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* ── TAB: STATUS MAPPING ───────────────────────────────────────── */}
        <TabsContent value="status" className="mt-4">
          <Card className="bg-card border-card-border">
            <CardHeader className="pb-2 pt-4 px-4">
              <CardTitle className="text-xs font-mono uppercase tracking-wider text-muted-foreground">Airport Feed Status → Canonical AODB Status</CardTitle>
            </CardHeader>
            <CardContent className="px-0 pb-0">
              <div className="overflow-x-auto">
                <table className="w-full text-xs font-mono">
                  <thead>
                    <tr className="border-b border-border text-muted-foreground">
                      {["Feed Status", "→", "Canonical Status", "Notes"].map((h, i) => (
                        <th key={i} className="px-4 py-2 text-left uppercase tracking-wider text-[10px] whitespace-nowrap">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {STATUS_MAPPINGS.map((m, i) => (
                      <tr key={i} className="border-b border-border/40">
                        <td className="px-4 py-2"><Badge variant="outline" className="text-[10px] font-mono bg-slate-500/20 text-slate-300 border-slate-500/30">{m.feed}</Badge></td>
                        <td className="px-4 py-2 text-muted-foreground text-center">→</td>
                        <td className="px-4 py-2">
                          <Badge variant="outline" className={`text-[10px] font-mono uppercase ${m.canonical === "CANCELLED" ? "bg-red-500/20 text-red-300 border-red-500/30" : m.canonical === "DIVERTED" ? "bg-orange-500/20 text-orange-300 border-orange-500/30" : ["LANDED", "ON_BLOCK"].includes(m.canonical) ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/30" : m.canonical === "AIRBORNE" ? "bg-sky-500/20 text-sky-300 border-sky-500/30" : m.canonical === "DEPARTED" ? "bg-indigo-500/20 text-indigo-300 border-indigo-500/30" : "bg-blue-500/20 text-blue-300 border-blue-500/30"}`}>
                            {m.canonical.replace(/_/g, " ")}
                          </Badge>
                        </td>
                        <td className="px-4 py-2 text-muted-foreground text-[11px]">{m.notes}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="px-4 pb-4 pt-3">
                <div className="bg-secondary/30 rounded-lg p-3 border border-border/30 text-[11px] font-mono text-muted-foreground leading-relaxed">
                  <strong className="text-foreground/80">FR24 and ADS-B Exchange override rules:</strong> When either ADS-B source reports a confirmed position event (wheels-on, wheels-off), it overrides the feed status.
                  Feed status is always preserved verbatim in <code className="text-amber-400">flight_event.payload.statusRaw</code> for full audit traceability.
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* FR24 API Key entry popup */}
      <Dialog open={fr24KeyDialogOpen} onOpenChange={(open) => {
        setFr24KeyDialogOpen(open);
        if (!open) { setFr24DialogKey(""); setFr24DialogShowKey(false); }
      }}>
        <DialogContent className="sm:max-w-lg" data-testid="dialog-fr24-key">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 font-mono">
              <KeyRound className="h-5 w-5 text-sky-400" />
              Enter Flightradar24 API Key
            </DialogTitle>
            <DialogDescription className="font-mono text-[11px] leading-relaxed">
              Paste your FR24 Bearer token below. It is sent over HTTPS, stored server-side in the database, and is never
              returned to the browser after saving. Do not share it in chat, email, or screenshots.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-3 py-2">
            {/* Security callout */}
            <div className="bg-amber-500/10 border border-amber-500/30 rounded p-3 flex items-start gap-2">
              <Lock className="h-4 w-4 text-amber-400 mt-0.5 shrink-0" />
              <div className="font-mono text-[10px] text-amber-200/80 leading-snug">
                Keep this window private. Anyone with this key can query your FR24 quota and data.
              </div>
            </div>

            {/* Key input */}
            <div className="space-y-1.5">
              <Label className="text-xs font-mono uppercase text-muted-foreground">API Key / Bearer Token</Label>
              <div className="relative">
                <Input
                  data-testid="input-fr24-key-dialog"
                  type={fr24DialogShowKey ? "text" : "password"}
                  value={fr24DialogKey}
                  onChange={(e) => setFr24DialogKey(e.target.value)}
                  className="font-mono text-xs bg-background pr-9"
                  placeholder="Paste your FR24 API key here"
                  autoComplete="off"
                  autoFocus
                  spellCheck={false}
                />
                <button
                  type="button"
                  onClick={() => setFr24DialogShowKey((v) => !v)}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  aria-label={fr24DialogShowKey ? "Hide key" : "Show key"}
                  data-testid="button-fr24-toggle-visibility"
                >
                  {fr24DialogShowKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
              <div className="text-[10px] font-mono text-muted-foreground/60 flex items-center justify-between">
                <span>{fr24DialogKey ? `${fr24DialogKey.length} chars entered` : "Hidden by default · click eye to show"}</span>
                <span className="text-muted-foreground/40">Bearer eyJ… or similar</span>
              </div>
            </div>

            {/* Endpoint that will be used */}
            <div className="bg-background/50 border border-border rounded p-2.5">
              <div className="text-[9px] font-mono uppercase text-muted-foreground mb-1">Will Authenticate Against</div>
              <div className="font-mono text-[10px] text-emerald-300 break-all">
                GET https://fr24api.flightradar24.com/api/live/flight-positions/full?airports={fr24Status?.airportIcao ?? "CYLW"}
              </div>
            </div>
          </div>

          <DialogFooter className="gap-2 sm:gap-2">
            <Button
              variant="outline"
              className="font-mono"
              onClick={() => { setFr24KeyDialogOpen(false); setFr24DialogKey(""); setFr24DialogShowKey(false); }}
              data-testid="button-fr24-cancel"
            >
              Cancel
            </Button>
            <Button
              data-testid="button-fr24-save-dialog"
              className="bg-sky-500 hover:bg-sky-400 text-slate-950 font-mono font-bold"
              disabled={!fr24DialogKey.trim() || fr24ConfigMutation.isPending}
              onClick={() => {
                if (!fr24DialogKey.trim()) return;
                fr24ConfigMutation.mutate(
                  {
                    apiKey: fr24DialogKey.trim(),
                    pollingIntervalSeconds: parseInt(fr24Polling, 10),
                    operatingHoursStart: fr24HoursStart,
                    operatingHoursEnd: fr24HoursEnd,
                    radiusNm: parseInt(fr24Radius, 10),
                  },
                  {
                    onSuccess: () => {
                      setFr24KeySaved(true);
                      setFr24DialogKey("");
                      setFr24DialogShowKey(false);
                      setFr24KeyDialogOpen(false);
                    },
                  },
                );
              }}
            >
              {fr24ConfigMutation.isPending ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Saving…
                </>
              ) : (
                <>
                  <Lock className="h-4 w-4 mr-2" />
                  Save API Key Securely
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
