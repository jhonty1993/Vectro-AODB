import { useGetQualityOverview, useGetAuditLog, getGetQualityOverviewQueryKey, getGetAuditLogQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { Scale, ShieldCheck, AlertTriangle, XCircle } from "lucide-react";
import type { AuditEntry } from "@workspace/api-client-react";

function formatDateTime(iso: string | null | undefined): string {
  if (!iso) return "—";
  try { return new Date(iso).toLocaleString("en-CA", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit", hour12: false }); } catch { return "—"; }
}

export default function Quality() {
  const overviewQuery = useGetQualityOverview({ query: { queryKey: getGetQualityOverviewQueryKey() } });
  const auditQuery = useGetAuditLog({ query: { queryKey: getGetAuditLogQueryKey() } });

  const overview = overviewQuery.data;
  const auditLog = auditQuery.data ?? [];

  return (
    <div className="p-6 space-y-6">
      <div>
        <div className="flex items-center gap-2 mb-1">
          <Scale className="h-5 w-5 text-primary" />
          <h1 className="text-2xl font-mono font-bold text-foreground">Data Quality & Audit</h1>
        </div>
        <p className="text-sm text-muted-foreground font-mono">Data Quality & Audit (IT / Ops)</p>
      </div>

      {/* Quality Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {overviewQuery.isLoading ? (
          Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-24" />)
        ) : (
          <>
            <Card className="bg-card border-card-border md:col-span-1">
              <CardContent className="p-4">
                <div className="text-xs font-mono text-muted-foreground uppercase mb-2">Avg Data Quality</div>
                <div className={`text-3xl font-mono font-bold ${(overview?.averageScore ?? 0) >= 80 ? "text-emerald-400" : (overview?.averageScore ?? 0) >= 60 ? "text-amber-400" : "text-red-400"}`}>
                  {overview?.averageScore ?? 0}%
                </div>
                <Progress value={overview?.averageScore ?? 0} className="h-1.5 mt-2" />
              </CardContent>
            </Card>
            <Card className="bg-emerald-500/5 border-emerald-500/20">
              <CardContent className="p-4">
                <div className="text-xs font-mono text-emerald-400 uppercase mb-1 flex items-center gap-1"><ShieldCheck className="h-3 w-3" />High (&gt;80%)</div>
                <div className="text-2xl font-mono font-bold text-emerald-400">{overview?.highQuality ?? 0}</div>
              </CardContent>
            </Card>
            <Card className="bg-amber-500/5 border-amber-500/20">
              <CardContent className="p-4">
                <div className="text-xs font-mono text-amber-400 uppercase mb-1 flex items-center gap-1"><AlertTriangle className="h-3 w-3" />Medium (60-80%)</div>
                <div className="text-2xl font-mono font-bold text-amber-400">{overview?.mediumQuality ?? 0}</div>
              </CardContent>
            </Card>
            <Card className="bg-red-500/5 border-red-500/20">
              <CardContent className="p-4">
                <div className="text-xs font-mono text-red-400 uppercase mb-1 flex items-center gap-1"><XCircle className="h-3 w-3" />Low (&lt;60%)</div>
                <div className="text-2xl font-mono font-bold text-red-400">{overview?.lowQuality ?? 0}</div>
              </CardContent>
            </Card>
          </>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Missing Data Stats */}
        <Card className="bg-card border-card-border">
          <CardHeader className="pb-2 pt-4 px-4">
            <CardTitle className="text-xs font-mono uppercase tracking-wider text-muted-foreground">Data Gaps</CardTitle>
          </CardHeader>
          <CardContent className="px-4 pb-4 space-y-3">
            {overviewQuery.isLoading ? <Skeleton className="h-32" /> : (
              <>
                <div className="flex justify-between items-center py-2 border-b border-border/40">
                  <span className="text-xs font-mono text-muted-foreground">Missing Tail Number</span>
                  <Badge variant="outline" className={`text-xs font-mono ${(overview?.missingTailNumber ?? 0) > 0 ? "bg-amber-500/20 text-amber-300 border-amber-500/20" : "bg-emerald-500/20 text-emerald-300 border-emerald-500/20"}`}>
                    {overview?.missingTailNumber ?? 0}
                  </Badge>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-border/40">
                  <span className="text-xs font-mono text-muted-foreground">Missing Actual Time</span>
                  <Badge variant="outline" className={`text-xs font-mono ${(overview?.missingActualTime ?? 0) > 0 ? "bg-red-500/20 text-red-300 border-red-500/20" : "bg-emerald-500/20 text-emerald-300 border-emerald-500/20"}`}>
                    {overview?.missingActualTime ?? 0}
                  </Badge>
                </div>
                <div className="flex justify-between items-center py-2">
                  <span className="text-xs font-mono text-muted-foreground">Conflicting Timestamps</span>
                  <Badge variant="outline" className={`text-xs font-mono ${(overview?.conflictingTimestamps ?? 0) > 0 ? "bg-red-500/20 text-red-300 border-red-500/20" : "bg-emerald-500/20 text-emerald-300 border-emerald-500/20"}`}>
                    {overview?.conflictingTimestamps ?? 0}
                  </Badge>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {/* Source Breakdown Chart */}
        <Card className="bg-card border-card-border md:col-span-2">
          <CardHeader className="pb-2 pt-4 px-4">
            <CardTitle className="text-xs font-mono uppercase tracking-wider text-muted-foreground">Event Source Breakdown</CardTitle>
          </CardHeader>
          <CardContent className="pb-4 px-4">
            {overviewQuery.isLoading ? <Skeleton className="h-40" /> : (
              <ResponsiveContainer width="100%" height={160}>
                <BarChart data={overview?.sourceBreakdown ?? []} layout="vertical" margin={{ top: 0, right: 10, left: 40, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 20% 16%)" />
                  <XAxis type="number" tick={{ fontSize: 10, fontFamily: "monospace", fill: "#94a3b8" }} />
                  <YAxis dataKey="source" type="category" tick={{ fontSize: 9, fontFamily: "monospace", fill: "#94a3b8" }} width={80} />
                  <Tooltip contentStyle={{ background: "hsl(220 20% 10%)", border: "1px solid hsl(220 20% 16%)", fontFamily: "monospace", fontSize: 11 }} />
                  <Bar dataKey="count" fill="hsl(217.2 91.2% 59.8%)" name="Events" radius={[0, 2, 2, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Audit Log */}
      <Card className="bg-card border-card-border">
        <CardHeader className="pb-2 pt-4 px-4">
          <CardTitle className="text-xs font-mono uppercase tracking-wider text-muted-foreground">
            Manual Change Audit Log ({auditLog.length} entries)
          </CardTitle>
        </CardHeader>
        <CardContent className="px-0 pb-0">
          <div className="overflow-x-auto">
            <table className="w-full text-xs font-mono">
              <thead>
                <tr className="border-b border-border text-muted-foreground">
                  {["Flight", "Action", "Operator", "Reason", "Field", "Old Value", "New Value", "Timestamp"].map((h) => (
                    <th key={h} className="px-4 py-2 text-left uppercase tracking-wider text-[10px] whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {auditQuery.isLoading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <tr key={i} className="border-b border-border/50">
                      {Array.from({ length: 8 }).map((_, j) => <td key={j} className="px-4 py-2"><Skeleton className="h-3 w-16" /></td>)}
                    </tr>
                  ))
                ) : auditLog.length === 0 ? (
                  <tr><td colSpan={8} className="px-6 py-8 text-center text-muted-foreground">No manual changes recorded yet. Manual corrections will appear here.</td></tr>
                ) : (
                  auditLog.map((entry: AuditEntry) => (
                    <tr key={entry.id} data-testid={`audit-row-${entry.id}`} className="border-b border-border/40 hover:bg-secondary/30">
                      <td className="px-4 py-2 font-bold text-foreground">{entry.flightNumber}</td>
                      <td className="px-4 py-2">
                        <Badge variant="outline" className="text-[10px] font-mono uppercase px-1.5 py-0">{entry.action.replace(/_/g, " ")}</Badge>
                      </td>
                      <td className="px-4 py-2 text-muted-foreground">{entry.operator}</td>
                      <td className="px-4 py-2 text-foreground/80 max-w-48 truncate" title={entry.reason}>{entry.reason}</td>
                      <td className="px-4 py-2 text-muted-foreground">{entry.fieldChanged ?? "—"}</td>
                      <td className="px-4 py-2 text-red-400/70">{entry.oldValue ?? "—"}</td>
                      <td className="px-4 py-2 text-emerald-400/70">{entry.newValue ?? "—"}</td>
                      <td className="px-4 py-2 text-muted-foreground whitespace-nowrap">{formatDateTime(entry.createdAt)}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
