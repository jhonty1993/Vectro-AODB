import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { AlertTriangle, CheckCircle2, Download, CreditCard, RefreshCw, TrendingDown, Activity, BarChart2, Settings } from "lucide-react";

// ── API helpers ───────────────────────────────────────────────────────────────

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, "") || "";
const api = (path: string) => `${BASE}/api/sources${path}`;

interface UsageSummary {
  startingCredits: number;
  totalUsed: number;
  remaining: number;
  remainingPct: number;
  todayUsed: number;
  totalCalls: number;
  successCount: number;
  failCount: number;
  warnings: {
    dailyExceeded: boolean;
    remainingLow: boolean;
    dailyWarningThreshold: number;
    remainingWarningThreshold: number;
  };
}

interface DailyRow {
  date: string;
  calls: number;
  credits: number;
  successes: number;
  failures: number;
  endpoints: Record<string, number>;
}

interface LogEntry {
  id: string;
  calledAt: string;
  endpoint: string;
  purpose: string;
  success: boolean;
  httpStatus: number | null;
  estimatedCredits: number;
  responseTimeMs: number | null;
  errorMessage: string | null;
}

function fmt(n: number): string { return n.toLocaleString("en-CA"); }
function fmtTime(iso: string): string {
  try { return new Date(iso).toLocaleString("en-CA", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit", hour12: false }); } catch { return iso; }
}

// ── Credit bar ────────────────────────────────────────────────────────────────

function CreditBar({ used, total }: { used: number; total: number }) {
  const pct = total > 0 ? Math.min(100, (used / total) * 100) : 0;
  const cls = pct >= 90 ? "bg-red-500" : pct >= 75 ? "bg-amber-500" : pct >= 50 ? "bg-yellow-500" : "bg-emerald-500";
  return (
    <div className="w-full h-2 bg-secondary rounded-full overflow-hidden">
      <div className={`h-full rounded-full transition-all ${cls}`} style={{ width: `${pct}%` }} />
    </div>
  );
}

// ── Page ─────────────────────────────────────────────────────────────────────

export default function Fr24UsagePage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [days, setDays] = useState(30);
  const [logOffset, setLogOffset] = useState(0);
  const LOG_LIMIT = 50;

  const [newBalance, setNewBalance] = useState("");
  const [dailyWarn, setDailyWarn] = useState("");
  const [remainWarn, setRemainWarn] = useState("");

  const summaryQ = useQuery<UsageSummary>({
    queryKey: ["fr24-usage-summary"],
    queryFn: () => fetch(api("/fr24/usage/summary")).then((r) => r.json()),
    refetchInterval: 30_000,
  });

  const dailyQ = useQuery<{ days: number; rows: DailyRow[] }>({
    queryKey: ["fr24-usage-daily", days],
    queryFn: () => fetch(api(`/fr24/usage/daily?days=${days}`)).then((r) => r.json()),
  });

  const logQ = useQuery<{ logs: LogEntry[]; total: number }>({
    queryKey: ["fr24-usage-log", logOffset],
    queryFn: () => fetch(api(`/fr24/usage/log?limit=${LOG_LIMIT}&offset=${logOffset}`)).then((r) => r.json()),
  });

  const resetMut = useMutation({
    mutationFn: (body: { startingCredits?: number; dailyWarningThreshold?: number; remainingWarningThreshold?: number }) =>
      fetch(api("/fr24/usage/reset-balance"), { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }).then((r) => r.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["fr24-usage-summary"] });
      toast({ title: "Balance updated", description: "FR24 credit settings saved." });
      setNewBalance(""); setDailyWarn(""); setRemainWarn("");
    },
  });

  const s = summaryQ.data;

  function handleExport() {
    window.open(api("/fr24/usage/export"), "_blank");
  }

  function handleSaveSettings() {
    const body: Record<string, number> = {};
    if (newBalance) body.startingCredits = parseInt(newBalance.replace(/,/g, ""), 10);
    if (dailyWarn) body.dailyWarningThreshold = parseInt(dailyWarn.replace(/,/g, ""), 10);
    if (remainWarn) body.remainingWarningThreshold = parseInt(remainWarn.replace(/,/g, ""), 10);
    if (Object.keys(body).length === 0) return;
    resetMut.mutate(body);
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <CreditCard className="h-5 w-5 text-primary" />
          <div>
            <h1 className="text-2xl font-mono font-bold text-foreground">FR24 API Credit Usage</h1>
            <p className="text-sm text-muted-foreground font-mono">Flightradar24 API credit consumption tracker</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="font-mono text-xs h-7 gap-1.5" onClick={() => queryClient.invalidateQueries({ queryKey: ["fr24-usage-summary"] })}>
            <RefreshCw className="h-3 w-3" />Refresh
          </Button>
          <Button variant="outline" size="sm" className="font-mono text-xs h-7 gap-1.5" onClick={handleExport}>
            <Download className="h-3 w-3" />Export CSV
          </Button>
        </div>
      </div>

      {/* Warning banners */}
      {s?.warnings.remainingLow && (
        <div className="flex items-center gap-2 rounded-md border border-red-500/30 bg-red-500/10 px-4 py-3">
          <AlertTriangle className="h-4 w-4 text-red-400 shrink-0" />
          <p className="text-sm font-mono text-red-300">
            Low credit balance — <strong>{fmt(s.remaining)}</strong> credits remaining ({s.remainingPct}% of starting balance).
            Threshold: {fmt(s.warnings.remainingWarningThreshold)}.
          </p>
        </div>
      )}
      {s?.warnings.dailyExceeded && (
        <div className="flex items-center gap-2 rounded-md border border-amber-500/30 bg-amber-500/10 px-4 py-3">
          <AlertTriangle className="h-4 w-4 text-amber-400 shrink-0" />
          <p className="text-sm font-mono text-amber-300">
            Daily limit exceeded — <strong>{fmt(s.todayUsed)}</strong> credits used today.
            Threshold: {fmt(s.warnings.dailyWarningThreshold)}.
          </p>
        </div>
      )}

      {/* Summary cards */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {[
          { label: "Starting Balance", value: s ? fmt(s.startingCredits) : null, sub: "configured total", color: "text-foreground" },
          { label: "Credits Used", value: s ? fmt(s.totalUsed) : null, sub: `${s ? (100 - s.remainingPct).toFixed(1) : "—"}% consumed`, color: "text-amber-400" },
          { label: "Remaining", value: s ? fmt(s.remaining) : null, sub: `${s ? s.remainingPct.toFixed(1) : "—"}% left`, color: s && s.warnings.remainingLow ? "text-red-400" : "text-emerald-400" },
          { label: "Today", value: s ? fmt(s.todayUsed) : null, sub: `of ${s ? fmt(s.warnings.dailyWarningThreshold) : "—"} daily limit`, color: s && s.warnings.dailyExceeded ? "text-red-400" : "text-sky-400" },
        ].map((c) => (
          <Card key={c.label} className="bg-card border-card-border">
            <CardContent className="p-4">
              <div className="text-[10px] font-mono text-muted-foreground uppercase tracking-wider mb-1">{c.label}</div>
              {c.value === null ? (
                <Skeleton className="h-7 w-24 mt-0.5" />
              ) : (
                <>
                  <div className={`text-2xl font-mono font-bold ${c.color}`}>{c.value}</div>
                  <div className="text-[10px] font-mono text-muted-foreground mt-1">{c.sub}</div>
                </>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Credit consumption bar */}
      <Card className="bg-card border-card-border">
        <CardContent className="px-4 py-4 space-y-2">
          <div className="flex items-center justify-between text-xs font-mono text-muted-foreground">
            <span>Credit Consumption</span>
            <span>{s ? `${fmt(s.totalUsed)} / ${fmt(s.startingCredits)}` : "—"}</span>
          </div>
          {s ? <CreditBar used={s.totalUsed} total={s.startingCredits} /> : <Skeleton className="h-2 w-full" />}
          <div className="flex items-center justify-between text-[10px] font-mono text-muted-foreground">
            <span>Total Calls: {s ? fmt(s.totalCalls) : "—"} &nbsp;·&nbsp; Success: {s ? fmt(s.successCount) : "—"} &nbsp;·&nbsp; Failed: {s ? fmt(s.failCount) : "—"}</span>
            {s && s.warnings.remainingLow && <Badge variant="outline" className="text-[9px] border-red-500/30 text-red-400 bg-red-500/10">LOW BALANCE</Badge>}
            {s && !s.warnings.remainingLow && s.remaining > 0 && <Badge variant="outline" className="text-[9px] border-emerald-500/30 text-emerald-400 bg-emerald-500/10">OK</Badge>}
          </div>
        </CardContent>
      </Card>

      {/* Daily usage table */}
      <Card className="bg-card border-card-border">
        <CardHeader className="pb-2 pt-4 px-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <BarChart2 className="h-4 w-4 text-muted-foreground" />
              <CardTitle className="text-xs font-mono uppercase tracking-wider text-muted-foreground">Daily Credit Usage</CardTitle>
            </div>
            <div className="flex items-center gap-1">
              {[7, 14, 30, 60, 90].map((d) => (
                <Button key={d} variant={days === d ? "default" : "outline"} size="sm" className="font-mono text-[10px] h-6 px-2" onClick={() => setDays(d)}>
                  {d}d
                </Button>
              ))}
            </div>
          </div>
        </CardHeader>
        <CardContent className="px-0 pb-0">
          <div className="overflow-x-auto">
            <table className="w-full text-xs font-mono">
              <thead>
                <tr className="border-b border-border text-muted-foreground">
                  {["Date", "Credits Used", "API Calls", "Successes", "Failures", "Endpoints"].map((h) => (
                    <th key={h} className="px-3 py-2 text-left uppercase tracking-wider text-[10px] whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {dailyQ.isLoading ? (
                  Array.from({ length: 6 }).map((_, i) => (
                    <tr key={i} className="border-b border-border/50">
                      {Array.from({ length: 6 }).map((_, j) => <td key={j} className="px-3 py-2"><Skeleton className="h-3 w-16" /></td>)}
                    </tr>
                  ))
                ) : !dailyQ.data?.rows.length ? (
                  <tr><td colSpan={6} className="px-6 py-8 text-center text-muted-foreground text-xs">No usage logged yet — make an FR24 test or sync call to see data here.</td></tr>
                ) : dailyQ.data.rows.map((row) => (
                  <tr key={row.date} className="border-b border-border/40 hover:bg-secondary/40 transition-colors">
                    <td className="px-3 py-2 font-bold text-foreground">{row.date}</td>
                    <td className="px-3 py-2 text-amber-400">{fmt(row.credits)}</td>
                    <td className="px-3 py-2">{fmt(row.calls)}</td>
                    <td className="px-3 py-2 text-emerald-400">{fmt(row.successes)}</td>
                    <td className="px-3 py-2 text-red-400">{row.failures > 0 ? fmt(row.failures) : <span className="text-muted-foreground/40">0</span>}</td>
                    <td className="px-3 py-2 text-muted-foreground text-[10px]">
                      {Object.entries(row.endpoints).map(([ep, creds]) => (
                        <div key={ep}><code className="text-foreground/70">{ep.split("/").slice(-2).join("/")}</code>: {creds}</div>
                      ))}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Settings & Balance */}
      <Card className="bg-card border-card-border">
        <CardHeader className="pb-2 pt-4 px-4">
          <div className="flex items-center gap-2">
            <Settings className="h-4 w-4 text-muted-foreground" />
            <CardTitle className="text-xs font-mono uppercase tracking-wider text-muted-foreground">Credit Balance & Warning Thresholds</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="px-4 pb-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <div className="space-y-1.5">
              <Label className="text-xs font-mono uppercase text-muted-foreground">Starting Credits Balance</Label>
              <Input
                className="font-mono text-sm bg-background"
                placeholder={s ? fmt(s.startingCredits) : "1,210,000"}
                value={newBalance}
                onChange={(e) => setNewBalance(e.target.value)}
              />
              <p className="text-[10px] font-mono text-muted-foreground">Current: {s ? fmt(s.startingCredits) : "—"}</p>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-mono uppercase text-muted-foreground">Daily Warning Threshold</Label>
              <Input
                className="font-mono text-sm bg-background"
                placeholder={s ? fmt(s.warnings.dailyWarningThreshold) : "50,000"}
                value={dailyWarn}
                onChange={(e) => setDailyWarn(e.target.value)}
              />
              <p className="text-[10px] font-mono text-muted-foreground">Credits/day before alert. Current: {s ? fmt(s.warnings.dailyWarningThreshold) : "—"}</p>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-mono uppercase text-muted-foreground">Remaining Balance Warning</Label>
              <Input
                className="font-mono text-sm bg-background"
                placeholder={s ? fmt(s.warnings.remainingWarningThreshold) : "100,000"}
                value={remainWarn}
                onChange={(e) => setRemainWarn(e.target.value)}
              />
              <p className="text-[10px] font-mono text-muted-foreground">Alert when below this. Current: {s ? fmt(s.warnings.remainingWarningThreshold) : "—"}</p>
            </div>
          </div>
          <Button
            className="mt-4 font-mono text-xs"
            disabled={resetMut.isPending || (!newBalance && !dailyWarn && !remainWarn)}
            onClick={handleSaveSettings}
          >
            {resetMut.isPending ? "Saving..." : "Save Credit Settings"}
          </Button>
        </CardContent>
      </Card>

      {/* Raw call log */}
      <Card className="bg-card border-card-border">
        <CardHeader className="pb-2 pt-4 px-4">
          <div className="flex items-center gap-2">
            <Activity className="h-4 w-4 text-muted-foreground" />
            <CardTitle className="text-xs font-mono uppercase tracking-wider text-muted-foreground">
              Raw API Call Log {logQ.data ? `(${fmt(logQ.data.total)} total)` : ""}
            </CardTitle>
          </div>
        </CardHeader>
        <CardContent className="px-0 pb-0">
          <div className="overflow-x-auto">
            <table className="w-full text-xs font-mono">
              <thead>
                <tr className="border-b border-border text-muted-foreground">
                  {["Timestamp", "Endpoint", "Purpose", "Result", "HTTP", "Credits", "Response Ms", "Error"].map((h) => (
                    <th key={h} className="px-3 py-2 text-left uppercase tracking-wider text-[10px] whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {logQ.isLoading ? (
                  Array.from({ length: 6 }).map((_, i) => (
                    <tr key={i} className="border-b border-border/50">
                      {Array.from({ length: 8 }).map((_, j) => <td key={j} className="px-3 py-2"><Skeleton className="h-3 w-14" /></td>)}
                    </tr>
                  ))
                ) : !logQ.data?.logs.length ? (
                  <tr><td colSpan={8} className="px-6 py-8 text-center text-muted-foreground text-xs">No API calls logged yet.</td></tr>
                ) : logQ.data.logs.map((l) => (
                  <tr key={l.id} className="border-b border-border/40 hover:bg-secondary/40 transition-colors">
                    <td className="px-3 py-2 whitespace-nowrap text-muted-foreground">{fmtTime(l.calledAt)}</td>
                    <td className="px-3 py-2 text-[10px] text-foreground/70 max-w-[140px] truncate" title={l.endpoint}>{l.endpoint.split("/").slice(-2).join("/")}</td>
                    <td className="px-3 py-2 whitespace-nowrap">
                      <Badge variant="outline" className="text-[9px] font-mono uppercase px-1 py-0">{l.purpose}</Badge>
                    </td>
                    <td className="px-3 py-2">
                      {l.success
                        ? <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                        : <AlertTriangle className="h-3.5 w-3.5 text-red-400" />}
                    </td>
                    <td className="px-3 py-2 text-muted-foreground">{l.httpStatus ?? "—"}</td>
                    <td className="px-3 py-2 text-amber-400 font-bold">{l.estimatedCredits}</td>
                    <td className="px-3 py-2 text-muted-foreground">{l.responseTimeMs != null ? `${l.responseTimeMs}ms` : "—"}</td>
                    <td className="px-3 py-2 text-red-400/80 text-[10px] max-w-[180px] truncate" title={l.errorMessage ?? ""}>{l.errorMessage ?? ""}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {logQ.data && logQ.data.total > LOG_LIMIT && (
            <div className="flex items-center justify-between px-4 py-3 border-t border-border">
              <span className="text-[10px] font-mono text-muted-foreground">
                {logOffset + 1}–{Math.min(logOffset + LOG_LIMIT, logQ.data.total)} of {fmt(logQ.data.total)}
              </span>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" className="font-mono text-xs h-7" disabled={logOffset === 0} onClick={() => setLogOffset((o) => Math.max(0, o - LOG_LIMIT))}>Prev</Button>
                <Button size="sm" variant="outline" className="font-mono text-xs h-7" disabled={logOffset + LOG_LIMIT >= logQ.data.total} onClick={() => setLogOffset((o) => o + LOG_LIMIT)}>Next</Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
