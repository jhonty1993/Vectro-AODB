import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription,
} from "@/components/ui/sheet";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Search, FileStack, Pause, Trash2, CheckCircle2, History, AlertTriangle } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { BillingShell } from "@/components/billing-shell";
import {
  apiGet, apiSend, formatCAD, formatDateTime,
  CHARGE_STATUS_STYLE, ALERT_LEVEL_STYLE, ALERT_CODE_LABEL,
  dataSourceStyle, dataSourceLabel,
  type BillableCharge, type ChargeDetail, type BillingCustomer,
} from "@/lib/billing-api";

const STATUSES = ["pending", "held", "ready", "invoiced", "discarded", "credited"];

export default function BillingCharges() {
  const qc = useQueryClient();
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [openId, setOpenId] = useState<string | null>(null);

  const qs = statusFilter === "all" ? "" : `?status=${statusFilter}`;
  const { data: charges, isLoading } = useQuery({
    queryKey: ["billing", "charges", statusFilter],
    queryFn: () => apiGet<BillableCharge[]>(`/billing/charges${qs}`),
  });
  const { data: customers } = useQuery({
    queryKey: ["billing", "customers"],
    queryFn: () => apiGet<BillingCustomer[]>("/billing/customers"),
  });

  const customerName = (id: string | null) =>
    id ? customers?.find((c) => c.id === id)?.name ?? id : "—";

  const filtered = (charges ?? []).filter((c) =>
    !search || c.description.toLowerCase().includes(search.toLowerCase()),
  );

  const selectedReady = filtered.filter((c) => selected.has(c.id) && c.status === "ready" && c.customerId);

  const createBatch = useMutation({
    mutationFn: () =>
      apiSend<{ batchNumber: string; invoiceCount: number }>("/billing/invoice-batches", "POST", {
        chargeIds: [...selected],
      }),
    onSuccess: (r) => {
      toast({ title: "Batch created", description: `${r.batchNumber} — ${r.invoiceCount} invoice(s).` });
      setSelected(new Set());
      qc.invalidateQueries({ queryKey: ["billing"] });
    },
    onError: (e: Error) => toast({ title: "Batch failed", description: e.message, variant: "destructive" }),
  });

  function toggle(id: string) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }

  return (
    <BillingShell
      title="Billable Charges"
      description="Auto-rated landing & parking charges with provenance and review workflow."
      actions={
        <Button
          size="sm"
          disabled={selectedReady.length === 0 || createBatch.isPending}
          onClick={() => createBatch.mutate()}
        >
          <FileStack className="h-3.5 w-3.5 mr-1.5" />
          Create batch ({selectedReady.length} ready)
        </Button>
      }
    >
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-muted-foreground" />
          <Input
            placeholder="Search description…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-8 w-64"
          />
        </div>
        <Select value={statusFilter} onValueChange={(v) => { setStatusFilter(v); setSelected(new Set()); }}>
          <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem>
            {STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
          </SelectContent>
        </Select>
        <span className="text-xs text-muted-foreground font-mono ml-auto">{filtered.length} charges</span>
      </div>

      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-4 space-y-2">{Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-10" />)}</div>
          ) : filtered.length === 0 ? (
            <p className="text-sm text-muted-foreground p-8 text-center">No charges match.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-8"></TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead>Source</TableHead>
                  <TableHead className="text-right">Qty</TableHead>
                  <TableHead className="text-right">Rate</TableHead>
                  <TableHead className="text-right">Amount</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Alert</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((c) => (
                  <TableRow key={c.id} className="cursor-pointer" onClick={() => setOpenId(c.id)}>
                    <TableCell onClick={(e) => e.stopPropagation()}>
                      <Checkbox checked={selected.has(c.id)} onCheckedChange={() => toggle(c.id)} />
                    </TableCell>
                    <TableCell className="max-w-[280px] truncate text-sm">{c.description}</TableCell>
                    <TableCell className="text-sm">{customerName(c.customerId)}</TableCell>
                    <TableCell>
                      {c.movementDataSource ? (
                        <Badge variant="outline" className={`font-mono text-[10px] ${dataSourceStyle(c.movementDataSource)}`}>
                          {dataSourceLabel(c.movementDataSource)}
                        </Badge>
                      ) : (
                        <span className="text-muted-foreground text-xs">—</span>
                      )}
                    </TableCell>
                    <TableCell className="text-right font-mono text-xs">{c.quantity}</TableCell>
                    <TableCell className="text-right font-mono text-xs">{c.unitRate.toFixed(2)}</TableCell>
                    <TableCell className="text-right font-mono text-sm">{formatCAD(c.amount, c.currency)}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className={`font-mono text-[10px] ${CHARGE_STATUS_STYLE[c.status] ?? ""}`}>{c.status}</Badge>
                    </TableCell>
                    <TableCell>
                      {c.alertLevel !== "green" && (
                        <Badge variant="outline" className={`font-mono text-[10px] ${ALERT_LEVEL_STYLE[c.alertLevel] ?? ""}`}>{c.alertLevel}</Badge>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <ChargeDrawer chargeId={openId} onClose={() => setOpenId(null)} customerName={customerName} />
    </BillingShell>
  );
}

function ChargeDrawer({ chargeId, onClose, customerName }: {
  chargeId: string | null; onClose: () => void; customerName: (id: string | null) => string;
}) {
  const qc = useQueryClient();
  const [reason, setReason] = useState("");

  const { data: charge, isLoading } = useQuery({
    queryKey: ["billing", "charge", chargeId],
    queryFn: () => apiGet<ChargeDetail>(`/billing/charges/${chargeId}`),
    enabled: !!chargeId,
  });

  const action = useMutation({
    mutationFn: ({ kind, body }: { kind: string; body?: unknown }) =>
      apiSend<BillableCharge>(`/billing/charges/${chargeId}/${kind}`, "POST", body ?? {}),
    onSuccess: () => {
      setReason("");
      qc.invalidateQueries({ queryKey: ["billing"] });
      toast({ title: "Charge updated" });
    },
    onError: (e: Error) => toast({ title: "Action failed", description: e.message, variant: "destructive" }),
  });

  return (
    <Sheet open={!!chargeId} onOpenChange={(o) => !o && onClose()}>
      <SheetContent className="w-full sm:max-w-lg overflow-y-auto">
        {isLoading || !charge ? (
          <div className="space-y-3 mt-6">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-12" />)}</div>
        ) : (
          <>
            <SheetHeader>
              <SheetTitle className="font-mono">{charge.description}</SheetTitle>
              <SheetDescription>
                {customerName(charge.customerId)} · {charge.itemCode?.name ?? charge.itemCodeId}
              </SheetDescription>
            </SheetHeader>

            <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
              <Field label="Amount" value={formatCAD(charge.amount, charge.currency)} mono />
              <Field label="Status"><Badge variant="outline" className={`font-mono ${CHARGE_STATUS_STYLE[charge.status] ?? ""}`}>{charge.status}</Badge></Field>
              <Field label="Quantity" value={`${charge.quantity}`} mono />
              <Field label="Unit rate" value={charge.unitRate.toFixed(2)} mono />
              <Field label="Confidence" value={`${charge.confidenceScore}%`} mono />
              <Field label="Alert level"><Badge variant="outline" className={`font-mono ${ALERT_LEVEL_STYLE[charge.alertLevel] ?? ""}`}>{charge.alertLevel}</Badge></Field>
              <Field label="Rate rule" value={charge.rateRule?.name ?? "—"} />
              <Field label="Charge date" value={charge.chargeDate} mono />
            </div>

            {charge.movement && (
              <div className="mt-4 rounded-lg border border-border p-3 text-sm">
                <div className="flex items-center justify-between mb-1">
                  <div className="text-[11px] font-mono uppercase tracking-wider text-muted-foreground">Linked movement</div>
                  <Badge variant="outline" className={`font-mono text-[10px] ${dataSourceStyle(charge.movement.dataSource)}`}>
                    {dataSourceLabel(charge.movement.dataSource)}
                  </Badge>
                </div>
                <div className="font-mono">{charge.movement.flightNumber} · {charge.movement.direction} · {charge.movement.origin}→{charge.movement.destination}</div>
                <div className="text-xs text-muted-foreground mt-0.5">{charge.movement.tailNumber ?? "no tail"} · {charge.movement.aircraftType ?? "unknown type"}</div>
                <div className="text-[11px] text-muted-foreground mt-1.5">Data originated from <span className="text-foreground">{dataSourceLabel(charge.movement.dataSource)}</span></div>
              </div>
            )}

            {charge.alerts.length > 0 && (
              <div className="mt-4">
                <div className="text-[11px] font-mono uppercase tracking-wider text-muted-foreground mb-2 flex items-center gap-1.5">
                  <AlertTriangle className="h-3.5 w-3.5" /> Alerts
                </div>
                <div className="space-y-1.5">
                  {charge.alerts.map((a) => (
                    <div key={a.id} className="flex items-start gap-2 text-sm">
                      <Badge variant="outline" className={`font-mono text-[10px] mt-0.5 ${ALERT_LEVEL_STYLE[a.level] ?? ""}`}>{a.level}</Badge>
                      <div>
                        <div className="text-foreground">{ALERT_CODE_LABEL[a.code] ?? a.code}</div>
                        <div className="text-xs text-muted-foreground">{a.message}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="mt-5 space-y-2">
              <div className="text-[11px] font-mono uppercase tracking-wider text-muted-foreground">Actions</div>
              <Textarea
                placeholder="Reason (required to hold or discard)…"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="h-16 text-sm"
              />
              <div className="flex flex-wrap gap-2">
                {charge.status !== "ready" && charge.status !== "invoiced" && (
                  <Button size="sm" onClick={() => action.mutate({ kind: "ready" })} disabled={action.isPending}>
                    <CheckCircle2 className="h-3.5 w-3.5 mr-1.5" /> Mark ready
                  </Button>
                )}
                {charge.status !== "held" && charge.status !== "invoiced" && (
                  <Button size="sm" variant="outline" disabled={!reason || action.isPending}
                    onClick={() => action.mutate({ kind: "hold", body: { reason } })}>
                    <Pause className="h-3.5 w-3.5 mr-1.5" /> Hold
                  </Button>
                )}
                {charge.status !== "discarded" && charge.status !== "invoiced" && (
                  <Button size="sm" variant="outline" disabled={!reason || action.isPending}
                    className="text-red-400 hover:text-red-300"
                    onClick={() => action.mutate({ kind: "discard", body: { reason } })}>
                    <Trash2 className="h-3.5 w-3.5 mr-1.5" /> Discard
                  </Button>
                )}
              </div>
            </div>

            <div className="mt-5">
              <div className="text-[11px] font-mono uppercase tracking-wider text-muted-foreground mb-2 flex items-center gap-1.5">
                <History className="h-3.5 w-3.5" /> Decision log
              </div>
              <div className="space-y-2 border-l border-border pl-3">
                {charge.decisions.map((d) => (
                  <div key={d.id} className="text-xs">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-foreground">{d.action}</span>
                      <span className="text-muted-foreground">{formatDateTime(d.createdAt)}</span>
                    </div>
                    <div className="text-muted-foreground">{d.detail}</div>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}

function Field({ label, value, children, mono }: { label: string; value?: string; children?: React.ReactNode; mono?: boolean }) {
  return (
    <div>
      <div className="text-[11px] font-mono uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className={`mt-0.5 ${mono ? "font-mono" : ""} text-foreground`}>{children ?? value}</div>
    </div>
  );
}
