import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Plus, Pencil } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { BillingShell } from "@/components/billing-shell";
import { apiGet, apiSend, type BillingCustomer } from "@/lib/billing-api";

const TYPES = ["airline", "handler", "ga", "cargo", "other"];
const empty = { code: "", name: "", type: "airline", iataCode: "", icaoCode: "", contactEmail: "", paymentTermsDays: 30, status: "active" };

export default function BillingCustomers() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<BillingCustomer | null>(null);
  const [form, setForm] = useState<Record<string, unknown>>(empty);

  const { data, isLoading } = useQuery({
    queryKey: ["billing", "customers"],
    queryFn: () => apiGet<BillingCustomer[]>("/billing/customers"),
  });

  const save = useMutation({
    mutationFn: () => {
      const body = { ...form, paymentTermsDays: Number(form.paymentTermsDays) || 30 };
      return editing
        ? apiSend(`/billing/customers/${editing.id}`, "PUT", body)
        : apiSend("/billing/customers", "POST", body);
    },
    onSuccess: () => {
      toast({ title: editing ? "Customer updated" : "Customer created" });
      setOpen(false);
      qc.invalidateQueries({ queryKey: ["billing", "customers"] });
    },
    onError: (e: Error) => toast({ title: "Save failed", description: e.message, variant: "destructive" }),
  });

  function openNew() { setEditing(null); setForm(empty); setOpen(true); }
  function openEdit(c: BillingCustomer) {
    setEditing(c);
    setForm({ code: c.code, name: c.name, type: c.type, iataCode: c.iataCode ?? "", icaoCode: c.icaoCode ?? "", contactEmail: c.contactEmail ?? "", paymentTermsDays: c.paymentTermsDays, status: c.status });
    setOpen(true);
  }

  return (
    <BillingShell
      title="Customers"
      description="Airlines, handlers and other billable accounts."
      actions={<Button size="sm" onClick={openNew}><Plus className="h-3.5 w-3.5 mr-1.5" /> New customer</Button>}
    >
      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-4 space-y-2">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-10" />)}</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Code</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>IATA</TableHead>
                  <TableHead className="text-right">Terms</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="w-8"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {(data ?? []).map((c) => (
                  <TableRow key={c.id}>
                    <TableCell className="font-mono text-sm">{c.code}</TableCell>
                    <TableCell className="text-sm">{c.name}</TableCell>
                    <TableCell className="text-sm capitalize">{c.type}</TableCell>
                    <TableCell className="font-mono text-sm">{c.iataCode ?? "—"}</TableCell>
                    <TableCell className="text-right font-mono text-sm">{c.paymentTermsDays}d</TableCell>
                    <TableCell><Badge variant="outline" className="font-mono text-[10px] capitalize">{c.status}</Badge></TableCell>
                    <TableCell>
                      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openEdit(c)}><Pencil className="h-3.5 w-3.5" /></Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editing ? "Edit customer" : "New customer"}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-3">
            <FormField label="Code"><Input value={form.code as string} onChange={(e) => setForm({ ...form, code: e.target.value })} /></FormField>
            <FormField label="Type">
              <Select value={form.type as string} onValueChange={(v) => setForm({ ...form, type: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{TYPES.map((t) => <SelectItem key={t} value={t} className="capitalize">{t}</SelectItem>)}</SelectContent>
              </Select>
            </FormField>
            <FormField label="Name" full><Input value={form.name as string} onChange={(e) => setForm({ ...form, name: e.target.value })} /></FormField>
            <FormField label="IATA"><Input value={form.iataCode as string} onChange={(e) => setForm({ ...form, iataCode: e.target.value })} /></FormField>
            <FormField label="ICAO"><Input value={form.icaoCode as string} onChange={(e) => setForm({ ...form, icaoCode: e.target.value })} /></FormField>
            <FormField label="Contact email" full><Input value={form.contactEmail as string} onChange={(e) => setForm({ ...form, contactEmail: e.target.value })} /></FormField>
            <FormField label="Payment terms (days)"><Input type="number" value={form.paymentTermsDays as number} onChange={(e) => setForm({ ...form, paymentTermsDays: e.target.value })} /></FormField>
            <FormField label="Status">
              <Select value={form.status as string} onValueChange={(v) => setForm({ ...form, status: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="active">active</SelectItem><SelectItem value="inactive">inactive</SelectItem></SelectContent>
              </Select>
            </FormField>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={() => save.mutate()} disabled={save.isPending || !form.code || !form.name}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </BillingShell>
  );
}

function FormField({ label, children, full }: { label: string; children: React.ReactNode; full?: boolean }) {
  return (
    <div className={full ? "col-span-2" : ""}>
      <Label className="text-[11px] font-mono uppercase tracking-wider text-muted-foreground">{label}</Label>
      <div className="mt-1">{children}</div>
    </div>
  );
}
