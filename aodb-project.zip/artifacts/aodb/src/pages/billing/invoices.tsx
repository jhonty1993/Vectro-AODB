import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription,
} from "@/components/ui/sheet";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { BillingShell } from "@/components/billing-shell";
import {
  apiGet, formatCAD, formatDate,
  type InvoiceBatch, type InvoiceBatchDetail, type BillingCustomer,
} from "@/lib/billing-api";

const BATCH_STATUS: Record<string, string> = {
  open: "bg-blue-500/20 text-blue-300 border-blue-500/30",
  finalized: "bg-emerald-500/20 text-emerald-300 border-emerald-500/30",
  exported: "bg-purple-500/20 text-purple-300 border-purple-500/30",
};

export default function BillingInvoices() {
  const [openId, setOpenId] = useState<string | null>(null);
  const { data: batches, isLoading } = useQuery({
    queryKey: ["billing", "invoice-batches"],
    queryFn: () => apiGet<InvoiceBatch[]>("/billing/invoice-batches"),
  });

  return (
    <BillingShell title="Invoice Batches" description="Finalized invoice runs grouped per customer.">
      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-4 space-y-2">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-10" />)}</div>
          ) : (batches ?? []).length === 0 ? (
            <p className="text-sm text-muted-foreground p-8 text-center">No invoice batches yet. Create one from the Charges page.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Batch</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Invoices</TableHead>
                  <TableHead className="text-right">Charges</TableHead>
                  <TableHead className="text-right">Total</TableHead>
                  <TableHead>Created</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {batches!.map((b) => (
                  <TableRow key={b.id} className="cursor-pointer" onClick={() => setOpenId(b.id)}>
                    <TableCell className="font-mono text-sm">{b.batchNumber}</TableCell>
                    <TableCell><Badge variant="outline" className={`font-mono text-[10px] ${BATCH_STATUS[b.status] ?? ""}`}>{b.status}</Badge></TableCell>
                    <TableCell className="text-right font-mono text-sm">{b.invoiceCount}</TableCell>
                    <TableCell className="text-right font-mono text-sm">{b.chargeCount}</TableCell>
                    <TableCell className="text-right font-mono text-sm">{formatCAD(b.totalAmount, b.currency)}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">{formatDate(b.createdAt)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
      <BatchDrawer batchId={openId} onClose={() => setOpenId(null)} />
    </BillingShell>
  );
}

function BatchDrawer({ batchId, onClose }: { batchId: string | null; onClose: () => void }) {
  const { data: batch, isLoading } = useQuery({
    queryKey: ["billing", "invoice-batch", batchId],
    queryFn: () => apiGet<InvoiceBatchDetail>(`/billing/invoice-batches/${batchId}`),
    enabled: !!batchId,
  });
  const { data: customers } = useQuery({
    queryKey: ["billing", "customers"],
    queryFn: () => apiGet<BillingCustomer[]>("/billing/customers"),
  });
  const customerName = (id: string) => customers?.find((c) => c.id === id)?.name ?? id;

  return (
    <Sheet open={!!batchId} onOpenChange={(o) => !o && onClose()}>
      <SheetContent className="w-full sm:max-w-xl overflow-y-auto">
        {isLoading || !batch ? (
          <div className="space-y-3 mt-6">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-12" />)}</div>
        ) : (
          <>
            <SheetHeader>
              <SheetTitle className="font-mono">{batch.batchNumber}</SheetTitle>
              <SheetDescription>
                {batch.invoiceCount} invoice(s) · {formatCAD(batch.totalAmount, batch.currency)} · {batch.status}
              </SheetDescription>
            </SheetHeader>
            <div className="mt-4 space-y-4">
              {batch.invoices.map((inv) => (
                <div key={inv.id} className="rounded-lg border border-border p-3">
                  <div className="flex items-center justify-between">
                    <div className="font-mono text-sm">{inv.invoiceNumber}</div>
                    <Badge variant="outline" className="font-mono text-[10px]">{inv.status}</Badge>
                  </div>
                  <div className="text-xs text-muted-foreground mt-0.5">
                    {customerName(inv.customerId)} · due {formatDate(inv.dueDate)}
                  </div>
                  <table className="w-full mt-2 text-xs">
                    <tbody>
                      {inv.lines.map((l) => (
                        <tr key={l.id} className="border-t border-border/50">
                          <td className="py-1 pr-2 text-muted-foreground">{l.description}</td>
                          <td className="py-1 text-right font-mono">{formatCAD(l.amount, inv.currency)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  <div className="mt-2 flex justify-end gap-4 text-xs font-mono">
                    <span className="text-muted-foreground">Tax {formatCAD(inv.taxAmount, inv.currency)}</span>
                    <span className="text-foreground font-bold">Total {formatCAD(inv.total, inv.currency)}</span>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}
