import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { BillingShell } from "@/components/billing-shell";
import {
  apiGet, formatDateTime,
  type ParkingStay, type BillingCustomer,
} from "@/lib/billing-api";

const STATUS: Record<string, string> = {
  active: "bg-blue-500/20 text-blue-300 border-blue-500/30",
  closed: "bg-slate-500/20 text-slate-300 border-slate-500/30",
  charged: "bg-emerald-500/20 text-emerald-300 border-emerald-500/30",
};

function hm(mins: number): string {
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return h ? `${h}h ${m}m` : `${m}m`;
}

export default function BillingParking() {
  const { data, isLoading } = useQuery({
    queryKey: ["billing", "parking"],
    queryFn: () => apiGet<ParkingStay[]>("/billing/parking"),
  });
  const { data: customers } = useQuery({
    queryKey: ["billing", "customers"],
    queryFn: () => apiGet<BillingCustomer[]>("/billing/customers"),
  });
  const customerName = (id: string | null) => (id ? customers?.find((c) => c.id === id)?.name ?? id : "—");

  return (
    <BillingShell title="Parking Stays" description="Apron/stand occupancy with chargeable duration beyond the free period.">
      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-4 space-y-2">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-10" />)}</div>
          ) : (data ?? []).length === 0 ? (
            <p className="text-sm text-muted-foreground p-8 text-center">No parking stays recorded.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Tail</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead>Stand</TableHead>
                  <TableHead>Arrival</TableHead>
                  <TableHead className="text-right">Duration</TableHead>
                  <TableHead className="text-right">Chargeable</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data!.map((p) => (
                  <TableRow key={p.id}>
                    <TableCell className="font-mono text-sm">{p.tailNumber ?? "—"}</TableCell>
                    <TableCell className="text-sm">{customerName(p.customerId)}</TableCell>
                    <TableCell className="font-mono text-sm">{p.stand ?? "—"}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">{formatDateTime(p.arrivalTime)}</TableCell>
                    <TableCell className="text-right font-mono text-sm">{hm(p.durationMinutes)}</TableCell>
                    <TableCell className="text-right font-mono text-sm">{p.chargeableMinutes ? hm(p.chargeableMinutes) : "free"}</TableCell>
                    <TableCell><Badge variant="outline" className={`font-mono text-[10px] ${STATUS[p.status] ?? ""}`}>{p.status}</Badge></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </BillingShell>
  );
}
