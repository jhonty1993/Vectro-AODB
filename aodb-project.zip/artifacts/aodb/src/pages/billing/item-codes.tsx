import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Plus, Pencil } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { BillingShell } from "@/components/billing-shell";
import { apiGet, apiSend, type ItemCode } from "@/lib/billing-api";

const CATEGORIES = ["landing", "parking", "passenger", "terminal", "security", "other"];
const UNITS = ["per_mtow_tonne", "per_pax", "per_stay", "per_quarter_hour", "flat"];
const empty = { code: "", name: "", category: "other", unit: "flat", glAccount: "", taxable: true, active: true };

export default function BillingItemCodes() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<ItemCode | null>(null);
  const [form, setForm] = useState<Record<string, unknown>>(empty);

  const { data, isLoading } = useQuery({
    queryKey: ["billing", "item-codes"],
    queryFn: () => apiGet<ItemCode[]>("/billing/item-codes"),
  });

  const save = useMutation({
    mutationFn: () =>
      editing
        ? apiSend(`/billing/item-codes/${editing.id}`, "PUT", form)
        : apiSend("/billing/item-codes", "POST", form),
    onSuccess: () => {
      toast({ title: editing ? "Item code updated" : "Item code created" });
      setOpen(false);
      qc.invalidateQueries({ queryKey: ["billing", "item-codes"] });
    },
    onError: (e: Error) => toast({ title: "Save failed", description: e.message, variant: "destructive" }),
  });

  function openNew() { setEditing(null); setForm(empty); setOpen(true); }
  function openEdit(c: ItemCode) {
    setEditing(c);
    setForm({ code: c.code, name: c.name, category: c.category, unit: c.unit, glAccount: c.glAccount ?? "", taxable: c.taxable, active: c.active });
    setOpen(true);
  }

  return (
    <BillingShell
      title="Item Codes"
      description="Chargeable GL line definitions used by rate rules."
      actions={<Button size="sm" onClick={openNew}><Plus className="h-3.5 w-3.5 mr-1.5" /> New item code</Button>}
    >
      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-4 space-y-2">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-10" />)}</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Code</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Unit</TableHead>
                  <TableHead>GL</TableHead>
                  <TableHead>Tax</TableHead>
                  <TableHead className="w-8"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {(data ?? []).map((c) => (
                  <TableRow key={c.id}>
                    <TableCell className="font-mono text-sm">{c.code}</TableCell>
                    <TableCell className="text-sm">{c.name}</TableCell>
                    <TableCell className="text-sm capitalize">{c.category}</TableCell>
                    <TableCell className="font-mono text-xs">{c.unit}</TableCell>
                    <TableCell className="font-mono text-sm">{c.glAccount ?? "—"}</TableCell>
                    <TableCell><Badge variant="outline" className="font-mono text-[10px]">{c.taxable ? "GST" : "exempt"}</Badge></TableCell>
                    <TableCell><Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openEdit(c)}><Pencil className="h-3.5 w-3.5" /></Button></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editing ? "Edit item code" : "New item code"}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-3">
            <Fld label="Code"><Input value={form.code as string} onChange={(e) => setForm({ ...form, code: e.target.value })} /></Fld>
            <Fld label="GL account"><Input value={form.glAccount as string} onChange={(e) => setForm({ ...form, glAccount: e.target.value })} /></Fld>
            <Fld label="Name" full><Input value={form.name as string} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Fld>
            <Fld label="Category">
              <Select value={form.category as string} onValueChange={(v) => setForm({ ...form, category: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{CATEGORIES.map((t) => <SelectItem key={t} value={t} className="capitalize">{t}</SelectItem>)}</SelectContent>
              </Select>
            </Fld>
            <Fld label="Unit">
              <Select value={form.unit as string} onValueChange={(v) => setForm({ ...form, unit: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{UNITS.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
              </Select>
            </Fld>
            <Fld label="Taxable">
              <Select value={String(form.taxable)} onValueChange={(v) => setForm({ ...form, taxable: v === "true" })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="true">GST 5%</SelectItem><SelectItem value="false">Exempt</SelectItem></SelectContent>
              </Select>
            </Fld>
            <Fld label="Active">
              <Select value={String(form.active)} onValueChange={(v) => setForm({ ...form, active: v === "true" })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="true">active</SelectItem><SelectItem value="false">inactive</SelectItem></SelectContent>
              </Select>
            </Fld>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={() => save.mutate()} disabled={save.isPending || !form.code || !form.name}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </BillingShell>
  );
}

function Fld({ label, children, full }: { label: string; children: React.ReactNode; full?: boolean }) {
  return (
    <div className={full ? "col-span-2" : ""}>
      <Label className="text-[11px] font-mono uppercase tracking-wider text-muted-foreground">{label}</Label>
      <div className="mt-1">{children}</div>
    </div>
  );
}
