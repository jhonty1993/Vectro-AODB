import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from "recharts";
import {
  Banknote, FileText, AlertTriangle, Users, CheckCircle2, RefreshCw, Layers, ArrowRight,
} from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { BillingShell } from "@/components/billing-shell";
import {
  apiGet, apiSend, formatCAD, ALERT_LEVEL_STYLE, ALERT_CODE_LABEL, CHARGE_STATUS_STYLE,
  type BillingDashboard,
} from "@/lib/billing-api";

function Stat({ icon: Icon, label, value, sub, tone }: {
  icon: React.ElementType; label: string; value: string; sub?: string; tone?: string;
}) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-mono uppercase tracking-wider text-muted-foreground">{label}</span>
          <Icon className={`h-4 w-4 ${tone ?? "text-muted-foreground"}`} />
        </div>
        <div className="mt-2 text-2xl font-bold font-mono text-foreground">{value}</div>
        {sub && <div className="mt-0.5 text-[11px] text-muted-foreground">{sub}</div>}
      </CardContent>
    </Card>
  );
}

export default function BillingDashboard() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["billing", "dashboard"],
    queryFn: () => apiGet<BillingDashboard>("/billing/dashboard"),
    refetchInterval: 30_000,
  });

  const rateAll = useMutation({
    mutationFn: () => apiSend<{ created: number; skipped: number }>("/billing/rate-all", "POST", {}),
    onSuccess: (r) => {
      toast({ title: "Rating complete", description: `${r.created} new charge(s) created, ${r.skipped} already rated.` });
      qc.invalidateQueries({ queryKey: ["billing"] });
    },
    onError: (e: Error) => toast({ title: "Rating failed", description: e.message, variant: "destructive" }),
  });

  const t = data?.totals;
  const cur = data?.currency ?? "CAD";

  const statusData = data
    ? Object.entries(data.byStatus).map(([status, v]) => ({ status, amount: v.amount, count: v.count }))
    : [];
  const openAlerts = data ? Object.entries(data.openAlertCodes).sort((a, b) => b[1] - a[1]) : [];

  return (
    <BillingShell
      title="Billing Dashboard"
      description="Airport revenue operations — landing, parking, terminal & recurring charges."
      actions={
        <Button size="sm" onClick={() => rateAll.mutate()} disabled={rateAll.isPending}>
          <RefreshCw className={`h-3.5 w-3.5 mr-1.5 ${rateAll.isPending ? "animate-spin" : ""}`} />
          Rate all movements
        </Button>
      }
    >
      {isLoading || !t ? (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-24" />)}
        </div>
      ) : (
        <>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <Stat icon={Banknote} label="Ready to invoice" value={formatCAD(t.readyAmount, cur)} sub={`${data.byStatus.ready?.count ?? 0} charges`} tone="text-blue-400" />
            <Stat icon={CheckCircle2} label="Invoiced" value={formatCAD(t.invoicedAmount, cur)} sub={`${data.byStatus.invoiced?.count ?? 0} charges`} tone="text-emerald-400" />
            <Stat icon={AlertTriangle} label="Needs review" value={String(t.blockedCount + t.unmappedCount)} sub={`${t.unmappedCount} unmapped · ${t.blockedCount} held/pending`} tone="text-amber-400" />
            <Stat icon={Layers} label="Invoice batches" value={String(t.batches)} sub={`${t.activeRules} active rules`} tone="text-muted-foreground" />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">
            <Card className="lg:col-span-2">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-mono uppercase tracking-wider text-muted-foreground">Charges by status</CardTitle>
              </CardHeader>
              <CardContent>
                {statusData.length === 0 ? (
                  <p className="text-sm text-muted-foreground py-8 text-center">No charges yet.</p>
                ) : (
                  <ResponsiveContainer width="100%" height={240}>
                    <BarChart data={statusData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 20% 20%)" />
                      <XAxis dataKey="status" stroke="hsl(215 20% 65%)" fontSize={11} />
                      <YAxis stroke="hsl(215 20% 65%)" fontSize={11} />
                      <Tooltip
                        contentStyle={{ background: "hsl(220 20% 12%)", border: "1px solid hsl(220 20% 24%)", borderRadius: 8, fontSize: 12 }}
                        formatter={(v: number, n) => (n === "amount" ? formatCAD(v, cur) : v)}
                      />
                      <Bar dataKey="amount" fill="hsl(217 91% 60%)" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-mono uppercase tracking-wider text-muted-foreground">Open alerts</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {openAlerts.length === 0 ? (
                  <p className="text-sm text-muted-foreground py-4">No open alerts.</p>
                ) : (
                  openAlerts.map(([code, count]) => (
                    <div key={code} className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">{ALERT_CODE_LABEL[code] ?? code}</span>
                      <Badge variant="outline" className="font-mono">{count}</Badge>
                    </div>
                  ))
                )}
                <div className="pt-2">
                  <Link href="/billing/charges">
                    <Button variant="outline" size="sm" className="w-full">
                      Review charges <ArrowRight className="h-3.5 w-3.5 ml-1.5" />
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-mono uppercase tracking-wider text-muted-foreground flex items-center gap-2">
                  <Users className="h-4 w-4" /> Top customers by revenue
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-1.5">
                {data.topCustomers.length === 0 ? (
                  <p className="text-sm text-muted-foreground py-4">No revenue yet.</p>
                ) : (
                  data.topCustomers.map((c) => (
                    <div key={c.customerId} className="flex items-center justify-between text-sm">
                      <span className={c.customerId === "UNMAPPED" ? "text-amber-400" : "text-foreground"}>{c.name}</span>
                      <span className="font-mono text-muted-foreground">{formatCAD(c.amount, cur)}</span>
                    </div>
                  ))
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-mono uppercase tracking-wider text-muted-foreground flex items-center gap-2">
                  <FileText className="h-4 w-4" /> Charge alert levels
                </CardTitle>
              </CardHeader>
              <CardContent className="flex flex-wrap gap-2">
                {Object.entries(data.alertBreakdown).length === 0 ? (
                  <p className="text-sm text-muted-foreground py-4">No charges.</p>
                ) : (
                  Object.entries(data.alertBreakdown).map(([level, count]) => (
                    <Badge key={level} variant="outline" className={`font-mono ${ALERT_LEVEL_STYLE[level] ?? ""}`}>
                      {level}: {count}
                    </Badge>
                  ))
                )}
                <div className="w-full pt-2 flex flex-wrap gap-2">
                  {statusData.map((s) => (
                    <Badge key={s.status} variant="outline" className={`font-mono ${CHARGE_STATUS_STYLE[s.status] ?? ""}`}>
                      {s.status}: {s.count}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </>
      )}
    </BillingShell>
  );
}
