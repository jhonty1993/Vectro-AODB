import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { BillingShell } from "@/components/billing-shell";
import {
  apiGet, formatCAD, formatDate,
  type RecurringContract, type BillingCustomer,
} from "@/lib/billing-api";

const STATUS: Record<string, string> = {
  active: "bg-emerald-500/20 text-emerald-300 border-emerald-500/30",
  paused: "bg-amber-500/20 text-amber-300 border-amber-500/30",
  ended: "bg-slate-500/20 text-slate-300 border-slate-500/30",
};

export default function BillingRecurring() {
  const { data, isLoading } = useQuery({
    queryKey: ["billing", "recurring"],
    queryFn: () => apiGet<RecurringContract[]>("/billing/recurring"),
  });
  const { data: customers } = useQuery({
    queryKey: ["billing", "customers"],
    queryFn: () => apiGet<BillingCustomer[]>("/billing/customers"),
  });
  const customerName = (id: string | null) => (id ? customers?.find((c) => c.id === id)?.name ?? id : "—");

  return (
    <BillingShell title="Recurring Contracts" description="Fixed periodic charges — office leases, counter rentals, signage.">
      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-4 space-y-2">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-10" />)}</div>
          ) : (data ?? []).length === 0 ? (
            <p className="text-sm text-muted-foreground p-8 text-center">No recurring contracts.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Description</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead>Frequency</TableHead>
                  <TableHead className="text-right">Amount</TableHead>
                  <TableHead>Next run</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data!.map((r) => (
                  <TableRow key={r.id}>
                    <TableCell className="text-sm">{r.description}</TableCell>
                    <TableCell className="text-sm">{customerName(r.customerId)}</TableCell>
                    <TableCell className="text-sm capitalize">{r.frequency}</TableCell>
                    <TableCell className="text-right font-mono text-sm">{formatCAD(r.amount, r.currency)}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">{r.nextRunDate ? formatDate(r.nextRunDate) : "—"}</TableCell>
                    <TableCell><Badge variant="outline" className={`font-mono text-[10px] ${STATUS[r.status] ?? ""}`}>{r.status}</Badge></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </BillingShell>
  );
}
