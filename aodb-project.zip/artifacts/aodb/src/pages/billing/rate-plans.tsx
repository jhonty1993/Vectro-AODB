import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { BillingShell } from "@/components/billing-shell";
import {
  apiGet, apiSend, formatDate,
  type RatePlan, type RateRule, type ItemCode,
} from "@/lib/billing-api";

const ROUTE_TYPES = ["any", "domestic", "transborder", "international"];
const ENGINE_TYPES = ["any", "TURBOFAN", "TURBOPROP", "PISTON"];
const CALC_METHODS = ["per_mtow_tonne", "flat", "per_pax", "per_quarter_hour"];
const DIRECTIONS = ["any", "ARR", "DEP"];

export default function BillingRatePlans() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<RateRule | null>(null);
  const [form, setForm] = useState<Record<string, unknown>>({});

  const { data: plans, isLoading: loadingPlans } = useQuery({
    queryKey: ["billing", "rate-plans"],
    queryFn: () => apiGet<RatePlan[]>("/billing/rate-plans"),
  });
  const { data: rules, isLoading: loadingRules } = useQuery({
    queryKey: ["billing", "rate-rules"],
    queryFn: () => apiGet<RateRule[]>("/billing/rate-rules"),
  });
  const { data: items } = useQuery({
    queryKey: ["billing", "item-codes"],
    queryFn: () => apiGet<ItemCode[]>("/billing/item-codes"),
  });

  const activePlan = plans?.find((p) => p.isDefault && p.status === "active") ?? plans?.[0];
  const itemName = (id: string) => items?.find((i) => i.id === id)?.code ?? id;

  const save = useMutation({
    mutationFn: () => {
      const body = {
        ...form,
        ratePlanId: editing?.ratePlanId ?? activePlan?.id,
        rateAmount: Number(form.rateAmount) || 0,
        priority: Number(form.priority) || 100,
        minCharge: form.minCharge ? Number(form.minCharge) : null,
        effectiveFrom: form.effectiveFrom || activePlan?.effectiveFrom || "2026-01-01",
      };
      return editing
        ? apiSend(`/billing/rate-rules/${editing.id}`, "PUT", body)
        : apiSend("/billing/rate-rules", "POST", body);
    },
    onSuccess: () => {
      toast({ title: editing ? "Rule updated" : "Rule created" });
      setOpen(false);
      qc.invalidateQueries({ queryKey: ["billing", "rate-rules"] });
    },
    onError: (e: Error) => toast({ title: "Save failed", description: e.message, variant: "destructive" }),
  });

  const remove = useMutation({
    mutationFn: (id: string) => apiSend(`/billing/rate-rules/${id}`, "DELETE"),
    onSuccess: () => { toast({ title: "Rule deleted" }); qc.invalidateQueries({ queryKey: ["billing", "rate-rules"] }); },
    onError: (e: Error) => toast({ title: "Delete failed", description: e.message, variant: "destructive" }),
  });

  function openNew() {
    setEditing(null);
    setForm({ name: "", routeType: "any", engineType: "any", direction: "any", calcMethod: "per_mtow_tonne", rateAmount: 0, priority: 100, minCharge: "", itemCodeId: items?.find((i) => i.category === "landing")?.id ?? items?.[0]?.id, effectiveFrom: activePlan?.effectiveFrom ?? "2026-01-01" });
    setOpen(true);
  }
  function openEdit(r: RateRule) {
    setEditing(r);
    setForm({ name: r.name, routeType: r.routeType, engineType: r.engineType, direction: r.direction, calcMethod: r.calcMethod, rateAmount: r.rateAmount, priority: r.priority, minCharge: r.minCharge ?? "", itemCodeId: r.itemCodeId, effectiveFrom: r.effectiveFrom });
    setOpen(true);
  }

  return (
    <BillingShell
      title="Rate Plans & Rules"
      description="Effective-dated tariff rules matched by route, engine and aircraft weight."
      actions={<Button size="sm" onClick={openNew} disabled={!activePlan}><Plus className="h-3.5 w-3.5 mr-1.5" /> New rule</Button>}
    >
      <Card>
        <CardHeader className="pb-2"><CardTitle className="text-sm font-mono uppercase tracking-wider text-muted-foreground">Rate plans</CardTitle></CardHeader>
        <CardContent className="p-0">
          {loadingPlans ? (
            <div className="p-4 space-y-2">{Array.from({ length: 2 }).map((_, i) => <Skeleton key={i} className="h-8" />)}</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow><TableHead>Name</TableHead><TableHead>Effective</TableHead><TableHead>Currency</TableHead><TableHead>Status</TableHead><TableHead>Default</TableHead></TableRow>
              </TableHeader>
              <TableBody>
                {(plans ?? []).map((p) => (
                  <TableRow key={p.id}>
                    <TableCell className="text-sm">{p.name}</TableCell>
                    <TableCell className="font-mono text-xs">{formatDate(p.effectiveFrom)}{p.effectiveTo ? ` → ${formatDate(p.effectiveTo)}` : ""}</TableCell>
                    <TableCell className="font-mono text-sm">{p.currency}</TableCell>
                    <TableCell><Badge variant="outline" className="font-mono text-[10px]">{p.status}</Badge></TableCell>
                    <TableCell>{p.isDefault && <Badge variant="outline" className="font-mono text-[10px] bg-blue-500/20 text-blue-300 border-blue-500/30">default</Badge>}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2"><CardTitle className="text-sm font-mono uppercase tracking-wider text-muted-foreground">Rate rules</CardTitle></CardHeader>
        <CardContent className="p-0">
          {loadingRules ? (
            <div className="p-4 space-y-2">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-8" />)}</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead><TableHead>Item</TableHead><TableHead>Route</TableHead><TableHead>Engine</TableHead>
                  <TableHead className="text-right">Rate</TableHead><TableHead className="text-right">Min</TableHead>
                  <TableHead className="text-right">Priority</TableHead><TableHead className="w-16"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {(rules ?? []).map((r) => (
                  <TableRow key={r.id}>
                    <TableCell className="text-sm">{r.name}</TableCell>
                    <TableCell className="font-mono text-xs">{itemName(r.itemCodeId)}</TableCell>
                    <TableCell className="text-xs capitalize">{r.routeType}</TableCell>
                    <TableCell className="text-xs">{r.engineType}</TableCell>
                    <TableCell className="text-right font-mono text-sm">{r.rateAmount.toFixed(2)}</TableCell>
                    <TableCell className="text-right font-mono text-xs">{r.minCharge != null ? r.minCharge.toFixed(0) : "—"}</TableCell>
                    <TableCell className="text-right font-mono text-xs">{r.priority}</TableCell>
                    <TableCell className="flex gap-1">
                      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openEdit(r)}><Pencil className="h-3.5 w-3.5" /></Button>
                      <Button variant="ghost" size="icon" className="h-7 w-7 text-red-400" onClick={() => remove.mutate(r.id)}><Trash2 className="h-3.5 w-3.5" /></Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editing ? "Edit rate rule" : "New rate rule"}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-3">
            <Fld label="Name" full><Input value={form.name as string} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Fld>
            <Fld label="Item code">
              <Select value={form.itemCodeId as string} onValueChange={(v) => setForm({ ...form, itemCodeId: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{(items ?? []).map((i) => <SelectItem key={i.id} value={i.id}>{i.code} — {i.name}</SelectItem>)}</SelectContent>
              </Select>
            </Fld>
            <Fld label="Calc method">
              <Select value={form.calcMethod as string} onValueChange={(v) => setForm({ ...form, calcMethod: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{CALC_METHODS.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
              </Select>
            </Fld>
            <Fld label="Route type">
              <Select value={form.routeType as string} onValueChange={(v) => setForm({ ...form, routeType: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{ROUTE_TYPES.map((t) => <SelectItem key={t} value={t} className="capitalize">{t}</SelectItem>)}</SelectContent>
              </Select>
            </Fld>
            <Fld label="Engine type">
              <Select value={form.engineType as string} onValueChange={(v) => setForm({ ...form, engineType: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{ENGINE_TYPES.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
              </Select>
            </Fld>
            <Fld label="Direction">
              <Select value={form.direction as string} onValueChange={(v) => setForm({ ...form, direction: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{DIRECTIONS.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
              </Select>
            </Fld>
            <Fld label="Rate amount"><Input type="number" step="0.01" value={form.rateAmount as number} onChange={(e) => setForm({ ...form, rateAmount: e.target.value })} /></Fld>
            <Fld label="Min charge"><Input type="number" step="0.01" value={form.minCharge as string} onChange={(e) => setForm({ ...form, minCharge: e.target.value })} /></Fld>
            <Fld label="Priority"><Input type="number" value={form.priority as number} onChange={(e) => setForm({ ...form, priority: e.target.value })} /></Fld>
            <Fld label="Effective from"><Input type="date" value={form.effectiveFrom as string} onChange={(e) => setForm({ ...form, effectiveFrom: e.target.value })} /></Fld>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={() => save.mutate()} disabled={save.isPending || !form.name || !form.itemCodeId}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </BillingShell>
  );
}

function Fld({ label, children, full }: { label: string; children: React.ReactNode; full?: boolean }) {
  return (
    <div className={full ? "col-span-2" : ""}>
      <Label className="text-[11px] font-mono uppercase tracking-wider text-muted-foreground">{label}</Label>
      <div className="mt-1">{children}</div>
    </div>
  );
}
