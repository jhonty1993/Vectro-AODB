import { useState, useEffect, useCallback } from "react";
import { useLocation } from "wouter";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from "recharts";
import {
  Plane, ArrowDown, ArrowUp, AlertCircle, CheckCircle2, XCircle,
  TrendingUp, Search, AlertTriangle, RefreshCw, ChevronLeft, ChevronRight,
  Calendar, Clock, Wifi, WifiOff, Activity, Radio
} from "lucide-react";
import { useGetStaticScheduleStatus, getGetStaticScheduleStatusQueryKey } from "@workspace/api-client-react";

const YLW_TZ = "America/Vancouver";

function getTodayInYLW(): string {
  return new Intl.DateTimeFormat("en-CA", { timeZone: YLW_TZ }).format(new Date());
}

function formatDateDisplay(dateStr: string): string {
  return new Date(dateStr + "T12:00:00Z").toLocaleDateString("en-CA", {
    timeZone: YLW_TZ,
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

function addDays(dateStr: string, days: number): string {
  const d = new Date(dateStr + "T12:00:00Z");
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

const STATUS_COLORS: Record<string, string> = {
  SCHEDULED: "bg-slate-500/20 text-slate-300 border-slate-500/30",
  ESTIMATED: "bg-blue-500/20 text-blue-300 border-blue-500/30",
  AIRBORNE: "bg-sky-500/20 text-sky-300 border-sky-500/30",
  LANDED: "bg-emerald-500/20 text-emerald-300 border-emerald-500/30",
  ON_BLOCK: "bg-green-500/20 text-green-300 border-green-500/30",
  DEPARTED: "bg-indigo-500/20 text-indigo-300 border-indigo-500/30",
  CANCELLED: "bg-red-500/20 text-red-300 border-red-500/30",
  DIVERTED: "bg-orange-500/20 text-orange-300 border-orange-500/30",
};

function qualityColor(score: number): string {
  if (score >= 80) return "text-emerald-400";
  if (score >= 60) return "text-amber-400";
  return "text-red-400";
}

function qualityBg(score: number): string {
  if (score >= 80) return "bg-emerald-400";
  if (score >= 60) return "bg-amber-400";
  return "bg-red-400";
}

function formatTime(iso: string | null | undefined): string {
  if (!iso) return "—";
  try {
    return new Date(iso).toLocaleTimeString("en-CA", { timeZone: YLW_TZ, hour: "2-digit", minute: "2-digit", hour12: false });
  } catch { return "—"; }
}

function formatRelative(iso: string | null | undefined): string {
  if (!iso) return "—";
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

function DelayBadge({ minutes }: { minutes: number | null | undefined }) {
  if (minutes == null) return <span className="text-muted-foreground">—</span>;
  if (minutes <= 0) return <span className="text-emerald-400 text-xs font-mono">ON TIME</span>;
  if (minutes < 15) return <span className="text-amber-400 text-xs font-mono">+{minutes}m</span>;
  return <span className="text-red-400 text-xs font-mono font-bold">+{minutes}m</span>;
}

type DataHealth = {
  todayLocal: string;
  timezone: string;
  flightsForToday: number;
  flightsInDb: number;
  datesInDb: string[];
  flightDataIsToday: boolean;
  environmentMode: string;
  isDemo: boolean;
  freshness: "DEMO_CURRENT" | "DEMO_STALE" | "LIVE" | "STALE";
  fr24LastSync: string | null;
  fr24Status: string;
  adsbLastSync: string | null;
  adsbStatus: string;
};

type FlightRow = {
  id: string;
  flightNumber: string;
  airline: string;
  airlineIata: string;
  direction: "ARR" | "DEP";
  origin: string;
  destination: string;
  scheduledTime: string;
  estimatedTime: string | null;
  actualTime: string | null;
  tailNumber: string | null;
  aircraftType: string | null;
  status: string;
  dataQualityScore: number;
  delayMinutes: number | null;
  updatedAt: string;
  dataSource: string | null;
  fr24Seen?: boolean;
  fr24LastSeenAt?: string | null;
};

type ScheduleCoverage = {
  date: string;
  totalScheduled: number;
  arrivals: number;
  departures: number;
  matched: number;
  awaitingFr24: number;
  missingActuals: number;
  unmatchedFr24: number;
  bySource: { YLW_FEED: number; FR24_LIVE: number; STATIC_SCHEDULE: number; SEED_OR_UNKNOWN: number };
  excludedNonCommercial: number;
  visibleBoardCount: number;
};

type YlwFeedStatus = {
  lastSyncAt: string | null;
  lastSyncCount: number;
  lastSyncArrivals: number;
  lastSyncDepartures: number;
  lastSyncError: string | null;
};

const SOURCE_BADGE: Record<string, string> = {
  YLW_FEED: "bg-emerald-500/15 text-emerald-300 border-emerald-500/30",
  FR24_LIVE: "bg-blue-500/15 text-blue-300 border-blue-500/30",
  FR24_HISTORIC: "bg-cyan-500/15 text-cyan-300 border-cyan-500/30",
  STATIC_SCHEDULE: "bg-violet-500/15 text-violet-300 border-violet-500/30",
  SEED: "bg-slate-500/15 text-slate-300 border-slate-500/30",
  MANUAL: "bg-amber-500/15 text-amber-300 border-amber-500/30",
};

// Plain-English source labels + descriptions so non-technical users can tell at a
// glance where each row's data came from (matches the swatches in the "Live Data
// Sources" strip above the board).
const SOURCE_LABEL: Record<string, string> = {
  YLW_FEED: "Airport Feed",
  FR24_LIVE: "FlightRadar24",
  FR24_HISTORIC: "FR24 History",
  STATIC_SCHEDULE: "Schedule",
  SEED: "Demo",
  MANUAL: "Manual",
};

const SOURCE_DESC: Record<string, string> = {
  YLW_FEED: "Kelowna Airport public feed — schedule, gates, baggage & status.",
  FR24_LIVE: "FlightRadar24 live tracking — real actual landing/takeoff times & tail numbers.",
  FR24_HISTORIC: "FlightRadar24 historical record for a past day.",
  STATIC_SCHEDULE: "Imported airline schedule baseline.",
  SEED: "Built-in demo sample data.",
  MANUAL: "Entered by hand by an operator.",
};

const SOURCE_SWATCH: Record<string, string> = {
  YLW_FEED: "bg-emerald-500",
  FR24_LIVE: "bg-blue-500",
  FR24_HISTORIC: "bg-cyan-500",
  STATIC_SCHEDULE: "bg-violet-500",
  MANUAL: "bg-amber-500",
  SEED: "bg-slate-500",
};

type FreshDot = { cls: string; pulse: boolean; label: string };
function freshnessDot(iso: string | null | undefined, status?: string): FreshDot {
  if (status === "failed") return { cls: "bg-red-500", pulse: false, label: "Error" };
  if (status === "demo") return { cls: "bg-slate-500", pulse: false, label: "Demo" };
  if (status === "not_configured") return { cls: "bg-slate-500", pulse: false, label: "Off" };
  if (!iso) return { cls: "bg-slate-500", pulse: false, label: "No data" };
  const ageMs = Date.now() - new Date(iso).getTime();
  if (ageMs < 5 * 60_000) return { cls: "bg-emerald-500", pulse: true, label: "Live" };
  if (ageMs < 30 * 60_000) return { cls: "bg-amber-500", pulse: false, label: "Recent" };
  return { cls: "bg-red-500", pulse: false, label: "Stale" };
}

function SourcePill({ name, swatch, dot, detail }: { name: string; swatch: string; dot: FreshDot; detail: string }) {
  return (
    <div className="flex items-center gap-2.5 rounded border border-border bg-card/60 px-3 py-2">
      <span className={`inline-block h-3 w-3 shrink-0 rounded-sm ${swatch}`} />
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-1.5">
          <span className="text-xs font-mono font-bold text-foreground truncate">{name}</span>
          <span className="relative flex h-1.5 w-1.5">
            {dot.pulse && <span className={`absolute inline-flex h-full w-full animate-ping rounded-full ${dot.cls} opacity-75`} />}
            <span className={`relative inline-flex h-1.5 w-1.5 rounded-full ${dot.cls}`} />
          </span>
          <span className="text-[9px] font-mono uppercase tracking-wider text-muted-foreground">{dot.label}</span>
        </div>
        <div className="text-[10px] font-mono text-muted-foreground/60 truncate">{detail}</div>
      </div>
    </div>
  );
}

export default function Dashboard() {
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();
  const [selectedDate, setSelectedDate] = useState(getTodayInYLW);
  const [search, setSearch] = useState("");
  const [direction, setDirection] = useState<string>("ALL");
  const [statusFilter, setStatusFilter] = useState<string>("ALL");
  const [advancingDates, setAdvancingDates] = useState(false);
  const [backfilling, setBackfilling] = useState(false);
  const [backfillMsg, setBackfillMsg] = useState<string | null>(null);

  const isToday = selectedDate === getTodayInYLW();

  const healthQuery = useQuery<DataHealth>({
    queryKey: ["data-health"],
    queryFn: () => fetch("/api/flights/data-health").then((r) => r.json()),
    refetchInterval: 20_000,
  });

  const summaryQuery = useQuery({
    queryKey: ["dashboard-summary", selectedDate],
    queryFn: () => fetch(`/api/flights/dashboard/summary?date=${selectedDate}`).then((r) => r.json()),
    refetchInterval: 30_000,
  });

  const hourQuery = useQuery({
    queryKey: ["movements-by-hour", selectedDate],
    queryFn: () => fetch(`/api/flights/dashboard/movements-by-hour?date=${selectedDate}`).then((r) => r.json()),
    refetchInterval: 60_000,
  });

  const delayQuery = useQuery({
    queryKey: ["delays-by-airline", selectedDate],
    queryFn: () => fetch(`/api/flights/dashboard/delays-by-airline?date=${selectedDate}`).then((r) => r.json()),
    refetchInterval: 60_000,
  });

  const flightsQuery = useQuery<FlightRow[]>({
    queryKey: ["flights", selectedDate],
    queryFn: () => fetch(`/api/flights?date=${selectedDate}`).then((r) => r.json()),
    refetchInterval: 15_000,
  });

  const coverageQuery = useQuery<ScheduleCoverage>({
    queryKey: ["schedule-coverage", selectedDate],
    queryFn: () => fetch(`/api/flights/schedule-coverage?date=${selectedDate}`).then((r) => r.json()),
    refetchInterval: 60_000,
  });

  const ylwFeedQuery = useQuery<YlwFeedStatus>({
    queryKey: ["ylw-feed-status"],
    queryFn: () => fetch("/api/ylw-feed/status").then((r) => r.json()),
    refetchInterval: 20_000,
  });

  const scheduleQ = useGetStaticScheduleStatus({ query: { queryKey: getGetStaticScheduleStatusQueryKey() } });
  const scheduleMode = scheduleQ.data?.mode ?? "fr24_only";
  const activeSchedule = scheduleQ.data?.activeImport ?? null;

  const summary = summaryQuery.data;
  const health = healthQuery.data;
  const flights = flightsQuery.data ?? [];

  const filteredFlights = flights.filter((f) => {
    if (direction !== "ALL" && f.direction !== direction) return false;
    if (statusFilter !== "ALL" && f.status !== statusFilter) return false;
    if (search) {
      const q = search.toLowerCase();
      return (
        f.flightNumber.toLowerCase().includes(q) ||
        f.airline.toLowerCase().includes(q) ||
        (f.origin ?? "").toLowerCase().includes(q) ||
        (f.destination ?? "").toLowerCase().includes(q) ||
        (f.tailNumber ?? "").toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleAdvanceDates = async () => {
    setAdvancingDates(true);
    try {
      await fetch("/api/flights/advance-demo-dates", { method: "POST" });
      queryClient.invalidateQueries();
    } finally {
      setAdvancingDates(false);
    }
  };

  const handleRefresh = () => {
    queryClient.invalidateQueries();
  };

  const handleBackfillDay = async () => {
    setBackfilling(true);
    setBackfillMsg(null);
    try {
      const res = await fetch("/api/sources/fr24/backfill", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ from: selectedDate, to: selectedDate }),
      });
      const data = await res.json();
      setBackfillMsg(data.message ?? (res.ok ? "Backfill complete." : "Backfill failed."));
      queryClient.invalidateQueries();
    } catch {
      setBackfillMsg("Backfill request failed — check the FR24 connection.");
    } finally {
      setBackfilling(false);
    }
  };

  // Freshness banner config
  const freshness = health?.freshness ?? "DEMO_STALE";
  const freshnessConfig = {
    DEMO_CURRENT: {
      bg: "bg-amber-500/10 border-amber-500/30",
      icon: <AlertTriangle className="h-4 w-4 text-amber-400 shrink-0" />,
      label: "DEMO MODE — CURRENT",
      text: "Showing demo flights for today. No live FR24 or ADS-B data connected.",
      badge: "bg-amber-500/20 text-amber-300 border-amber-500/30",
    },
    DEMO_STALE: {
      bg: "bg-red-500/10 border-red-500/30",
      icon: <XCircle className="h-4 w-4 text-red-400 shrink-0" />,
      label: "STALE DEMO DATA",
      text: "Demo flights are NOT from today. Click \"Advance to Today\" to update dates.",
      badge: "bg-red-500/20 text-red-300 border-red-500/30",
    },
    LIVE: {
      bg: "bg-emerald-500/10 border-emerald-500/20",
      icon: <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />,
      label: "LIVE",
      text: "Connected to live data sources. Showing current operations.",
      badge: "bg-emerald-500/20 text-emerald-300 border-emerald-500/30",
    },
    STALE: {
      bg: "bg-orange-500/10 border-orange-500/30",
      icon: <AlertCircle className="h-4 w-4 text-orange-400 shrink-0" />,
      label: "STALE",
      text: "Live data sources connected but no recent sync. Showing last available data.",
      badge: "bg-orange-500/20 text-orange-300 border-orange-500/30",
    },
  }[freshness] ?? {
    bg: "bg-slate-500/10 border-slate-500/30",
    icon: <AlertCircle className="h-4 w-4 text-slate-400 shrink-0" />,
    label: "UNKNOWN",
    text: "Data status unknown.",
    badge: "bg-slate-500/20 text-slate-300 border-slate-500/30",
  };

  return (
    <div className="p-6 space-y-4">

      {/* ── Header ── */}
      <div className="flex flex-col sm:flex-row sm:items-start gap-3">
        <div className="flex-1">
          <h1 className="text-2xl font-mono font-bold tracking-tight text-foreground">Commercial Operations Dashboard</h1>
          <p className="text-sm text-muted-foreground mt-0.5 font-mono">
            YLW/CYLW — {formatDateDisplay(selectedDate)} · <span className="text-muted-foreground/60">America/Vancouver</span>
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {/* Date nav */}
          <div className="flex items-center gap-1 bg-secondary rounded border border-border px-1">
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setSelectedDate((d) => addDays(d, -1))}>
              <ChevronLeft className="h-3.5 w-3.5" />
            </Button>
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value || getTodayInYLW())}
              className="bg-transparent font-mono text-xs text-foreground border-none outline-none w-32 text-center"
            />
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setSelectedDate((d) => addDays(d, 1))}>
              <ChevronRight className="h-3.5 w-3.5" />
            </Button>
          </div>
          {!isToday && (
            <Button variant="outline" size="sm" className="h-7 text-xs font-mono" onClick={() => setSelectedDate(getTodayInYLW())}>
              Today
            </Button>
          )}
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={handleRefresh}>
            <RefreshCw className="h-3.5 w-3.5" />
          </Button>
          {scheduleMode === "static_schedule_fr24" ? (
            <Badge variant="outline" className="font-mono text-xs bg-emerald-500/10 text-emerald-400 border-emerald-500/20 uppercase">Static + FR24</Badge>
          ) : (
            <Badge variant="outline" className="font-mono text-xs bg-violet-500/10 text-violet-400 border-violet-500/20 uppercase">FR24 Only</Badge>
          )}
          <Badge variant="outline" className={`font-mono text-xs uppercase ${freshnessConfig.badge}`}>
            {freshness.replace("_", " ")}
          </Badge>
        </div>
      </div>

      {/* ── Data Freshness Banner ── */}
      <Card className={`${freshnessConfig.bg} border`}>
        <CardContent className="p-3 flex items-start gap-3">
          {freshnessConfig.icon}
          <div className="flex-1 min-w-0">
            <div className="font-mono text-xs font-bold mb-0.5">
              DATA STATUS: {freshnessConfig.label}
            </div>
            <div className="font-mono text-[11px] text-muted-foreground leading-relaxed">
              {freshnessConfig.text}
              {health && !health.flightDataIsToday && isToday && (
                <span> Flight data is from: <strong className="text-red-300">{health.datesInDb.join(", ") || "unknown"}</strong></span>
              )}
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            {health?.isDemo && (!health.flightDataIsToday || freshness === "DEMO_STALE") && (
              <Button
                size="sm"
                variant="outline"
                className="h-7 text-xs font-mono border-amber-500/40 text-amber-300 hover:bg-amber-500/10"
                onClick={handleAdvanceDates}
                disabled={advancingDates}
              >
                {advancingDates ? "Advancing..." : "Advance to Today"}
              </Button>
            )}
            <div className="text-right text-[10px] font-mono text-muted-foreground/60 whitespace-nowrap">
              <div>FR24: {health?.fr24LastSync ? formatRelative(health.fr24LastSync) : "—"}</div>
              <div>ADS-B: {health?.adsbLastSync ? formatRelative(health.adsbLastSync) : "—"}</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* ── Live Data Sources (plain-English provenance for non-technical users) ── */}
      <Card className="bg-card/40 border-border">
        <CardContent className="p-3">
          <div className="flex items-center gap-2 mb-2">
            <Radio className="h-3.5 w-3.5 text-sky-400" />
            <span className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">
              Where this data comes from — live sources &amp; sync status
            </span>
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-2">
            <SourcePill
              name="FlightRadar24"
              swatch={SOURCE_SWATCH.FR24_LIVE}
              dot={freshnessDot(health?.fr24LastSync, health?.fr24Status)}
              detail={`Actual times & tails · synced ${health?.fr24LastSync ? formatRelative(health.fr24LastSync) : "—"}`}
            />
            <SourcePill
              name="Airport Feed"
              swatch={SOURCE_SWATCH.YLW_FEED}
              dot={freshnessDot(ylwFeedQuery.data?.lastSyncAt)}
              detail={`Schedule, gates & status · synced ${ylwFeedQuery.data?.lastSyncAt ? formatRelative(ylwFeedQuery.data.lastSyncAt) : "—"}`}
            />
            <SourcePill
              name="ADS-B"
              swatch="bg-fuchsia-500"
              dot={freshnessDot(health?.adsbLastSync, health?.adsbStatus)}
              detail={`Position backup · synced ${health?.adsbLastSync ? formatRelative(health.adsbLastSync) : "—"}`}
            />
            <SourcePill
              name="Manual"
              swatch={SOURCE_SWATCH.MANUAL}
              dot={{ cls: "bg-amber-500", pulse: false, label: "Operator" }}
              detail="Hand-entered corrections"
            />
          </div>
          <div className="text-[10px] font-mono text-muted-foreground/50 mt-2">
            The colored square next to each flight in the board below shows which of these sources that row came from.
          </div>
        </CardContent>
      </Card>

      {/* ── Schedule Mode Banner ── */}
      {scheduleMode === "static_schedule_fr24" && activeSchedule ? (
        <Card className="bg-emerald-500/5 border-emerald-500/20">
          <CardContent className="p-3 flex items-start gap-3">
            <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400 shrink-0 mt-0.5" />
            <div className="flex-1 min-w-0">
              <div className="font-mono text-xs font-bold text-emerald-300 mb-0.5">Static Schedule + FR24 Live Mode</div>
              <div className="font-mono text-[11px] text-emerald-200/70 leading-relaxed">
                Baseline: <strong className="text-emerald-300">{activeSchedule.filename}</strong> (v{activeSchedule.version}) ·{" "}
                {activeSchedule.arrivalCount} arrivals + {activeSchedule.departureCount} departures ·{" "}
                Period {activeSchedule.periodStart} → {activeSchedule.periodEnd}.
              </div>
            </div>
          </CardContent>
        </Card>
      ) : null}

      {/* ── YLW Live Feed + Schedule Coverage ── */}
      <div className="grid grid-cols-1 lg:grid-cols-6 gap-3">
        <Card className="lg:col-span-1 bg-emerald-500/5 border-emerald-500/20">
          <CardContent className="p-3">
            <div className="flex items-center gap-2 mb-1">
              <Activity className="h-3.5 w-3.5 text-emerald-400" />
              <span className="text-[10px] font-mono text-emerald-300 uppercase tracking-wider">YLW Live Feed</span>
            </div>
            <div className="text-2xl font-mono font-bold text-emerald-300">{ylwFeedQuery.data?.lastSyncCount ?? 0}</div>
            <div className="text-[10px] font-mono text-emerald-200/70 mt-0.5">
              {ylwFeedQuery.data?.lastSyncArrivals ?? 0} arr · {ylwFeedQuery.data?.lastSyncDepartures ?? 0} dep
            </div>
            <div className="text-[10px] font-mono text-muted-foreground/60 mt-0.5">
              {ylwFeedQuery.data?.lastSyncAt ? formatRelative(ylwFeedQuery.data.lastSyncAt) : "—"}
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-card-border">
          <CardContent className="p-3">
            <div className="text-[10px] font-mono text-muted-foreground uppercase tracking-wider mb-1">Total Scheduled</div>
            <div className="text-2xl font-mono font-bold text-foreground">{coverageQuery.data?.totalScheduled ?? 0}</div>
            <div className="text-[10px] font-mono text-muted-foreground/60 mt-0.5">commercial only</div>
          </CardContent>
        </Card>
        <Card className="bg-card border-card-border">
          <CardContent className="p-3">
            <div className="text-[10px] font-mono text-muted-foreground uppercase tracking-wider mb-1">Matched (Est/Actual)</div>
            <div className="text-2xl font-mono font-bold text-blue-300">{coverageQuery.data?.matched ?? 0}</div>
            <div className="text-[10px] font-mono text-muted-foreground/60 mt-0.5">has live data</div>
          </CardContent>
        </Card>
        <Card className="bg-card border-card-border">
          <CardContent className="p-3">
            <div className="text-[10px] font-mono text-muted-foreground uppercase tracking-wider mb-1">Awaiting Live</div>
            <div className="text-2xl font-mono font-bold text-amber-300">{coverageQuery.data?.awaitingFr24 ?? 0}</div>
            <div className="text-[10px] font-mono text-muted-foreground/60 mt-0.5">scheduled, no est</div>
          </CardContent>
        </Card>
        <Card className="bg-card border-card-border">
          <CardContent className="p-3">
            <div className="text-[10px] font-mono text-muted-foreground uppercase tracking-wider mb-1">Missing Actuals</div>
            <div className="text-2xl font-mono font-bold text-red-300">{coverageQuery.data?.missingActuals ?? 0}</div>
            <div className="text-[10px] font-mono text-muted-foreground/60 mt-0.5">past window</div>
          </CardContent>
        </Card>
        <Card className="bg-card border-card-border">
          <CardContent className="p-3">
            <div className="text-[10px] font-mono text-muted-foreground uppercase tracking-wider mb-1">Excluded</div>
            <div className="text-2xl font-mono font-bold text-slate-300">{coverageQuery.data?.excludedNonCommercial ?? 0}</div>
            <div className="text-[10px] font-mono text-muted-foreground/60 mt-0.5">non-commercial</div>
          </CardContent>
        </Card>
      </div>

      {/* ── Summary Cards ── */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {summaryQuery.isLoading ? (
          Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-24" />)
        ) : (
          <>
            <Card className="bg-card border-card-border">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-1">
                  <ArrowDown className="h-3.5 w-3.5 text-sky-400" />
                  <span className="text-xs font-mono text-muted-foreground uppercase tracking-wider">Arrivals</span>
                </div>
                <div className="text-3xl font-mono font-bold text-foreground">{summary?.totalArrivals ?? 0}</div>
                <div className="text-[10px] font-mono text-muted-foreground/60 mt-0.5">for {isToday ? "today" : selectedDate}</div>
              </CardContent>
            </Card>
            <Card className="bg-card border-card-border">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-1">
                  <ArrowUp className="h-3.5 w-3.5 text-indigo-400" />
                  <span className="text-xs font-mono text-muted-foreground uppercase tracking-wider">Departures</span>
                </div>
                <div className="text-3xl font-mono font-bold text-foreground">{summary?.totalDepartures ?? 0}</div>
                <div className="text-[10px] font-mono text-muted-foreground/60 mt-0.5">for {isToday ? "today" : selectedDate}</div>
              </CardContent>
            </Card>
            <Card className="bg-card border-card-border">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-1">
                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                  <span className="text-xs font-mono text-muted-foreground uppercase tracking-wider">On Time</span>
                </div>
                <div className="text-3xl font-mono font-bold text-emerald-400">{summary?.onTime ?? 0}</div>
                {summary && <div className="text-xs text-red-400 font-mono mt-0.5">{summary.delayed} delayed</div>}
              </CardContent>
            </Card>
            <Card className="bg-card border-card-border">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-1">
                  <XCircle className="h-3.5 w-3.5 text-red-400" />
                  <span className="text-xs font-mono text-muted-foreground uppercase tracking-wider">Canc/Div</span>
                </div>
                <div className="text-3xl font-mono font-bold text-red-400">{(summary?.cancelled ?? 0) + (summary?.diverted ?? 0)}</div>
                {summary && <div className="text-xs text-muted-foreground font-mono mt-0.5">{summary.cancelled}C / {summary.diverted}D</div>}
              </CardContent>
            </Card>
            <Card className="bg-card border-card-border">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-1">
                  <TrendingUp className="h-3.5 w-3.5 text-primary" />
                  <span className="text-xs font-mono text-muted-foreground uppercase tracking-wider">Data Quality</span>
                </div>
                <div className={`text-3xl font-mono font-bold ${qualityColor(summary?.avgDataQuality ?? 0)}`}>
                  {summary?.avgDataQuality ?? 0}%
                </div>
                {summary && <div className="text-xs text-amber-400 font-mono mt-0.5">{summary.lowQualityCount} low quality</div>}
              </CardContent>
            </Card>
          </>
        )}
      </div>

      {/* ── Data Health Card ── */}
      {health && (
        <Card className="bg-card border-border">
          <CardContent className="p-3">
            <div className="flex items-center gap-2 mb-2">
              <Activity className="h-3.5 w-3.5 text-muted-foreground" />
              <span className="text-[11px] font-mono uppercase tracking-wider text-muted-foreground font-bold">Current Data Health</span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3">
              <div>
                <div className="text-[10px] font-mono text-muted-foreground/60 uppercase">Today (YLW)</div>
                <div className="text-xs font-mono text-foreground font-bold">{health.todayLocal}</div>
              </div>
              <div>
                <div className="text-[10px] font-mono text-muted-foreground/60 uppercase">Mode</div>
                <div className="text-xs font-mono">
                  <Badge variant="outline" className={`text-[10px] px-1 py-0 ${health.isDemo ? "bg-amber-500/10 text-amber-300 border-amber-500/20" : "bg-emerald-500/10 text-emerald-300 border-emerald-500/20"}`}>
                    {health.environmentMode}
                  </Badge>
                </div>
              </div>
              <div>
                <div className="text-[10px] font-mono text-muted-foreground/60 uppercase">Flights Today</div>
                <div className={`text-xs font-mono font-bold ${health.flightsForToday > 0 ? "text-emerald-400" : "text-red-400"}`}>
                  {health.flightsForToday} / {health.flightsInDb} total
                </div>
              </div>
              <div>
                <div className="text-[10px] font-mono text-muted-foreground/60 uppercase">FR24</div>
                <div className="text-xs font-mono flex items-center gap-1">
                  {health.fr24Status === "live" ? (
                    <Wifi className="h-3 w-3 text-emerald-400" />
                  ) : (
                    <WifiOff className="h-3 w-3 text-muted-foreground" />
                  )}
                  <span className={health.fr24Status === "live" ? "text-emerald-400" : "text-muted-foreground"}>
                    {health.fr24LastSync ? formatRelative(health.fr24LastSync) : "No sync"}
                  </span>
                </div>
              </div>
              <div>
                <div className="text-[10px] font-mono text-muted-foreground/60 uppercase">ADS-B</div>
                <div className="text-xs font-mono flex items-center gap-1">
                  {health.adsbStatus === "live" ? (
                    <Wifi className="h-3 w-3 text-emerald-400" />
                  ) : (
                    <WifiOff className="h-3 w-3 text-muted-foreground" />
                  )}
                  <span className={health.adsbStatus === "live" ? "text-emerald-400" : "text-muted-foreground"}>
                    {health.adsbLastSync ? formatRelative(health.adsbLastSync) : "No sync"}
                  </span>
                </div>
              </div>
              <div>
                <div className="text-[10px] font-mono text-muted-foreground/60 uppercase">Data Dates</div>
                <div className="text-xs font-mono text-muted-foreground">
                  {health.datesInDb.length > 0 ? health.datesInDb.join(", ") : "—"}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* ── Charts ── */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="bg-card border-card-border">
          <CardHeader className="pb-2 pt-4 px-4">
            <CardTitle className="text-sm font-mono uppercase tracking-wider text-muted-foreground">
              Movements by Hour · {isToday ? "Today" : selectedDate}
            </CardTitle>
          </CardHeader>
          <CardContent className="pb-4 px-4">
            {hourQuery.isLoading ? (
              <Skeleton className="h-48" />
            ) : (
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={hourQuery.data ?? []} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 20% 16%)" />
                  <XAxis dataKey="hour" tick={{ fontSize: 10, fontFamily: "monospace", fill: "#94a3b8" }} />
                  <YAxis tick={{ fontSize: 10, fontFamily: "monospace", fill: "#94a3b8" }} />
                  <Tooltip contentStyle={{ background: "hsl(220 20% 10%)", border: "1px solid hsl(220 20% 16%)", fontFamily: "monospace", fontSize: 11 }} />
                  <Legend iconType="square" wrapperStyle={{ fontSize: 10, fontFamily: "monospace" }} />
                  <Bar dataKey="arrivals" fill="hsl(217.2 91.2% 59.8%)" name="ARR" radius={[2, 2, 0, 0]} />
                  <Bar dataKey="departures" fill="hsl(271.5 81.3% 55.9%)" name="DEP" radius={[2, 2, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
        <Card className="bg-card border-card-border">
          <CardHeader className="pb-2 pt-4 px-4">
            <CardTitle className="text-sm font-mono uppercase tracking-wider text-muted-foreground">
              Avg Delay by Airline (minutes) · {isToday ? "Today" : selectedDate}
            </CardTitle>
          </CardHeader>
          <CardContent className="pb-4 px-4">
            {delayQuery.isLoading ? (
              <Skeleton className="h-48" />
            ) : (
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={delayQuery.data ?? []} layout="vertical" margin={{ top: 0, right: 10, left: 10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 20% 16%)" />
                  <XAxis type="number" tick={{ fontSize: 10, fontFamily: "monospace", fill: "#94a3b8" }} />
                  <YAxis dataKey="airlineIata" type="category" tick={{ fontSize: 10, fontFamily: "monospace", fill: "#94a3b8" }} width={30} />
                  <Tooltip contentStyle={{ background: "hsl(220 20% 10%)", border: "1px solid hsl(220 20% 16%)", fontFamily: "monospace", fontSize: 11 }} />
                  <Bar dataKey="avgDelayMinutes" fill="hsl(35.5 91.7% 53.9%)" name="Avg Delay (min)" radius={[0, 2, 2, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>

      {/* ── Movement Board ── */}
      <Card className="bg-card border-card-border">
        <CardHeader className="pb-3 pt-4 px-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
            <div className="flex items-center gap-2 flex-1">
              <CardTitle className="text-sm font-mono uppercase tracking-wider text-muted-foreground">
                {isToday ? "Live" : "Historical"} Movement Board
              </CardTitle>
              {!isToday && (
                <Badge variant="outline" className="bg-violet-500/10 text-violet-300 border-violet-500/20 text-[10px] font-mono uppercase">
                  Historical · {selectedDate}
                </Badge>
              )}
            </div>
            <div className="flex flex-wrap gap-2">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-muted-foreground" />
                <Input
                  placeholder="Flight, airline, tail..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-8 h-8 w-48 font-mono text-xs bg-background border-border"
                />
              </div>
              <Select value={direction} onValueChange={setDirection}>
                <SelectTrigger className="h-8 w-24 font-mono text-xs bg-background border-border">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ALL">ALL</SelectItem>
                  <SelectItem value="ARR">ARR</SelectItem>
                  <SelectItem value="DEP">DEP</SelectItem>
                </SelectContent>
              </Select>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="h-8 w-32 font-mono text-xs bg-background border-border">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ALL">All Status</SelectItem>
                  <SelectItem value="SCHEDULED">Scheduled</SelectItem>
                  <SelectItem value="ESTIMATED">Estimated</SelectItem>
                  <SelectItem value="AIRBORNE">Airborne</SelectItem>
                  <SelectItem value="LANDED">Landed</SelectItem>
                  <SelectItem value="ON_BLOCK">On Block</SelectItem>
                  <SelectItem value="DEPARTED">Departed</SelectItem>
                  <SelectItem value="CANCELLED">Cancelled</SelectItem>
                  <SelectItem value="DIVERTED">Diverted</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent className="px-0 pb-0">
          {/* No data state */}
          {!flightsQuery.isLoading && filteredFlights.length === 0 && (
            <div className="px-6 py-10 text-center space-y-3">
              <Calendar className="h-8 w-8 text-muted-foreground/40 mx-auto" />
              <div className="text-sm font-mono text-muted-foreground">
                {flights.length === 0
                  ? `No flights found for ${isToday ? "today" : selectedDate} in ${YLW_TZ}`
                  : "No movements matching filters"}
              </div>
              {flights.length === 0 && health?.isDemo && isToday && !health.flightDataIsToday && (
                <div className="text-xs font-mono text-muted-foreground/60">
                  Demo data is from {health.datesInDb.join(", ")} — use "Advance to Today" above to update.
                </div>
              )}
              {flights.length === 0 && !health?.isDemo && isToday && (
                <div className="text-xs font-mono text-muted-foreground/60">
                  No live movements received for this date. Check FR24 data source configuration.
                </div>
              )}
              {flights.length === 0 && !isToday && (
                <div className="space-y-2">
                  <div className="text-xs font-mono text-muted-foreground/60">
                    Live feeds only cover the current day. Pull the real flight history for this date from FlightRadar24.
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={handleBackfillDay}
                    disabled={backfilling}
                    className="font-mono text-xs"
                  >
                    {backfilling ? "Loading FR24 history…" : `Load FR24 history for ${selectedDate}`}
                  </Button>
                  {backfillMsg && (
                    <div className="text-[11px] font-mono text-muted-foreground/70 max-w-md mx-auto">{backfillMsg}</div>
                  )}
                </div>
              )}
            </div>
          )}
          {filteredFlights.length > 0 && (
            <div className="overflow-x-auto">
              <table className="w-full text-xs font-mono">
                <thead>
                  <tr className="border-b border-border text-muted-foreground">
                    {["Dir", "Flight", "Airline", "Route", "Sched (PT)", "Est (PT)", "Actual (PT)", "Tail", "Type", "Status", "Source", "DQ", "Delay", "Updated"].map((h) => (
                      <th key={h} className="px-3 py-2 text-left uppercase tracking-wider text-[10px] whitespace-nowrap">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {flightsQuery.isLoading
                    ? Array.from({ length: 6 }).map((_, i) => (
                        <tr key={i} className="border-b border-border/50">
                          {Array.from({ length: 14 }).map((_, j) => (
                            <td key={j} className="px-3 py-2"><Skeleton className="h-3 w-16" /></td>
                          ))}
                        </tr>
                      ))
                    : filteredFlights.map((f) => (
                        <tr
                          key={f.id}
                          className="border-b border-border/40 hover:bg-secondary/50 cursor-pointer transition-colors"
                          onClick={() => navigate(`/flights/${f.id}`)}
                        >
                          <td className="px-3 py-2">
                            {f.direction === "ARR"
                              ? <ArrowDown className="h-3.5 w-3.5 text-sky-400" />
                              : <ArrowUp className="h-3.5 w-3.5 text-indigo-400" />}
                          </td>
                          <td className="px-3 py-2 font-bold text-foreground whitespace-nowrap">{f.flightNumber}</td>
                          <td className="px-3 py-2 whitespace-nowrap">
                            <span className="bg-secondary px-1.5 py-0.5 rounded text-[10px]">{f.airlineIata}</span>
                          </td>
                          <td className="px-3 py-2 text-muted-foreground whitespace-nowrap">
                            {f.origin} → {f.destination}
                          </td>
                          <td className="px-3 py-2 whitespace-nowrap">{formatTime(f.scheduledTime)}</td>
                          <td className="px-3 py-2 whitespace-nowrap text-blue-400">{formatTime(f.estimatedTime)}</td>
                          <td className="px-3 py-2 whitespace-nowrap text-emerald-400">{formatTime(f.actualTime)}</td>
                          <td className="px-3 py-2 text-muted-foreground">{f.tailNumber ?? "—"}</td>
                          <td className="px-3 py-2 text-muted-foreground whitespace-nowrap">{f.aircraftType ?? "—"}</td>
                          <td className="px-3 py-2 whitespace-nowrap">
                            <Badge variant="outline" className={`text-[10px] uppercase px-1.5 py-0 ${STATUS_COLORS[f.status] ?? ""}`}>
                              {f.status.replace("_", " ")}
                            </Badge>
                          </td>
                          <td className="px-3 py-2 whitespace-nowrap">
                            <div className="flex flex-wrap items-center gap-1">
                              <span className={`inline-block h-2.5 w-2.5 shrink-0 rounded-sm ${SOURCE_SWATCH[f.dataSource ?? "SEED"] ?? SOURCE_SWATCH.SEED}`} />
                              <Badge variant="outline" title={SOURCE_DESC[f.dataSource ?? "SEED"] ?? ""} className={`text-[10px] uppercase px-1.5 py-0 ${SOURCE_BADGE[f.dataSource ?? "SEED"] ?? SOURCE_BADGE.SEED}`}>
                                {SOURCE_LABEL[f.dataSource ?? "SEED"] ?? (f.dataSource ?? "SEED").replace("_", " ")}
                              </Badge>
                              {f.fr24Seen && f.dataSource !== "FR24_LIVE" && f.dataSource !== "FR24_HISTORIC" && (
                                <Badge
                                  variant="outline"
                                  title={f.fr24LastSeenAt ? `FR24 data last seen ${formatTime(f.fr24LastSeenAt)}` : "Enriched with FlightRadar24 data"}
                                  className={`text-[10px] uppercase px-1.5 py-0 ${SOURCE_BADGE.FR24_LIVE}`}
                                >
                                  +FR24
                                </Badge>
                              )}
                            </div>
                          </td>
                          <td className="px-3 py-2">
                            <div className="flex items-center gap-1.5">
                              <div className="w-12 h-1.5 bg-secondary rounded-full overflow-hidden">
                                <div className={`h-full rounded-full ${qualityBg(f.dataQualityScore)}`} style={{ width: `${f.dataQualityScore}%` }} />
                              </div>
                              <span className={qualityColor(f.dataQualityScore)}>{Math.round(f.dataQualityScore)}</span>
                            </div>
                          </td>
                          <td className="px-3 py-2"><DelayBadge minutes={f.delayMinutes} /></td>
                          <td className="px-3 py-2 text-muted-foreground/60 whitespace-nowrap text-[10px]">
                            {formatRelative(f.updatedAt)}
                          </td>
                        </tr>
                      ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
