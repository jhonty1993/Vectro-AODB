import { useEffect, useMemo, useState } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useUser } from "@clerk/react";
import { Plane, PlaneLanding, PlaneTakeoff, LogIn, LayoutDashboard } from "lucide-react";

const YLW_TZ = "America/Vancouver";
const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

interface Flight {
  id: string;
  flightNumber: string;
  airline: string;
  airlineIata: string;
  direction: "ARR" | "DEP";
  origin: string;
  destination: string;
  scheduledTime: string;
  estimatedTime: string | null;
  actualTime: string | null;
  status: string;
  gate: string | null;
  belt: string | null;
}

function fmtTime(iso: string | null): string {
  if (!iso) return "—";
  try {
    return new Intl.DateTimeFormat("en-CA", {
      timeZone: YLW_TZ,
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
    }).format(new Date(iso));
  } catch {
    return "—";
  }
}

const STATUS_STYLE: Record<string, { label: string; cls: string }> = {
  SCHEDULED: { label: "Scheduled", cls: "bg-slate-500/15 text-slate-300 border-slate-500/30" },
  ESTIMATED: { label: "Estimated", cls: "bg-blue-500/15 text-blue-300 border-blue-500/30" },
  AIRBORNE: { label: "En route", cls: "bg-sky-500/15 text-sky-300 border-sky-500/30" },
  LANDED: { label: "Landed", cls: "bg-emerald-500/15 text-emerald-300 border-emerald-500/30" },
  ON_BLOCK: { label: "Arrived", cls: "bg-emerald-500/15 text-emerald-300 border-emerald-500/30" },
  DEPARTED: { label: "Departed", cls: "bg-emerald-500/15 text-emerald-300 border-emerald-500/30" },
  CANCELLED: { label: "Cancelled", cls: "bg-red-500/15 text-red-300 border-red-500/30" },
  DIVERTED: { label: "Diverted", cls: "bg-orange-500/15 text-orange-300 border-orange-500/30" },
};

function statusStyle(s: string) {
  return STATUS_STYLE[s] ?? { label: s, cls: "bg-slate-500/15 text-slate-300 border-slate-500/30" };
}

function LiveClock() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  const time = new Intl.DateTimeFormat("en-CA", {
    timeZone: YLW_TZ,
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  }).format(now);
  const date = new Intl.DateTimeFormat("en-CA", {
    timeZone: YLW_TZ,
    weekday: "short",
    month: "short",
    day: "numeric",
  }).format(now);
  return (
    <div className="text-right leading-tight">
      <div className="font-mono text-2xl md:text-3xl font-bold tabular-nums text-foreground">{time}</div>
      <div className="text-[11px] font-mono uppercase tracking-wider text-muted-foreground">{date} · PT</div>
    </div>
  );
}

export default function PublicBoard() {
  const { isSignedIn } = useUser();
  const [dir, setDir] = useState<"ARR" | "DEP">("ARR");

  const { data, isLoading, dataUpdatedAt } = useQuery<Flight[]>({
    queryKey: ["public-board"],
    queryFn: () => fetch(`${BASE}/api/flights`).then((r) => r.json()),
    refetchInterval: 30_000,
  });

  const flights = useMemo(() => {
    const list = Array.isArray(data) ? data : [];
    return list
      .filter((f) => f.direction === dir)
      .sort((a, b) => new Date(a.scheduledTime).getTime() - new Date(b.scheduledTime).getTime());
  }, [data, dir]);

  const updated = dataUpdatedAt ? fmtTime(new Date(dataUpdatedAt).toISOString()) : "—";

  return (
    <div className="min-h-screen w-full bg-background dark text-foreground flex flex-col">
      {/* Header */}
      <header className="border-b border-border bg-sidebar/60 backdrop-blur supports-[backdrop-filter]:bg-sidebar/50">
        <div className="mx-auto max-w-6xl px-4 md:px-8 py-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <img src={`${BASE}/logo.svg`} alt="AODB" className="h-11 w-11 rounded-xl" />
            <div className="leading-tight">
              <h1 className="font-mono font-bold text-lg md:text-xl tracking-tight text-foreground">
                Kelowna International Airport
              </h1>
              <div className="text-[11px] md:text-xs font-mono uppercase tracking-wider text-muted-foreground">
                YLW · CYLW — Flight Information
              </div>
            </div>
          </div>
          <div className="flex items-center gap-5">
            <div className="hidden sm:block">
              <LiveClock />
            </div>
            {isSignedIn ? (
              <Link
                href="/ops"
                className="inline-flex items-center gap-2 rounded-md border border-primary/40 bg-primary/15 px-3 py-2 text-xs font-mono uppercase tracking-wider text-primary hover:bg-primary/25 transition-colors"
              >
                <LayoutDashboard className="h-4 w-4" />
                <span className="hidden md:inline">Ops Console</span>
              </Link>
            ) : (
              <Link
                href="/sign-in"
                className="inline-flex items-center gap-2 rounded-md border border-border bg-secondary px-3 py-2 text-xs font-mono uppercase tracking-wider text-foreground hover:bg-accent transition-colors"
              >
                <LogIn className="h-4 w-4" />
                <span className="hidden md:inline">Staff sign in</span>
              </Link>
            )}
          </div>
        </div>
      </header>

      {/* Tabs */}
      <div className="mx-auto w-full max-w-6xl px-4 md:px-8 pt-6">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div className="inline-flex rounded-lg border border-border bg-card p-1">
            <button
              type="button"
              onClick={() => setDir("ARR")}
              className={`inline-flex items-center gap-2 rounded-md px-4 py-2 text-sm font-mono uppercase tracking-wider transition-colors ${
                dir === "ARR" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <PlaneLanding className="h-4 w-4" /> Arrivals
            </button>
            <button
              type="button"
              onClick={() => setDir("DEP")}
              className={`inline-flex items-center gap-2 rounded-md px-4 py-2 text-sm font-mono uppercase tracking-wider transition-colors ${
                dir === "DEP" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <PlaneTakeoff className="h-4 w-4" /> Departures
            </button>
          </div>
          <div className="text-[11px] font-mono uppercase tracking-wider text-muted-foreground flex items-center gap-2">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-60" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
            </span>
            Live · updated {updated}
          </div>
        </div>
      </div>

      {/* Board */}
      <main className="mx-auto w-full max-w-6xl px-4 md:px-8 py-5 flex-1">
        <div className="overflow-hidden rounded-xl border border-border bg-card">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-secondary/50 text-left">
                <th className="px-4 py-3 font-mono text-[11px] uppercase tracking-wider text-muted-foreground">Sched</th>
                <th className="px-4 py-3 font-mono text-[11px] uppercase tracking-wider text-muted-foreground">{dir === "ARR" ? "Est / Land" : "Est / Off"}</th>
                <th className="px-4 py-3 font-mono text-[11px] uppercase tracking-wider text-muted-foreground">Flight</th>
                <th className="px-4 py-3 font-mono text-[11px] uppercase tracking-wider text-muted-foreground">Airline</th>
                <th className="px-4 py-3 font-mono text-[11px] uppercase tracking-wider text-muted-foreground">{dir === "ARR" ? "From" : "To"}</th>
                <th className="px-4 py-3 font-mono text-[11px] uppercase tracking-wider text-muted-foreground">{dir === "ARR" ? "Belt" : "Gate"}</th>
                <th className="px-4 py-3 font-mono text-[11px] uppercase tracking-wider text-muted-foreground text-right">Status</th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                <tr>
                  <td colSpan={7} className="px-4 py-16 text-center text-muted-foreground font-mono text-xs">
                    Loading flights…
                  </td>
                </tr>
              ) : flights.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-4 py-16 text-center text-muted-foreground">
                    <Plane className="mx-auto mb-3 h-8 w-8 opacity-40" />
                    <div className="font-mono text-xs uppercase tracking-wider">
                      No {dir === "ARR" ? "arrivals" : "departures"} scheduled today
                    </div>
                  </td>
                </tr>
              ) : (
                flights.map((f) => {
                  const st = statusStyle(f.status);
                  const actualOrEst = f.actualTime ?? f.estimatedTime;
                  const showAlt = actualOrEst && actualOrEst !== f.scheduledTime;
                  return (
                    <tr key={f.id} className="border-b border-border/60 last:border-0 hover:bg-accent/40 transition-colors">
                      <td className="px-4 py-3 font-mono tabular-nums text-base text-foreground">{fmtTime(f.scheduledTime)}</td>
                      <td className="px-4 py-3 font-mono tabular-nums">
                        {showAlt ? (
                          <span className={f.actualTime ? "text-emerald-400" : "text-blue-300"}>{fmtTime(actualOrEst)}</span>
                        ) : (
                          <span className="text-muted-foreground/50">—</span>
                        )}
                      </td>
                      <td className="px-4 py-3 font-mono font-semibold text-foreground">{f.flightNumber}</td>
                      <td className="px-4 py-3 text-muted-foreground">{f.airline}</td>
                      <td className="px-4 py-3 font-mono text-foreground">{dir === "ARR" ? f.origin : f.destination}</td>
                      <td className="px-4 py-3 font-mono text-muted-foreground">{(dir === "ARR" ? f.belt : f.gate) || "—"}</td>
                      <td className="px-4 py-3 text-right">
                        <span className={`inline-block rounded-md border px-2.5 py-1 font-mono text-[11px] uppercase tracking-wider ${st.cls}`}>
                          {st.label}
                        </span>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
        <p className="mt-4 text-center text-[11px] font-mono text-muted-foreground/60">
          All times shown in Pacific Time (PT). Flight information is provided for reference and may change without notice.
        </p>
      </main>

      <footer className="border-t border-border py-4">
        <div className="mx-auto max-w-6xl px-4 md:px-8 flex items-center justify-between text-[10px] font-mono uppercase tracking-wider text-muted-foreground/50">
          <span>AODB · Airport Operational Database</span>
          {!isSignedIn && (
            <Link href="/sign-in" className="hover:text-foreground transition-colors">
              Staff access →
            </Link>
          )}
        </div>
      </footer>
    </div>
  );
}
