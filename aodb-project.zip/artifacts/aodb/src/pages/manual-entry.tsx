import { useState } from "react";
import { useLocation } from "wouter";
import { useCreateFlight, getListFlightsQueryKey, getGetDashboardSummaryQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { ClipboardEdit, AlertCircle, CheckCircle2 } from "lucide-react";

const AIRLINES = [
  { name: "Air Canada", iata: "AC" },
  { name: "WestJet", iata: "WS" },
  { name: "Pacific Coastal", iata: "8P" },
  { name: "Jazz Aviation", iata: "QK" },
  { name: "Sky Regional", iata: "RS" },
  { name: "Other", iata: "XX" },
];

export default function ManualEntry() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [flightNumber, setFlightNumber] = useState("");
  const [airline, setAirline] = useState("");
  const [airlineIata, setAirlineIata] = useState("");
  const [direction, setDirection] = useState<"ARR" | "DEP">("ARR");
  const [origin, setOrigin] = useState("");
  const [destination, setDestination] = useState("CYLW");
  const [scheduledTime, setScheduledTime] = useState(new Date().toISOString().slice(0, 16));
  const [tailNumber, setTailNumber] = useState("");
  const [aircraftType, setAircraftType] = useState("");
  const [paxCount, setPaxCount] = useState("");
  const [reason, setReason] = useState("");
  const [source, setSource] = useState("MANUAL");

  const createFlight = useCreateFlight({
    mutation: {
      onSuccess: (flight) => {
        queryClient.invalidateQueries({ queryKey: getListFlightsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
        toast({ title: "Flight created", description: `${flight.flightNumber} added to movement board.` });
        navigate(`/flights/${flight.id}`);
      },
    },
  });

  function handleSelectAirline(val: string) {
    const found = AIRLINES.find((a) => a.iata === val);
    if (found) {
      setAirlineIata(found.iata);
      setAirline(found.name);
    }
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!reason.trim()) return;
    createFlight.mutate({
      data: {
        flightNumber: flightNumber.toUpperCase(),
        airline,
        airlineIata,
        direction,
        origin: origin.toUpperCase(),
        destination: destination.toUpperCase(),
        scheduledTime: new Date(scheduledTime).toISOString(),
        tailNumber: tailNumber || undefined,
        aircraftType: aircraftType || undefined,
        paxCount: paxCount ? parseInt(paxCount) : undefined,
        reason,
        source,
      },
    });
  }

  const isValid = flightNumber && airline && airlineIata && origin && destination && scheduledTime && reason.trim();

  return (
    <div className="p-6 space-y-6 max-w-2xl">
      <div>
        <div className="flex items-center gap-2 mb-1">
          <ClipboardEdit className="h-5 w-5 text-primary" />
          <h1 className="text-2xl font-mono font-bold text-foreground">Manual Entry</h1>
        </div>
        <p className="text-sm text-muted-foreground font-mono">Operations — Manual Entry (Ops User)</p>
      </div>

      <Card className="bg-amber-500/5 border-amber-500/20">
        <CardContent className="p-4 flex items-start gap-3">
          <AlertCircle className="h-4 w-4 text-amber-400 mt-0.5 shrink-0" />
          <div className="text-xs font-mono text-amber-200/80">
            Manual entries are appended to the immutable event log with your reason and source. 
            All manual changes are auditable. Reason and source are required.
          </div>
        </CardContent>
      </Card>

      <Card className="bg-card border-card-border">
        <CardHeader className="pb-2 pt-4 px-5">
          <CardTitle className="text-xs font-mono uppercase tracking-wider text-muted-foreground">New Flight Movement</CardTitle>
        </CardHeader>
        <CardContent className="px-5 pb-5">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <Label className="text-xs font-mono uppercase text-muted-foreground">Flight Number *</Label>
                <Input
                  data-testid="input-flight-number"
                  value={flightNumber}
                  onChange={(e) => setFlightNumber(e.target.value)}
                  className="font-mono text-sm bg-background uppercase"
                  placeholder="AC8819"
                  required
                />
              </div>
              <div className="space-y-1">
                <Label className="text-xs font-mono uppercase text-muted-foreground">Airline *</Label>
                <Select value={airlineIata} onValueChange={handleSelectAirline}>
                  <SelectTrigger data-testid="select-airline" className="font-mono text-sm bg-background">
                    <SelectValue placeholder="Select airline" />
                  </SelectTrigger>
                  <SelectContent>
                    {AIRLINES.map((a) => (
                      <SelectItem key={a.iata} value={a.iata} className="font-mono text-sm">
                        <span className="font-bold mr-2">{a.iata}</span> {a.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-1">
                <Label className="text-xs font-mono uppercase text-muted-foreground">Direction *</Label>
                <Select value={direction} onValueChange={(v) => { setDirection(v as "ARR" | "DEP"); if (v === "ARR") { setDestination("CYLW"); setOrigin(""); } else { setOrigin("CYLW"); setDestination(""); } }}>
                  <SelectTrigger data-testid="select-direction" className="font-mono text-sm bg-background">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ARR">ARR — Arrival</SelectItem>
                    <SelectItem value="DEP">DEP — Departure</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label className="text-xs font-mono uppercase text-muted-foreground">Origin *</Label>
                <Input
                  data-testid="input-origin"
                  value={origin}
                  onChange={(e) => setOrigin(e.target.value.toUpperCase())}
                  className="font-mono text-sm bg-background uppercase"
                  placeholder="CYVR"
                  required
                />
              </div>
              <div className="space-y-1">
                <Label className="text-xs font-mono uppercase text-muted-foreground">Destination *</Label>
                <Input
                  data-testid="input-destination"
                  value={destination}
                  onChange={(e) => setDestination(e.target.value.toUpperCase())}
                  className="font-mono text-sm bg-background uppercase"
                  placeholder="CYLW"
                  required
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <Label className="text-xs font-mono uppercase text-muted-foreground">Scheduled Time *</Label>
                <Input
                  data-testid="input-scheduled-time"
                  type="datetime-local"
                  value={scheduledTime}
                  onChange={(e) => setScheduledTime(e.target.value)}
                  className="font-mono text-sm bg-background"
                  required
                />
              </div>
              <div className="space-y-1">
                <Label className="text-xs font-mono uppercase text-muted-foreground">Tail Number</Label>
                <Input
                  data-testid="input-tail-number"
                  value={tailNumber}
                  onChange={(e) => setTailNumber(e.target.value.toUpperCase())}
                  className="font-mono text-sm bg-background uppercase"
                  placeholder="C-FGDP"
                />
              </div>
            </div>
            <div className="grid grid-cols-1 gap-4">
              <div className="space-y-1">
                <Label className="text-xs font-mono uppercase text-muted-foreground">Aircraft Type</Label>
                <Input
                  data-testid="input-aircraft-type"
                  value={aircraftType}
                  onChange={(e) => setAircraftType(e.target.value.toUpperCase())}
                  className="font-mono text-sm bg-background"
                  placeholder="B737-800"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <Label className="text-xs font-mono uppercase text-muted-foreground">Pax Count</Label>
                <Input
                  data-testid="input-pax-count"
                  type="number"
                  value={paxCount}
                  onChange={(e) => setPaxCount(e.target.value)}
                  className="font-mono text-sm bg-background"
                  placeholder="0"
                />
              </div>
              <div className="space-y-1">
                <Label className="text-xs font-mono uppercase text-muted-foreground">Source *</Label>
                <Input
                  data-testid="input-source"
                  value={source}
                  onChange={(e) => setSource(e.target.value)}
                  className="font-mono text-sm bg-background"
                  placeholder="MANUAL"
                  required
                />
              </div>
            </div>
            <div className="space-y-1">
              <Label className="text-xs font-mono uppercase text-muted-foreground">
                Reason / Justification * <span className="text-amber-400">(Required for all manual entries)</span>
              </Label>
              <Textarea
                data-testid="textarea-reason"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="font-mono text-sm bg-background min-h-[80px]"
                placeholder="Describe why this flight is being entered manually..."
                required
              />
            </div>
            <Button
              type="submit"
              className="w-full font-mono text-sm"
              disabled={!isValid || createFlight.isPending}
              data-testid="button-submit-flight"
            >
              {createFlight.isPending ? "Creating..." : "Create Flight Movement"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
