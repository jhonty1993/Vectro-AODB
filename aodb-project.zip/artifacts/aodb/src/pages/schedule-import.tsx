import { useState, useRef, useCallback } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  useGetStaticScheduleStatus,
  useListStaticScheduleMovements,
  getGetStaticScheduleStatusQueryKey,
  getListStaticScheduleMovementsQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import {
  Upload,
  FileText,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  RefreshCw,
  Plane,
  ArrowDown,
  ArrowUp,
  Clock,
  Database,
  Filter,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";

// ── Types ─────────────────────────────────────────────────────────────────────

interface ImportResult {
  success: boolean;
  importId: string;
  filename: string;
  periodStart: string;
  periodEnd: string;
  version: number;
  totalRows: number;
  arrivalCount: number;
  departureCount: number;
  skippedCount: number;
  commercialCount: number;
  errors: string[];
  warnings: string[];
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function fmtTime(t: string | null | undefined): string {
  if (!t) return "—";
  try {
    return new Date(t).toLocaleString("en-CA", {
      month: "short", day: "numeric", hour: "2-digit", minute: "2-digit", hour12: false,
    });
  } catch {
    return t;
  }
}

function dirBadge(dir: string) {
  return dir === "ARR"
    ? <Badge variant="outline" className="text-[9px] font-mono bg-sky-500/10 text-sky-400 border-sky-500/20 px-1 py-0"><ArrowDown className="h-2.5 w-2.5 inline mr-0.5" />ARR</Badge>
    : <Badge variant="outline" className="text-[9px] font-mono bg-indigo-500/10 text-indigo-400 border-indigo-500/20 px-1 py-0"><ArrowUp className="h-2.5 w-2.5 inline mr-0.5" />DEP</Badge>;
}

function matchBadge(status: string | null | undefined) {
  if (status === "matched") return <Badge variant="outline" className="text-[9px] font-mono bg-emerald-500/10 text-emerald-400 border-emerald-500/20 px-1 py-0">Matched</Badge>;
  if (status === "unmatched") return <Badge variant="outline" className="text-[9px] font-mono bg-red-500/10 text-red-400 border-red-500/20 px-1 py-0">Unmatched</Badge>;
  return <Badge variant="outline" className="text-[9px] font-mono bg-slate-500/10 text-slate-400 border-slate-500/20 px-1 py-0">Pending</Badge>;
}

// ── Sub-components ────────────────────────────────────────────────────────────

function ActiveScheduleCard({ onReplace }: { onReplace: () => void }) {
  const statusQ = useGetStaticScheduleStatus({ query: { queryKey: getGetStaticScheduleStatusQueryKey() } });
  const status = statusQ.data;

  if (statusQ.isLoading) return <Skeleton className="h-28" />;
  if (!status) return null;

  if (!status.hasActiveSchedule) {
    return (
      <Card className="bg-amber-500/5 border-amber-500/20">
        <CardContent className="p-4 flex items-center gap-3">
          <AlertTriangle className="h-5 w-5 text-amber-400 shrink-0" />
          <div>
            <div className="font-mono text-sm font-bold text-amber-300">No Active Schedule</div>
            <div className="font-mono text-xs text-amber-200/60 mt-0.5">Upload a turnaround handling CSV to establish the baseline commercial schedule.</div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const imp = status.activeImport!;
  return (
    <Card className="bg-emerald-500/5 border-emerald-500/20">
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="h-5 w-5 text-emerald-400 shrink-0" />
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-sm font-bold text-emerald-300">Active Schedule v{imp.version}</span>
                <Badge variant="outline" className="text-[9px] font-mono bg-emerald-500/20 text-emerald-300 border-emerald-500/20">Live Baseline</Badge>
              </div>
              <div className="font-mono text-xs text-emerald-200/60 mt-0.5 truncate max-w-xs">{imp.filename}</div>
              <div className="font-mono text-xs text-emerald-200/50 mt-0.5">Period: {imp.periodStart} → {imp.periodEnd}</div>
            </div>
          </div>
          <div className="shrink-0 grid grid-cols-2 gap-x-6 gap-y-1 text-right">
            <div><div className="text-[9px] font-mono text-muted-foreground uppercase">Arrivals</div><div className="font-mono text-sm font-bold text-sky-300">{imp.arrivalCount}</div></div>
            <div><div className="text-[9px] font-mono text-muted-foreground uppercase">Departures</div><div className="font-mono text-sm font-bold text-indigo-300">{imp.departureCount}</div></div>
            <div><div className="text-[9px] font-mono text-muted-foreground uppercase">Commercial</div><div className="font-mono text-sm font-bold text-emerald-300">{imp.commercialCount}</div></div>
            <div><div className="text-[9px] font-mono text-muted-foreground uppercase">Skipped</div><div className="font-mono text-sm font-bold text-amber-300">{imp.skippedCount}</div></div>
          </div>
        </div>
        <div className="mt-3 flex items-center justify-between">
          <div className="font-mono text-[10px] text-muted-foreground/50">
            Imported: {new Date(imp.importedAt).toLocaleDateString("en-CA")}
            {status.allImports.length > 1 && ` · ${status.allImports.length} total versions`}
          </div>
          <Button size="sm" variant="outline" className="font-mono text-xs h-7 gap-1" onClick={onReplace}>
            <Upload className="h-3 w-3" />Replace Schedule
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

function ScheduleMovementsTable() {
  const [page, setPage] = useState(1);
  const [dirFilter, setDirFilter] = useState<"" | "ARR" | "DEP">("");
  const [airlineFilter, setAirlineFilter] = useState("");
  const limit = 25;

  const { data, isLoading } = useListStaticScheduleMovements(
    {
      page,
      limit,
      ...(dirFilter ? { direction: dirFilter } : {}),
      ...(airlineFilter ? { airline: airlineFilter.toUpperCase() } : {}),
      commercial_only: true,
    },
    { query: { queryKey: [...getListStaticScheduleMovementsQueryKey(), page, dirFilter, airlineFilter] } }
  );

  const totalPages = data ? Math.ceil(data.total / limit) : 1;

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-3 flex-wrap">
        <div className="flex items-center gap-2">
          <Filter className="h-3.5 w-3.5 text-muted-foreground" />
          <span className="text-xs font-mono text-muted-foreground">Filter:</span>
        </div>
        <div className="flex gap-1">
          {(["", "ARR", "DEP"] as const).map((d) => (
            <button
              key={d || "ALL"}
              onClick={() => { setDirFilter(d); setPage(1); }}
              className={`text-[10px] font-mono px-2 py-0.5 rounded border transition-colors ${dirFilter === d ? "bg-primary/20 border-primary/40 text-primary" : "bg-secondary/30 border-border/30 text-muted-foreground hover:bg-secondary/60"}`}
            >
              {d || "ALL"}
            </button>
          ))}
        </div>
        <Input
          value={airlineFilter}
          onChange={(e) => { setAirlineFilter(e.target.value.toUpperCase()); setPage(1); }}
          placeholder="Airline (WS, AC...)"
          className="font-mono text-xs h-7 w-32 bg-background uppercase"
        />
        {data && <span className="text-[10px] font-mono text-muted-foreground ml-auto">{data.total.toLocaleString()} movements</span>}
      </div>

      <div className="rounded-lg border border-border/40 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead className="bg-secondary/30 border-b border-border/40">
              <tr>
                <th className="px-3 py-2 text-left font-mono text-muted-foreground uppercase text-[9px] tracking-wider">Dir</th>
                <th className="px-3 py-2 text-left font-mono text-muted-foreground uppercase text-[9px] tracking-wider">Flight</th>
                <th className="px-3 py-2 text-left font-mono text-muted-foreground uppercase text-[9px] tracking-wider">Airline</th>
                <th className="px-3 py-2 text-left font-mono text-muted-foreground uppercase text-[9px] tracking-wider">Sched Time</th>
                <th className="px-3 py-2 text-left font-mono text-muted-foreground uppercase text-[9px] tracking-wider">Route</th>
                <th className="px-3 py-2 text-left font-mono text-muted-foreground uppercase text-[9px] tracking-wider">Aircraft</th>
                <th className="px-3 py-2 text-left font-mono text-muted-foreground uppercase text-[9px] tracking-wider">Seats/Pax</th>
                <th className="px-3 py-2 text-left font-mono text-muted-foreground uppercase text-[9px] tracking-wider">FR24</th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                Array.from({ length: 8 }).map((_, i) => (
                  <tr key={i} className="border-b border-border/20"><td colSpan={9} className="px-3 py-2"><Skeleton className="h-4" /></td></tr>
                ))
              ) : !data?.movements.length ? (
                <tr><td colSpan={9} className="px-3 py-6 text-center font-mono text-xs text-muted-foreground">No schedule movements found</td></tr>
              ) : data.movements.map((m) => (
                <tr key={m.id} className="border-b border-border/20 hover:bg-secondary/20 transition-colors">
                  <td className="px-3 py-2">{dirBadge(m.direction)}</td>
                  <td className="px-3 py-2 font-mono font-bold text-foreground">{m.flightNumber}</td>
                  <td className="px-3 py-2 font-mono text-muted-foreground">
                    <div>{m.airlineIata}</div>
                    {m.airlineName && <div className="text-[9px] text-muted-foreground/50 truncate max-w-[80px]">{m.airlineName}</div>}
                  </td>
                  <td className="px-3 py-2 font-mono text-foreground whitespace-nowrap">
                    <div className="flex items-center gap-1"><Clock className="h-2.5 w-2.5 text-muted-foreground" />{fmtTime(m.scheduledTime)}</div>
                  </td>
                  <td className="px-3 py-2 font-mono text-muted-foreground whitespace-nowrap">
                    {m.origin ?? "—"} → {m.destination ?? "—"}
                    {m.city && <div className="text-[9px] text-muted-foreground/50">{m.city}</div>}
                  </td>
                  <td className="px-3 py-2 font-mono text-muted-foreground">
                    <div>{m.aircraftType ?? "—"}</div>
                    {m.aircraftGroup && <div className="text-[9px] text-muted-foreground/50">{m.aircraftGroup}</div>}
                  </td>
                  <td className="px-3 py-2 font-mono text-muted-foreground">
                    <div>{m.seats ?? "—"} / {m.plannedPax ?? "—"}</div>
                  </td>
                  <td className="px-3 py-2">{matchBadge(m.fr24MatchStatus)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {data && data.total > limit && (
        <div className="flex items-center justify-between pt-1">
          <Button size="sm" variant="outline" className="font-mono text-xs h-7 gap-1" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
            <ChevronLeft className="h-3 w-3" />Prev
          </Button>
          <span className="font-mono text-xs text-muted-foreground">Page {page} of {totalPages}</span>
          <Button size="sm" variant="outline" className="font-mono text-xs h-7 gap-1" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>
            Next<ChevronRight className="h-3 w-3" />
          </Button>
        </div>
      )}
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────

export default function ScheduleImport() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [isDragging, setIsDragging] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [csvContent, setCsvContent] = useState<string | null>(null);
  const [detectedHeaders, setDetectedHeaders] = useState<string[]>([]);
  const [previewRows, setPreviewRows] = useState<string[][]>([]);

  const [periodStart, setPeriodStart] = useState("2026-05-01");
  const [periodEnd, setPeriodEnd] = useState("2026-06-30");
  const [replace, setReplace] = useState(true);
  const [notes, setNotes] = useState("");

  const [importResult, setImportResult] = useState<ImportResult | null>(null);
  const [showUpload, setShowUpload] = useState(false);

  const statusQ = useGetStaticScheduleStatus({ query: { queryKey: getGetStaticScheduleStatusQueryKey() } });

  function parsePreview(content: string) {
    const lines = content.split(/\r?\n/).filter((l) => l.trim());
    const headers = lines[0].split(";").map((h) => h.trim().replace(/^"|"$/g, ""));
    setDetectedHeaders(headers);
    const rows = lines.slice(1, 6).map((l) =>
      l.split(";").map((v) => v.trim().replace(/^"|"$/g, "").slice(0, 40))
    );
    setPreviewRows(rows);
  }

  function handleFileSelected(file: File) {
    if (!file.name.endsWith(".csv") && !file.name.endsWith(".txt")) {
      toast({ title: "Invalid file type", description: "Please select a .csv file", variant: "destructive" });
      return;
    }
    setSelectedFile(file);
    setImportResult(null);

    const dateMatch = file.name.match(/(\d{4}-\d{2}-\d{2})_(\d{4}-\d{2}-\d{2})/);
    if (dateMatch) {
      setPeriodStart(dateMatch[1]);
      setPeriodEnd(dateMatch[2]);
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      setCsvContent(content);
      parsePreview(content);
    };
    reader.readAsText(file);
  }

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFileSelected(file);
  }, []);

  const importMutation = useMutation({
    mutationFn: async () => {
      if (!csvContent || !selectedFile) throw new Error("No file selected");
      const res = await fetch("/api/schedules/static/import", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          csv: csvContent,
          filename: selectedFile.name,
          periodStart,
          periodEnd,
          replace,
          notes: notes || undefined,
        }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: "Import failed" }));
        throw new Error(err.error ?? "Import failed");
      }
      return res.json() as Promise<ImportResult>;
    },
    onSuccess: (result) => {
      setImportResult(result);
      queryClient.invalidateQueries({ queryKey: getGetStaticScheduleStatusQueryKey() });
      queryClient.invalidateQueries({ queryKey: getListStaticScheduleMovementsQueryKey() });
      setShowUpload(false);
      toast({
        title: "Schedule imported successfully",
        description: `${result.arrivalCount} arrivals + ${result.departureCount} departures · v${result.version}`,
      });
    },
    onError: (err) => {
      toast({ title: "Import failed", description: String(err.message), variant: "destructive" });
    },
  });

  const hasActive = statusQ.data?.hasActiveSchedule;

  return (
    <div className="p-6 space-y-6 max-w-7xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-mono font-bold tracking-tight text-foreground">Static Schedule Import</h1>
          <p className="text-sm text-muted-foreground mt-1 font-mono">
            Turnaround Handling CSV → Commercial Baseline · FR24 Live Actuals Overlay
          </p>
        </div>
        <div className="flex items-center gap-2">
          {hasActive && !showUpload && (
            <Badge variant="outline" className="font-mono text-xs bg-emerald-500/10 text-emerald-400 border-emerald-500/20 uppercase">Schedule Active</Badge>
          )}
          <Badge variant="outline" className="font-mono text-xs bg-sky-500/10 text-sky-400 border-sky-500/20 uppercase">Commercial Only</Badge>
        </div>
      </div>

      {/* Data strategy banner */}
      <Card className="bg-card border-border/40">
        <CardContent className="p-3 flex flex-wrap items-center gap-6">
          {[
            { label: "Static Turn Schedule CSV", role: "Baseline Schedule", color: "text-amber-300", dot: "bg-amber-400" },
            { label: "Flightradar24 (FR24)", role: "Live Day-of-Ops Actuals", color: "text-violet-300", dot: "bg-violet-400" },
            { label: "ADS-B Exchange", role: "Secondary Verification", color: "text-emerald-300", dot: "bg-emerald-400" },
            { label: "Airport JSON Feed", role: "Phase 2 / Status Overlay", color: "text-slate-400", dot: "bg-slate-500" },
          ].map((s) => (
            <div key={s.label} className="flex items-center gap-2">
              <div className={`h-2 w-2 rounded-full ${s.dot}`} />
              <div>
                <div className={`font-mono text-[10px] font-bold ${s.color}`}>{s.label}</div>
                <div className="font-mono text-[9px] text-muted-foreground/60">{s.role}</div>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      <Tabs defaultValue={hasActive && !showUpload ? "schedule" : "import"}>
        <TabsList className="font-mono text-xs">
          <TabsTrigger value="import">
            <Upload className="h-3.5 w-3.5 mr-1.5" />Import CSV
          </TabsTrigger>
          <TabsTrigger value="schedule">
            <Database className="h-3.5 w-3.5 mr-1.5" />Schedule Board
          </TabsTrigger>
        </TabsList>

        {/* ── IMPORT TAB ── */}
        <TabsContent value="import" className="mt-4 space-y-4">
          <ActiveScheduleCard onReplace={() => setReplace(true)} />

          {/* File Upload Zone */}
          <Card className="bg-card border-card-border">
            <CardHeader className="pb-2 pt-4 px-4">
              <CardTitle className="text-xs font-mono uppercase tracking-wider text-muted-foreground">
                Upload Turnaround Handling CSV
              </CardTitle>
            </CardHeader>
            <CardContent className="px-4 pb-4 space-y-4">
              <div
                onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={onDrop}
                onClick={() => fileInputRef.current?.click()}
                className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-all ${
                  isDragging
                    ? "border-primary/60 bg-primary/5"
                    : selectedFile
                    ? "border-emerald-500/40 bg-emerald-500/5"
                    : "border-border/40 hover:border-border/70 hover:bg-secondary/20"
                }`}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".csv,.txt"
                  className="hidden"
                  onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFileSelected(f); }}
                />
                {selectedFile ? (
                  <div className="space-y-1">
                    <FileText className="h-8 w-8 text-emerald-400 mx-auto" />
                    <div className="font-mono text-sm font-bold text-emerald-300">{selectedFile.name}</div>
                    <div className="font-mono text-xs text-muted-foreground">
                      {(selectedFile.size / 1024 / 1024).toFixed(2)} MB · {detectedHeaders.length} columns detected
                    </div>
                    <div className="font-mono text-[10px] text-muted-foreground/50">Click to select a different file</div>
                  </div>
                ) : (
                  <div className="space-y-1">
                    <Upload className="h-8 w-8 text-muted-foreground/40 mx-auto" />
                    <div className="font-mono text-sm text-muted-foreground">Drag & drop a CSV file here</div>
                    <div className="font-mono text-xs text-muted-foreground/50">or click to browse · semicolon-delimited · turnRoundHandlings format</div>
                  </div>
                )}
              </div>

              {/* Column detection */}
              {detectedHeaders.length > 0 && (
                <div className="space-y-2">
                  <div className="text-xs font-mono uppercase text-muted-foreground tracking-wider">Detected Columns ({detectedHeaders.length})</div>
                  <div className="flex flex-wrap gap-1 max-h-32 overflow-y-auto">
                    {detectedHeaders.map((h) => {
                      const isArr = h.startsWith("Arrival");
                      const isDep = h.startsWith("Departure");
                      return (
                        <code
                          key={h}
                          className={`text-[9px] font-mono px-1.5 py-0.5 rounded ${
                            isArr ? "bg-sky-500/10 text-sky-400/80 border border-sky-500/20"
                            : isDep ? "bg-indigo-500/10 text-indigo-400/80 border border-indigo-500/20"
                            : "bg-secondary text-muted-foreground border border-border/20"
                          }`}
                        >
                          {h}
                        </code>
                      );
                    })}
                  </div>
                  <div className="flex gap-3 text-[10px] font-mono text-muted-foreground/60">
                    <span><span className="inline-block w-2 h-2 rounded bg-sky-500/50 mr-1" />Arrival columns</span>
                    <span><span className="inline-block w-2 h-2 rounded bg-indigo-500/50 mr-1" />Departure columns</span>
                    <span><span className="inline-block w-2 h-2 rounded bg-secondary mr-1" />Resource/other</span>
                  </div>
                </div>
              )}

              {/* Preview table */}
              {previewRows.length > 0 && (
                <div className="space-y-2">
                  <div className="text-xs font-mono uppercase text-muted-foreground tracking-wider">Preview (first 5 rows)</div>
                  <div className="rounded border border-border/40 overflow-x-auto">
                    <table className="text-[9px] font-mono">
                      <thead className="bg-secondary/30">
                        <tr>
                          {detectedHeaders.slice(0, 12).map((h) => (
                            <th key={h} className="px-2 py-1.5 text-left text-muted-foreground whitespace-nowrap">{h}</th>
                          ))}
                          {detectedHeaders.length > 12 && <th className="px-2 py-1.5 text-muted-foreground">+{detectedHeaders.length - 12} more</th>}
                        </tr>
                      </thead>
                      <tbody>
                        {previewRows.map((row, i) => (
                          <tr key={i} className="border-t border-border/20">
                            {row.slice(0, 12).map((cell, j) => (
                              <td key={j} className="px-2 py-1.5 text-muted-foreground whitespace-nowrap max-w-[120px] truncate">{cell || "—"}</td>
                            ))}
                            {row.length > 12 && <td className="px-2 py-1.5 text-muted-foreground/40">…</td>}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Import settings */}
              {selectedFile && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-2 border-t border-border/30">
                  <div className="space-y-1">
                    <Label className="text-xs font-mono uppercase text-muted-foreground">Period Start</Label>
                    <Input value={periodStart} onChange={(e) => setPeriodStart(e.target.value)} className="font-mono text-sm bg-background" placeholder="2026-05-01" />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs font-mono uppercase text-muted-foreground">Period End</Label>
                    <Input value={periodEnd} onChange={(e) => setPeriodEnd(e.target.value)} className="font-mono text-sm bg-background" placeholder="2026-06-30" />
                  </div>
                  <div className="col-span-2 space-y-1">
                    <Label className="text-xs font-mono uppercase text-muted-foreground">Notes (optional)</Label>
                    <Input value={notes} onChange={(e) => setNotes(e.target.value)} className="font-mono text-sm bg-background" placeholder="e.g. Summer schedule IATA S26" />
                  </div>
                  <div className="col-span-2 md:col-span-4 flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => setReplace(!replace)}
                      className={`flex items-center gap-2 text-xs font-mono px-3 py-1.5 rounded border transition-all ${replace ? "border-amber-500/40 bg-amber-500/10 text-amber-300" : "border-border/30 bg-secondary/20 text-muted-foreground"}`}
                    >
                      {replace ? <AlertTriangle className="h-3.5 w-3.5" /> : <CheckCircle2 className="h-3.5 w-3.5" />}
                      {replace ? "Deactivate current schedule on import" : "Keep current schedule active (add as new version)"}
                    </button>
                  </div>
                </div>
              )}

              <Button
                onClick={() => importMutation.mutate()}
                disabled={!selectedFile || !csvContent || importMutation.isPending}
                className="font-mono text-sm gap-2 w-full"
              >
                {importMutation.isPending
                  ? <><RefreshCw className="h-4 w-4 animate-spin" />Parsing & Importing…</>
                  : <><Upload className="h-4 w-4" />Import Static Schedule</>}
              </Button>
            </CardContent>
          </Card>

          {/* Import result */}
          {importResult && (
            <Card className={`${importResult.success ? "bg-emerald-500/5 border-emerald-500/20" : "bg-red-500/5 border-red-500/20"}`}>
              <CardContent className="p-4 space-y-3">
                <div className="flex items-center gap-2">
                  {importResult.success
                    ? <CheckCircle2 className="h-5 w-5 text-emerald-400" />
                    : <XCircle className="h-5 w-5 text-red-400" />}
                  <span className="font-mono font-bold text-sm">
                    {importResult.success ? `Import Complete — Schedule v${importResult.version}` : "Import Failed"}
                  </span>
                </div>
                {importResult.success && (
                  <>
                    <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                      {[
                        { label: "Total Rows", value: importResult.totalRows, cls: "text-foreground" },
                        { label: "Arrivals", value: importResult.arrivalCount, cls: "text-sky-300" },
                        { label: "Departures", value: importResult.departureCount, cls: "text-indigo-300" },
                        { label: "Commercial", value: importResult.commercialCount, cls: "text-emerald-300" },
                        { label: "Skipped", value: importResult.skippedCount, cls: "text-amber-300" },
                      ].map((stat) => (
                        <div key={stat.label} className="bg-secondary/30 rounded p-2 text-center">
                          <div className={`font-mono text-xl font-bold ${stat.cls}`}>{stat.value.toLocaleString()}</div>
                          <div className="font-mono text-[10px] text-muted-foreground uppercase">{stat.label}</div>
                        </div>
                      ))}
                    </div>
                    <div className="font-mono text-xs text-muted-foreground">
                      Period: {importResult.periodStart} → {importResult.periodEnd} · {importResult.filename}
                    </div>
                  </>
                )}
                {importResult.errors.length > 0 && (
                  <div className="space-y-1">
                    <div className="font-mono text-xs font-bold text-red-400">Errors ({importResult.errors.length})</div>
                    {importResult.errors.slice(0, 5).map((e, i) => (
                      <div key={i} className="font-mono text-[10px] text-red-300/70">· {e}</div>
                    ))}
                  </div>
                )}
                {importResult.warnings.length > 0 && (
                  <div className="space-y-1">
                    <div className="font-mono text-xs font-bold text-amber-400">Warnings</div>
                    {importResult.warnings.map((w, i) => (
                      <div key={i} className="font-mono text-[10px] text-amber-300/70">· {w}</div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Mapping rules reference */}
          <Card className="bg-card border-card-border">
            <CardHeader className="pb-2 pt-4 px-4">
              <CardTitle className="text-xs font-mono uppercase tracking-wider text-muted-foreground">CSV Mapping Rules</CardTitle>
            </CardHeader>
            <CardContent className="px-4 pb-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <div className="flex items-center gap-1.5 mb-2"><ArrowDown className="h-3.5 w-3.5 text-sky-400" /><span className="font-mono text-xs font-bold text-sky-300">Arrival Movements</span></div>
                  <div className="space-y-1 font-mono text-[10px] text-muted-foreground">
                    {[
                      ["Trigger", "ArrivalScheduleTime populated"],
                      ["Flight #", "ArrivalAirline + ArrivalFlightNumber"],
                      ["STA", "ArrivalScheduleTime"],
                      ["Origin", "ArrivalOrigin / ArrivalCity"],
                      ["Destination", "YLW (fixed)"],
                      ["Aircraft", "ArrivalAircraftType"],
                      ["Pax", "ArrivalPax / ArrivalSeats"],
                      ["Commercial?", "FlightType=J or airline IATA in set"],
                    ].map(([k, v]) => (
                      <div key={k} className="flex gap-2"><span className="w-24 text-muted-foreground/50 shrink-0">{k}</span><span>{v}</span></div>
                    ))}
                  </div>
                </div>
                <div>
                  <div className="flex items-center gap-1.5 mb-2"><ArrowUp className="h-3.5 w-3.5 text-indigo-400" /><span className="font-mono text-xs font-bold text-indigo-300">Departure Movements</span></div>
                  <div className="space-y-1 font-mono text-[10px] text-muted-foreground">
                    {[
                      ["Trigger", "DepartureScheduleTime populated"],
                      ["Flight #", "DepartureAirline + DepartureFlightNumber"],
                      ["STD", "DepartureScheduleTime"],
                      ["Origin", "YLW (fixed)"],
                      ["Destination", "DepartureOrigin / DepartureCity"],
                      ["Aircraft", "DepartureAircraftType"],
                      ["Pax", "DeparturePax / DepartureSeats"],
                      ["Commercial?", "FlightType=J or airline IATA in set"],
                    ].map(([k, v]) => (
                      <div key={k} className="flex gap-2"><span className="w-24 text-muted-foreground/50 shrink-0">{k}</span><span>{v}</span></div>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── SCHEDULE BOARD TAB ── */}
        <TabsContent value="schedule" className="mt-4 space-y-4">
          <ActiveScheduleCard onReplace={() => {}} />

          {statusQ.data?.hasActiveSchedule ? (
            <Card className="bg-card border-card-border">
              <CardHeader className="pb-2 pt-4 px-4">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xs font-mono uppercase tracking-wider text-muted-foreground">
                    <Plane className="h-3.5 w-3.5 inline mr-1.5 text-primary" />
                    Commercial Schedule Movements
                  </CardTitle>
                  <Badge variant="outline" className="text-[9px] font-mono bg-sky-500/10 text-sky-400 border-sky-500/20">Commercial Only</Badge>
                </div>
              </CardHeader>
              <CardContent className="px-4 pb-4">
                <ScheduleMovementsTable />
              </CardContent>
            </Card>
          ) : (
            <Card className="bg-card border-card-border">
              <CardContent className="p-12 text-center">
                <Database className="h-10 w-10 text-muted-foreground/30 mx-auto mb-3" />
                <div className="font-mono text-sm text-muted-foreground">No active schedule imported yet</div>
                <div className="font-mono text-xs text-muted-foreground/50 mt-1">Upload a turnaround handling CSV on the Import tab to populate the schedule board.</div>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
