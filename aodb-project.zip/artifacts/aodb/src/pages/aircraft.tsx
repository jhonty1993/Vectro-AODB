import { useState } from "react";
import {
  useListAircraft,
  useListTariffs,
  useCreateAircraft,
  useCreateTariff,
  getListAircraftQueryKey,
  getListTariffsQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Plane, Plus, Check } from "lucide-react";
import type { AircraftRegistry, TariffRecord } from "@workspace/api-client-react";

export default function AircraftPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [aircraftOpen, setAircraftOpen] = useState(false);
  const [tariffOpen, setTariffOpen] = useState(false);

  // Aircraft form
  const [tailNumber, setTailNumber] = useState("");
  const [aircraftType, setAircraftType] = useState("");
  const [mtowKg, setMtowKg] = useState("");
  const [engineType, setEngineType] = useState("TURBOFAN");
  const [seats, setSeats] = useState("");
  const [noiseCategory, setNoiseCategory] = useState("CAT2");
  const [airline, setAirline] = useState("");

  // Tariff form
  const [tariffVersion, setTariffVersion] = useState("");
  const [effectiveDate, setEffectiveDate] = useState(new Date().toISOString().slice(0, 10));
  const [expiryDate, setExpiryDate] = useState("");
  const [ldDom, setLdDom] = useState("2.90");
  const [ldIntl, setLdIntl] = useState("3.45");
  const [aifDom, setAifDom] = useState("16.50");
  const [aifIntl, setAifIntl] = useState("27.00");
  const [noiseCat1, setNoiseCat1] = useState("65.00");
  const [noiseCat2, setNoiseCat2] = useState("185.00");

  const aircraftQuery = useListAircraft({ query: { queryKey: getListAircraftQueryKey() } });
  const tariffsQuery = useListTariffs({ query: { queryKey: getListTariffsQueryKey() } });

  const createAircraft = useCreateAircraft({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListAircraftQueryKey() });
        setAircraftOpen(false);
        toast({ title: "Aircraft added", description: `${tailNumber} added to registry.` });
        setTailNumber(""); setAircraftType(""); setMtowKg(""); setSeats(""); setAirline("");
      },
    },
  });

  const createTariff = useCreateTariff({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListTariffsQueryKey() });
        setTariffOpen(false);
        toast({ title: "Tariff version created", description: `Version ${tariffVersion} added.` });
        setTariffVersion("");
      },
    },
  });

  const aircraft = aircraftQuery.data ?? [];
  const tariffs = tariffsQuery.data ?? [];

  return (
    <div className="p-6 space-y-6">
      <div>
        <div className="flex items-center gap-2 mb-1">
          <Plane className="h-5 w-5 text-primary" />
          <h1 className="text-2xl font-mono font-bold text-foreground">Aircraft & Tariffs</h1>
        </div>
        <p className="text-sm text-muted-foreground font-mono">Admin — Registry & Tariffs (Admin User)</p>
      </div>

      <Tabs defaultValue="aircraft">
        <TabsList className="font-mono text-xs bg-secondary">
          <TabsTrigger value="aircraft">Aircraft Registry ({aircraft.length})</TabsTrigger>
          <TabsTrigger value="tariffs">Tariff Records ({tariffs.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="aircraft" className="mt-4">
          <Card className="bg-card border-card-border">
            <CardHeader className="pb-2 pt-4 px-4">
              <div className="flex items-center justify-between">
                <CardTitle className="text-xs font-mono uppercase tracking-wider text-muted-foreground">Aircraft Registry — Keyed by Tail Number</CardTitle>
                <Dialog open={aircraftOpen} onOpenChange={setAircraftOpen}>
                  <DialogTrigger asChild>
                    <Button size="sm" variant="outline" className="h-7 text-xs font-mono gap-1" data-testid="button-add-aircraft">
                      <Plus className="h-3.5 w-3.5" />Add Aircraft
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="bg-card border-card-border max-w-md">
                    <DialogHeader>
                      <DialogTitle className="font-mono text-sm">Add to Aircraft Registry</DialogTitle>
                    </DialogHeader>
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        createAircraft.mutate({
                          data: { tailNumber, aircraftType, mtowKg: parseFloat(mtowKg), engineType, seats: seats ? parseInt(seats) : undefined, noiseCategory: noiseCategory || undefined, airline: airline || undefined },
                        });
                      }}
                      className="space-y-3 mt-2"
                    >
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <Label className="text-xs font-mono uppercase text-muted-foreground">Tail Number *</Label>
                          <Input data-testid="input-tail" value={tailNumber} onChange={(e) => setTailNumber(e.target.value.toUpperCase())} className="font-mono text-xs bg-background uppercase" placeholder="C-FGDP" required />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs font-mono uppercase text-muted-foreground">Aircraft Type *</Label>
                          <Input data-testid="input-type" value={aircraftType} onChange={(e) => setAircraftType(e.target.value)} className="font-mono text-xs bg-background" placeholder="B737-800" required />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs font-mono uppercase text-muted-foreground">MTOW (kg) *</Label>
                          <Input data-testid="input-mtow" type="number" value={mtowKg} onChange={(e) => setMtowKg(e.target.value)} className="font-mono text-xs bg-background" placeholder="79016" required />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs font-mono uppercase text-muted-foreground">Engine Type *</Label>
                          <Select value={engineType} onValueChange={setEngineType}>
                            <SelectTrigger data-testid="select-engine" className="font-mono text-xs bg-background">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="TURBOFAN">TURBOFAN</SelectItem>
                              <SelectItem value="TURBOPROP">TURBOPROP</SelectItem>
                              <SelectItem value="PISTON">PISTON</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs font-mono uppercase text-muted-foreground">Seats</Label>
                          <Input data-testid="input-seats" type="number" value={seats} onChange={(e) => setSeats(e.target.value)} className="font-mono text-xs bg-background" placeholder="162" />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs font-mono uppercase text-muted-foreground">Noise Category</Label>
                          <Select value={noiseCategory} onValueChange={setNoiseCategory}>
                            <SelectTrigger className="font-mono text-xs bg-background">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="CAT1">CAT1</SelectItem>
                              <SelectItem value="CAT2">CAT2</SelectItem>
                              <SelectItem value="CAT3">CAT3</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs font-mono uppercase text-muted-foreground">Airline</Label>
                        <Input data-testid="input-airline" value={airline} onChange={(e) => setAirline(e.target.value)} className="font-mono text-xs bg-background" placeholder="Air Canada" />
                      </div>
                      <Button type="submit" className="w-full font-mono text-xs" disabled={createAircraft.isPending} data-testid="button-submit-aircraft">
                        {createAircraft.isPending ? "Adding..." : "Add to Registry"}
                      </Button>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent className="px-0 pb-0">
              <div className="overflow-x-auto">
                <table className="w-full text-xs font-mono">
                  <thead>
                    <tr className="border-b border-border text-muted-foreground">
                      {["Tail No.", "Type", "MTOW (kg)", "Engine", "Seats", "Noise Cat.", "Airline"].map((h) => (
                        <th key={h} className="px-4 py-2 text-left uppercase tracking-wider text-[10px] whitespace-nowrap">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {aircraftQuery.isLoading ? (
                      Array.from({ length: 5 }).map((_, i) => (
                        <tr key={i} className="border-b border-border/50">
                          {Array.from({ length: 7 }).map((_, j) => <td key={j} className="px-4 py-2"><Skeleton className="h-3 w-16" /></td>)}
                        </tr>
                      ))
                    ) : aircraft.map((a: AircraftRegistry) => (
                      <tr key={a.id} data-testid={`aircraft-row-${a.id}`} className="border-b border-border/40 hover:bg-secondary/30">
                        <td className="px-4 py-2 font-bold text-foreground">{a.tailNumber}</td>
                        <td className="px-4 py-2">{a.aircraftType}</td>
                        <td className="px-4 py-2">{a.mtowKg.toLocaleString()}</td>
                        <td className="px-4 py-2 text-muted-foreground">{a.engineType}</td>
                        <td className="px-4 py-2 text-muted-foreground">{a.seats ?? "—"}</td>
                        <td className="px-4 py-2">
                          {a.noiseCategory && (
                            <Badge variant="outline" className="text-[10px] font-mono uppercase px-1.5 py-0">{a.noiseCategory}</Badge>
                          )}
                        </td>
                        <td className="px-4 py-2 text-muted-foreground">{a.airline ?? "—"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tariffs" className="mt-4">
          <Card className="bg-card border-card-border">
            <CardHeader className="pb-2 pt-4 px-4">
              <div className="flex items-center justify-between">
                <CardTitle className="text-xs font-mono uppercase tracking-wider text-muted-foreground">Versioned Tariff Records</CardTitle>
                <Dialog open={tariffOpen} onOpenChange={setTariffOpen}>
                  <DialogTrigger asChild>
                    <Button size="sm" variant="outline" className="h-7 text-xs font-mono gap-1" data-testid="button-add-tariff">
                      <Plus className="h-3.5 w-3.5" />New Version
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="bg-card border-card-border max-w-md">
                    <DialogHeader>
                      <DialogTitle className="font-mono text-sm">New Tariff Version</DialogTitle>
                    </DialogHeader>
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        createTariff.mutate({
                          data: {
                            version: tariffVersion,
                            effectiveDate,
                            expiryDate: expiryDate || undefined,
                            landingFeeDomesticPerTonne: parseFloat(ldDom),
                            landingFeeIntlPerTonne: parseFloat(ldIntl),
                            aifDomestic: parseFloat(aifDom),
                            aifIntl: parseFloat(aifIntl),
                            noiseChargeCategory1: parseFloat(noiseCat1),
                            noiseChargeCategory2: parseFloat(noiseCat2),
                            currency: "CAD",
                          },
                        });
                      }}
                      className="space-y-3 mt-2"
                    >
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <Label className="text-xs font-mono uppercase text-muted-foreground">Version *</Label>
                          <Input data-testid="input-version" value={tariffVersion} onChange={(e) => setTariffVersion(e.target.value)} className="font-mono text-xs bg-background" placeholder="2025-B" required />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs font-mono uppercase text-muted-foreground">Effective Date *</Label>
                          <Input data-testid="input-effective" type="date" value={effectiveDate} onChange={(e) => setEffectiveDate(e.target.value)} className="font-mono text-xs bg-background" required />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs font-mono uppercase text-muted-foreground">LD Fee Dom/t (CAD)</Label>
                          <Input data-testid="input-ld-dom" type="number" step="0.01" value={ldDom} onChange={(e) => setLdDom(e.target.value)} className="font-mono text-xs bg-background" />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs font-mono uppercase text-muted-foreground">LD Fee Intl/t (CAD)</Label>
                          <Input data-testid="input-ld-intl" type="number" step="0.01" value={ldIntl} onChange={(e) => setLdIntl(e.target.value)} className="font-mono text-xs bg-background" />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs font-mono uppercase text-muted-foreground">AIF Dom (CAD/pax)</Label>
                          <Input type="number" step="0.01" value={aifDom} onChange={(e) => setAifDom(e.target.value)} className="font-mono text-xs bg-background" />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs font-mono uppercase text-muted-foreground">AIF Intl (CAD/pax)</Label>
                          <Input type="number" step="0.01" value={aifIntl} onChange={(e) => setAifIntl(e.target.value)} className="font-mono text-xs bg-background" />
                        </div>
                      </div>
                      <Button type="submit" className="w-full font-mono text-xs" disabled={createTariff.isPending} data-testid="button-submit-tariff">
                        {createTariff.isPending ? "Creating..." : "Create Tariff Version"}
                      </Button>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent className="px-0 pb-0">
              <div className="overflow-x-auto">
                <table className="w-full text-xs font-mono">
                  <thead>
                    <tr className="border-b border-border text-muted-foreground">
                      {["Version", "Effective", "Expiry", "LD Dom/t", "LD Intl/t", "AIF Dom", "AIF Intl", "Noise Cat1", "Noise Cat2", "Currency", "Active"].map((h) => (
                        <th key={h} className="px-3 py-2 text-left uppercase tracking-wider text-[10px] whitespace-nowrap">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {tariffsQuery.isLoading ? (
                      Array.from({ length: 4 }).map((_, i) => (
                        <tr key={i} className="border-b border-border/50">
                          {Array.from({ length: 11 }).map((_, j) => <td key={j} className="px-3 py-2"><Skeleton className="h-3 w-12" /></td>)}
                        </tr>
                      ))
                    ) : tariffs.map((t: TariffRecord) => (
                      <tr key={t.id} data-testid={`tariff-row-${t.id}`} className={`border-b border-border/40 hover:bg-secondary/30 ${t.isActive ? "bg-emerald-500/5" : ""}`}>
                        <td className="px-3 py-2 font-bold text-foreground">{t.version}</td>
                        <td className="px-3 py-2">{t.effectiveDate}</td>
                        <td className="px-3 py-2 text-muted-foreground">{t.expiryDate ?? "—"}</td>
                        <td className="px-3 py-2">${t.landingFeeDomesticPerTonne.toFixed(2)}</td>
                        <td className="px-3 py-2">${t.landingFeeIntlPerTonne.toFixed(2)}</td>
                        <td className="px-3 py-2">${t.aifDomestic.toFixed(2)}</td>
                        <td className="px-3 py-2">${t.aifIntl.toFixed(2)}</td>
                        <td className="px-3 py-2">${t.noiseChargeCategory1.toFixed(2)}</td>
                        <td className="px-3 py-2">${t.noiseChargeCategory2.toFixed(2)}</td>
                        <td className="px-3 py-2 text-muted-foreground">{t.currency}</td>
                        <td className="px-3 py-2">
                          {t.isActive ? (
                            <Badge variant="outline" className="bg-emerald-500/20 text-emerald-300 border-emerald-500/20 text-[10px] font-mono uppercase px-1.5 py-0">
                              <Check className="h-2.5 w-2.5 mr-1" />Active
                            </Badge>
                          ) : (
                            <span className="text-muted-foreground text-[10px]">inactive</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
