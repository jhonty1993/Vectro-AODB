// Lightweight billing API client + types for the AODB billing module.
// Uses raw fetch + react-query (mirrors public-board.tsx). Types mirror the
// Drizzle select shapes from @workspace/db (dates arrive as ISO strings).

export async function apiGet<T>(path: string): Promise<T> {
  const r = await fetch(`/api${path}`);
  if (!r.ok) {
    const body = await r.json().catch(() => ({}));
    throw new Error(body.error || `GET ${path} failed (${r.status})`);
  }
  return r.json();
}

export async function apiSend<T>(path: string, method: string, body?: unknown): Promise<T> {
  const r = await fetch(`/api${path}`, {
    method,
    headers: body !== undefined ? { "Content-Type": "application/json" } : undefined,
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  if (!r.ok) {
    const errBody = await r.json().catch(() => ({}));
    throw new Error(errBody.error || `${method} ${path} failed (${r.status})`);
  }
  if (r.status === 204) return undefined as T;
  return r.json();
}

export function formatCAD(val: number | null | undefined, currency = "CAD"): string {
  if (val == null) return "—";
  return new Intl.NumberFormat("en-CA", { style: "currency", currency }).format(val);
}

export function formatDate(s: string | null | undefined): string {
  if (!s) return "—";
  try {
    return new Date(s.length <= 10 ? s + "T12:00:00Z" : s).toLocaleDateString("en-CA", {
      year: "numeric",
      month: "short",
      day: "2-digit",
    });
  } catch {
    return s;
  }
}

export function formatDateTime(s: string | null | undefined): string {
  if (!s) return "—";
  try {
    return new Date(s).toLocaleString("en-CA", {
      timeZone: "America/Vancouver",
      month: "short",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
    });
  } catch {
    return s;
  }
}

/* ----------------------------- Types ----------------------------- */

export type BillingCustomer = {
  id: string;
  code: string;
  name: string;
  type: string;
  iataCode: string | null;
  icaoCode: string | null;
  contactName: string | null;
  contactEmail: string | null;
  billingAddress: string | null;
  paymentTermsDays: number;
  currency: string;
  status: string;
  notes: string | null;
  createdAt: string;
  updatedAt: string;
};

export type ItemCode = {
  id: string;
  code: string;
  name: string;
  description: string | null;
  category: string;
  unit: string;
  glAccount: string | null;
  taxable: boolean;
  active: boolean;
  createdAt: string;
  updatedAt: string;
};

export type RatePlan = {
  id: string;
  name: string;
  description: string | null;
  effectiveFrom: string;
  effectiveTo: string | null;
  currency: string;
  status: string;
  isDefault: boolean;
  createdAt: string;
  updatedAt: string;
};

export type RateRule = {
  id: string;
  ratePlanId: string;
  itemCodeId: string;
  name: string;
  priority: number;
  effectiveFrom: string;
  effectiveTo: string | null;
  routeType: string;
  engineType: string;
  customerType: string;
  direction: string;
  airlineIata: string | null;
  minMtowKg: number | null;
  maxMtowKg: number | null;
  calcMethod: string;
  rateAmount: number;
  minCharge: number | null;
  maxCharge: number | null;
  currency: string;
  notes: string | null;
  active: boolean;
  createdAt: string;
  updatedAt: string;
};

export type ChargeStatus = "pending" | "held" | "discarded" | "ready" | "invoiced" | "credited";

export type BillableCharge = {
  id: string;
  movementId: string | null;
  customerId: string | null;
  itemCodeId: string;
  ratePlanId: string | null;
  rateRuleId: string | null;
  description: string;
  quantity: number;
  unitRate: number;
  amount: number;
  currency: string;
  status: ChargeStatus;
  alertLevel: string;
  confidenceScore: number;
  holdReason: string | null;
  discardReason: string | null;
  invoiceBatchId: string | null;
  invoiceId: string | null;
  chargeDate: string;
  source: string;
  movementDataSource?: string | null;
  createdAt: string;
  updatedAt: string;
};

export type BillingAlert = {
  id: string;
  chargeId: string;
  level: string;
  code: string;
  message: string;
  resolved: boolean;
  createdAt: string;
};

export type BillingDecision = {
  id: string;
  chargeId: string;
  action: string;
  detail: string;
  payload: unknown;
  operator: string | null;
  createdAt: string;
};

export type Movement = {
  id: string;
  flightNumber: string;
  airline: string;
  airlineIata: string;
  direction: "ARR" | "DEP";
  origin: string;
  destination: string;
  scheduledTime: string;
  estimatedTime: string | null;
  actualTime: string | null;
  tailNumber: string | null;
  aircraftType: string | null;
  status: string;
  dataSource: string | null;
};

export type ChargeDetail = BillableCharge & {
  alerts: BillingAlert[];
  decisions: BillingDecision[];
  movement: Movement | null;
  customer: BillingCustomer | null;
  rateRule: RateRule | null;
  itemCode: ItemCode | null;
};

export type InvoiceBatch = {
  id: string;
  batchNumber: string;
  status: string;
  periodStart: string | null;
  periodEnd: string | null;
  chargeCount: number;
  invoiceCount: number;
  totalAmount: number;
  currency: string;
  createdBy: string | null;
  notes: string | null;
  createdAt: string;
  updatedAt: string;
};

export type Invoice = {
  id: string;
  invoiceNumber: string;
  batchId: string;
  customerId: string;
  status: string;
  issueDate: string | null;
  dueDate: string | null;
  subtotal: number;
  taxAmount: number;
  total: number;
  currency: string;
  createdAt: string;
  updatedAt: string;
};

export type InvoiceLine = {
  id: string;
  invoiceId: string;
  chargeId: string | null;
  itemCodeId: string;
  description: string;
  quantity: number;
  unitRate: number;
  amount: number;
  taxRate: number;
  taxAmount: number;
  createdAt: string;
};

export type InvoiceBatchDetail = InvoiceBatch & {
  invoices: (Invoice & { lines: InvoiceLine[] })[];
};

export type ParkingStay = {
  id: string;
  arrivalMovementId: string | null;
  departureMovementId: string | null;
  customerId: string | null;
  tailNumber: string | null;
  stand: string | null;
  arrivalTime: string | null;
  departureTime: string | null;
  durationMinutes: number;
  freeMinutes: number;
  chargeableMinutes: number;
  status: string;
  chargeId: string | null;
  createdAt: string;
  updatedAt: string;
};

export type RecurringContract = {
  id: string;
  customerId: string;
  itemCodeId: string;
  name: string;
  description: string | null;
  amount: number;
  currency: string;
  frequency: string;
  nextRunDate: string | null;
  lastRunDate: string | null;
  effectiveFrom: string | null;
  effectiveTo: string | null;
  status: string;
  createdAt: string;
  updatedAt: string;
};

export type BillingDashboard = {
  totals: {
    charges: number;
    customers: number;
    activeRules: number;
    batches: number;
    readyAmount: number;
    invoicedAmount: number;
    blockedCount: number;
    unmappedCount: number;
    noRuleCount: number;
  };
  byStatus: Record<string, { count: number; amount: number }>;
  alertBreakdown: Record<string, number>;
  openAlertCodes: Record<string, number>;
  topCustomers: { customerId: string; name: string; amount: number }[];
  currency: string;
};

export const CHARGE_STATUS_STYLE: Record<string, string> = {
  pending: "bg-slate-500/20 text-slate-300 border-slate-500/30",
  held: "bg-amber-500/20 text-amber-300 border-amber-500/30",
  discarded: "bg-zinc-600/20 text-zinc-400 border-zinc-600/30",
  ready: "bg-blue-500/20 text-blue-300 border-blue-500/30",
  invoiced: "bg-emerald-500/20 text-emerald-300 border-emerald-500/30",
  credited: "bg-purple-500/20 text-purple-300 border-purple-500/30",
};

export const ALERT_LEVEL_STYLE: Record<string, string> = {
  green: "bg-emerald-500/20 text-emerald-300 border-emerald-500/30",
  blue: "bg-blue-500/20 text-blue-300 border-blue-500/30",
  yellow: "bg-amber-500/20 text-amber-300 border-amber-500/30",
  purple: "bg-purple-500/20 text-purple-300 border-purple-500/30",
  red: "bg-red-500/20 text-red-300 border-red-500/30",
  black: "bg-zinc-900 text-zinc-200 border-zinc-700",
};

export const DATA_SOURCE_STYLE: Record<string, string> = {
  YLW_FEED: "bg-cyan-500/20 text-cyan-300 border-cyan-500/30",
  FR24_LIVE: "bg-violet-500/20 text-violet-300 border-violet-500/30",
  FR24_HISTORIC: "bg-violet-500/10 text-violet-300/80 border-violet-500/20",
  FR24: "bg-violet-500/20 text-violet-300 border-violet-500/30",
  ADSBX: "bg-orange-500/20 text-orange-300 border-orange-500/30",
  CIRIUM: "bg-blue-500/20 text-blue-300 border-blue-500/30",
  MANUAL: "bg-slate-500/20 text-slate-300 border-slate-500/30",
};

export const DATA_SOURCE_LABEL: Record<string, string> = {
  YLW_FEED: "YLW Feed",
  FR24_LIVE: "FR24 Live",
  FR24_HISTORIC: "FR24 Historic",
  FR24: "FR24",
  ADSBX: "ADS-B Exchange",
  CIRIUM: "Cirium",
  MANUAL: "Manual",
};

export function dataSourceStyle(src: string | null | undefined): string {
  if (!src) return "bg-zinc-700/20 text-zinc-400 border-zinc-700/30";
  return DATA_SOURCE_STYLE[src] ?? "bg-zinc-700/20 text-zinc-400 border-zinc-700/30";
}

export function dataSourceLabel(src: string | null | undefined): string {
  if (!src) return "Unknown";
  return DATA_SOURCE_LABEL[src] ?? src;
}

export const ALERT_CODE_LABEL: Record<string, string> = {
  NO_CUSTOMER_MAPPING: "No customer mapping",
  NO_RATE_RULE: "No rate rule matched",
  MTOW_MISSING: "MTOW missing",
  LOW_CONFIDENCE: "Low confidence",
  DUPLICATE_SUSPECTED: "Possible duplicate",
  MIN_CHARGE_APPLIED: "Minimum charge applied",
  MANUAL_OVERRIDE: "Manual override",
};
