import { type ReactNode } from "react";
import { useUser } from "@clerk/react";
import { Redirect } from "wouter";

export type Role = "public" | "ops" | "finance" | "admin";

const RANK: Record<Role, number> = { public: 0, ops: 1, finance: 2, admin: 3 };

// Roles are read from Clerk publicMetadata.role. Access is invite-only (trusted
// staff), so this drives nav visibility and client-side route guards. Default is
// "admin" so that a freshly invited staff account sees the full console until a
// role is explicitly assigned in the Clerk dashboard.
export function useRole(): Role {
  const { user } = useUser();
  const raw = user?.publicMetadata?.role;
  if (raw === "public" || raw === "ops" || raw === "finance" || raw === "admin") {
    return raw;
  }
  return "admin";
}

export function hasRole(role: Role, allowed: Role[]): boolean {
  return allowed.includes(role);
}

export function atLeast(role: Role, min: Role): boolean {
  return RANK[role] >= RANK[min];
}

// Client-side route guard. Redirects to /ops if the signed-in user's role is
// below the minimum required. Backend routes are still auth-gated at the
// requireAuth (signed-in) level; this guard is for nav/UX in an invite-only,
// trusted-staff deployment.
export function RequireRole({
  min,
  redirectTo = "/ops",
  children,
}: {
  min: Role;
  redirectTo?: string;
  children: ReactNode;
}) {
  const { isLoaded } = useUser();
  const role = useRole();
  if (!isLoaded) return null;
  if (!atLeast(role, min)) return <Redirect to={redirectTo} />;
  return <>{children}</>;
}
