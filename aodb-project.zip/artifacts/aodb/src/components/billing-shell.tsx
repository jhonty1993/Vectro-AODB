import { Link, useLocation } from "wouter";
import {
  LayoutDashboard,
  ReceiptText,
  FileStack,
  Building2,
  Tags,
  Scale,
  ParkingSquare,
  Repeat,
} from "lucide-react";

const TABS = [
  { title: "Dashboard", url: "/billing", icon: LayoutDashboard },
  { title: "Charges", url: "/billing/charges", icon: ReceiptText },
  { title: "Invoice Batches", url: "/billing/invoices", icon: FileStack },
  { title: "Customers", url: "/billing/customers", icon: Building2 },
  { title: "Item Codes", url: "/billing/item-codes", icon: Tags },
  { title: "Rate Plans", url: "/billing/rate-plans", icon: Scale },
  { title: "Parking", url: "/billing/parking", icon: ParkingSquare },
  { title: "Recurring", url: "/billing/recurring", icon: Repeat },
];

export function BillingShell({
  title,
  description,
  actions,
  children,
}: {
  title: string;
  description?: string;
  actions?: React.ReactNode;
  children: React.ReactNode;
}) {
  const [location] = useLocation();

  return (
    <div className="min-h-screen p-6 space-y-6">
      <div>
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h1 className="text-2xl font-bold font-mono tracking-tight text-foreground">{title}</h1>
            {description && <p className="text-sm text-muted-foreground mt-1">{description}</p>}
          </div>
          {actions && <div className="flex items-center gap-2">{actions}</div>}
        </div>
        <nav className="mt-4 flex flex-wrap gap-1 border-b border-border">
          {TABS.map((tab) => {
            const active = location === tab.url;
            return (
              <Link
                key={tab.url}
                href={tab.url}
                className={`flex items-center gap-1.5 px-3 py-2 text-xs font-mono uppercase tracking-wide border-b-2 -mb-px transition-colors ${
                  active
                    ? "border-primary text-foreground"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                }`}
              >
                <tab.icon className="h-3.5 w-3.5" />
                {tab.title}
              </Link>
            );
          })}
        </nav>
      </div>
      {children}
    </div>
  );
}
