import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useClerk, useUser } from "@clerk/react";
import { 
  Plane, 
  Activity, 
  ClipboardEdit, 
  Settings2, 
  Banknote, 
  Scale, 
  Database,
  Network,
  FileText,
  CreditCard,
  Radio,
  LogOut,
  Monitor,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useRole, atLeast, type Role } from "@/lib/role";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
} from "@/components/ui/sidebar";
import { Badge } from "@/components/ui/badge";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

export function AppLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { user } = useUser();
  const { signOut } = useClerk();

  const { data: health } = useQuery<{ freshness?: string; isDemo?: boolean }>({
    queryKey: ["data-health"],
    queryFn: () => fetch("/api/flights/data-health").then((r) => r.json()),
    refetchInterval: 20_000,
  });
  const fresh = health?.freshness;
  const statusBadge =
    fresh === "LIVE"
      ? { label: "Live", cls: "bg-green-500/10 text-green-500 border-green-500/20" }
      : fresh === "STALE"
        ? { label: "Stale", cls: "bg-orange-500/10 text-orange-400 border-orange-500/20" }
        : fresh === "DEMO_CURRENT" || fresh === "DEMO_STALE"
          ? { label: "Demo", cls: "bg-amber-500/10 text-amber-400 border-amber-500/20" }
          : { label: "—", cls: "bg-slate-500/10 text-slate-400 border-slate-500/20" };

  const role = useRole();

  const allGroups: {
    title: string;
    min: Role;
    items: { title: string; url: string; icon: React.ElementType }[];
  }[] = [
    {
      title: "Operations",
      min: "ops",
      items: [
        { title: "Dashboard", url: "/ops", icon: Activity },
        { title: "ADS-B Live Map", url: "/adsb-map", icon: Radio },
        { title: "Schedule Import", url: "/schedule-import", icon: FileText },
        { title: "Manual Entry", url: "/manual-entry", icon: ClipboardEdit },
      ],
    },
    {
      title: "Integrations",
      min: "ops",
      items: [
        { title: "RMS", url: "/rms", icon: Settings2 },
      ],
    },
    {
      title: "Finance",
      min: "finance",
      items: [
        { title: "Billing Dashboard", url: "/billing", icon: Banknote },
        { title: "Charges", url: "/billing/charges", icon: FileText },
        { title: "Invoice Batches", url: "/billing/invoices", icon: CreditCard },
        { title: "Customers", url: "/billing/customers", icon: Plane },
        { title: "Item Codes", url: "/billing/item-codes", icon: Database },
        { title: "Rate Plans", url: "/billing/rate-plans", icon: Scale },
        { title: "Parking", url: "/billing/parking", icon: Settings2 },
        { title: "Recurring", url: "/billing/recurring", icon: Network },
        { title: "Reconciliation", url: "/billing/reconciliation", icon: Banknote },
      ],
    },
    {
      title: "Admin",
      min: "ops",
      items: [
        { title: "Aircraft & Tariffs", url: "/aircraft", icon: Plane },
        { title: "Quality", url: "/quality", icon: Scale },
        { title: "Data Sources", url: "/data-sources", icon: Network },
        { title: "FR24 Credit Usage", url: "/fr24-usage", icon: CreditCard },
        { title: "Settings", url: "/settings", icon: Database },
      ],
    },
  ];

  const navigation = allGroups.filter((g) => atLeast(role, g.min));

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full bg-background dark text-foreground">
        <Sidebar className="border-r border-border bg-sidebar">
          <SidebarHeader className="border-b border-sidebar-border px-4 py-4">
            <div className="flex items-center gap-2 font-mono font-bold text-lg tracking-tight text-sidebar-primary">
              <Plane className="h-6 w-6" />
              <span>AODB</span>
              <Badge variant="outline" className="text-[9px] font-mono uppercase bg-sky-500/20 text-sky-300 border-sky-500/30 px-1.5 py-0 ml-0.5">Commercial</Badge>
            </div>
            <div className="text-xs text-muted-foreground font-mono mt-1 uppercase">YLW Commercial Ops · MVP</div>
          </SidebarHeader>
          <SidebarContent>
            {navigation.map((group) => (
              <SidebarGroup key={group.title}>
                <SidebarGroupLabel className="font-mono uppercase tracking-wider text-[10px] text-sidebar-foreground/50">{group.title}</SidebarGroupLabel>
                <SidebarGroupContent>
                  <SidebarMenu>
                    {group.items.map((item) => (
                      <SidebarMenuItem key={item.title}>
                        <SidebarMenuButton asChild isActive={location === item.url}>
                          <Link href={item.url}>
                            <item.icon className="h-4 w-4" />
                            <span>{item.title}</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    ))}
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>
            ))}
          </SidebarContent>
          <SidebarFooter className="border-t border-sidebar-border p-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono text-muted-foreground">Data Status</span>
              <Badge variant="outline" className={`uppercase font-mono text-[10px] ${statusBadge.cls}`}>
                {statusBadge.label}
              </Badge>
            </div>
            <div className="mt-1.5 flex items-center justify-between">
              <span className="text-[10px] font-mono text-sidebar-foreground/40">{health?.isDemo ? "Demo data" : "Live sources"}</span>
              <Badge variant="outline" className="text-[9px] font-mono uppercase bg-sky-500/10 text-sky-400 border-sky-500/20 px-1 py-0">
                Commercial MVP
              </Badge>
            </div>

            <div className="mt-3 border-t border-sidebar-border/60 pt-3 space-y-2">
              <Link
                href="/"
                className="flex items-center gap-2 text-[11px] font-mono text-sidebar-foreground/70 hover:text-sidebar-foreground transition-colors"
              >
                <Monitor className="h-3.5 w-3.5" />
                View public board
              </Link>
              {user && (
                <div className="flex items-center justify-between gap-2">
                  <span className="truncate text-[10px] font-mono text-sidebar-foreground/50">
                    {user.primaryEmailAddress?.emailAddress ?? user.username ?? "Signed in"}
                  </span>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-7 px-2 text-[10px] font-mono uppercase tracking-wider text-sidebar-foreground/70 hover:text-sidebar-foreground"
                    onClick={() => signOut({ redirectUrl: BASE || "/" })}
                  >
                    <LogOut className="h-3.5 w-3.5" />
                    Sign out
                  </Button>
                </div>
              )}
            </div>
          </SidebarFooter>
        </Sidebar>
        <main className="flex-1 overflow-auto">
          {children}
        </main>
      </div>
    </SidebarProvider>
  );
}
