import { lazy, Suspense, useEffect, useRef } from "react";
import {
  Switch,
  Route,
  Redirect,
  useLocation,
  Router as WouterRouter,
} from "wouter";
import {
  QueryClient,
  QueryClientProvider,
  useQueryClient,
} from "@tanstack/react-query";
import {
  ClerkProvider,
  SignIn,
  SignUp,
  useClerk,
  useUser,
} from "@clerk/react";
import { publishableKeyFromHost } from "@clerk/react/internal";
import { shadcn } from "@clerk/themes";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { AppLayout } from "@/components/layout";
import { RequireRole } from "@/lib/role";

const PublicBoard = lazy(() => import("@/pages/public-board"));
const Dashboard = lazy(() => import("@/pages/dashboard"));
const FlightDetail = lazy(() => import("@/pages/flight-detail"));
const ManualEntry = lazy(() => import("@/pages/manual-entry"));
const RmsPage = lazy(() => import("@/pages/rms"));
const Billing = lazy(() => import("@/pages/billing"));
const BillingDashboard = lazy(() => import("@/pages/billing/dashboard"));
const BillingCharges = lazy(() => import("@/pages/billing/charges"));
const BillingInvoices = lazy(() => import("@/pages/billing/invoices"));
const BillingCustomers = lazy(() => import("@/pages/billing/customers"));
const BillingItemCodes = lazy(() => import("@/pages/billing/item-codes"));
const BillingRatePlans = lazy(() => import("@/pages/billing/rate-plans"));
const BillingParking = lazy(() => import("@/pages/billing/parking"));
const BillingRecurring = lazy(() => import("@/pages/billing/recurring"));
const AircraftPage = lazy(() => import("@/pages/aircraft"));
const Quality = lazy(() => import("@/pages/quality"));
const Settings = lazy(() => import("@/pages/settings"));
const DataSources = lazy(() => import("@/pages/data-sources"));
const ScheduleImport = lazy(() => import("@/pages/schedule-import"));
const Fr24Usage = lazy(() => import("@/pages/fr24-usage"));
const AdsbMap = lazy(() => import("@/pages/adsb-map"));

// REQUIRED — copy verbatim. Resolves the key from window.location.hostname so the
// same build serves multiple Clerk custom domains.
const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);

// REQUIRED — copy verbatim. Empty in dev, auto-set in prod. Do NOT gate on PROD.
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;

const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

function stripBase(path: string): string {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || "/"
    : path;
}

if (!clerkPubKey) {
  throw new Error("Missing VITE_CLERK_PUBLISHABLE_KEY in .env file");
}

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      staleTime: 30_000,
    },
  },
});

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: "clerk",
  options: {
    logoPlacement: "inside" as const,
    logoLinkUrl: basePath || "/",
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: "hsl(217 91% 60%)",
    colorForeground: "hsl(210 40% 98%)",
    colorMutedForeground: "hsl(215 20% 65%)",
    colorDanger: "hsl(0 84% 60%)",
    colorBackground: "hsl(220 20% 10%)",
    colorInput: "hsl(220 20% 16%)",
    colorInputForeground: "hsl(210 40% 98%)",
    colorNeutral: "hsl(220 20% 24%)",
    fontFamily: "'Inter', sans-serif",
    borderRadius: "0.5rem",
  },
  elements: {
    rootBox: "w-full flex justify-center",
    cardBox:
      "bg-[hsl(220_20%_10%)] border border-[hsl(220_20%_16%)] rounded-2xl w-[440px] max-w-full overflow-hidden shadow-2xl",
    card: "!shadow-none !border-0 !bg-transparent !rounded-none",
    footer: "!shadow-none !border-0 !bg-transparent !rounded-none",
    headerTitle: "text-[hsl(210_40%_98%)]",
    headerSubtitle: "text-[hsl(215_20%_65%)]",
    socialButtonsBlockButtonText: "text-[hsl(210_40%_98%)]",
    formFieldLabel: "text-[hsl(210_40%_98%)]",
    formButtonPrimary:
      "bg-[hsl(217_91%_60%)] hover:bg-[hsl(217_91%_54%)] text-white",
    footerActionText: "text-[hsl(215_20%_65%)]",
    footerActionLink: "text-[hsl(217_91%_65%)] hover:text-[hsl(217_91%_72%)]",
    dividerText: "text-[hsl(215_20%_65%)]",
    formFieldInput:
      "bg-[hsl(220_20%_16%)] text-[hsl(210_40%_98%)] border-[hsl(220_20%_24%)]",
  },
};

function SignInPage() {
  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-background px-4">
      <SignIn
        routing="path"
        path={`${basePath}/sign-in`}
        signUpUrl={`${basePath}/sign-up`}
        fallbackRedirectUrl={`${basePath}/ops`}
      />
    </div>
  );
}

function SignUpPage() {
  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-background px-4">
      <SignUp
        routing="path"
        path={`${basePath}/sign-up`}
        signInUrl={`${basePath}/sign-in`}
        fallbackRedirectUrl={`${basePath}/ops`}
      />
    </div>
  );
}

function PageLoader() {
  return (
    <div className="flex items-center justify-center h-48 text-muted-foreground font-mono text-xs">
      Loading...
    </div>
  );
}

function FullScreenLoader() {
  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-background text-muted-foreground font-mono text-xs">
      Loading…
    </div>
  );
}

function OpsRoutes() {
  const { isLoaded, isSignedIn } = useUser();

  if (!isLoaded) return <FullScreenLoader />;
  if (!isSignedIn) return <Redirect to="/sign-in" />;

  return (
    <RequireRole min="ops" redirectTo="/">
    <AppLayout>
      <Suspense fallback={<PageLoader />}>
        <Switch>
          <Route path="/ops" component={Dashboard} />
          <Route path="/flights/:id" component={FlightDetail} />
          <Route path="/manual-entry" component={ManualEntry} />
          <Route path="/rms" component={RmsPage} />
          <Route path="/billing">
            <RequireRole min="finance"><BillingDashboard /></RequireRole>
          </Route>
          <Route path="/billing/charges">
            <RequireRole min="finance"><BillingCharges /></RequireRole>
          </Route>
          <Route path="/billing/invoices">
            <RequireRole min="finance"><BillingInvoices /></RequireRole>
          </Route>
          <Route path="/billing/customers">
            <RequireRole min="finance"><BillingCustomers /></RequireRole>
          </Route>
          <Route path="/billing/item-codes">
            <RequireRole min="finance"><BillingItemCodes /></RequireRole>
          </Route>
          <Route path="/billing/rate-plans">
            <RequireRole min="finance"><BillingRatePlans /></RequireRole>
          </Route>
          <Route path="/billing/parking">
            <RequireRole min="finance"><BillingParking /></RequireRole>
          </Route>
          <Route path="/billing/recurring">
            <RequireRole min="finance"><BillingRecurring /></RequireRole>
          </Route>
          <Route path="/billing/reconciliation">
            <RequireRole min="finance"><Billing /></RequireRole>
          </Route>
          <Route path="/aircraft" component={AircraftPage} />
          <Route path="/quality" component={Quality} />
          <Route path="/data-sources" component={DataSources} />
          <Route path="/settings" component={Settings} />
          <Route path="/schedule-import" component={ScheduleImport} />
          <Route path="/fr24-usage" component={Fr24Usage} />
          <Route path="/adsb-map" component={AdsbMap} />
          <Route component={NotFound} />
        </Switch>
      </Suspense>
    </AppLayout>
    </RequireRole>
  );
}

// Invalidate cached queries when the signed-in user changes.
function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const qc = useQueryClient();
  const prevUserIdRef = useRef<string | null | undefined>(undefined);

  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const userId = user?.id ?? null;
      if (
        prevUserIdRef.current !== undefined &&
        prevUserIdRef.current !== userId
      ) {
        qc.clear();
      }
      prevUserIdRef.current = userId;
    });
    return unsubscribe;
  }, [addListener, qc]);

  return null;
}

function ClerkProviderWithRoutes() {
  const [, setLocation] = useLocation();

  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      localization={{
        signIn: {
          start: {
            title: "Staff sign in",
            subtitle: "Access the YLW operations console",
          },
        },
        signUp: {
          start: {
            title: "Create staff account",
            subtitle: "Invite-only access to YLW operations",
          },
        },
      }}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <QueryClientProvider client={queryClient}>
        <ClerkQueryClientCacheInvalidator />
        <TooltipProvider>
          <Suspense fallback={<FullScreenLoader />}>
            <Switch>
              <Route path="/" component={PublicBoard} />
              <Route path="/sign-in/*?" component={SignInPage} />
              <Route path="/sign-up/*?" component={SignUpPage} />
              <Route component={OpsRoutes} />
            </Switch>
          </Suspense>
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </ClerkProvider>
  );
}

function App() {
  return (
    <WouterRouter base={basePath}>
      <ClerkProviderWithRoutes />
    </WouterRouter>
  );
}

export default App;
