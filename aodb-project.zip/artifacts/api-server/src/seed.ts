import { db } from "@workspace/db";
import {
  flightMovementsTable,
  flightEventsTable,
  aircraftRegistryTable,
  tariffRecordsTable,
  billingRecordsTable,
  integrationOutboxTable,
  appSettingsTable,
} from "@workspace/db";
import { eq } from "drizzle-orm";
import { randomUUID } from "crypto";

const YLW_TZ = "America/Vancouver";

// Get today's date string in Pacific time
function getYLWToday(): string {
  return new Intl.DateTimeFormat("en-CA", { timeZone: YLW_TZ }).format(new Date());
}

// Convert a Pacific local hour:minute on a given date to a proper UTC ISO string
function pacificToUTC(dateStr: string, hour: number, minute: number): string {
  // Probe the PDT/PST offset for this specific date
  const probe = new Date(dateStr + "T20:00:00Z");
  const pacificHour = parseInt(
    new Intl.DateTimeFormat("en-US", { timeZone: YLW_TZ, hour: "2-digit", hour12: false }).format(probe)
  );
  const offsetHours = 20 - pacificHour; // 7 for PDT, 8 for PST
  const [yr, mo, dy] = dateStr.split("-").map(Number);
  return new Date(Date.UTC(yr, mo - 1, dy, hour + offsetHours, minute, 0, 0)).toISOString();
}

const dateStr = getYLWToday();

// ts() creates a UTC ISO string for a Pacific local time on today's date
function ts(hour: number, minute: number = 0): string {
  return pacificToUTC(dateStr, hour, minute);
}

const AIRCRAFT_REGISTRY = [
  { id: randomUUID(), tailNumber: "C-FGDP", aircraftType: "B737-800", mtowKg: 79016, engineType: "TURBOFAN", seats: 162, noiseCategory: "CAT2", airline: "Air Canada" },
  { id: randomUUID(), tailNumber: "C-GJLS", aircraftType: "A320-200", mtowKg: 73500, engineType: "TURBOFAN", seats: 150, noiseCategory: "CAT2", airline: "WestJet" },
  { id: randomUUID(), tailNumber: "C-FFNA", aircraftType: "DHC-8-402", mtowKg: 29257, engineType: "TURBOPROP", seats: 74, noiseCategory: "CAT1", airline: "Pacific Coastal" },
  { id: randomUUID(), tailNumber: "C-GKPJ", aircraftType: "CRJ-900", mtowKg: 36514, engineType: "TURBOFAN", seats: 76, noiseCategory: "CAT2", airline: "Jazz Aviation" },
  { id: randomUUID(), tailNumber: "C-FWSK", aircraftType: "B737-700", mtowKg: 70080, engineType: "TURBOFAN", seats: 128, noiseCategory: "CAT2", airline: "WestJet" },
  { id: randomUUID(), tailNumber: "C-GTQC", aircraftType: "A319-100", mtowKg: 64000, engineType: "TURBOFAN", seats: 120, noiseCategory: "CAT2", airline: "Air Canada" },
  { id: randomUUID(), tailNumber: "C-FMZX", aircraftType: "B737-MAX8", mtowKg: 82191, engineType: "TURBOFAN", seats: 178, noiseCategory: "CAT2", airline: "WestJet" },
  { id: randomUUID(), tailNumber: "C-GPNR", aircraftType: "ERJ-175", mtowKg: 38600, engineType: "TURBOFAN", seats: 76, noiseCategory: "CAT2", airline: "Sky Regional" },
];

const flightId1 = randomUUID();
const flightId2 = randomUUID();
const flightId3 = randomUUID();
const flightId4 = randomUUID();
const flightId5 = randomUUID();
const flightId6 = randomUUID();
const flightId7 = randomUUID();
const flightId8 = randomUUID();
const flightId9 = randomUUID();
const flightId10 = randomUUID();
const flightId11 = randomUUID();
const flightId12 = randomUUID();
const flightId13 = randomUUID();
const flightId14 = randomUUID();
const flightId15 = randomUUID();
const flightId16 = randomUUID();
const flightId17 = randomUUID();
const flightId18 = randomUUID();

const FLIGHT_MOVEMENTS = [
  // Arrivals
  { id: flightId1, flightNumber: "AC8819", airline: "Air Canada", airlineIata: "AC", direction: "ARR", origin: "CYVR", destination: "CYLW", scheduledTime: ts(6, 45), estimatedTime: ts(6, 50), actualTime: ts(6, 52), tailNumber: "C-FGDP", aircraftType: "B737-800", stand: null, gate: null, belt: null, runway: null, status: "ON_BLOCK", dataQualityScore: 95, delayMinutes: 7, paxCount: 142 },
  { id: flightId2, flightNumber: "WS3281", airline: "WestJet", airlineIata: "WS", direction: "ARR", origin: "CYYC", destination: "CYLW", scheduledTime: ts(7, 30), estimatedTime: ts(7, 45), actualTime: ts(7, 48), tailNumber: "C-GJLS", aircraftType: "A320-200", stand: null, gate: null, belt: null, runway: null, status: "ON_BLOCK", dataQualityScore: 92, delayMinutes: 18, paxCount: 138 },
  { id: flightId3, flightNumber: "8P401", airline: "Pacific Coastal", airlineIata: "8P", direction: "ARR", origin: "CYVR", destination: "CYLW", scheduledTime: ts(9, 15), estimatedTime: ts(9, 20), actualTime: null, tailNumber: "C-FFNA", aircraftType: "DHC-8-402", stand: null, gate: null, belt: null, runway: null, status: "AIRBORNE", dataQualityScore: 78, delayMinutes: 5, paxCount: 58 },
  { id: flightId4, flightNumber: "QK8419", airline: "Jazz Aviation", airlineIata: "QK", direction: "ARR", origin: "CYEG", destination: "CYLW", scheduledTime: ts(10, 0), estimatedTime: ts(10, 35), actualTime: null, tailNumber: "C-GKPJ", aircraftType: "CRJ-900", stand: null, gate: null, belt: null, runway: null, status: "AIRBORNE", dataQualityScore: 70, delayMinutes: 35, paxCount: 68 },
  { id: flightId5, flightNumber: "AC1234", airline: "Air Canada", airlineIata: "AC", direction: "ARR", origin: "CYYZ", destination: "CYLW", scheduledTime: ts(11, 20), estimatedTime: null, actualTime: null, tailNumber: null, aircraftType: "A320-200", stand: null, gate: null, belt: null, runway: null, status: "SCHEDULED", dataQualityScore: 55, delayMinutes: null, paxCount: null },
  { id: flightId6, flightNumber: "WS1102", airline: "WestJet", airlineIata: "WS", direction: "ARR", origin: "CYYC", destination: "CYLW", scheduledTime: ts(13, 0), estimatedTime: ts(13, 22), actualTime: null, tailNumber: "C-FMZX", aircraftType: "B737-MAX8", stand: null, gate: null, belt: null, runway: null, status: "ESTIMATED", dataQualityScore: 82, delayMinutes: 22, paxCount: 165 },
  { id: flightId7, flightNumber: "AC8823", airline: "Air Canada", airlineIata: "AC", direction: "ARR", origin: "CYVR", destination: "CYLW", scheduledTime: ts(14, 35), estimatedTime: null, actualTime: null, tailNumber: "C-GTQC", aircraftType: "A319-100", stand: null, gate: null, belt: null, runway: null, status: "SCHEDULED", dataQualityScore: 88, delayMinutes: null, paxCount: 112 },
  { id: flightId8, flightNumber: "WS3285", airline: "WestJet", airlineIata: "WS", direction: "ARR", origin: "CYEG", destination: "CYLW", scheduledTime: ts(16, 10), estimatedTime: null, actualTime: null, tailNumber: null, aircraftType: null, stand: null, gate: null, belt: null, runway: null, status: "SCHEDULED", dataQualityScore: 42, delayMinutes: null, paxCount: null },
  { id: flightId9, flightNumber: "QK8423", airline: "Jazz Aviation", airlineIata: "QK", direction: "ARR", origin: "CYVR", destination: "CYLW", scheduledTime: ts(17, 45), estimatedTime: ts(17, 45), actualTime: null, tailNumber: "C-GPNR", aircraftType: "ERJ-175", stand: null, gate: null, belt: null, runway: null, status: "ESTIMATED", dataQualityScore: 76, delayMinutes: 0, paxCount: 72 },
  { id: flightId10, flightNumber: "AC8831", airline: "Air Canada", airlineIata: "AC", direction: "ARR", origin: "CYVR", destination: "CYLW", scheduledTime: ts(19, 25), estimatedTime: null, actualTime: null, tailNumber: null, aircraftType: "B737-800", stand: null, gate: null, belt: null, runway: null, status: "SCHEDULED", dataQualityScore: 65, delayMinutes: null, paxCount: null },
  // Cancelled/Diverted
  { id: flightId11, flightNumber: "WS3289", airline: "WestJet", airlineIata: "WS", direction: "ARR", origin: "CYYC", destination: "CYLW", scheduledTime: ts(15, 30), estimatedTime: null, actualTime: null, tailNumber: "C-FWSK", aircraftType: "B737-700", stand: null, gate: null, belt: null, runway: null, status: "CANCELLED", dataQualityScore: 60, delayMinutes: null, paxCount: 120 },
  { id: flightId12, flightNumber: "8P405", airline: "Pacific Coastal", airlineIata: "8P", direction: "ARR", origin: "CYVR", destination: "CYLW", scheduledTime: ts(18, 0), estimatedTime: null, actualTime: null, tailNumber: "C-FFNA", aircraftType: "DHC-8-402", stand: null, gate: null, belt: null, runway: null, status: "DIVERTED", dataQualityScore: 58, delayMinutes: null, paxCount: 45 },
  // Departures
  { id: flightId13, flightNumber: "AC8820", airline: "Air Canada", airlineIata: "AC", direction: "DEP", origin: "CYLW", destination: "CYVR", scheduledTime: ts(7, 30), estimatedTime: ts(7, 35), actualTime: ts(7, 37), tailNumber: "C-FGDP", aircraftType: "B737-800", stand: null, gate: null, belt: null, runway: null, status: "DEPARTED", dataQualityScore: 97, delayMinutes: 7, paxCount: 148 },
  { id: flightId14, flightNumber: "WS3282", airline: "WestJet", airlineIata: "WS", direction: "DEP", origin: "CYLW", destination: "CYYC", scheduledTime: ts(8, 20), estimatedTime: ts(8, 20), actualTime: ts(8, 23), tailNumber: "C-GJLS", aircraftType: "A320-200", stand: null, gate: null, belt: null, runway: null, status: "DEPARTED", dataQualityScore: 90, delayMinutes: 3, paxCount: 131 },
  { id: flightId15, flightNumber: "8P402", airline: "Pacific Coastal", airlineIata: "8P", direction: "DEP", origin: "CYLW", destination: "CYVR", scheduledTime: ts(10, 0), estimatedTime: ts(10, 15), actualTime: null, tailNumber: "C-FFNA", aircraftType: "DHC-8-402", stand: null, gate: null, belt: null, runway: null, status: "ESTIMATED", dataQualityScore: 74, delayMinutes: 15, paxCount: 52 },
  { id: flightId16, flightNumber: "QK8420", airline: "Jazz Aviation", airlineIata: "QK", direction: "DEP", origin: "CYLW", destination: "CYEG", scheduledTime: ts(11, 15), estimatedTime: null, actualTime: null, tailNumber: null, aircraftType: "CRJ-900", stand: null, gate: null, belt: null, runway: null, status: "SCHEDULED", dataQualityScore: 50, delayMinutes: null, paxCount: null },
  { id: flightId17, flightNumber: "WS1103", airline: "WestJet", airlineIata: "WS", direction: "DEP", origin: "CYLW", destination: "CYYC", scheduledTime: ts(14, 10), estimatedTime: ts(14, 40), actualTime: null, tailNumber: "C-FMZX", aircraftType: "B737-MAX8", stand: null, gate: null, belt: null, runway: null, status: "AIRBORNE", dataQualityScore: 85, delayMinutes: 30, paxCount: 172 },
  { id: flightId18, flightNumber: "AC8824", airline: "Air Canada", airlineIata: "AC", direction: "DEP", origin: "CYLW", destination: "CYYZ", scheduledTime: ts(17, 0), estimatedTime: null, actualTime: null, tailNumber: "C-GTQC", aircraftType: "A319-100", stand: null, gate: null, belt: null, runway: null, status: "SCHEDULED", dataQualityScore: 72, delayMinutes: null, paxCount: 108 },
];

const TARIFF_RECORDS = [
  { id: randomUUID(), version: "2022-A", effectiveDate: "2022-01-01", expiryDate: "2022-12-31", landingFeeDomesticPerTonne: 2.45, landingFeeIntlPerTonne: 2.95, aifDomestic: 13.00, aifIntl: 20.00, noiseChargeCategory1: 50.0, noiseChargeCategory2: 150.0, currency: "CAD", isActive: false },
  { id: randomUUID(), version: "2023-A", effectiveDate: "2023-01-01", expiryDate: "2023-12-31", landingFeeDomesticPerTonne: 2.60, landingFeeIntlPerTonne: 3.10, aifDomestic: 14.00, aifIntl: 22.00, noiseChargeCategory1: 55.0, noiseChargeCategory2: 160.0, currency: "CAD", isActive: false },
  { id: randomUUID(), version: "2024-A", effectiveDate: "2024-01-01", expiryDate: "2024-12-31", landingFeeDomesticPerTonne: 2.75, landingFeeIntlPerTonne: 3.25, aifDomestic: 15.00, aifIntl: 25.00, noiseChargeCategory1: 60.0, noiseChargeCategory2: 175.0, currency: "CAD", isActive: true },
  { id: randomUUID(), version: "2025-A", effectiveDate: "2025-01-01", expiryDate: null, landingFeeDomesticPerTonne: 2.90, landingFeeIntlPerTonne: 3.45, aifDomestic: 16.50, aifIntl: 27.00, noiseChargeCategory1: 65.0, noiseChargeCategory2: 185.0, currency: "CAD", isActive: false },
];

function buildBillingRecords() {
  const billingFlights = [
    FLIGHT_MOVEMENTS.find((f) => f.id === flightId1)!,
    FLIGHT_MOVEMENTS.find((f) => f.id === flightId2)!,
    FLIGHT_MOVEMENTS.find((f) => f.id === flightId13)!,
    FLIGHT_MOVEMENTS.find((f) => f.id === flightId14)!,
    FLIGHT_MOVEMENTS.find((f) => f.id === flightId12)!,
  ];

  return [
    { id: randomUUID(), flightId: flightId1, flightNumber: "AC8819", airline: "Air Canada", tailNumber: "C-FGDP", aircraftType: "B737-800", mtowKg: 79016, engineType: "TURBOFAN", isInternational: false, landingTime: ts(6, 52), paxCount: 142, calculatedLandingFee: 217.3, aifEstimate: 2130.0, tariffVersion: "2024-A", reconciliationStatus: "RECONCILED", flags: [] },
    { id: randomUUID(), flightId: flightId2, flightNumber: "WS3281", airline: "WestJet", tailNumber: "C-GJLS", aircraftType: "A320-200", mtowKg: 73500, engineType: "TURBOFAN", isInternational: false, landingTime: ts(7, 48), paxCount: 138, calculatedLandingFee: 202.1, aifEstimate: 2070.0, tariffVersion: "2024-A", reconciliationStatus: "FLAGGED", flags: ["PAX_VARIANCE"] },
    { id: randomUUID(), flightId: flightId13, flightNumber: "AC8820", airline: "Air Canada", tailNumber: "C-FGDP", aircraftType: "B737-800", mtowKg: 79016, engineType: "TURBOFAN", isInternational: false, landingTime: ts(7, 37), paxCount: 148, calculatedLandingFee: 217.3, aifEstimate: 2220.0, tariffVersion: "2024-A", reconciliationStatus: "RECONCILED", flags: [] },
    { id: randomUUID(), flightId: flightId14, flightNumber: "WS3282", airline: "WestJet", tailNumber: "C-GJLS", aircraftType: "A320-200", mtowKg: 73500, engineType: "TURBOFAN", isInternational: false, landingTime: ts(8, 23), paxCount: 131, calculatedLandingFee: 202.1, aifEstimate: 1965.0, tariffVersion: "2024-A", reconciliationStatus: "PENDING", flags: [] },
    { id: randomUUID(), flightId: flightId12, flightNumber: "8P405", airline: "Pacific Coastal", tailNumber: "C-FFNA", aircraftType: "DHC-8-402", mtowKg: 29257, engineType: "TURBOPROP", isInternational: false, landingTime: null, paxCount: 45, calculatedLandingFee: null, aifEstimate: null, tariffVersion: "2024-A", reconciliationStatus: "FLAGGED", flags: ["MISSING_LANDING_TIME", "DIVERTED_FLIGHT"] },
    { id: randomUUID(), flightId: flightId11, flightNumber: "WS3289", airline: "WestJet", tailNumber: "C-FWSK", aircraftType: "B737-700", mtowKg: null, engineType: "TURBOFAN", isInternational: false, landingTime: null, paxCount: 120, calculatedLandingFee: null, aifEstimate: null, tariffVersion: "2024-A", reconciliationStatus: "FLAGGED", flags: ["MISSING_LANDING_TIME", "MTOW_MISMATCH"] },
  ];
}

function buildOutboxEvents(flights: typeof FLIGHT_MOVEMENTS) {
  const events = [];
  for (const f of flights.slice(0, 8)) {
    events.push({
      id: randomUUID(),
      flightId: f.id,
      flightNumber: f.flightNumber,
      eventType: "FLIGHT_CREATED",
      destination: "RMS" as const,
      status: "SENT" as const,
      payload: { flightNumber: f.flightNumber, direction: f.direction, scheduledTime: f.scheduledTime },
      sentAt: new Date(Date.now() - Math.random() * 3600000).toISOString(),
    });
  }
  // A few queued and failed ones
  events.push({
    id: randomUUID(), flightId: flightId5, flightNumber: "AC1234", eventType: "STAND_REQUEST",
    destination: "RMS" as const, status: "QUEUED" as const,
    payload: { flightId: flightId5, requestedStand: "A1" }, sentAt: null,
  });
  events.push({
    id: randomUUID(), flightId: flightId8, flightNumber: "WS3285", eventType: "ALLOCATION_UPDATED",
    destination: "RMS" as const, status: "FAILED" as const,
    payload: { error: "RMS timeout", retryCount: 3 }, sentAt: new Date(Date.now() - 600000).toISOString(),
  });
  return events;
}

function buildFlightEvents() {
  const events = [];
  for (const f of FLIGHT_MOVEMENTS) {
    events.push({
      id: randomUUID(),
      flightId: f.id,
      eventType: "SCHEDULED",
      eventTime: f.scheduledTime,
      source: "SCHED",
      operator: null as string | null,
      reason: "Initial schedule import from airline schedule feed",
      payload: { flightNumber: f.flightNumber, origin: f.origin, destination: f.destination, scheduledTime: f.scheduledTime },
    });
    if (f.estimatedTime) {
      events.push({
        id: randomUUID(), flightId: f.id, eventType: "ESTIMATED", eventTime: f.estimatedTime,
        source: "FR24_SIMULATOR", operator: null, reason: "ETA updated via ADS-B position data",
        payload: { estimatedTime: f.estimatedTime, previousStatus: "SCHEDULED", position: { lat: 49.5 + Math.random(), lon: -119.0 + Math.random() } },
      });
    }
    if (f.status === "AIRBORNE" || f.status === "LANDED" || f.status === "ON_BLOCK" || f.status === "DEPARTED") {
      events.push({
        id: randomUUID(), flightId: f.id, eventType: "AIRBORNE", eventTime: new Date(new Date(f.scheduledTime).getTime() - 3600000).toISOString(),
        source: "FR24_SIMULATOR", operator: null, reason: "Aircraft airborne detected",
        payload: { altitude: 35000, groundSpeed: 450, heading: 280 },
      });
    }
    if (f.actualTime && (f.status === "ON_BLOCK" || f.status === "LANDED")) {
      events.push({
        id: randomUUID(), flightId: f.id, eventType: "LANDED", eventTime: f.actualTime,
        source: "FR24_SIMULATOR", operator: null, reason: "Landing confirmed via ADS-B touchdown",
        payload: { landingTime: f.actualTime, windDirection: "340", windSpeed: 12 },
      });
    }
    if (f.status === "ON_BLOCK" && f.actualTime) {
      events.push({
        id: randomUUID(), flightId: f.id, eventType: "ON_BLOCK", eventTime: new Date(new Date(f.actualTime).getTime() + 12 * 60000).toISOString(),
        source: "ACARS", operator: null, reason: "ACARS on-block time received",
        payload: { onBlockTime: new Date(new Date(f.actualTime).getTime() + 12 * 60000).toISOString() },
      });
    }
    if (f.status === "DEPARTED" && f.actualTime) {
      events.push({
        id: randomUUID(), flightId: f.id, eventType: "DEPARTED", eventTime: f.actualTime,
        source: "ACARS", operator: null, reason: "Off-block and departure confirmed",
        payload: { departureTime: f.actualTime },
      });
    }
    if (f.status === "CANCELLED") {
      events.push({
        id: randomUUID(), flightId: f.id, eventType: "CANCELLED", eventTime: new Date(new Date(f.scheduledTime).getTime() - 7200000).toISOString(),
        source: "MANUAL", operator: "Ops Controller", reason: "Cancelled by airline - weather conditions at origin",
        payload: { cancelledBy: "WestJet Operations", reason: "WEATHER" },
      });
    }
    if (f.status === "DIVERTED") {
      events.push({
        id: randomUUID(), flightId: f.id, eventType: "DIVERTED", eventTime: new Date(new Date(f.scheduledTime).getTime() - 3600000).toISOString(),
        source: "ATC", operator: "YLW TWR", reason: "Diverted to CYKA due to low visibility at YLW",
        payload: { divertedTo: "CYKA", reason: "LOW_VIS", ceiling: 200, visibility: 0.25 },
      });
    }
  }
  return events;
}

// ── One-time fix: old seeds stored "Pacific local hour" as UTC (missing +7/+8 offset)
// Detect: earliest flight UTC hour < 7 means it was stored without the offset applied.
// Fix: shift all timestamps forward by the Pacific offset hours so times are correct UTC.
async function fixLegacyTimestamps(flights: typeof flightMovementsTable.$inferSelect[]): Promise<void> {
  const earliest = [...flights].sort((a, b) =>
    new Date(a.scheduledTime).getTime() - new Date(b.scheduledTime).getTime()
  )[0];
  if (!earliest) return;

  const earliestUTCHour = new Date(earliest.scheduledTime).getUTCHours();
  // If UTC hour >= 7 the offset was already applied — timestamps are fine
  if (earliestUTCHour >= 7) return;

  // Probe Pacific offset for this date
  const dateStr = earliest.scheduledTime.slice(0, 10);
  const probe = new Date(dateStr + "T20:00:00Z");
  const pacificHour = parseInt(
    new Intl.DateTimeFormat("en-US", { timeZone: YLW_TZ, hour: "2-digit", hour12: false }).format(probe)
  );
  const offsetHours = 20 - pacificHour; // 7 for PDT, 8 for PST
  const offsetMs = offsetHours * 3_600_000;

  console.log(`Fixing legacy timestamps: UTC hour of earliest flight = ${earliestUTCHour}, applying +${offsetHours}h correction...`);

  const shiftTs = (iso: string) => new Date(new Date(iso).getTime() + offsetMs).toISOString();

  for (const f of flights) {
    const updates: Record<string, string | Date> = { updatedAt: new Date() };
    updates.scheduledTime = shiftTs(f.scheduledTime);
    if (f.estimatedTime) updates.estimatedTime = shiftTs(f.estimatedTime);
    if (f.actualTime) updates.actualTime = shiftTs(f.actualTime);
    await db.update(flightMovementsTable).set(updates).where(eq(flightMovementsTable.id, f.id));
  }

  const billing = await db.select().from(billingRecordsTable);
  for (const b of billing) {
    if (b.landingTime) {
      await db.update(billingRecordsTable)
        .set({ landingTime: shiftTs(b.landingTime) })
        .where(eq(billingRecordsTable.id, b.id));
    }
  }

  const events = await db.select().from(flightEventsTable);
  for (const ev of events) {
    if (ev.eventTime) {
      await db.update(flightEventsTable)
        .set({ eventTime: shiftTs(ev.eventTime) })
        .where(eq(flightEventsTable.id, ev.id));
    }
  }

  console.log(`Fixed ${flights.length} flight timestamps (+${offsetHours}h UTC correction).`);
}

export async function advanceDemoFlightDates(): Promise<void> {
  let flights = await db.select().from(flightMovementsTable);
  if (flights.length === 0) return;

  // Step 1 — fix legacy seeds that stored Pacific local hour as UTC
  await fixLegacyTimestamps(flights);

  // Re-read after potential fix
  flights = await db.select().from(flightMovementsTable);

  const todayPacific = new Intl.DateTimeFormat("en-CA", { timeZone: YLW_TZ }).format(new Date());

  // Use the earliest scheduled flight to determine what date the data is on
  const earliest = [...flights].sort((a, b) =>
    new Date(a.scheduledTime).getTime() - new Date(b.scheduledTime).getTime()
  )[0];
  if (!earliest) return;

  const flightDatePacific = new Intl.DateTimeFormat("en-CA", { timeZone: YLW_TZ }).format(new Date(earliest.scheduledTime));

  if (flightDatePacific === todayPacific) {
    console.log(`Demo flights already on today (${todayPacific}), no advance needed.`);
    return;
  }

  console.log(`Advancing demo flights from ${flightDatePacific} → ${todayPacific}...`);

  // Step 2 — compute day offset and advance all times
  const oldDay = new Date(flightDatePacific + "T12:00:00Z");
  const newDay = new Date(todayPacific + "T12:00:00Z");
  const msOffset = Math.round((newDay.getTime() - oldDay.getTime()) / 86_400_000) * 86_400_000;

  const shiftTs = (iso: string) => new Date(new Date(iso).getTime() + msOffset).toISOString();

  for (const f of flights) {
    const updates: Record<string, string | Date> = { updatedAt: new Date() };
    updates.scheduledTime = shiftTs(f.scheduledTime);
    if (f.estimatedTime) updates.estimatedTime = shiftTs(f.estimatedTime);
    if (f.actualTime) updates.actualTime = shiftTs(f.actualTime);
    await db.update(flightMovementsTable).set(updates).where(eq(flightMovementsTable.id, f.id));
  }

  const billing = await db.select().from(billingRecordsTable);
  for (const b of billing) {
    if (b.landingTime) {
      await db.update(billingRecordsTable)
        .set({ landingTime: shiftTs(b.landingTime) })
        .where(eq(billingRecordsTable.id, b.id));
    }
  }

  const events = await db.select().from(flightEventsTable);
  for (const ev of events) {
    if (ev.eventTime) {
      await db.update(flightEventsTable)
        .set({ eventTime: shiftTs(ev.eventTime) })
        .where(eq(flightEventsTable.id, ev.id));
    }
  }

  console.log(`Advanced ${flights.length} demo flights, ${billing.length} billing records, ${events.length} events to ${todayPacific}.`);
}

export async function seed() {
  // Check if already seeded
  const existingFlights = await db.select().from(flightMovementsTable).limit(1);
  if (existingFlights.length > 0) {
    console.log("Database already seeded, skipping.");
    return;
  }

  console.log("Seeding database...");

  // Ensure settings
  const existingSettings = await db.select().from(appSettingsTable).where(eq(appSettingsTable.id, "singleton"));
  if (existingSettings.length === 0) {
    await db.insert(appSettingsTable).values({
      id: "singleton",
      airportIata: "YLW",
      airportIcao: "CYLW",
      airportName: "Kelowna International Airport",
      pollingIntervalSeconds: 60,
      environmentMode: "DEMO",
    });
  }

  await db.insert(aircraftRegistryTable).values(AIRCRAFT_REGISTRY);
  await db.insert(tariffRecordsTable).values(TARIFF_RECORDS);

  for (const flight of FLIGHT_MOVEMENTS) {
    await db.insert(flightMovementsTable).values({
      ...flight,
      dataSource: "SEED",
      createdAt: new Date(),
      updatedAt: new Date(),
    });
  }

  const flightEvents = buildFlightEvents();
  await db.insert(flightEventsTable).values(flightEvents);

  const outboxEvents = buildOutboxEvents(FLIGHT_MOVEMENTS);
  await db.insert(integrationOutboxTable).values(outboxEvents);

  const billingRecords = buildBillingRecords();
  await db.insert(billingRecordsTable).values(billingRecords);

  console.log(`Seeded: ${FLIGHT_MOVEMENTS.length} flights, ${flightEvents.length} events, ${AIRCRAFT_REGISTRY.length} aircraft, ${TARIFF_RECORDS.length} tariffs, ${billingRecords.length} billing records`);
}
