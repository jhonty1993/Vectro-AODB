import { randomUUID } from "crypto";
import { eq, inArray } from "drizzle-orm";
import {
  db,
  flightMovementsTable,
  aircraftRegistryTable,
  billingCustomersTable,
  itemCodesTable,
  ratePlansTable,
  rateRulesTable,
  billableChargesTable,
  billingAlertsTable,
  billingDecisionLogTable,
  invoiceBatchesTable,
  invoicesTable,
  invoiceLinesTable,
  parkingStaysTable,
  recurringContractsTable,
} from "@workspace/db";
import type { RatingCatalog } from "./lib/billing-engine";
import { rateMovementToLandingCharge } from "./lib/billing-engine";
import { logger } from "./lib/logger";

const TAX_RATE = 0.05;

// Note: KFA/Kelowna Flightcraft (FK) is intentionally NOT mapped, to demonstrate
// the NO_CUSTOMER_MAPPING alert workflow on real movements.
const CUSTOMERS = [
  { code: "WS", name: "WestJet", type: "airline", iataCode: "WS", paymentTermsDays: 30, contactEmail: "ap@westjet.com" },
  { code: "AC", name: "Air Canada", type: "airline", iataCode: "AC", paymentTermsDays: 45, contactEmail: "billing@aircanada.ca" },
  { code: "QK", name: "Jazz Aviation", type: "airline", iataCode: "QK", paymentTermsDays: 30, contactEmail: "ar@flyjazz.ca" },
  { code: "8P", name: "Pacific Coastal Airlines", type: "airline", iataCode: "8P", paymentTermsDays: 30, contactEmail: "accounts@pacificcoastal.com" },
  { code: "AS", name: "Alaska Airlines", type: "airline", iataCode: "AS", paymentTermsDays: 45, contactEmail: "ap@alaskaair.com" },
  { code: "F8", name: "Flair Airlines", type: "airline", iataCode: "F8", paymentTermsDays: 30, contactEmail: "finance@flyflair.com" },
  { code: "WR", name: "WestJet Encore", type: "airline", iataCode: "WR", paymentTermsDays: 30, contactEmail: "ap@westjet.com" },
  { code: "DL", name: "Delta Air Lines", type: "airline", iataCode: "DL", paymentTermsDays: 45, contactEmail: "ap@delta.com" },
  { code: "YXE-GA", name: "Okanagan GA Handling", type: "ga", iataCode: null, paymentTermsDays: 15, contactEmail: "ops@okanaganga.ca" },
];

const ITEM_CODES = [
  { code: "LDG", name: "Landing Fee", category: "landing", unit: "per_mtow_tonne", glAccount: "4100", taxable: true, description: "Aircraft landing fee charged per tonne MTOW." },
  { code: "PARK", name: "Aircraft Parking", category: "parking", unit: "per_quarter_hour", glAccount: "4200", taxable: true, description: "Apron/stand parking charged per 15 minutes beyond the free period." },
  { code: "TERM", name: "Terminal Fee", category: "terminal", unit: "flat", glAccount: "4300", taxable: true, description: "Flat terminal usage fee per turn." },
  { code: "PAX", name: "Passenger Facility (AIF)", category: "passenger", unit: "per_pax", glAccount: "4400", taxable: false, description: "Airport improvement fee per enplaned passenger." },
  { code: "SEC", name: "Security Recovery", category: "security", unit: "flat", glAccount: "4500", taxable: true, description: "Security cost recovery per movement." },
];

export async function seedBilling(): Promise<void> {
  const existing = await db.select().from(billingCustomersTable).limit(1);
  if (existing.length > 0) {
    logger.info("Billing already seeded, skipping.");
    return;
  }

  const now = new Date();

  // 1) Customers
  await db.insert(billingCustomersTable).values(CUSTOMERS.map((c) => ({ id: randomUUID(), ...c })));
  const customers = await db.select().from(billingCustomersTable);

  // 2) Item codes
  await db.insert(itemCodesTable).values(ITEM_CODES.map((i) => ({ id: randomUUID(), ...i })));
  const items = await db.select().from(itemCodesTable);
  const landingItem = items.find((i) => i.code === "LDG")!;
  const parkItem = items.find((i) => i.code === "PARK")!;

  // 3) Rate plan + rules
  const ratePlan = {
    id: randomUUID(),
    name: "2026 Standard Airport Tariff",
    description: "Effective-dated landing & terminal tariff for CYLW.",
    effectiveFrom: "2026-01-01",
    effectiveTo: null,
    currency: "CAD",
    status: "active",
    isDefault: true,
  };
  await db.insert(ratePlansTable).values(ratePlan);
  const [ratePlanRow] = await db.select().from(ratePlansTable).where(eq(ratePlansTable.id, ratePlan.id));

  const rules = [
    { name: "Domestic jet landing", routeType: "domestic", engineType: "TURBOFAN", calcMethod: "per_mtow_tonne", rateAmount: 8.5, minCharge: 120, priority: 100 },
    { name: "Transborder jet landing", routeType: "transborder", engineType: "TURBOFAN", calcMethod: "per_mtow_tonne", rateAmount: 11.25, minCharge: 150, priority: 100 },
    { name: "International jet landing", routeType: "international", engineType: "TURBOFAN", calcMethod: "per_mtow_tonne", rateAmount: 13.0, minCharge: 180, priority: 100 },
    { name: "Turboprop landing (all routes)", routeType: "any", engineType: "TURBOPROP", calcMethod: "per_mtow_tonne", rateAmount: 6.25, minCharge: 75, priority: 90 },
    { name: "Domestic general fallback", routeType: "domestic", engineType: "any", calcMethod: "per_mtow_tonne", rateAmount: 7.0, minCharge: 100, priority: 50 },
  ].map((r) => ({
    id: randomUUID(),
    ratePlanId: ratePlan.id,
    itemCodeId: landingItem.id,
    effectiveFrom: "2026-01-01",
    effectiveTo: null,
    customerType: "any",
    direction: "any",
    airlineIata: null,
    minMtowKg: null,
    maxMtowKg: null,
    maxCharge: null,
    currency: "CAD",
    active: true,
    notes: null,
    ...r,
  }));
  await db.insert(rateRulesTable).values(rules);

  // 4) Rate existing movements (the live YLW board) into landing charges.
  const [registry, movements] = await Promise.all([
    db.select().from(aircraftRegistryTable),
    db.select().from(flightMovementsTable),
  ]);

  const catalog: RatingCatalog = {
    registry,
    customers: customers.map((c) => ({ ...c, createdAt: now, updatedAt: now })),
    ratePlan: { ...ratePlan, createdAt: now, updatedAt: now },
    rules: rules.map((r) => ({ ...r, createdAt: now, updatedAt: now })),
    landingItemCode: { ...landingItem, createdAt: now, updatedAt: now },
  };

  const allCharges = [];
  const allAlerts = [];
  const allDecisions = [];
  for (const m of movements) {
    const result = rateMovementToLandingCharge(m, catalog, "system");
    allCharges.push(result.charge);
    allAlerts.push(...result.alerts.map((a) => ({ ...a, chargeId: result.charge.id })));
    allDecisions.push(...result.decisions.map((d) => ({ ...d, chargeId: result.charge.id })));
  }
  if (allCharges.length) await db.insert(billableChargesTable).values(allCharges);
  if (allAlerts.length) await db.insert(billingAlertsTable).values(allAlerts);
  if (allDecisions.length) await db.insert(billingDecisionLogTable).values(allDecisions);

  // 5) Parking stays for a few arrival movements with known tails.
  const arrivalsWithTail = movements.filter((m) => m.direction === "ARR" && m.tailNumber).slice(0, 5);
  const wsCustomer = customers.find((c) => c.code === "WS");
  for (const m of arrivalsWithTail) {
    const cust = customers.find((c) => c.iataCode === m.airlineIata);
    const duration = 90 + Math.floor(Math.random() * 240);
    const free = 120;
    const chargeable = Math.max(0, duration - free);
    const quarter = Math.ceil(chargeable / 15);
    const rate = 4.5;
    const stayId = randomUUID();
    let chargeId: string | null = null;
    if (chargeable > 0 && cust) {
      chargeId = randomUUID();
      const amount = Math.round(quarter * rate * 100) / 100;
      await db.insert(billableChargesTable).values({
        id: chargeId,
        movementId: m.id,
        customerId: cust.id,
        itemCodeId: parkItem.id,
        ratePlanId: ratePlan.id,
        rateRuleId: null,
        description: `Parking — ${m.tailNumber} stand ${m.stand ?? "—"} (${quarter}×15min)`,
        quantity: quarter,
        unitRate: rate,
        amount,
        currency: "CAD",
        status: "ready",
        alertLevel: "green",
        confidenceScore: 95,
        chargeDate: (m.scheduledTime || now.toISOString()).slice(0, 10),
        source: "parking",
      });
      await db.insert(billingDecisionLogTable).values({
        id: randomUUID(),
        chargeId,
        action: "RATED",
        detail: `Parking charge: ${duration} min stay − ${free} min free = ${chargeable} chargeable min (${quarter}×15min @ ${rate}).`,
        payload: { duration, free, chargeable, quarter, rate },
        operator: "system",
      });
    }
    await db.insert(parkingStaysTable).values({
      id: stayId,
      arrivalMovementId: m.id,
      departureMovementId: null,
      customerId: cust?.id ?? null,
      tailNumber: m.tailNumber,
      stand: m.stand,
      arrivalTime: m.actualTime ?? m.estimatedTime ?? m.scheduledTime,
      departureTime: null,
      durationMinutes: duration,
      freeMinutes: free,
      chargeableMinutes: chargeable,
      status: chargeId ? "charged" : "active",
      chargeId,
    });
  }

  // 6) Recurring contracts
  if (wsCustomer) {
    await db.insert(recurringContractsTable).values([
      {
        id: randomUUID(),
        customerId: wsCustomer.id,
        itemCodeId: items.find((i) => i.code === "TERM")!.id,
        name: "WestJet ticket counter lease",
        description: "Monthly counter & back-office space lease.",
        amount: 4200,
        currency: "CAD",
        frequency: "monthly",
        nextRunDate: new Date(now.getFullYear(), now.getMonth() + 1, 1).toISOString().slice(0, 10),
        lastRunDate: new Date(now.getFullYear(), now.getMonth(), 1).toISOString().slice(0, 10),
        effectiveFrom: "2026-01-01",
        effectiveTo: null,
        status: "active",
      },
    ]);
  }
  const pcCustomer = customers.find((c) => c.code === "8P");
  if (pcCustomer) {
    await db.insert(recurringContractsTable).values([
      {
        id: randomUUID(),
        customerId: pcCustomer.id,
        itemCodeId: items.find((i) => i.code === "SEC")!.id,
        name: "Pacific Coastal handling retainer",
        description: "Quarterly ground handling retainer.",
        amount: 8500,
        currency: "CAD",
        frequency: "quarterly",
        nextRunDate: new Date(now.getFullYear(), now.getMonth() + 3, 1).toISOString().slice(0, 10),
        lastRunDate: new Date(now.getFullYear(), now.getMonth(), 1).toISOString().slice(0, 10),
        effectiveFrom: "2026-01-01",
        effectiveTo: null,
        status: "active",
      },
    ]);
  }

  // 7) One finalized invoice batch from a slice of ready charges (so invoice screens have data).
  await createDemoBatch();

  logger.info({ charges: allCharges.length, parking: arrivalsWithTail.length }, "Billing seeded");
}

async function createDemoBatch(): Promise<void> {
  const ready = (await db.select().from(billableChargesTable).where(eq(billableChargesTable.status, "ready")))
    .filter((c) => c.customerId)
    .slice(0, 8);
  if (ready.length === 0) return;

  const itemCodes = await db.select().from(itemCodesTable);
  const batchId = randomUUID();
  const batchNumber = `BATCH-${new Date().toISOString().slice(0, 10).replace(/-/g, "")}-DEMO`;
  const issueDate = new Date().toISOString().slice(0, 10);

  const byCustomer = new Map<string, typeof ready>();
  for (const c of ready) {
    const arr = byCustomer.get(c.customerId!) ?? [];
    arr.push(c);
    byCustomer.set(c.customerId!, arr);
  }

  let batchTotal = 0;
  let seq = 0;
  for (const [customerId, charges] of byCustomer) {
    seq++;
    const invoiceId = randomUUID();
    const invoiceNumber = `INV-DEMO-${String(seq).padStart(3, "0")}`;
    const subtotal = charges.reduce((s, c) => s + c.amount, 0);
    let taxAmount = 0;
    const lines = charges.map((c) => {
      const item = itemCodes.find((i) => i.id === c.itemCodeId);
      const lineTax = item?.taxable ? Math.round(c.amount * TAX_RATE * 100) / 100 : 0;
      taxAmount += lineTax;
      return {
        id: randomUUID(),
        invoiceId,
        chargeId: c.id,
        itemCodeId: c.itemCodeId,
        description: c.description,
        quantity: c.quantity,
        unitRate: c.unitRate,
        amount: c.amount,
        taxRate: item?.taxable ? TAX_RATE : 0,
        taxAmount: lineTax,
      };
    });
    taxAmount = Math.round(taxAmount * 100) / 100;
    const total = Math.round((subtotal + taxAmount) * 100) / 100;
    batchTotal += total;

    const [customer] = await db.select().from(billingCustomersTable).where(eq(billingCustomersTable.id, customerId));
    const dueDate = new Date(Date.now() + (customer?.paymentTermsDays ?? 30) * 86400000).toISOString().slice(0, 10);

    await db.insert(invoicesTable).values({
      id: invoiceId,
      invoiceNumber,
      batchId,
      customerId,
      status: "issued",
      issueDate,
      dueDate,
      subtotal: Math.round(subtotal * 100) / 100,
      taxAmount,
      total,
      currency: charges[0].currency,
    });
    await db.insert(invoiceLinesTable).values(lines);
    await db
      .update(billableChargesTable)
      .set({ status: "invoiced", invoiceBatchId: batchId, invoiceId })
      .where(inArray(billableChargesTable.id, charges.map((c) => c.id)));
    for (const c of charges) {
      await db.insert(billingDecisionLogTable).values({
        id: randomUUID(),
        chargeId: c.id,
        action: "INVOICED",
        detail: `Invoiced on ${invoiceNumber} (batch ${batchNumber}).`,
        payload: { invoiceNumber, batchNumber },
        operator: "system",
      });
    }
  }

  await db.insert(invoiceBatchesTable).values({
    id: batchId,
    batchNumber,
    status: "finalized",
    periodStart: issueDate,
    periodEnd: issueDate,
    chargeCount: ready.length,
    invoiceCount: seq,
    totalAmount: Math.round(batchTotal * 100) / 100,
    currency: ready[0].currency,
    createdBy: "system",
    notes: "Demo seed batch.",
  });
}
