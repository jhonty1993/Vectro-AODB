import express, { type Express, type RequestHandler } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import { clerkMiddleware, getAuth } from "@clerk/express";
import { publishableKeyFromHost } from "@clerk/shared/keys";
import {
  CLERK_PROXY_PATH,
  clerkProxyMiddleware,
  getClerkProxyHost,
} from "./middlewares/clerkProxyMiddleware";
import router from "./routes";
import { logger } from "./lib/logger";
import { seed, advanceDemoFlightDates } from "./seed";
import { seedBilling } from "./seed-billing";
import { startYlwFeedScheduler } from "./routes/ylw-feed";
import { startFr24Scheduler } from "./routes/sources";

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);

// Clerk proxy must be mounted before the body parsers (it streams raw bytes).
app.use(CLERK_PROXY_PATH, clerkProxyMiddleware());

app.use(cors({ credentials: true, origin: true }));
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

// Resolve the publishable key from the incoming request host so the same
// server can serve multiple Clerk custom domains. Falls back to
// CLERK_PUBLISHABLE_KEY when the host doesn't map to a custom domain.
app.use(
  clerkMiddleware((req) => ({
    publishableKey: publishableKeyFromHost(
      getClerkProxyHost(req) ?? "",
      process.env.CLERK_PUBLISHABLE_KEY,
    ),
  })),
);

// Endpoints that stay public for the unauthenticated Arrivals & Departures
// board. Everything else under /api requires an authenticated staff session.
// NOTE: req.path here is relative to the "/api" mount (e.g. "/flights").
function isPublicApiRequest(req: express.Request): boolean {
  if (req.method !== "GET") return false;
  // Liveness probe for deployment health checks.
  if (req.path === "/healthz") return true;
  // The flight list powers the public board. /flights/:id and the
  // /flights/dashboard/* analytics endpoints stay protected.
  if (req.path === "/flights") return true;
  return false;
}

const requireAuth: RequestHandler = (req, res, next) => {
  const auth = getAuth(req);
  const userId = auth?.sessionClaims?.userId || auth?.userId;
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  next();
};

const authGate: RequestHandler = (req, res, next) => {
  if (isPublicApiRequest(req)) {
    next();
    return;
  }
  requireAuth(req, res, next);
};

app.use("/api", authGate, router);

seed()
  .then(() => advanceDemoFlightDates())
  .then(() => seedBilling())
  .then(() => {
    startYlwFeedScheduler();
    startFr24Scheduler();
  })
  .catch((err) => {
    logger.error({ err }, "Seed/advance/feed-start failed");
  });

export default app;
