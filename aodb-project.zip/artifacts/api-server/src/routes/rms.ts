import { Router } from "express";
import { db } from "@workspace/db";
import { integrationOutboxTable, flightMovementsTable, flightEventsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { UpdateRmsAllocationBody } from "@workspace/api-zod";
import { randomUUID } from "crypto";

const router = Router();

function toISO(t: Date | string): string {
  return typeof t === "string" ? t : t.toISOString();
}

router.get("/outbox", async (_req, res) => {
  const events = await db.select().from(integrationOutboxTable).orderBy(integrationOutboxTable.createdAt);
  res.json(events.map((e) => ({ ...e, createdAt: toISO(e.createdAt) })));
});

router.post("/allocations", async (req, res) => {
  const body = UpdateRmsAllocationBody.parse(req.body);
  const [flight] = await db.select().from(flightMovementsTable).where(eq(flightMovementsTable.id, body.flightId));
  if (!flight) { res.status(404).json({ error: "Flight not found" }); return; }

  const updates: Partial<typeof flightMovementsTable.$inferInsert> = { updatedAt: new Date() };
  if (body.checkinCounters !== undefined) updates.checkinCounters = body.checkinCounters;

  await db.update(flightMovementsTable).set(updates).where(eq(flightMovementsTable.id, body.flightId));

  await db.insert(flightEventsTable).values({
    id: randomUUID(),
    flightId: body.flightId,
    eventType: "ALLOCATION_UPDATED",
    eventTime: new Date().toISOString(),
    source: "RMS",
    operator: body.operator,
    reason: body.reason,
    payload: { checkinCounters: body.checkinCounters },
  });

  await db.insert(integrationOutboxTable).values({
    id: randomUUID(),
    flightId: body.flightId,
    flightNumber: flight.flightNumber,
    eventType: "ALLOCATION_UPDATED",
    destination: "RMS",
    status: "SENT",
    payload: { checkinCounters: body.checkinCounters },
    sentAt: new Date().toISOString(),
  });

  const [updated] = await db.select().from(flightMovementsTable).where(eq(flightMovementsTable.id, body.flightId));
  res.json({ ...updated, createdAt: toISO(updated.createdAt), updatedAt: toISO(updated.updatedAt) });
});

export default router;
