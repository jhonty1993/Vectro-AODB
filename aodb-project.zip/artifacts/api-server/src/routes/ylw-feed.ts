import { Router } from "express";
import { db } from "@workspace/db";
import {
  flightMovementsTable,
  staticScheduleImportsTable,
  staticScheduleMovementsTable,
  type FlightMovement,
} from "@workspace/db";
import { eq, and, sql, like, inArray } from "drizzle-orm";
import { randomUUID } from "crypto";
import { logger } from "../lib/logger";

const router = Router();

const ARR_URL = "https://kelprodylwfast01.blob.core.windows.net/$web/ylw/flights/arrivals.json";
const DEP_URL = "https://kelprodylwfast01.blob.core.windows.net/$web/ylw/flights/departures.json";

const YLW_TZ = "America/Vancouver";

const AIRLINE_NAMES: Record<string, string> = {
  AC: "Air Canada",
  WS: "WestJet",
  "8P": "Pacific Coastal Airlines",
  QK: "Jazz Aviation",
  PD: "Porter Airlines",
  F8: "Flair Airlines",
  TS: "Air Transat",
  WG: "Sunwing",
  UA: "United Airlines",
  DL: "Delta",
  AA: "American Airlines",
  AS: "Alaska Airlines",
  WN: "Southwest",
};

const CITY_NAMES: Record<string, string> = {
  YVR: "Vancouver",
  YYC: "Calgary",
  YYZ: "Toronto",
  YEG: "Edmonton",
  YXC: "Cranbrook",
  YXS: "Prince George",
  YYJ: "Victoria",
  YQR: "Regina",
  YWG: "Winnipeg",
  YOW: "Ottawa",
  YUL: "Montreal",
  SEA: "Seattle",
  LAX: "Los Angeles",
  SFO: "San Francisco",
  PHX: "Phoenix",
  LAS: "Las Vegas",
  PVR: "Puerto Vallarta",
};

interface YlwFeedEntry {
  HostAirportCode?: string;
  HostAirportCity?: string;
  FlightNumber?: string;
  AirlineCode?: string;
  ArrivalOrDeparture?: string;
  ViaAirportCode?: string;
  ViaAirportCity?: string;
  ScheduleTime?: string;
  EstimatedTime?: string | null;
  ActualTime?: string | null;
  Gate?: string | null;
  Baggage?: string | null;
  Status?: string;
  StatusRaw?: string;
  TailNumber?: string | null;
  AircraftType?: string | null;
}

function mapStatus(raw: string | undefined, hasActual: boolean): string {
  const s = (raw ?? "").toUpperCase().trim();
  if (!s) return hasActual ? "LANDED" : "SCHEDULED";
  if (s === "ARRIVED" || s === "LANDED") return "LANDED";
  if (s === "DEPARTED" || s === "AIRBORNE") return "DEPARTED";
  if (s === "CANCELLED" || s === "CANCELED") return "CANCELLED";
  if (s === "DIVERTED") return "DIVERTED";
  if (s === "BOARDING" || s === "GATE" || s === "FINAL CALL") return "ESTIMATED";
  if (s === "DELAYED" || s.includes("DELAY")) return "ESTIMATED";
  if (s === "EARLY" || s.includes("EARLY")) return "ESTIMATED";
  if (s === "EN ROUTE" || s === "ENROUTE" || s === "INBOUND" || s === "APPROACHING") return "ESTIMATED";
  if (s === "ON TIME" || s === "SCHEDULED") return "SCHEDULED";
  return "SCHEDULED";
}

function dateInPacific(iso: string): string {
  return new Intl.DateTimeFormat("en-CA", { timeZone: YLW_TZ }).format(new Date(iso));
}

async function fetchFeed(url: string): Promise<YlwFeedEntry[]> {
  const res = await fetch(`${url}?_=${Date.now()}`);
  if (!res.ok) throw new Error(`YLW feed ${res.status}`);
  const data = (await res.json()) as YlwFeedEntry[];
  if (!Array.isArray(data)) throw new Error("YLW feed returned non-array");
  return data;
}

interface NormalizedMovement {
  flightNumber: string;
  airline: string;
  airlineIata: string;
  direction: "ARR" | "DEP";
  origin: string;
  destination: string;
  scheduledTime: string;
  estimatedTime: string | null;
  actualTime: string | null;
  hasExplicitActual: boolean;
  tailNumber: string | null;
  aircraftType: string | null;
  status: string;
  delayMinutes: number | null;
  gate: string | null;
  belt: string | null;
  rawStatus: string;
}

function normalize(entry: YlwFeedEntry, direction: "ARR" | "DEP"): NormalizedMovement | null {
  const iata = (entry.AirlineCode ?? "").toUpperCase().trim();
  const num = (entry.FlightNumber ?? "").trim();
  const sched = entry.ScheduleTime;
  if (!iata || !num || !sched) return null;

  const via = (entry.ViaAirportCode ?? "").toUpperCase().trim();
  const status = mapStatus(entry.Status ?? entry.StatusRaw, !!entry.ActualTime);
  const isTerminal = status === "LANDED" || status === "DEPARTED";

  const scheduledTime = new Date(sched).toISOString();
  const estimatedTime = entry.EstimatedTime ? new Date(entry.EstimatedTime).toISOString() : null;
  const actualTime = entry.ActualTime
    ? new Date(entry.ActualTime).toISOString()
    : (isTerminal && estimatedTime ? estimatedTime : null);
  // Distinguish a real feed-reported actual from the estimate-derived fallback
  // above, so downstream logic never treats a lagging estimate as an authoritative ATA.
  const hasExplicitActual = !!entry.ActualTime;

  let delayMinutes: number | null = null;
  if (estimatedTime || actualTime) {
    const ref = actualTime ?? estimatedTime!;
    delayMinutes = Math.round((new Date(ref).getTime() - new Date(scheduledTime).getTime()) / 60000);
  }

  return {
    flightNumber: iata + num,
    airline: AIRLINE_NAMES[iata] ?? iata,
    airlineIata: iata,
    direction,
    origin: direction === "ARR" ? via : "YLW",
    destination: direction === "ARR" ? "YLW" : via,
    scheduledTime,
    estimatedTime,
    actualTime,
    hasExplicitActual,
    tailNumber: entry.TailNumber?.trim() || null,
    aircraftType: entry.AircraftType?.trim() || null,
    status,
    delayMinutes,
    gate: entry.Gate?.trim() || null,
    belt: entry.Baggage?.trim() || null,
    rawStatus: entry.Status ?? entry.StatusRaw ?? "",
  };
}

function qualityScore(m: NormalizedMovement): number {
  let s = 100;
  if (!m.tailNumber) s -= 10;
  if (!m.aircraftType) s -= 10;
  if (!m.actualTime && (m.status === "LANDED" || m.status === "DEPARTED")) s -= 15;
  return Math.max(40, s);
}

async function upsertMovement(m: NormalizedMovement, existing: FlightMovement[]): Promise<{ inserted: boolean; updated: boolean }> {
  const datePac = dateInPacific(m.scheduledTime);
  const match = existing.find(
    (f) =>
      f.flightNumber === m.flightNumber &&
      f.direction === m.direction &&
      dateInPacific(f.scheduledTime) === datePac
  );

  if (match) {
    // Respect source priority: FR24_LIVE owns ATA/ATD/status/estimatedTime.
    // YLW_FEED can refine baseline (sched, origin/dest, tail/type) but must not
    // null-out or downgrade FR24-derived actuals/status. Pre-existing manual edits
    // (dataSource = MANUAL) are also preserved.
    const fr24Owns = match.dataSource === "FR24_LIVE";
    const manualOwns = match.dataSource === "MANUAL";

    const patch: Partial<typeof flightMovementsTable.$inferInsert> = {
      airline: m.airline,
      airlineIata: m.airlineIata,
      origin: m.origin,
      destination: m.destination,
      scheduledTime: m.scheduledTime,
      tailNumber: m.tailNumber ?? match.tailNumber,
      aircraftType: m.aircraftType ?? match.aircraftType,
      dataQualityScore: qualityScore(m),
      updatedAt: new Date(),
    };

    if (!fr24Owns && !manualOwns) {
      // YLW or SEED row — feed is authoritative for actuals/status
      patch.estimatedTime = m.estimatedTime ?? match.estimatedTime;
      patch.actualTime = m.actualTime ?? match.actualTime;
      patch.status = m.status;
      patch.delayMinutes = m.delayMinutes ?? match.delayMinutes;
      patch.dataSource = "YLW_FEED";
    } else {
      // FR24/manual owns actuals — never downgrade. Only fill nulls. The owner's
      // delayMinutes is derived from its authoritative times, so the feed must not
      // overwrite it (it would re-introduce an estimate-based delay).
      if (!match.estimatedTime && m.estimatedTime) patch.estimatedTime = m.estimatedTime;
      if (!match.actualTime && m.actualTime) patch.actualTime = m.actualTime;
      if (match.delayMinutes == null && m.delayMinutes != null) patch.delayMinutes = m.delayMinutes;
      // Terminal-state override: FR24 only ever supplies ETAs, never a terminal
      // status (LANDED/DEPARTED/CANCELLED/DIVERTED). The airport feed is the
      // authority for those transitions, so let a terminal YLW status progress
      // the row even when FR24 owns it — otherwise a flight with a stale
      // actualTime can get stranded at ESTIMATED. Manual edits stay protected.
      const ylwTerminal = ["LANDED", "DEPARTED", "CANCELLED", "DIVERTED"].includes(m.status);
      if (fr24Owns && ylwTerminal) {
        patch.status = m.status;
        // Only adopt the feed's actual when it is an EXPLICIT feed-reported time and
        // FR24 doesn't already hold one — never overwrite FR24's authoritative ATA
        // with the feed's estimate-derived fallback (the original 8P1885 discrepancy).
        if (m.hasExplicitActual && m.actualTime && !match.actualTime) {
          patch.actualTime = m.actualTime;
        }
      }
      // Keep dataSource so the Source badge keeps reflecting the authoritative origin.
    }

    await db
      .update(flightMovementsTable)
      .set(patch)
      .where(eq(flightMovementsTable.id, match.id));
    return { inserted: false, updated: true };
  }

  await db.insert(flightMovementsTable).values({
    id: randomUUID(),
    flightNumber: m.flightNumber,
    airline: m.airline,
    airlineIata: m.airlineIata,
    direction: m.direction,
    origin: m.origin,
    destination: m.destination,
    scheduledTime: m.scheduledTime,
    estimatedTime: m.estimatedTime,
    actualTime: m.actualTime,
    tailNumber: m.tailNumber,
    aircraftType: m.aircraftType,
    status: m.status,
    dataSource: "YLW_FEED",
    dataQualityScore: qualityScore(m),
    delayMinutes: m.delayMinutes,
  });
  return { inserted: true, updated: false };
}

async function upsertScheduleRow(
  m: NormalizedMovement,
  importId: string,
  existingSched: { id: string; flightNumber: string; direction: string; scheduledTime: string }[],
) {
  const datePac = dateInPacific(m.scheduledTime);
  const match = existingSched.find(
    (s) =>
      s.flightNumber === m.flightNumber &&
      s.direction === m.direction &&
      dateInPacific(s.scheduledTime) === datePac,
  );

  const city = CITY_NAMES[m.direction === "ARR" ? m.origin : m.destination] ?? null;

  if (match) {
    await db
      .update(staticScheduleMovementsTable)
      .set({
        scheduledTime: m.scheduledTime,
        airlineName: m.airline,
        aircraftType: m.aircraftType,
        tailNumber: m.tailNumber,
        status: m.rawStatus || m.status,
        fr24MatchStatus: m.tailNumber ? "matched" : "pending",
        fr24ActualTime: m.actualTime,
        fr24TailNumber: m.tailNumber,
        fr24AircraftType: m.aircraftType,
        varianceMinutes: m.delayMinutes,
      })
      .where(eq(staticScheduleMovementsTable.id, match.id));
    return;
  }

  await db.insert(staticScheduleMovementsTable).values({
    id: randomUUID(),
    importId,
    direction: m.direction,
    flightNumber: m.flightNumber,
    airlineIata: m.airlineIata,
    airlineName: m.airline,
    scheduledTime: m.scheduledTime,
    origin: m.direction === "ARR" ? m.origin : "YLW",
    destination: m.direction === "ARR" ? "YLW" : m.destination,
    city,
    aircraftType: m.aircraftType,
    aircraftGroup: null,
    seats: null,
    plannedPax: null,
    flightType: "J",
    flightNature: "S",
    sector: "D",
    status: m.rawStatus || m.status,
    codeshares: null,
    tailNumber: m.tailNumber,
    stand: null,
    gate: null,
    passengerHandling: "Y",
    isCommercial: true,
    rawPayload: { source: "YLW_FEED", rawStatus: m.rawStatus } as Record<string, unknown>,
    linkedMovementId: null,
    fr24MatchStatus: m.tailNumber ? "matched" : "pending",
    fr24ActualTime: m.actualTime,
    fr24TailNumber: m.tailNumber,
    fr24AircraftType: m.aircraftType,
    varianceMinutes: m.delayMinutes,
  });
}

let lastSyncAt: Date | null = null;
let lastSyncCount = 0;
let lastSyncArrivals = 0;
let lastSyncDepartures = 0;
let lastSyncError: string | null = null;
let activeFeedImportId: string | null = null;

async function getOrCreateFeedImport(): Promise<string> {
  if (activeFeedImportId) {
    const existing = await db
      .select()
      .from(staticScheduleImportsTable)
      .where(eq(staticScheduleImportsTable.id, activeFeedImportId))
      .limit(1);
    if (existing.length) return activeFeedImportId;
  }

  const allImports = await db.select().from(staticScheduleImportsTable);
  const existing = allImports.find((i) => i.filename.startsWith("YLW Live Feed"));
  if (existing) {
    activeFeedImportId = existing.id;
    await db.update(staticScheduleImportsTable).set({ isActive: false });
    await db
      .update(staticScheduleImportsTable)
      .set({ isActive: true })
      .where(eq(staticScheduleImportsTable.id, existing.id));
    return existing.id;
  }

  await db.update(staticScheduleImportsTable).set({ isActive: false });
  const id = randomUUID();
  await db.insert(staticScheduleImportsTable).values({
    id,
    filename: "YLW Live Feed (kelprodylwfast01)",
    periodStart: dateInPacific(new Date().toISOString()),
    periodEnd: dateInPacific(new Date(Date.now() + 90 * 86400000).toISOString()),
    isActive: true,
    version: 1,
    totalRows: 0,
    arrivalCount: 0,
    departureCount: 0,
    skippedCount: 0,
    commercialCount: 0,
    notes: "Auto-synced from the public YLW airport JSON feeds. Updates every 5 minutes.",
  });
  activeFeedImportId = id;
  return id;
}

async function purgeNonFeedRows(): Promise<number> {
  // After a successful YLW feed sync, sweep rows that aren't owned by a live source.
  // Authoritative sources: YLW_FEED, FR24_LIVE, MANUAL. Only SEED rows are removed —
  // NULL is intentionally NOT purged, because legacy data and any future un-tagged
  // inserts (e.g. third-party tools) should not be silently destroyed. The seed
  // routine stamps dataSource='SEED' on every demo row, so the seed-vs-real split
  // is unambiguous.
  const result = await db
    .delete(flightMovementsTable)
    .where(eq(flightMovementsTable.dataSource, "SEED"))
    .returning({ id: flightMovementsTable.id });

  const demoImports = await db
    .select()
    .from(staticScheduleImportsTable)
    .where(like(staticScheduleImportsTable.filename, "%demo sample%"));
  for (const imp of demoImports) {
    await db.delete(staticScheduleMovementsTable).where(eq(staticScheduleMovementsTable.importId, imp.id));
    await db.delete(staticScheduleImportsTable).where(eq(staticScheduleImportsTable.id, imp.id));
  }

  if (result.length > 0 || demoImports.length > 0) {
    logger.info({ removed: result.length, demoImports: demoImports.length }, "Purged non-feed rows");
  }
  return result.length;
}

export async function syncYlwFeedToScheduleAndMovements(): Promise<{
  ok: boolean;
  arrivals: number;
  departures: number;
  inserted: number;
  updated: number;
  error?: string;
}> {
  try {
    const [arrJson, depJson] = await Promise.all([fetchFeed(ARR_URL), fetchFeed(DEP_URL)]);
    const arrivals = arrJson.map((e) => normalize(e, "ARR")).filter((m): m is NormalizedMovement => !!m);
    const departures = depJson.map((e) => normalize(e, "DEP")).filter((m): m is NormalizedMovement => !!m);
    const all = [...arrivals, ...departures];

    if (all.length === 0) {
      lastSyncError = "Feed returned 0 valid entries";
      return { ok: false, arrivals: 0, departures: 0, inserted: 0, updated: 0, error: lastSyncError };
    }

    if (all.length >= 10) {
      await purgeNonFeedRows();
    }

    const importId = await getOrCreateFeedImport();
    const existingMovements = await db.select().from(flightMovementsTable);
    const existingSched = await db
      .select({
        id: staticScheduleMovementsTable.id,
        flightNumber: staticScheduleMovementsTable.flightNumber,
        direction: staticScheduleMovementsTable.direction,
        scheduledTime: staticScheduleMovementsTable.scheduledTime,
      })
      .from(staticScheduleMovementsTable)
      .where(eq(staticScheduleMovementsTable.importId, importId));

    let inserted = 0;
    let updated = 0;
    for (const m of all) {
      const r = await upsertMovement(m, existingMovements);
      if (r.inserted) inserted++;
      if (r.updated) updated++;
      await upsertScheduleRow(m, importId, existingSched);
    }

    await db
      .update(staticScheduleImportsTable)
      .set({
        totalRows: all.length,
        arrivalCount: arrivals.length,
        departureCount: departures.length,
        commercialCount: all.length,
        notes: `Auto-synced from YLW public feeds. Last sync: ${new Date().toISOString()}. ${arrivals.length} arrivals, ${departures.length} departures.`,
      })
      .where(eq(staticScheduleImportsTable.id, importId));

    lastSyncAt = new Date();
    lastSyncCount = all.length;
    lastSyncArrivals = arrivals.length;
    lastSyncDepartures = departures.length;
    lastSyncError = null;
    logger.info({ inserted, updated, arrivals: arrivals.length, departures: departures.length }, "YLW feed sync OK");
    return { ok: true, arrivals: arrivals.length, departures: departures.length, inserted, updated };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    lastSyncError = msg;
    logger.error({ err: msg }, "YLW feed sync failed");
    return { ok: false, arrivals: 0, departures: 0, inserted: 0, updated: 0, error: msg };
  }
}

let ylwSyncInFlight = false;
async function runSyncGuarded() {
  if (ylwSyncInFlight) return;
  ylwSyncInFlight = true;
  try {
    await syncYlwFeedToScheduleAndMovements();
  } catch {
    // errors are recorded on lastSyncError inside the sync routine
  } finally {
    ylwSyncInFlight = false;
  }
}

export function startYlwFeedScheduler() {
  void runSyncGuarded();
  setInterval(() => {
    void runSyncGuarded();
  }, 2 * 60 * 1000);
}

router.get("/status", async (_req, res) => {
  res.json({
    lastSyncAt: lastSyncAt?.toISOString() ?? null,
    lastSyncCount,
    lastSyncArrivals,
    lastSyncDepartures,
    lastSyncError,
    arrivalsUrl: ARR_URL,
    departuresUrl: DEP_URL,
    refreshIntervalSeconds: 120,
  });
});

router.post("/sync", async (_req, res) => {
  const result = await syncYlwFeedToScheduleAndMovements();
  res.json({ ...result, lastSyncAt: lastSyncAt?.toISOString() ?? null });
});

router.get("/preview", async (req, res) => {
  const direction = (req.query.direction === "DEP" ? "DEP" : "ARR") as "ARR" | "DEP";
  const url = direction === "ARR" ? ARR_URL : DEP_URL;
  try {
    const data = await fetchFeed(url);
    const normalized = data.map((e) => normalize(e, direction)).filter((m): m is NormalizedMovement => !!m);
    res.json({ direction, count: normalized.length, sample: normalized.slice(0, 5), raw: data.slice(0, 3) });
  } catch (err) {
    res.status(502).json({ error: err instanceof Error ? err.message : "Feed fetch failed" });
  }
});

export default router;
