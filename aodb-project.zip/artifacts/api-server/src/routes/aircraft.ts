import { Router } from "express";
import { db } from "@workspace/db";
import { aircraftRegistryTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { CreateAircraftBody, UpdateAircraftParams, UpdateAircraftBody } from "@workspace/api-zod";
import { randomUUID } from "crypto";

const router = Router();

function toISO(t: Date | string): string {
  return typeof t === "string" ? t : t.toISOString();
}

router.get("/", async (_req, res) => {
  const aircraft = await db.select().from(aircraftRegistryTable).orderBy(aircraftRegistryTable.tailNumber);
  res.json(aircraft.map((a) => ({ ...a, createdAt: toISO(a.createdAt), updatedAt: toISO(a.updatedAt) })));
});

router.post("/", async (req, res) => {
  const body = CreateAircraftBody.parse(req.body);
  const [inserted] = await db.insert(aircraftRegistryTable).values({
    id: randomUUID(),
    tailNumber: body.tailNumber,
    aircraftType: body.aircraftType,
    mtowKg: body.mtowKg,
    engineType: body.engineType,
    seats: body.seats ?? null,
    noiseCategory: body.noiseCategory ?? null,
    airline: body.airline ?? null,
  }).returning();
  res.status(201).json({ ...inserted, createdAt: toISO(inserted.createdAt), updatedAt: toISO(inserted.updatedAt) });
});

router.put("/:id", async (req, res) => {
  const { id } = UpdateAircraftParams.parse(req.params);
  const body = UpdateAircraftBody.parse(req.body);
  const [updated] = await db.update(aircraftRegistryTable).set({
    tailNumber: body.tailNumber,
    aircraftType: body.aircraftType,
    mtowKg: body.mtowKg,
    engineType: body.engineType,
    seats: body.seats ?? null,
    noiseCategory: body.noiseCategory ?? null,
    airline: body.airline ?? null,
    updatedAt: new Date(),
  }).where(eq(aircraftRegistryTable.id, id)).returning();
  if (!updated) { res.status(404).json({ error: "Aircraft not found" }); return; }
  res.json({ ...updated, createdAt: toISO(updated.createdAt), updatedAt: toISO(updated.updatedAt) });
});

export default router;
