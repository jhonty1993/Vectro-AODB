import { Router } from "express";
import { db } from "@workspace/db";
import {
  flightMovementsTable,
  flightEventsTable,
  integrationOutboxTable,
  billingRecordsTable,
  appSettingsTable,
  type FlightMovement,
} from "@workspace/db";
import { eq, desc, and, ilike, or, sql } from "drizzle-orm";
import { isCommercial, classifyFlight } from "../lib/commercial";
import {
  ListFlightsQueryParams,
  CreateFlightBody,
  GetFlightParams,
  GetFlightEventsParams,
  AddFlightEventParams,
  AddFlightEventBody,
} from "@workspace/api-zod";
import { randomUUID } from "crypto";
import { advanceDemoFlightDates } from "../seed";

const router = Router();

// ── YLW Timezone Helpers ────────────────────────────────────────────────────

const YLW_TZ = "America/Vancouver";

export function getTodayInYLW(): string {
  return new Intl.DateTimeFormat("en-CA", { timeZone: YLW_TZ }).format(new Date());
}

export function getYLWDayBoundsAsUTC(dateStr: string): { start: Date; end: Date } {
  // Probe the Pacific offset for this specific date using Intl
  const testDate = new Date(dateStr + "T20:00:00Z");
  const pacificHour = parseInt(
    new Intl.DateTimeFormat("en-US", { timeZone: YLW_TZ, hour: "2-digit", hour12: false }).format(testDate)
  );
  const offsetHours = 20 - pacificHour; // 7 for PDT, 8 for PST
  const [yr, mo, dy] = dateStr.split("-").map(Number);
  const start = new Date(Date.UTC(yr, mo - 1, dy, offsetHours, 0, 0, 0));
  return { start, end: new Date(start.getTime() + 86400000) };
}

function filterFlightsByDate(flights: FlightMovement[], dateStr: string): FlightMovement[] {
  const { start, end } = getYLWDayBoundsAsUTC(dateStr);
  return flights.filter((f) => {
    const ft = new Date(f.scheduledTime);
    return ft >= start && ft < end;
  });
}

// ── Helpers ─────────────────────────────────────────────────────────────────

function computeQualityScore(flight: Partial<FlightMovement>): number {
  let score = 100;
  if (!flight.tailNumber) score -= 15;
  if (!flight.aircraftType) score -= 10;
  if (!flight.actualTime && flight.status === "LANDED") score -= 20;
  if (!flight.paxCount) score -= 5;
  return Math.max(0, score);
}

function computeStatus(events: { eventType: string }[]): string {
  const types = events.map((e) => e.eventType);
  if (types.includes("CANCELLED")) return "CANCELLED";
  if (types.includes("DIVERTED")) return "DIVERTED";
  if (types.includes("ON_BLOCK")) return "ON_BLOCK";
  if (types.includes("LANDED")) return "LANDED";
  if (types.includes("DEPARTED")) return "DEPARTED";
  if (types.includes("AIRBORNE")) return "AIRBORNE";
  if (types.includes("ESTIMATED")) return "ESTIMATED";
  return "SCHEDULED";
}

function toISO(t: Date | string): string {
  return typeof t === "string" ? t : t.toISOString();
}

// ── Data Health ──────────────────────────────────────────────────────────────

router.get("/data-health", async (_req, res) => {
  const todayPacific = getTodayInYLW();
  const { start: dayStart, end: dayEnd } = getYLWDayBoundsAsUTC(todayPacific);

  const [settings] = await db.select().from(appSettingsTable).limit(1).catch(() => [null]);
  const allFlights = await db.select().from(flightMovementsTable);

  const todayFlights = allFlights.filter((f) => {
    const ft = new Date(f.scheduledTime);
    return ft >= dayStart && ft < dayEnd;
  });

  const isDemo = settings?.environmentMode === "DEMO";
  const flightsAreToday = todayFlights.length > 0;

  const fr24Recent = settings?.fr24LastSyncAt
    ? (Date.now() - new Date(settings.fr24LastSyncAt).getTime()) < 3600000
    : false;

  let freshness: string;
  if (isDemo) {
    // The schedule baseline (YLW live feed) and FR24 enrichment are both real.
    // When FR24 has synced recently and today's flights are present, surface LIVE
    // so the UI accurately reflects that FR24 data is connected.
    if (!flightsAreToday) freshness = "DEMO_STALE";
    else freshness = fr24Recent ? "LIVE" : "DEMO_CURRENT";
  } else {
    freshness = flightsAreToday && fr24Recent ? "LIVE" : "STALE";
  }

  const flightDates = allFlights.map((f) =>
    new Intl.DateTimeFormat("en-CA", { timeZone: YLW_TZ }).format(new Date(f.scheduledTime))
  );
  const uniqueDates = [...new Set(flightDates)].sort();

  return res.json({
    todayLocal: todayPacific,
    timezone: YLW_TZ,
    flightsForToday: todayFlights.length,
    flightsInDb: allFlights.length,
    datesInDb: uniqueDates,
    flightDataIsToday: flightsAreToday,
    environmentMode: settings?.environmentMode ?? "DEMO",
    isDemo,
    freshness,
    fr24LastSync: settings?.fr24LastSyncAt?.toISOString() ?? null,
    fr24Status: settings?.fr24ConnectionStatus ?? "demo",
    adsbLastSync: settings?.adsbxLastSyncAt?.toISOString() ?? null,
    adsbStatus: settings?.adsbxConnectionStatus ?? "demo",
    scheduleCheckedAt: new Date().toISOString(),
  });
});

// ── Advance demo dates (manual trigger) ─────────────────────────────────────

router.post("/advance-demo-dates", async (_req, res) => {
  await advanceDemoFlightDates();
  const todayPacific = getTodayInYLW();
  const { start, end } = getYLWDayBoundsAsUTC(todayPacific);
  const flights = await db.select().from(flightMovementsTable);
  const todayCount = flights.filter((f) => {
    const ft = new Date(f.scheduledTime);
    return ft >= start && ft < end;
  }).length;
  return res.json({ advanced: true, todayLocal: todayPacific, flightsForToday: todayCount });
});

// ── Dashboard Routes (all date-filtered) ────────────────────────────────────

router.get("/dashboard/summary", async (req, res) => {
  const dateStr = String(req.query.date ?? getTodayInYLW());
  const allFlights = await db.select().from(flightMovementsTable);
  const flights = filterFlightsByDate(allFlights as FlightMovement[], dateStr);

  const arrivals = flights.filter((f) => f.direction === "ARR");
  const departures = flights.filter((f) => f.direction === "DEP");
  const onTime = flights.filter((f) => (f.delayMinutes ?? 0) < 15 && !["CANCELLED", "DIVERTED"].includes(f.status)).length;
  const delayed = flights.filter((f) => (f.delayMinutes ?? 0) >= 15 && !["CANCELLED", "DIVERTED"].includes(f.status)).length;
  const cancelled = flights.filter((f) => f.status === "CANCELLED").length;
  const diverted = flights.filter((f) => f.status === "DIVERTED").length;
  const airborne = flights.filter((f) => f.status === "AIRBORNE").length;
  const avgDataQuality = flights.length > 0
    ? flights.reduce((sum, f) => sum + f.dataQualityScore, 0) / flights.length
    : 0;
  const lowQualityCount = flights.filter((f) => f.dataQualityScore < 60).length;
  const pendingBilling = await db.select().from(billingRecordsTable)
    .then((r) => r.filter((b) => b.reconciliationStatus === "PENDING").length);

  res.json({
    date: dateStr,
    totalArrivals: arrivals.length,
    totalDepartures: departures.length,
    onTime,
    delayed,
    cancelled,
    diverted,
    airborne,
    avgDataQuality: Math.round(avgDataQuality * 10) / 10,
    lowQualityCount,
    pendingBillingCount: pendingBilling,
    flightsForDate: flights.length,
  });
});

router.get("/dashboard/movements-by-hour", async (req, res) => {
  const dateStr = String(req.query.date ?? getTodayInYLW());
  const allFlights = await db.select().from(flightMovementsTable);
  const flights = filterFlightsByDate(allFlights as FlightMovement[], dateStr);

  const hourMap: Record<string, { arrivals: number; departures: number }> = {};
  for (let h = 6; h <= 22; h++) {
    const key = `${h.toString().padStart(2, "0")}:00`;
    hourMap[key] = { arrivals: 0, departures: 0 };
  }
  for (const f of flights) {
    const t = f.scheduledTime;
    if (!t) continue;
    const hour = new Date(t).getHours();
    const key = `${hour.toString().padStart(2, "0")}:00`;
    if (!hourMap[key]) hourMap[key] = { arrivals: 0, departures: 0 };
    if (f.direction === "ARR") hourMap[key].arrivals++;
    else hourMap[key].departures++;
  }
  res.json(Object.entries(hourMap).map(([hour, data]) => ({ hour, ...data })));
});

router.get("/dashboard/delays-by-airline", async (req, res) => {
  const dateStr = String(req.query.date ?? getTodayInYLW());
  const allFlights = await db.select().from(flightMovementsTable);
  const flights = filterFlightsByDate(allFlights as FlightMovement[], dateStr);

  const map: Record<string, { airline: string; airlineIata: string; totalDelay: number; count: number }> = {};
  for (const f of flights) {
    if (!map[f.airlineIata]) map[f.airlineIata] = { airline: f.airline, airlineIata: f.airlineIata, totalDelay: 0, count: 0 };
    map[f.airlineIata].totalDelay += f.delayMinutes ?? 0;
    map[f.airlineIata].count++;
  }
  res.json(Object.values(map).map((entry) => ({
    airline: entry.airline,
    airlineIata: entry.airlineIata,
    avgDelayMinutes: entry.count > 0 ? Math.round((entry.totalDelay / entry.count) * 10) / 10 : 0,
    flightCount: entry.count,
  })));
});

// ── List Flights ─────────────────────────────────────────────────────────────

router.get("/", async (req, res) => {
  const query = ListFlightsQueryParams.parse(req.query);
  const dateStr = query.date ?? getTodayInYLW();
  const commercialOnly = (req.query as Record<string, string>).commercial_only !== "false";

  let allFlights = await db.select().from(flightMovementsTable).orderBy(flightMovementsTable.scheduledTime);
  let flights = filterFlightsByDate(allFlights as FlightMovement[], dateStr);

  if (commercialOnly) {
    flights = flights.filter((f) => isCommercial({ airlineIata: f.airlineIata, flightNumber: f.flightNumber, aircraftType: f.aircraftType }));
  }
  if (query.direction) flights = flights.filter((f) => f.direction === query.direction);
  if (query.airline) flights = flights.filter((f) => f.airlineIata === query.airline || f.airline.toLowerCase().includes(query.airline!.toLowerCase()));
  if (query.status) flights = flights.filter((f) => f.status === query.status);
  if (query.search) {
    const q = query.search.toLowerCase();
    flights = flights.filter((f) =>
      f.flightNumber.toLowerCase().includes(q) ||
      f.airline.toLowerCase().includes(q) ||
      f.origin.toLowerCase().includes(q) ||
      f.destination.toLowerCase().includes(q) ||
      (f.tailNumber ?? "").toLowerCase().includes(q)
    );
  }

  flights.sort((a, b) => new Date(a.scheduledTime).getTime() - new Date(b.scheduledTime).getTime());

  const classification = (f: FlightMovement) => classifyFlight({ airlineIata: f.airlineIata, flightNumber: f.flightNumber, aircraftType: f.aircraftType });
  res.json(flights.map((f) => {
    const c = classification(f);
    return {
      ...f,
      createdAt: toISO(f.createdAt),
      updatedAt: toISO(f.updatedAt),
      isCommercial: c.isCommercial,
      commercialClass: c.class,
      dataSource: f.dataSource ?? null,
    };
  }));
});

// ── Schedule Coverage Diagnostic ─────────────────────────────────────────────

router.get("/schedule-coverage", async (req, res) => {
  const dateStr = String(req.query.date ?? getTodayInYLW());
  const { start, end } = getYLWDayBoundsAsUTC(dateStr);

  const allFlights = (await db.select().from(flightMovementsTable)) as FlightMovement[];
  const flights = allFlights.filter((f) => {
    const t = new Date(f.scheduledTime);
    return t >= start && t < end;
  });

  const commercial = flights.filter((f) =>
    isCommercial({ airlineIata: f.airlineIata, flightNumber: f.flightNumber, aircraftType: f.aircraftType }),
  );

  const arrivals = commercial.filter((f) => f.direction === "ARR");
  const departures = commercial.filter((f) => f.direction === "DEP");
  const fromYlwFeed = commercial.filter((f) => f.dataSource === "YLW_FEED");
  const fromFr24 = commercial.filter((f) => f.dataSource === "FR24_LIVE");
  const fromStaticSchedule = commercial.filter((f) => f.dataSource === "STATIC_SCHEDULE");
  const fromSeed = commercial.filter((f) => !f.dataSource || f.dataSource === "SEED");

  const now = Date.now();
  const missingActuals = commercial.filter((f) => {
    const sched = new Date(f.scheduledTime).getTime();
    return (
      sched < now - 30 * 60 * 1000 &&
      !f.actualTime &&
      f.status !== "CANCELLED" &&
      f.status !== "DIVERTED" &&
      f.status !== "LANDED" &&
      f.status !== "ON_BLOCK" &&
      f.status !== "DEPARTED"
    );
  });
  const awaitingFr24 = commercial.filter((f) => !f.actualTime && f.status === "SCHEDULED");
  const matched = commercial.filter((f) => !!f.actualTime || !!f.estimatedTime);

  // FR24-sourced rows that do NOT correspond to any YLW_FEED schedule baseline
  // (same flight number + direction + Pacific date). These are live observations
  // the schedule baseline hasn't accounted for yet.
  const ylwKey = (f: FlightMovement) =>
    `${f.flightNumber}|${f.direction}|${new Date(f.scheduledTime).toLocaleDateString("en-CA", { timeZone: YLW_TZ })}`;
  const ylwKeys = new Set(fromYlwFeed.map(ylwKey));
  const unmatchedFr24 = fromFr24.filter((f) => !ylwKeys.has(ylwKey(f))).length;

  res.json({
    date: dateStr,
    timezone: YLW_TZ,
    totalScheduled: commercial.length,
    arrivals: arrivals.length,
    departures: departures.length,
    matched: matched.length,
    awaitingFr24: awaitingFr24.length,
    missingActuals: missingActuals.length,
    unmatchedFr24,
    bySource: {
      YLW_FEED: fromYlwFeed.length,
      FR24_LIVE: fromFr24.length,
      STATIC_SCHEDULE: fromStaticSchedule.length,
      SEED_OR_UNKNOWN: fromSeed.length,
    },
    excludedNonCommercial: flights.length - commercial.length,
    visibleBoardCount: commercial.length,
    checkedAt: new Date().toISOString(),
  });
});

// ── Create Flight ─────────────────────────────────────────────────────────────

router.post("/", async (req, res) => {
  const body = CreateFlightBody.parse(req.body);
  const id = randomUUID();
  const now = new Date().toISOString();

  const newFlight = {
    id,
    flightNumber: body.flightNumber,
    airline: body.airline,
    airlineIata: body.airlineIata,
    direction: body.direction,
    origin: body.origin,
    destination: body.destination,
    scheduledTime: body.scheduledTime,
    tailNumber: body.tailNumber ?? null,
    aircraftType: body.aircraftType ?? null,
    paxCount: body.paxCount ?? null,
    status: "SCHEDULED",
    dataSource: "MANUAL",
    dataQualityScore: 80,
    delayMinutes: null,
    estimatedTime: null,
    actualTime: null,
    checkinCounters: null,
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  const qualityScore = computeQualityScore(newFlight);
  newFlight.dataQualityScore = qualityScore;

  const [inserted] = await db.insert(flightMovementsTable).values(newFlight).returning();

  await db.insert(flightEventsTable).values({
    id: randomUUID(),
    flightId: id,
    eventType: "SCHEDULED",
    eventTime: body.scheduledTime,
    source: body.source,
    operator: "Manual Entry",
    reason: body.reason,
    payload: { flightNumber: body.flightNumber, origin: body.origin, destination: body.destination },
  });

  await db.insert(integrationOutboxTable).values({
    id: randomUUID(),
    flightId: id,
    flightNumber: body.flightNumber,
    eventType: "FLIGHT_CREATED",
    destination: "RMS",
    status: "QUEUED",
    payload: { id, flightNumber: body.flightNumber, direction: body.direction, scheduledTime: body.scheduledTime },
  });

  res.status(201).json({ ...inserted, createdAt: toISO(inserted.createdAt), updatedAt: toISO(inserted.updatedAt) });
});

// ── Single Flight ─────────────────────────────────────────────────────────────

router.get("/:id", async (req, res) => {
  const { id } = GetFlightParams.parse(req.params);
  const [flight] = await db.select().from(flightMovementsTable).where(eq(flightMovementsTable.id, id));
  if (!flight) { res.status(404).json({ error: "Flight not found" }); return; }
  res.json({ ...flight, createdAt: toISO(flight.createdAt), updatedAt: toISO(flight.updatedAt) });
});

router.get("/:id/events", async (req, res) => {
  const { id } = GetFlightEventsParams.parse(req.params);
  const events = await db.select().from(flightEventsTable).where(eq(flightEventsTable.flightId, id)).orderBy(flightEventsTable.eventTime);
  res.json(events.map((e) => ({ ...e, createdAt: toISO(e.createdAt) })));
});

router.post("/:id/events", async (req, res) => {
  const { id } = AddFlightEventParams.parse(req.params);
  const body = AddFlightEventBody.parse(req.body);

  const [flight] = await db.select().from(flightMovementsTable).where(eq(flightMovementsTable.id, id));
  if (!flight) { res.status(404).json({ error: "Flight not found" }); return; }

  const eventId = randomUUID();
  const [event] = await db.insert(flightEventsTable).values({
    id: eventId,
    flightId: id,
    eventType: body.eventType,
    eventTime: body.eventTime,
    source: body.source,
    operator: body.operator ?? null,
    reason: body.reason,
    payload: body.payload ?? null,
  }).returning();

  const allEvents = await db.select().from(flightEventsTable).where(eq(flightEventsTable.flightId, id)).orderBy(flightEventsTable.eventTime);
  const newStatus = computeStatus(allEvents);

  const updates: Partial<typeof flightMovementsTable.$inferInsert> = {
    status: newStatus,
    updatedAt: new Date(),
    dataQualityScore: computeQualityScore({ ...flight, status: newStatus }),
  };

  if (body.eventType === "ESTIMATED" && body.payload && (body.payload as Record<string, unknown>)["estimatedTime"]) {
    updates.estimatedTime = String((body.payload as Record<string, unknown>)["estimatedTime"]);
  }
  if (body.eventType === "LANDED" || body.eventType === "ON_BLOCK" || body.eventType === "DEPARTED") {
    updates.actualTime = body.eventTime;
    const scheduled = new Date(flight.scheduledTime);
    const actual = new Date(body.eventTime);
    updates.delayMinutes = Math.round((actual.getTime() - scheduled.getTime()) / 60000);
  }
  await db.update(flightMovementsTable).set(updates).where(eq(flightMovementsTable.id, id));

  if (body.eventType === "LANDED" || body.eventType === "ON_BLOCK") {
    await db.insert(integrationOutboxTable).values({
      id: randomUUID(),
      flightId: id,
      flightNumber: flight.flightNumber,
      eventType: body.eventType,
      destination: "BILLING",
      status: "QUEUED",
      payload: { eventType: body.eventType, eventTime: body.eventTime, flightNumber: flight.flightNumber },
    });
  }

  res.status(201).json({ ...event, createdAt: toISO(event.createdAt) });
});

export default router;
