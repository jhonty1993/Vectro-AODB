import { Router } from "express";
import { db } from "@workspace/db";
import { tariffRecordsTable } from "@workspace/db";
import { CreateTariffBody } from "@workspace/api-zod";
import { randomUUID } from "crypto";

const router = Router();

function toISO(t: Date | string): string {
  return typeof t === "string" ? t : t.toISOString();
}

router.get("/", async (_req, res) => {
  const tariffs = await db.select().from(tariffRecordsTable).orderBy(tariffRecordsTable.effectiveDate);
  res.json(tariffs.map((t) => ({ ...t, createdAt: toISO(t.createdAt) })));
});

router.post("/", async (req, res) => {
  const body = CreateTariffBody.parse(req.body);
  const [inserted] = await db.insert(tariffRecordsTable).values({
    id: randomUUID(),
    version: body.version,
    effectiveDate: body.effectiveDate,
    expiryDate: body.expiryDate ?? null,
    landingFeeDomesticPerTonne: body.landingFeeDomesticPerTonne,
    landingFeeIntlPerTonne: body.landingFeeIntlPerTonne,
    aifDomestic: body.aifDomestic,
    aifIntl: body.aifIntl,
    noiseChargeCategory1: body.noiseChargeCategory1,
    noiseChargeCategory2: body.noiseChargeCategory2,
    currency: body.currency,
    isActive: false,
  }).returning();
  res.status(201).json({ ...inserted, createdAt: toISO(inserted.createdAt) });
});

export default router;
