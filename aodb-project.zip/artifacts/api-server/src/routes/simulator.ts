import { Router } from "express";
import { db } from "@workspace/db";
import {
  flightMovementsTable,
  flightEventsTable,
  integrationOutboxTable,
  billingRecordsTable,
  aircraftRegistryTable,
} from "@workspace/db";
import { eq, not, inArray } from "drizzle-orm";
import { randomUUID } from "crypto";

const router = Router();

const TERMINAL_STATUSES = ["CANCELLED", "DIVERTED", "ON_BLOCK", "DEPARTED"];
const STATUS_TRANSITIONS: Record<string, { nextStatus: string; eventType: string; description: string }> = {
  SCHEDULED: { nextStatus: "ESTIMATED", eventType: "ESTIMATED", description: "ETD/ETA updated via FR24 simulation" },
  ESTIMATED: { nextStatus: "AIRBORNE", eventType: "AIRBORNE", description: "Aircraft airborne detected via FR24" },
  AIRBORNE: { nextStatus: "LANDED", eventType: "LANDED", description: "Aircraft landed — position data confirmed" },
  LANDED: { nextStatus: "ON_BLOCK", eventType: "ON_BLOCK", description: "On-block time confirmed via ACARS" },
};

router.post("/tick", async (_req, res) => {
  const flights = await db
    .select()
    .from(flightMovementsTable)
    .where(not(inArray(flightMovementsTable.status, TERMINAL_STATUSES)));

  if (flights.length === 0) {
    res.json({ eventsGenerated: 0, flightsUpdated: 0, details: ["No eligible flights to simulate"] });
    return;
  }

  const maxToUpdate = Math.min(3, flights.length);
  const selectedFlights = flights.sort(() => Math.random() - 0.5).slice(0, maxToUpdate);

  let eventsGenerated = 0;
  const details: string[] = [];

  for (const flight of selectedFlights) {
    const transition = STATUS_TRANSITIONS[flight.status];
    if (!transition) continue;

    const now = new Date();
    const eventTime = new Date(now.getTime() + (Math.random() * 10 - 5) * 60000).toISOString();

    await db.insert(flightEventsTable).values({
      id: randomUUID(),
      flightId: flight.id,
      eventType: transition.eventType,
      eventTime,
      source: "FR24_SIMULATOR",
      operator: null,
      reason: transition.description,
      payload: {
        simulatedAt: now.toISOString(),
        source: "FR24_SIMULATOR",
        flightNumber: flight.flightNumber,
        previousStatus: flight.status,
        newStatus: transition.nextStatus,
        lat: 49.956 + (Math.random() * 2 - 1),
        lon: -119.378 + (Math.random() * 2 - 1),
        altitude: transition.nextStatus === "AIRBORNE" ? Math.floor(Math.random() * 10000 + 2000) : 0,
        groundSpeed: transition.nextStatus === "AIRBORNE" ? Math.floor(Math.random() * 200 + 200) : 0,
      },
    });

    const updates: Partial<typeof flightMovementsTable.$inferInsert> = {
      status: transition.nextStatus,
      updatedAt: new Date(),
    };

    if (transition.eventType === "ESTIMATED") {
      const scheduled = new Date(flight.scheduledTime);
      const randomDelay = Math.floor(Math.random() * 40 - 5);
      updates.estimatedTime = new Date(scheduled.getTime() + randomDelay * 60000).toISOString();
    }

    if (transition.eventType === "LANDED" || transition.eventType === "DEPARTED") {
      updates.actualTime = eventTime;
      const scheduled = new Date(flight.scheduledTime);
      const actual = new Date(eventTime);
      updates.delayMinutes = Math.round((actual.getTime() - scheduled.getTime()) / 60000);
    }

    if (!flight.tailNumber) {
      updates.tailNumber = `C-F${Math.random().toString(36).substr(2, 3).toUpperCase()}`;
    }

    await db.update(flightMovementsTable).set(updates).where(eq(flightMovementsTable.id, flight.id));

    if (transition.eventType === "LANDED" || transition.eventType === "ON_BLOCK") {
      await db.insert(integrationOutboxTable).values({
        id: randomUUID(),
        flightId: flight.id,
        flightNumber: flight.flightNumber,
        eventType: transition.eventType,
        destination: "BILLING",
        status: "QUEUED",
        payload: { eventType: transition.eventType, eventTime, flightNumber: flight.flightNumber },
      });
    }

    await db.insert(integrationOutboxTable).values({
      id: randomUUID(),
      flightId: flight.id,
      flightNumber: flight.flightNumber,
      eventType: `STATUS_${transition.nextStatus}`,
      destination: "RMS",
      status: "SENT",
      payload: { status: transition.nextStatus, eventTime },
      sentAt: now.toISOString(),
    });

    eventsGenerated++;
    details.push(`${flight.flightNumber}: ${flight.status} → ${transition.nextStatus} at ${eventTime.slice(11, 16)} UTC`);

    if ((transition.nextStatus === "ON_BLOCK" || transition.nextStatus === "LANDED") && flight.direction === "ARR") {
      const existingBilling = await db.select().from(billingRecordsTable).where(eq(billingRecordsTable.flightId, flight.id));
      if (existingBilling.length === 0) {
        const aircraft = flight.tailNumber
          ? await db.select().from(aircraftRegistryTable).where(eq(aircraftRegistryTable.tailNumber, flight.tailNumber)).then((r) => r[0])
          : null;

        const mtow = aircraft?.mtowKg ?? 75000;
        const isIntl = !["YVR", "YYC", "YEG", "YWG", "YUL", "YYZ", "YHZ", "YOW", "CYVR", "CYYC", "CYEG", "CYWG", "CYUL", "CYYZ", "CYHZ", "CYOW"].some(
          (code) => flight.origin.includes(code) || flight.destination.includes(code)
        ) ? false : true;

        const rate = isIntl ? 3.25 : 2.75;
        const landingFee = Math.round((mtow / 1000) * rate * 100) / 100;
        const aif = isIntl ? (flight.paxCount ?? 150) * 25.0 : (flight.paxCount ?? 150) * 15.0;

        const flags: string[] = [];
        if (!flight.actualTime && transition.nextStatus !== "LANDED") flags.push("MISSING_LANDING_TIME");
        if (!aircraft?.mtowKg) flags.push("MTOW_MISMATCH");
        if (!flight.paxCount) flags.push("PAX_VARIANCE");
        if (flight.status === "DIVERTED") flags.push("DIVERTED_FLIGHT");

        await db.insert(billingRecordsTable).values({
          id: randomUUID(),
          flightId: flight.id,
          flightNumber: flight.flightNumber,
          airline: flight.airline,
          tailNumber: flight.tailNumber ?? null,
          aircraftType: flight.aircraftType ?? aircraft?.aircraftType ?? null,
          mtowKg: mtow,
          engineType: aircraft?.engineType ?? "TURBOFAN",
          isInternational: isIntl,
          landingTime: eventTime,
          paxCount: flight.paxCount ?? null,
          calculatedLandingFee: landingFee,
          aifEstimate: aif,
          tariffVersion: "2024-A",
          reconciliationStatus: flags.length > 0 ? "FLAGGED" : "PENDING",
          flags,
        });
      }
    }
  }

  res.json({
    eventsGenerated,
    flightsUpdated: selectedFlights.length,
    details,
  });
});

export default router;
