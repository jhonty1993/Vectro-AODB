import { Router } from "express";
import { randomUUID } from "crypto";
import { and, desc, eq, inArray, getTableColumns } from "drizzle-orm";
import { z } from "zod/v4";
import {
  db,
  flightMovementsTable,
  aircraftRegistryTable,
  billingCustomersTable,
  itemCodesTable,
  ratePlansTable,
  rateRulesTable,
  billableChargesTable,
  billingAlertsTable,
  billingDecisionLogTable,
  invoiceBatchesTable,
  invoicesTable,
  invoiceLinesTable,
  parkingStaysTable,
  recurringContractsTable,
  insertBillingCustomerSchema,
  insertItemCodeSchema,
  insertRatePlanSchema,
  insertRateRuleSchema,
  insertRecurringContractSchema,
} from "@workspace/db";
import type { RatingCatalog } from "../lib/billing-engine";
import { rateMovementToLandingCharge } from "../lib/billing-engine";

const router = Router();

const TAX_RATE = 0.05; // GST

async function loadRatingCatalog(): Promise<RatingCatalog | null> {
  const [registry, customers, plans, rules, items] = await Promise.all([
    db.select().from(aircraftRegistryTable),
    db.select().from(billingCustomersTable),
    db.select().from(ratePlansTable),
    db.select().from(rateRulesTable),
    db.select().from(itemCodesTable),
  ]);
  const ratePlan = plans.find((p) => p.isDefault && p.status === "active") ?? plans.find((p) => p.status === "active");
  const landingItemCode = items.find((i) => i.category === "landing") ?? items.find((i) => i.code === "LDG");
  if (!ratePlan || !landingItemCode) return null;
  return { registry, customers, ratePlan, rules, landingItemCode };
}

async function persistRating(movementId: string, operator: string) {
  const catalog = await loadRatingCatalog();
  if (!catalog) throw new Error("No active rate plan or landing item code configured.");
  const [movement] = await db.select().from(flightMovementsTable).where(eq(flightMovementsTable.id, movementId));
  if (!movement) throw new Error("Movement not found.");

  const result = rateMovementToLandingCharge(movement, catalog, operator);
  await db.insert(billableChargesTable).values(result.charge);
  if (result.alerts.length) {
    await db.insert(billingAlertsTable).values(result.alerts.map((a) => ({ ...a, chargeId: result.charge.id })));
  }
  if (result.decisions.length) {
    await db.insert(billingDecisionLogTable).values(result.decisions.map((d) => ({ ...d, chargeId: result.charge.id })));
  }
  return result.charge;
}

async function logDecision(chargeId: string, action: string, detail: string, operator: string, payload?: unknown) {
  await db.insert(billingDecisionLogTable).values({
    id: randomUUID(),
    chargeId,
    action,
    detail,
    payload: payload ?? null,
    operator,
  });
}

/* ----------------------------- Customers ----------------------------- */

router.get("/customers", async (_req, res) => {
  const rows = await db.select().from(billingCustomersTable).orderBy(billingCustomersTable.name);
  res.json(rows);
});

router.post("/customers", async (req, res) => {
  const parsed = insertBillingCustomerSchema.partial({ id: true }).parse(req.body);
  const row = { ...parsed, id: parsed.id ?? randomUUID() };
  const [created] = await db.insert(billingCustomersTable).values(row).returning();
  res.status(201).json(created);
});

router.put("/customers/:id", async (req, res) => {
  const parsed = insertBillingCustomerSchema.partial().parse(req.body);
  const [updated] = await db
    .update(billingCustomersTable)
    .set({ ...parsed, updatedAt: new Date() })
    .where(eq(billingCustomersTable.id, req.params.id))
    .returning();
  if (!updated) { res.status(404).json({ error: "Customer not found" }); return; }
  res.json(updated);
});

/* ----------------------------- Item codes ----------------------------- */

router.get("/item-codes", async (_req, res) => {
  const rows = await db.select().from(itemCodesTable).orderBy(itemCodesTable.code);
  res.json(rows);
});

router.post("/item-codes", async (req, res) => {
  const parsed = insertItemCodeSchema.partial({ id: true }).parse(req.body);
  const row = { ...parsed, id: parsed.id ?? randomUUID() };
  const [created] = await db.insert(itemCodesTable).values(row).returning();
  res.status(201).json(created);
});

router.put("/item-codes/:id", async (req, res) => {
  const parsed = insertItemCodeSchema.partial().parse(req.body);
  const [updated] = await db
    .update(itemCodesTable)
    .set({ ...parsed, updatedAt: new Date() })
    .where(eq(itemCodesTable.id, req.params.id))
    .returning();
  if (!updated) { res.status(404).json({ error: "Item code not found" }); return; }
  res.json(updated);
});

/* ----------------------------- Rate plans ----------------------------- */

router.get("/rate-plans", async (_req, res) => {
  const rows = await db.select().from(ratePlansTable).orderBy(desc(ratePlansTable.effectiveFrom));
  res.json(rows);
});

router.post("/rate-plans", async (req, res) => {
  const parsed = insertRatePlanSchema.partial({ id: true }).parse(req.body);
  const row = { ...parsed, id: parsed.id ?? randomUUID() };
  const [created] = await db.insert(ratePlansTable).values(row).returning();
  res.status(201).json(created);
});

router.put("/rate-plans/:id", async (req, res) => {
  const parsed = insertRatePlanSchema.partial().parse(req.body);
  const [updated] = await db
    .update(ratePlansTable)
    .set({ ...parsed, updatedAt: new Date() })
    .where(eq(ratePlansTable.id, req.params.id))
    .returning();
  if (!updated) { res.status(404).json({ error: "Rate plan not found" }); return; }
  res.json(updated);
});

/* ----------------------------- Rate rules ----------------------------- */

router.get("/rate-rules", async (req, res) => {
  const ratePlanId = typeof req.query.ratePlanId === "string" ? req.query.ratePlanId : undefined;
  const rows = ratePlanId
    ? await db.select().from(rateRulesTable).where(eq(rateRulesTable.ratePlanId, ratePlanId)).orderBy(desc(rateRulesTable.priority))
    : await db.select().from(rateRulesTable).orderBy(desc(rateRulesTable.priority));
  res.json(rows);
});

router.post("/rate-rules", async (req, res) => {
  const parsed = insertRateRuleSchema.partial({ id: true }).parse(req.body);
  const row = { ...parsed, id: parsed.id ?? randomUUID() };
  const [created] = await db.insert(rateRulesTable).values(row).returning();
  res.status(201).json(created);
});

router.put("/rate-rules/:id", async (req, res) => {
  const parsed = insertRateRuleSchema.partial().parse(req.body);
  const [updated] = await db
    .update(rateRulesTable)
    .set({ ...parsed, updatedAt: new Date() })
    .where(eq(rateRulesTable.id, req.params.id))
    .returning();
  if (!updated) { res.status(404).json({ error: "Rate rule not found" }); return; }
  res.json(updated);
});

router.delete("/rate-rules/:id", async (req, res) => {
  await db.delete(rateRulesTable).where(eq(rateRulesTable.id, req.params.id));
  res.status(204).end();
});

/* ----------------------------- Charges ----------------------------- */

router.get("/charges", async (req, res) => {
  const filters = [];
  if (typeof req.query.status === "string") filters.push(eq(billableChargesTable.status, req.query.status));
  if (typeof req.query.alertLevel === "string") filters.push(eq(billableChargesTable.alertLevel, req.query.alertLevel));
  if (typeof req.query.customerId === "string") filters.push(eq(billableChargesTable.customerId, req.query.customerId));
  if (typeof req.query.movementId === "string") filters.push(eq(billableChargesTable.movementId, req.query.movementId));

  const base = db
    .select({
      ...getTableColumns(billableChargesTable),
      movementDataSource: flightMovementsTable.dataSource,
    })
    .from(billableChargesTable)
    .leftJoin(flightMovementsTable, eq(billableChargesTable.movementId, flightMovementsTable.id));

  const rows = filters.length
    ? await base.where(and(...filters)).orderBy(desc(billableChargesTable.createdAt))
    : await base.orderBy(desc(billableChargesTable.createdAt));
  res.json(rows);
});

router.get("/charges/:id", async (req, res) => {
  const [charge] = await db.select().from(billableChargesTable).where(eq(billableChargesTable.id, req.params.id));
  if (!charge) { res.status(404).json({ error: "Charge not found" }); return; }

  const [alerts, decisions] = await Promise.all([
    db.select().from(billingAlertsTable).where(eq(billingAlertsTable.chargeId, charge.id)).orderBy(desc(billingAlertsTable.createdAt)),
    db.select().from(billingDecisionLogTable).where(eq(billingDecisionLogTable.chargeId, charge.id)).orderBy(billingDecisionLogTable.createdAt),
  ]);

  let movement = null;
  let customer = null;
  let rateRule = null;
  let itemCode = null;
  if (charge.movementId) [movement] = await db.select().from(flightMovementsTable).where(eq(flightMovementsTable.id, charge.movementId));
  if (charge.customerId) [customer] = await db.select().from(billingCustomersTable).where(eq(billingCustomersTable.id, charge.customerId));
  if (charge.rateRuleId) [rateRule] = await db.select().from(rateRulesTable).where(eq(rateRulesTable.id, charge.rateRuleId));
  [itemCode] = await db.select().from(itemCodesTable).where(eq(itemCodesTable.id, charge.itemCodeId));

  res.json({ ...charge, alerts, decisions, movement, customer, rateRule, itemCode });
});

const holdSchema = z.object({ reason: z.string().min(1), operator: z.string().optional() });

router.post("/charges/:id/hold", async (req, res) => {
  const { reason, operator = "staff" } = holdSchema.parse(req.body);
  const [updated] = await db
    .update(billableChargesTable)
    .set({ status: "held", holdReason: reason, updatedAt: new Date() })
    .where(eq(billableChargesTable.id, req.params.id))
    .returning();
  if (!updated) { res.status(404).json({ error: "Charge not found" }); return; }
  await logDecision(updated.id, "HELD", `Charge held: ${reason}`, operator, { reason });
  res.json(updated);
});

router.post("/charges/:id/discard", async (req, res) => {
  const { reason, operator = "staff" } = holdSchema.parse(req.body);
  const [updated] = await db
    .update(billableChargesTable)
    .set({ status: "discarded", discardReason: reason, updatedAt: new Date() })
    .where(eq(billableChargesTable.id, req.params.id))
    .returning();
  if (!updated) { res.status(404).json({ error: "Charge not found" }); return; }
  await logDecision(updated.id, "DISCARDED", `Charge discarded: ${reason}`, operator, { reason });
  res.json(updated);
});

router.post("/charges/:id/ready", async (req, res) => {
  const operator = typeof req.body?.operator === "string" ? req.body.operator : "staff";
  const [updated] = await db
    .update(billableChargesTable)
    .set({ status: "ready", holdReason: null, updatedAt: new Date() })
    .where(eq(billableChargesTable.id, req.params.id))
    .returning();
  if (!updated) { res.status(404).json({ error: "Charge not found" }); return; }
  await logDecision(updated.id, "READIED", "Charge marked ready to invoice.", operator);
  res.json(updated);
});

/* ----------------------------- Rating workflows ----------------------------- */

router.get("/movements/:movementId/charges", async (req, res) => {
  const rows = await db
    .select()
    .from(billableChargesTable)
    .where(eq(billableChargesTable.movementId, req.params.movementId))
    .orderBy(desc(billableChargesTable.createdAt));
  res.json(rows);
});

router.post("/rate-movement/:movementId", async (req, res) => {
  const operator = typeof req.body?.operator === "string" ? req.body.operator : "staff";
  try {
    const charge = await persistRating(req.params.movementId, operator);
    res.status(201).json(charge);
  } catch (err) {
    req.log.error({ err }, "rate-movement failed");
    res.status(400).json({ error: err instanceof Error ? err.message : "Rating failed" });
  }
});

router.post("/rate-all", async (req, res) => {
  const operator = typeof req.body?.operator === "string" ? req.body.operator : "staff";
  const catalog = await loadRatingCatalog();
  if (!catalog) { res.status(400).json({ error: "No active rate plan or landing item code configured." }); return; }

  const movements = await db.select().from(flightMovementsTable);
  const existing = await db.select({ movementId: billableChargesTable.movementId }).from(billableChargesTable);
  const rated = new Set(existing.map((e) => e.movementId));

  let created = 0;
  for (const m of movements) {
    if (rated.has(m.id)) continue;
    const result = rateMovementToLandingCharge(m, catalog, operator);
    await db.insert(billableChargesTable).values(result.charge);
    if (result.alerts.length) await db.insert(billingAlertsTable).values(result.alerts.map((a) => ({ ...a, chargeId: result.charge.id })));
    if (result.decisions.length) await db.insert(billingDecisionLogTable).values(result.decisions.map((d) => ({ ...d, chargeId: result.charge.id })));
    created++;
  }
  res.json({ created, skipped: movements.length - created });
});

/* ----------------------------- Invoice batches ----------------------------- */

const createBatchSchema = z.object({
  chargeIds: z.array(z.string()).min(1),
  periodStart: z.string().optional(),
  periodEnd: z.string().optional(),
  notes: z.string().optional(),
  createdBy: z.string().optional(),
});

router.get("/invoice-batches", async (_req, res) => {
  const rows = await db.select().from(invoiceBatchesTable).orderBy(desc(invoiceBatchesTable.createdAt));
  res.json(rows);
});

router.get("/invoice-batches/:id", async (req, res) => {
  const [batch] = await db.select().from(invoiceBatchesTable).where(eq(invoiceBatchesTable.id, req.params.id));
  if (!batch) { res.status(404).json({ error: "Batch not found" }); return; }
  const invoices = await db.select().from(invoicesTable).where(eq(invoicesTable.batchId, batch.id));
  const invoiceIds = invoices.map((i) => i.id);
  const lines = invoiceIds.length
    ? await db.select().from(invoiceLinesTable).where(inArray(invoiceLinesTable.invoiceId, invoiceIds))
    : [];
  res.json({ ...batch, invoices: invoices.map((inv) => ({ ...inv, lines: lines.filter((l) => l.invoiceId === inv.id) })) });
});

router.post("/invoice-batches", async (req, res) => {
  const { chargeIds, periodStart, periodEnd, notes, createdBy = "staff" } = createBatchSchema.parse(req.body);

  const charges = await db.select().from(billableChargesTable).where(inArray(billableChargesTable.id, chargeIds));
  const ready = charges.filter((c) => c.status === "ready" && c.customerId);
  if (ready.length === 0) {
    res.status(400).json({ error: "No ready charges with a customer mapping in selection." }); return;
  }

  const batchId = randomUUID();
  const batchNumber = `BATCH-${new Date().toISOString().slice(0, 10).replace(/-/g, "")}-${batchId.slice(0, 4).toUpperCase()}`;
  const issueDate = new Date().toISOString().slice(0, 10);

  // Group ready charges by customer → one invoice each.
  const byCustomer = new Map<string, typeof ready>();
  for (const c of ready) {
    const arr = byCustomer.get(c.customerId!) ?? [];
    arr.push(c);
    byCustomer.set(c.customerId!, arr);
  }

  let batchTotal = 0;
  let invoiceSeq = 0;
  const itemCodes = await db.select().from(itemCodesTable);

  for (const [customerId, custCharges] of byCustomer) {
    invoiceSeq++;
    const invoiceId = randomUUID();
    const invoiceNumber = `INV-${batchNumber.slice(6)}-${String(invoiceSeq).padStart(3, "0")}`;
    const subtotal = custCharges.reduce((s, c) => s + c.amount, 0);
    let taxAmount = 0;
    const lineRows = custCharges.map((c) => {
      const item = itemCodes.find((i) => i.id === c.itemCodeId);
      const lineTax = item?.taxable ? Math.round(c.amount * TAX_RATE * 100) / 100 : 0;
      taxAmount += lineTax;
      return {
        id: randomUUID(),
        invoiceId,
        chargeId: c.id,
        itemCodeId: c.itemCodeId,
        description: c.description,
        quantity: c.quantity,
        unitRate: c.unitRate,
        amount: c.amount,
        taxRate: item?.taxable ? TAX_RATE : 0,
        taxAmount: lineTax,
      };
    });
    taxAmount = Math.round(taxAmount * 100) / 100;
    const total = Math.round((subtotal + taxAmount) * 100) / 100;
    batchTotal += total;

    const [customer] = await db.select().from(billingCustomersTable).where(eq(billingCustomersTable.id, customerId));
    const dueDate = new Date(Date.now() + (customer?.paymentTermsDays ?? 30) * 86400000).toISOString().slice(0, 10);

    await db.insert(invoicesTable).values({
      id: invoiceId,
      invoiceNumber,
      batchId,
      customerId,
      status: "issued",
      issueDate,
      dueDate,
      subtotal: Math.round(subtotal * 100) / 100,
      taxAmount,
      total,
      currency: custCharges[0].currency,
    });
    await db.insert(invoiceLinesTable).values(lineRows);

    await db
      .update(billableChargesTable)
      .set({ status: "invoiced", invoiceBatchId: batchId, invoiceId, updatedAt: new Date() })
      .where(inArray(billableChargesTable.id, custCharges.map((c) => c.id)));

    for (const c of custCharges) {
      await logDecision(c.id, "INVOICED", `Invoiced on ${invoiceNumber} (batch ${batchNumber}).`, createdBy, { invoiceNumber, batchNumber });
    }
  }

  await db.insert(invoiceBatchesTable).values({
    id: batchId,
    batchNumber,
    status: "finalized",
    periodStart: periodStart ?? null,
    periodEnd: periodEnd ?? null,
    chargeCount: ready.length,
    invoiceCount: invoiceSeq,
    totalAmount: Math.round(batchTotal * 100) / 100,
    currency: ready[0].currency,
    createdBy,
    notes: notes ?? null,
  });

  res.status(201).json({ id: batchId, batchNumber, invoiceCount: invoiceSeq, chargeCount: ready.length, totalAmount: Math.round(batchTotal * 100) / 100 });
});

router.get("/invoices/:id", async (req, res) => {
  const [invoice] = await db.select().from(invoicesTable).where(eq(invoicesTable.id, req.params.id));
  if (!invoice) { res.status(404).json({ error: "Invoice not found" }); return; }
  const lines = await db.select().from(invoiceLinesTable).where(eq(invoiceLinesTable.invoiceId, invoice.id));
  const [customer] = await db.select().from(billingCustomersTable).where(eq(billingCustomersTable.id, invoice.customerId));
  res.json({ ...invoice, lines, customer });
});

/* ----------------------------- Parking & recurring ----------------------------- */

router.get("/parking", async (_req, res) => {
  const rows = await db.select().from(parkingStaysTable).orderBy(desc(parkingStaysTable.arrivalTime));
  res.json(rows);
});

router.get("/recurring", async (_req, res) => {
  const rows = await db.select().from(recurringContractsTable).orderBy(recurringContractsTable.name);
  res.json(rows);
});

router.post("/recurring", async (req, res) => {
  const parsed = insertRecurringContractSchema.partial({ id: true }).parse(req.body);
  const row = { ...parsed, id: parsed.id ?? randomUUID() };
  const [created] = await db.insert(recurringContractsTable).values(row).returning();
  res.status(201).json(created);
});

router.put("/recurring/:id", async (req, res) => {
  const parsed = insertRecurringContractSchema.partial().parse(req.body);
  const [updated] = await db
    .update(recurringContractsTable)
    .set({ ...parsed, updatedAt: new Date() })
    .where(eq(recurringContractsTable.id, req.params.id))
    .returning();
  if (!updated) { res.status(404).json({ error: "Contract not found" }); return; }
  res.json(updated);
});

/* ----------------------------- Dashboard ----------------------------- */

router.get("/dashboard", async (_req, res) => {
  const [charges, customers, rules, batches, alerts] = await Promise.all([
    db.select().from(billableChargesTable),
    db.select().from(billingCustomersTable),
    db.select().from(rateRulesTable),
    db.select().from(invoiceBatchesTable),
    db.select().from(billingAlertsTable),
  ]);

  const byStatus: Record<string, { count: number; amount: number }> = {};
  for (const c of charges) {
    byStatus[c.status] = byStatus[c.status] ?? { count: 0, amount: 0 };
    byStatus[c.status].count++;
    byStatus[c.status].amount = Math.round((byStatus[c.status].amount + c.amount) * 100) / 100;
  }

  const alertBreakdown: Record<string, number> = {};
  for (const c of charges) alertBreakdown[c.alertLevel] = (alertBreakdown[c.alertLevel] ?? 0) + 1;

  const openAlertCodes: Record<string, number> = {};
  for (const a of alerts) if (!a.resolved) openAlertCodes[a.code] = (openAlertCodes[a.code] ?? 0) + 1;

  const revenueByCustomer = new Map<string, number>();
  for (const c of charges) {
    if (c.status === "discarded") continue;
    const key = c.customerId ?? "UNMAPPED";
    revenueByCustomer.set(key, Math.round(((revenueByCustomer.get(key) ?? 0) + c.amount) * 100) / 100);
  }
  const customerName = (id: string) => (id === "UNMAPPED" ? "Unmapped" : customers.find((c) => c.id === id)?.name ?? id);
  const topCustomers = [...revenueByCustomer.entries()]
    .map(([id, amount]) => ({ customerId: id, name: customerName(id), amount }))
    .sort((a, b) => b.amount - a.amount)
    .slice(0, 8);

  const readyAmount = byStatus["ready"]?.amount ?? 0;
  const invoicedAmount = byStatus["invoiced"]?.amount ?? 0;
  const blockedCount =
    charges.filter((c) => c.status === "pending" || c.status === "held").length;
  const unmappedCount = charges.filter((c) => !c.customerId && c.status !== "discarded").length;
  const noRuleCount = charges.filter((c) => !c.rateRuleId && c.status !== "discarded").length;

  res.json({
    totals: {
      charges: charges.length,
      customers: customers.length,
      activeRules: rules.filter((r) => r.active).length,
      batches: batches.length,
      readyAmount,
      invoicedAmount,
      blockedCount,
      unmappedCount,
      noRuleCount,
    },
    byStatus,
    alertBreakdown,
    openAlertCodes,
    topCustomers,
    currency: charges[0]?.currency ?? "CAD",
  });
});

export default router;
