import { Router } from "express";

const router = Router();

router.post("/inspect", async (req, res) => {
  const { url } = req.body as { url?: string };
  if (!url || typeof url !== "string") {
    return res.status(400).json({ error: "url is required" });
  }
  try {
    const upstream = await fetch(url, {
      signal: AbortSignal.timeout(10_000),
      headers: { "Accept": "application/json" },
    });
    if (!upstream.ok) {
      return res.status(502).json({ error: `Upstream returned HTTP ${upstream.status}` });
    }
    const data = await upstream.json();
    return res.json({ data, fetchedAt: new Date().toISOString() });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return res.status(502).json({ error: `Failed to fetch feed URL: ${message}` });
  }
});

export default router;
