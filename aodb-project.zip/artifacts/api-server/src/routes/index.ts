import { Router, type IRouter } from "express";
import healthRouter from "./health";
import flightsRouter from "./flights";
import aircraftRouter from "./aircraft";
import tariffsRouter from "./tariffs";
import billingRouter from "./billing";
import billingModuleRouter from "./billing-module";
import rmsRouter from "./rms";
import qualityRouter from "./quality";
import settingsRouter from "./settings";
import simulatorRouter from "./simulator";
import feedRouter from "./feed";
import sourcesRouter from "./sources";
import schedulesRouter from "./schedules";
import ylwFeedRouter from "./ylw-feed";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/flights", flightsRouter);
router.use("/aircraft", aircraftRouter);
router.use("/tariffs", tariffsRouter);
router.use("/billing", billingRouter);
router.use("/billing", billingModuleRouter);
router.use("/rms", rmsRouter);
router.use("/quality", qualityRouter);
router.use("/settings", settingsRouter);
router.use("/simulator", simulatorRouter);
router.use("/feed", feedRouter);
router.use("/sources", sourcesRouter);
router.use("/schedules", schedulesRouter);
router.use("/ylw-feed", ylwFeedRouter);

export default router;
