import { Router } from "express";
import { db } from "@workspace/db";
import { appSettingsTable } from "@workspace/db";
import { UpdateSettingsBody } from "@workspace/api-zod";
import { eq } from "drizzle-orm";

const router = Router();

function toISO(t: Date | string): string {
  return typeof t === "string" ? t : t.toISOString();
}

async function ensureSettings() {
  const [existing] = await db.select().from(appSettingsTable).where(eq(appSettingsTable.id, "singleton"));
  if (!existing) {
    await db.insert(appSettingsTable).values({
      id: "singleton",
      airportIata: "YLW",
      airportIcao: "CYLW",
      airportName: "Kelowna International Airport",
      pollingIntervalSeconds: 60,
      environmentMode: "DEMO",
    });
    const [created] = await db.select().from(appSettingsTable).where(eq(appSettingsTable.id, "singleton"));
    return created;
  }
  return existing;
}

function settingsResponse(s: typeof appSettingsTable.$inferSelect) {
  return {
    airportIata: s.airportIata,
    airportIcao: s.airportIcao,
    airportName: s.airportName,
    fr24ApiConfigured: !!s.fr24ApiKey,
    pollingIntervalSeconds: s.pollingIntervalSeconds,
    rmsWebhookConfigured: !!s.rmsWebhookUrl,
    billingApiConfigured: !!s.billingApiUrl,
    notificationEmails: s.notificationEmails ?? null,
    environmentMode: s.environmentMode as "DEMO" | "LIVE",
    boundingBoxConfigured: !!(s.boundingBoxNorth && s.boundingBoxSouth),
    commercialOnlyMode: s.commercialOnlyMode ?? true,
  };
}

router.get("/", async (_req, res) => {
  const settings = await ensureSettings();
  res.json(settingsResponse(settings));
});

router.put("/", async (req, res) => {
  const body = UpdateSettingsBody.parse(req.body);
  const rawBody = req.body as Record<string, unknown>;
  await ensureSettings();
  await db.update(appSettingsTable).set({
    ...(body.airportIata && { airportIata: body.airportIata }),
    ...(body.airportIcao && { airportIcao: body.airportIcao }),
    ...(body.airportName && { airportName: body.airportName }),
    ...(body.pollingIntervalSeconds && { pollingIntervalSeconds: body.pollingIntervalSeconds }),
    ...(body.notificationEmails !== undefined && { notificationEmails: body.notificationEmails }),
    ...(body.environmentMode && { environmentMode: body.environmentMode }),
    ...(typeof rawBody.commercialOnlyMode === "boolean" && { commercialOnlyMode: rawBody.commercialOnlyMode }),
    updatedAt: new Date(),
  }).where(eq(appSettingsTable.id, "singleton"));

  const [updated] = await db.select().from(appSettingsTable).where(eq(appSettingsTable.id, "singleton"));
  res.json(settingsResponse(updated));
});

// Dedicated endpoint for toggling commercial-only scope
router.post("/commercial-scope", async (req, res) => {
  const rawBody = req.body as { commercialOnlyMode?: boolean };
  if (typeof rawBody.commercialOnlyMode !== "boolean") {
    return res.status(400).json({ error: "commercialOnlyMode must be a boolean" });
  }
  await ensureSettings();
  await db.update(appSettingsTable).set({ commercialOnlyMode: rawBody.commercialOnlyMode, updatedAt: new Date() }).where(eq(appSettingsTable.id, "singleton"));
  const [updated] = await db.select().from(appSettingsTable).where(eq(appSettingsTable.id, "singleton"));
  return res.json({ commercialOnlyMode: updated.commercialOnlyMode, message: rawBody.commercialOnlyMode ? "Commercial-only mode enabled" : "All-flights mode enabled" });
});

export default router;
