import { Router } from "express";
import { db } from "@workspace/db";
import { billingRecordsTable } from "@workspace/db";

const router = Router();

function toISO(t: Date | string): string {
  return typeof t === "string" ? t : t.toISOString();
}

router.get("/reconciliation", async (_req, res) => {
  const records = await db.select().from(billingRecordsTable).orderBy(billingRecordsTable.createdAt);
  res.json(records.map((r) => ({ ...r, createdAt: toISO(r.createdAt) })));
});

router.get("/summary", async (_req, res) => {
  const records = await db.select().from(billingRecordsTable);
  const totalBillable = records.length;
  const reconciled = records.filter((r) => r.reconciliationStatus === "RECONCILED").length;
  const flagged = records.filter((r) => r.reconciliationStatus === "FLAGGED").length;
  const pending = records.filter((r) => r.reconciliationStatus === "PENDING").length;
  const totalLandingFees = records.reduce((sum, r) => sum + (r.calculatedLandingFee ?? 0), 0);
  const totalAif = records.reduce((sum, r) => sum + (r.aifEstimate ?? 0), 0);

  const flagCounts: Record<string, number> = {};
  for (const r of records) {
    for (const flag of r.flags ?? []) {
      flagCounts[flag] = (flagCounts[flag] ?? 0) + 1;
    }
  }
  const exceptionTypes = Object.entries(flagCounts).map(([flag, count]) => ({ flag, count }));

  res.json({
    totalBillable,
    reconciled,
    flagged,
    pending,
    totalLandingFees: Math.round(totalLandingFees * 100) / 100,
    totalAif: Math.round(totalAif * 100) / 100,
    exceptionTypes,
  });
});

export default router;
