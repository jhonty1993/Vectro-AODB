import { Router } from "express";
import { randomUUID } from "crypto";
import { db } from "@workspace/db";
import { flightMovementsTable, appSettingsTable, adsbObservationsTable, adsbMatchesTable, fr24UsageLogTable } from "@workspace/db";
import { eq, desc, sql, gte, and, inArray } from "drizzle-orm";
import { classifyFlight, isCommercial, SOURCE_STRATEGY } from "../lib/commercial";
import { logger } from "../lib/logger";

const router = Router();

// CYLW coordinates
const CYLW_LAT = 49.9561;
const CYLW_LON = -119.3778;

// --- Deterministic seeded random for stable demo data ---
function seededRand(seed: number): () => number {
  let s = seed;
  return () => {
    s = (s * 9301 + 49297) % 233280;
    return s / 233280;
  };
}

function nmToKm(nm: number): number { return nm * 1.852; }
function distanceNm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 3440.065;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

const DEMO_HEX_POOL: Record<string, { hex: string; reg: string; type: string }> = {
  "WS525":  { hex: "c07aee", reg: "C-GWCM", type: "B737" },
  "AC8268": { hex: "c02a31", reg: "C-GGNY", type: "DH8D" },
  "WS181":  { hex: "c07b22", reg: "C-GWBF", type: "B737" },
  "AC8391": { hex: "c04f89", reg: "C-FGDP", type: "B738" },
  "8P691":  { hex: "c0c3de", reg: "C-GPCL", type: "PC12" },
  "AC8819": { hex: "c04f89", reg: "C-FGDP", type: "B738" },
  "WS3305": { hex: "c07bee", reg: "C-FWSL", type: "B737" },
  "AC8820": { hex: "c04f89", reg: "C-FGDP", type: "B738" },
};

// Simulated ADS-B Exchange nearby aircraft endpoint
// Production: GET https://adsbexchange-com1.p.rapidapi.com/v2/lat/{lat}/lon/{lon}/dist/{radius}/
router.get("/adsbexchange/nearby", async (req, res) => {
  const lat = parseFloat(req.query["lat"] as string ?? String(CYLW_LAT));
  const lon = parseFloat(req.query["lon"] as string ?? String(CYLW_LON));
  const radiusNm = parseFloat(req.query["radius"] as string ?? "25");

  const flights = await db.select().from(flightMovementsTable);
  const rand = seededRand(42);

  const now = new Date();
  const aircraft = flights
    .filter((f) => ["AIRBORNE", "SCHEDULED", "ESTIMATED", "LANDED", "ON_BLOCK"].includes(f.status))
    .slice(0, 8)
    .map((f, i) => {
      const r = seededRand(i + 100);
      const angle = r() * 2 * Math.PI;
      const dist = r() * radiusNm * 0.7;
      const acLat = lat + (dist / 60) * Math.cos(angle);
      const acLon = lon + (dist / (60 * Math.cos((lat * Math.PI) / 180))) * Math.sin(angle);
      const distFromAirport = distanceNm(lat, lon, acLat, acLon);

      const icaoKey = `${f.airlineIata}${f.flightNumber.replace(f.airlineIata, "")}`.substring(0, 8);
      const knownAc = DEMO_HEX_POOL[f.flightNumber] ?? { hex: `c0${(i * 0x1234 + 0xabcd).toString(16).slice(-4)}`, reg: f.tailNumber ?? "C-????", type: f.aircraftType ?? "UNKN" };

      const isGround = ["LANDED", "ON_BLOCK", "SCHEDULED"].includes(f.status);
      const alt = isGround ? 0 : Math.round(1500 + r() * 6000);
      const gs = isGround ? 0 : Math.round(150 + r() * 300);
      const track = Math.round(r() * 360);

      const inferredStatus = isGround
        ? (distFromAirport < 2 ? "ON_GROUND_NEAR_AIRPORT" : "ON_GROUND")
        : distFromAirport < 10
        ? "APPROACH"
        : "AIRBORNE";

      const seenSecondsAgo = Math.round(r() * 45);

      return {
        hex: knownAc.hex,
        callsign: f.flightNumber.trim(),
        registration: knownAc.reg,
        aircraftType: knownAc.type,
        lat: acLat,
        lon: acLon,
        altBaro: alt,
        groundSpeed: gs,
        track,
        distanceFromAirportNm: Math.round(distFromAirport * 10) / 10,
        seenSecondsAgo,
        lastSeen: new Date(now.getTime() - seenSecondsAgo * 1000).toISOString(),
        inferredStatus,
        matchedFlightId: f.id,
        matchedFlightNumber: f.flightNumber,
        source: "ADSBX_DEMO",
      };
    });

  return res.json({
    note: "DEMO SIMULATION — Production: use licensed ADS-B Exchange API. Globe reference: https://globe.adsbexchange.com/?airport=cylw",
    apiEndpointTemplate: "GET https://adsbexchange-com1.p.rapidapi.com/v2/lat/{lat}/lon/{lon}/dist/{radius}/",
    queryParams: { lat, lon, radiusNm },
    fetchedAt: now.toISOString(),
    count: aircraft.length,
    aircraft,
  });
});

// Simulated ADS-B Exchange manual sync
router.post("/adsbexchange/sync", async (_req, res) => {
  const flights = await db.select().from(flightMovementsTable);
  const matched = flights.filter((f) => DEMO_HEX_POOL[f.flightNumber]).length;
  const details = Object.entries(DEMO_HEX_POOL).slice(0, 4).map(
    ([fn, ac]) => `${fn} → hex ${ac.hex} (${ac.reg}/${ac.type}) seen near CYLW`
  );
  return res.json({
    eventsGenerated: matched,
    flightsUpdated: matched,
    unmatchedAircraft: 2,
    details: [
      ...details,
      `${matched} flights cross-checked with ADS-B Exchange demo data`,
      "2 unmatched ADS-B aircraft near CYLW — ops review recommended",
    ],
    syncedAt: new Date().toISOString(),
    note: "DEMO SIMULATION — configure licensed ADS-B Exchange API key for production use",
  });
});

// Source strategy definition
router.get("/strategy", async (_req, res) => {
  const [settings] = await db.select().from(appSettingsTable).limit(1).catch(() => []);
  return res.json({
    ...SOURCE_STRATEGY,
    commercialOnlyMode: settings?.commercialOnlyMode ?? true,
    environmentMode: settings?.environmentMode ?? "DEMO",
  });
});

// Multi-source comparison table
router.get("/comparison", async (req, res) => {
  const commercialOnly = req.query.commercial_only !== "false";
  const allFlights = await db.select().from(flightMovementsTable);
  const flights = commercialOnly
    ? allFlights.filter((f) => isCommercial({ airlineIata: f.airlineIata, flightNumber: f.flightNumber, aircraftType: f.aircraftType }))
    : allFlights;

  const rows = flights.slice(0, 18).map((f, i) => {
    const rand = seededRand(i + 7);
    const known = DEMO_HEX_POOL[f.flightNumber];

    const hasActual = !!f.actualTime;
    const delayMin = f.delayMinutes ?? 0;

    // Airport JSON feed values
    const feedSource = {
      source: "AIRPORT_FEED",
      flightNumber: f.flightNumber,
      scheduledTime: f.scheduledTime,
      estimatedTime: f.estimatedTime,
      status: f.status,
      tailNumber: null as string | null,
      aircraftType: null as string | null,
      confidence: 70 + Math.round(rand() * 20),
    };

    // FR24 values — actual movement truth
    const fr24Missing = rand() < 0.15;
    const fr24Source = fr24Missing
      ? null
      : {
          source: "FR24",
          flightNumber: f.flightNumber,
          actualTime: f.actualTime,
          tailNumber: f.tailNumber,
          aircraftType: f.aircraftType,
          status: f.status,
          confidence: 85 + Math.round(rand() * 12),
        };

    // ADS-B Exchange values — secondary verification
    const adsbMissing = rand() < 0.2;
    const adsbSource = adsbMissing
      ? null
      : {
          source: "ADSBX",
          hex: known?.hex ?? `c0${(i * 0x1234 + 0xabcd).toString(16).slice(-4)}`,
          callsign: f.flightNumber.trim(),
          registration: known?.reg ?? f.tailNumber ?? null,
          aircraftType: known?.type ?? f.aircraftType ?? null,
          altBaro: hasActual ? 0 : Math.round(1000 + rand() * 8000),
          groundSpeed: hasActual ? Math.round(rand() * 30) : Math.round(180 + rand() * 280),
          distanceFromAirportNm: Math.round(rand() * 15 * 10) / 10,
          lastSeen: new Date(Date.now() - Math.round(rand() * 120_000)).toISOString(),
          inferredStatus: hasActual
            ? "ON_GROUND_NEAR_AIRPORT"
            : rand() < 0.5
            ? "APPROACH"
            : "AIRBORNE",
          confidence: 75 + Math.round(rand() * 15),
        };

    // Cirium values — schedule / STA / STD
    const ciriumSource = {
      source: "CIRIUM",
      scheduledTime: f.scheduledTime,
      estimatedTime: f.estimatedTime,
      operatingCarrier: f.airlineIata,
      codeShare: rand() < 0.2 ? `${f.airlineIata}${Math.round(rand() * 9000)}` : null,
      confidence: 95,
    };

    // Conflict detection
    const conflicts: string[] = [];
    if (!fr24Source && !adsbSource) conflicts.push("NO_MOVEMENT_DATA");
    if (!fr24Source && adsbSource) conflicts.push("FR24_MISSING_ADSBX_PRESENT");
    if (fr24Source && adsbSource && fr24Source.tailNumber && adsbSource.registration && fr24Source.tailNumber !== adsbSource.registration) {
      conflicts.push("TAIL_MISMATCH");
    }
    if (fr24Source && adsbSource && fr24Source.aircraftType && adsbSource.aircraftType && fr24Source.aircraftType !== adsbSource.aircraftType) {
      conflicts.push("TYPE_MISMATCH");
    }
    if (delayMin >= 30 && !hasActual) conflicts.push("LARGE_DELAY_UNCONFIRMED");

    // Overall confidence
    const confidences = [feedSource.confidence, fr24Source?.confidence, adsbSource?.confidence, ciriumSource.confidence].filter(Boolean) as number[];
    const avgConfidence = Math.round(confidences.reduce((a, b) => a + b, 0) / confidences.length);

    const classification = classifyFlight({ airlineIata: f.airlineIata, flightNumber: f.flightNumber, aircraftType: f.aircraftType });

    return {
      flightId: f.id,
      flightNumber: f.flightNumber,
      direction: f.direction,
      airline: f.airline,
      airlineIata: f.airlineIata,
      origin: f.origin,
      destination: f.destination,
      status: f.status,
      delayMinutes: f.delayMinutes,
      overallConfidence: avgConfidence,
      conflicts,
      isCommercial: classification.isCommercial,
      commercialClass: classification.class,
      sources: {
        feed: feedSource,
        fr24: fr24Source,
        adsbx: adsbSource,
        cirium: ciriumSource,
      },
    };
  });

  const totalFlights = rows.length;
  const fr24Coverage = rows.filter((r) => r.sources.fr24).length;
  const adsbCoverage = rows.filter((r) => r.sources.adsbx).length;
  const bothCoverage = rows.filter((r) => r.sources.fr24 && r.sources.adsbx).length;
  const conflicts = rows.filter((r) => r.conflicts.length > 0).length;

  return res.json({
    summary: {
      totalFlights,
      fr24Coverage,
      adsbCoverage,
      bothCoverage,
      fr24MatchRate: totalFlights > 0 ? Math.round((fr24Coverage / totalFlights) * 100) : 0,
      adsbMatchRate: totalFlights > 0 ? Math.round((adsbCoverage / totalFlights) * 100) : 0,
      fr24AdsbAgreementRate: bothCoverage > 0 ? Math.round((bothCoverage / Math.max(fr24Coverage, adsbCoverage)) * 100) : 0,
      conflictCount: conflicts,
      ciriumCoverage: totalFlights,
    },
    operationalScope: commercialOnly ? "COMMERCIAL_ONLY" : "ALL",
    commercialOnly,
    flights: rows,
    fetchedAt: new Date().toISOString(),
  });
});

// Per-flight source field values
router.get("/:id/source-values", async (req, res) => {
  const { id } = req.params;
  const [flight] = await db.select().from(flightMovementsTable).where(
    eq(flightMovementsTable.id, id)
  ).limit(1).catch(() => []);

  if (!flight) return res.status(404).json({ error: "Flight not found" });

  const rand = seededRand(flight.flightNumber.charCodeAt(0) + flight.flightNumber.charCodeAt(1));
  const known = DEMO_HEX_POOL[flight.flightNumber];
  const fr24Missing = rand() < 0.15;
  const adsbMissing = rand() < 0.2;

  const fields: Array<{
    field: string;
    label: string;
    sources: Array<{ source: string; value: string | null; confidence: number; note?: string }>;
    winner: string;
    winnerReason: string;
  }> = [
    {
      field: "flightNumber",
      label: "Flight Number",
      sources: [
        { source: "AIRPORT_FEED", value: flight.flightNumber, confidence: 99 },
        { source: "FR24", value: fr24Missing ? null : flight.flightNumber, confidence: 99 },
        { source: "ADSBX", value: adsbMissing ? null : flight.flightNumber.trim(), confidence: 95, note: "Callsign (may differ from IATA)" },
        { source: "CIRIUM", value: flight.flightNumber, confidence: 99 },
      ],
      winner: "CIRIUM",
      winnerReason: "Cirium is authoritative for planned IATA flight identifiers",
    },
    {
      field: "tailNumber",
      label: "Tail / Registration",
      sources: [
        { source: "AIRPORT_FEED", value: null, confidence: 0, note: "Not in airport feed" },
        { source: "FR24", value: fr24Missing ? null : flight.tailNumber, confidence: 85 },
        { source: "ADSBX", value: adsbMissing ? null : (known?.reg ?? flight.tailNumber), confidence: 80, note: "Registration from Mode S transponder" },
        { source: "CIRIUM", value: null, confidence: 0, note: "Not a Cirium field" },
      ],
      winner: fr24Missing ? "ADSBX" : "FR24",
      winnerReason: fr24Missing ? "FR24 absent — ADS-B Exchange registration used" : "FR24 preferred for actual registration",
    },
    {
      field: "aircraftType",
      label: "Aircraft Type",
      sources: [
        { source: "AIRPORT_FEED", value: null, confidence: 0, note: "Not in airport feed" },
        { source: "FR24", value: fr24Missing ? null : flight.aircraftType, confidence: 90 },
        { source: "ADSBX", value: adsbMissing ? null : (known?.type ?? flight.aircraftType), confidence: 75, note: "Type from ICAO db lookup" },
        { source: "CIRIUM", value: flight.aircraftType, confidence: 70, note: "Scheduled a/c type; may change" },
      ],
      winner: fr24Missing ? "ADSBX" : "FR24",
      winnerReason: "FR24 preferred for actual operated aircraft type",
    },
    {
      field: "scheduledTime",
      label: "Scheduled Time (STA/STD)",
      sources: [
        { source: "AIRPORT_FEED", value: flight.scheduledTime, confidence: 80 },
        { source: "FR24", value: fr24Missing ? null : flight.scheduledTime, confidence: 70 },
        { source: "ADSBX", value: null, confidence: 0, note: "ADS-B does not carry schedule data" },
        { source: "CIRIUM", value: flight.scheduledTime, confidence: 98, note: "Cirium authoritative for STA/STD" },
      ],
      winner: "CIRIUM",
      winnerReason: "Cirium is the authoritative source for planned schedule times",
    },
    {
      field: "estimatedTime",
      label: "Estimated Time (ETA/ETD)",
      sources: [
        { source: "AIRPORT_FEED", value: flight.estimatedTime, confidence: 85, note: "Terminal display ETx" },
        { source: "FR24", value: fr24Missing ? null : flight.estimatedTime, confidence: 90, note: "ATC estimated based on position" },
        { source: "ADSBX", value: null, confidence: 0, note: "Not available from ADS-B" },
        { source: "CIRIUM", value: flight.estimatedTime, confidence: 88 },
      ],
      winner: fr24Missing ? "AIRPORT_FEED" : "FR24",
      winnerReason: "FR24 ATC estimate preferred for day-of-operations ETA",
    },
    {
      field: "actualTime",
      label: "Actual Time (ATA/ATD)",
      sources: [
        { source: "AIRPORT_FEED", value: flight.actualTime, confidence: 75, note: "Ops system update" },
        { source: "FR24", value: fr24Missing ? null : flight.actualTime, confidence: 95, note: "Wheels-on / wheels-off from ADS-B" },
        { source: "ADSBX", value: adsbMissing ? null : flight.actualTime, confidence: 80, note: "Inferred from altitude/speed profile" },
        { source: "CIRIUM", value: null, confidence: 0, note: "Cirium does not provide actuals" },
      ],
      winner: fr24Missing ? "ADSBX" : "FR24",
      winnerReason: "FR24 wheels-on/off events are most precise for actual timestamps",
    },
    {
      field: "status",
      label: "Flight Status",
      sources: [
        { source: "AIRPORT_FEED", value: flight.status, confidence: 70, note: "Terminal display status; coarse granularity" },
        { source: "FR24", value: fr24Missing ? null : flight.status, confidence: 92 },
        { source: "ADSBX", value: adsbMissing ? null : flight.status, confidence: 80, note: "Inferred from position/altitude/speed" },
        { source: "CIRIUM", value: "SCHEDULED", confidence: 40, note: "Cirium only knows planned status" },
      ],
      winner: fr24Missing ? "ADSBX" : "FR24",
      winnerReason: "FR24 actual-movement status overrides schedule/feed",
    },
  ];

  return res.json({
    flightId: flight.id,
    flightNumber: flight.flightNumber,
    direction: flight.direction,
    airline: flight.airline,
    status: flight.status,
    fields,
    fetchedAt: new Date().toISOString(),
  });
});

// Source reliability metrics
router.get("/reliability", async (_req, res) => {
  const flights = await db.select().from(flightMovementsTable);

  const byAirline: Record<string, { airline: string; total: number; fr24: number; adsbx: number; both: number; avgConfidence: number }> = {};
  let fr24Match = 0;
  let adsbMatch = 0;
  let bothMatch = 0;
  let unmatchedAdsbx = 2;

  for (const f of flights) {
    const rand = seededRand(f.flightNumber.charCodeAt(0) + f.flightNumber.charCodeAt(1));
    const hasFr24 = rand() >= 0.15;
    const hasAdsbx = rand() >= 0.2;

    if (hasFr24) fr24Match++;
    if (hasAdsbx) adsbMatch++;
    if (hasFr24 && hasAdsbx) bothMatch++;

    const key = f.airlineIata;
    if (!byAirline[key]) byAirline[key] = { airline: f.airline, total: 0, fr24: 0, adsbx: 0, both: 0, avgConfidence: 0 };
    byAirline[key].total++;
    if (hasFr24) byAirline[key].fr24++;
    if (hasAdsbx) byAirline[key].adsbx++;
    if (hasFr24 && hasAdsbx) byAirline[key].both++;
    byAirline[key].avgConfidence += (hasFr24 && hasAdsbx ? 90 : hasFr24 ? 82 : hasAdsbx ? 75 : 50);
  }

  for (const k of Object.keys(byAirline)) {
    byAirline[k].avgConfidence = Math.round(byAirline[k].avgConfidence / byAirline[k].total);
  }

  return res.json({
    overall: {
      totalFlights: flights.length,
      fr24MatchCount: fr24Match,
      adsbxMatchCount: adsbMatch,
      bothMatchCount: bothMatch,
      fr24MatchRate: Math.round((fr24Match / flights.length) * 100),
      adsbxMatchRate: Math.round((adsbMatch / flights.length) * 100),
      fr24AdsbxAgreementRate: bothMatch > 0 ? Math.round((bothMatch / Math.max(fr24Match, adsbMatch)) * 100) : 0,
      unmatchedAdsbxAircraft: unmatchedAdsbx,
      ciriumCoverage: 100,
    },
    byAirline: Object.values(byAirline).sort((a, b) => b.total - a.total),
    fetchedAt: new Date().toISOString(),
  });
});

// ── FR24 helpers ───────────────────────────────────────────────────────────

async function getSettings() {
  let [s] = await db.select().from(appSettingsTable).where(eq(appSettingsTable.id, "singleton"));
  if (!s) {
    await db.insert(appSettingsTable).values({ id: "singleton" });
    [s] = await db.select().from(appSettingsTable).where(eq(appSettingsTable.id, "singleton"));
  }
  return s;
}

const FR24_LIVE_BASE = "https://fr24api.flightradar24.com";

async function callFr24Api(apiKey: string, icao: string): Promise<{ ok: boolean; status: number; data?: unknown; error?: string }> {
  try {
    const url = `${FR24_LIVE_BASE}/api/live/flight-positions/full?airports=${icao}&categories=P,C&limit=100`;
    const res = await fetch(url, {
      headers: {
        Authorization: `Bearer ${apiKey}`,
        Accept: "application/json",
        "Accept-Version": "v1",
      },
      signal: AbortSignal.timeout(8000),
    });
    if (!res.ok) {
      const body = await res.text().catch(() => "");
      return { ok: false, status: res.status, error: `FR24 API returned HTTP ${res.status}: ${body.substring(0, 120)}` };
    }
    const data = await res.json();
    return { ok: true, status: res.status, data };
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Unknown error";
    return { ok: false, status: 0, error: msg };
  }
}

async function logFr24Call(opts: {
  endpoint: string;
  purpose: string;
  success: boolean;
  httpStatus?: number;
  estimatedCredits?: number;
  errorMessage?: string;
  responseTimeMs?: number;
  meta?: Record<string, unknown>;
}) {
  try {
    await db.insert(fr24UsageLogTable).values({
      id: randomUUID(),
      endpoint: opts.endpoint,
      purpose: opts.purpose,
      success: opts.success,
      httpStatus: opts.httpStatus ?? null,
      estimatedCredits: opts.estimatedCredits ?? 1,
      errorMessage: opts.errorMessage ?? null,
      responseTimeMs: opts.responseTimeMs ?? null,
      meta: opts.meta ?? null,
    });
  } catch { /* non-critical — don't block the response */ }
}

function getFr24Key(s: Awaited<ReturnType<typeof getSettings>>): { key: string | null; source: "db" | "env" | "none" } {
  if (s.fr24ApiKey) return { key: s.fr24ApiKey, source: "db" };
  const envKey = process.env.FLIGHTRADAR24_API_KEY?.trim() ?? process.env.FR24_API_KEY?.trim();
  if (envKey) return { key: envKey, source: "env" };
  return { key: null, source: "none" };
}

function fr24StatusSummary(s: Awaited<ReturnType<typeof getSettings>>) {
  const { key, source } = getFr24Key(s);
  const configured = !!key;
  const dbStatus = (s.fr24ConnectionStatus ?? "demo") as "demo" | "configured" | "live" | "failed";
  const connectionStatus: "demo" | "configured" | "live" | "failed" =
    !configured ? "demo" : source === "env" && dbStatus === "demo" ? "configured" : dbStatus;
  return {
    configured,
    keySource: source,
    connectionStatus,
    lastSyncAt: s.fr24LastSyncAt?.toISOString() ?? null,
    lastSyncStatus: s.fr24LastSyncStatus ?? null,
    lastSyncCount: s.fr24LastSyncCount ?? null,
    airportIata: s.airportIata,
    airportIcao: s.airportIcao,
    pollingIntervalSeconds: s.fr24PollingIntervalSeconds ?? 60,
    operatingHoursStart: s.fr24OperatingHoursStart ?? "06:00",
    operatingHoursEnd: s.fr24OperatingHoursEnd ?? "23:00",
    radiusNm: s.fr24RadiusNm ?? 50,
  };
}

// ── FR24 routes ─────────────────────────────────────────────────────────────

router.get("/fr24/status", async (_req, res) => {
  const s = await getSettings();
  return res.json(fr24StatusSummary(s));
});

router.post("/fr24/configure", async (req, res) => {
  const raw = req.body as Record<string, unknown>;
  const body = {
    apiKey: typeof raw.apiKey === "string" && raw.apiKey.length >= 8 ? raw.apiKey : undefined,
    pollingIntervalSeconds: typeof raw.pollingIntervalSeconds === "number" ? Math.max(10, Math.min(3600, raw.pollingIntervalSeconds)) : undefined,
    operatingHoursStart: typeof raw.operatingHoursStart === "string" && /^\d{2}:\d{2}$/.test(raw.operatingHoursStart) ? raw.operatingHoursStart : undefined,
    operatingHoursEnd: typeof raw.operatingHoursEnd === "string" && /^\d{2}:\d{2}$/.test(raw.operatingHoursEnd) ? raw.operatingHoursEnd : undefined,
    radiusNm: typeof raw.radiusNm === "number" ? Math.max(5, Math.min(250, raw.radiusNm)) : undefined,
  };
  await getSettings();

  const update: Record<string, unknown> = { updatedAt: new Date() };
  if (body.apiKey) {
    update.fr24ApiKey = body.apiKey;
    update.fr24ConnectionStatus = "configured";
  }
  if (body.pollingIntervalSeconds) update.fr24PollingIntervalSeconds = body.pollingIntervalSeconds;
  if (body.operatingHoursStart) update.fr24OperatingHoursStart = body.operatingHoursStart;
  if (body.operatingHoursEnd) update.fr24OperatingHoursEnd = body.operatingHoursEnd;
  if (body.radiusNm) update.fr24RadiusNm = body.radiusNm;

  await db.update(appSettingsTable).set(update).where(eq(appSettingsTable.id, "singleton"));
  const s = await getSettings();
  return res.json({ saved: true, ...fr24StatusSummary(s) });
});

router.post("/fr24/test-connection", async (_req, res) => {
  const s = await getSettings();
  const { key } = getFr24Key(s);

  if (!key) {
    return res.json({
      success: false,
      mode: "demo",
      message: "No FR24 API key configured. Running in Demo Mode.",
      hint: "Paste your key in the popup, or set the FR24_API_KEY secret in Replit Secrets.",
    });
  }

  const t0 = Date.now();
  const result = await callFr24Api(key, s.airportIcao);
  const ms = Date.now() - t0;

  if (result.ok) {
    const data = result.data as { result?: { response?: { data?: { rows?: unknown[] } } } };
    const rows = data?.result?.response?.data?.rows ?? (Array.isArray(data) ? data : []);
    const count = Array.isArray(rows) ? rows.length : 0;
    await Promise.all([
      db.update(appSettingsTable)
        .set({ fr24ConnectionStatus: "live", updatedAt: new Date() })
        .where(eq(appSettingsTable.id, "singleton")),
      logFr24Call({ endpoint: "/api/live/flight-positions/full", purpose: "test-connection", success: true, httpStatus: result.status, estimatedCredits: 1, responseTimeMs: ms, meta: { aircraftCount: count } }),
    ]);
    return res.json({
      success: true,
      mode: "live",
      message: `FR24 connection successful — ${count} aircraft near ${s.airportIcao} returned.`,
      aircraftCount: count,
    });
  }

  await Promise.all([
    db.update(appSettingsTable)
      .set({ fr24ConnectionStatus: "failed", updatedAt: new Date() })
      .where(eq(appSettingsTable.id, "singleton")),
    logFr24Call({ endpoint: "/api/live/flight-positions/full", purpose: "test-connection", success: false, httpStatus: result.status, estimatedCredits: 0, errorMessage: result.error, responseTimeMs: ms }),
  ]);

  let hint: string;
  if (result.status === 401) {
    hint = "Key was rejected by FR24 as invalid. Re-copy from the FR24 developer portal — long Bearer tokens are easy to truncate.";
  } else if (result.status === 402 || result.status === 403) {
    hint = "Key is valid, but the FR24 account has no active subscription for the Live Flight Positions endpoint. Activate or renew the FR24 commercial API plan in your FR24 portal.";
  } else if (result.status === 429) {
    hint = "FR24 rate-limit hit. Wait a minute and try again, or increase the polling interval.";
  } else if (result.status === 0) {
    hint = "Network/timeout error reaching FR24. Check egress and try again.";
  } else {
    hint = "Verify your API key, subscription, and that the airport ICAO is supported by your FR24 plan.";
  }

  return res.json({
    success: false,
    mode: "failed",
    message: `FR24 connection failed: ${result.error}`,
    httpStatus: result.status,
    hint,
  });
});

type Fr24SyncResult =
  | { mode: "demo"; eventsGenerated: number; flightsUpdated: number; message: string; details: string[]; syncedAt: string }
  | { mode: "failed"; message: string; httpStatus?: number }
  | { mode: "skipped"; reason: string }
  | { mode: "live"; aircraftInResponse: number; eventsGenerated: number; fieldsWritten: number; message: string; syncedAt: string; actualsMatched?: number; actualsUpdated?: number };

export async function runFr24Sync(opts: { trigger: "manual" | "scheduler" } = { trigger: "manual" }): Promise<Fr24SyncResult> {
  const s = await getSettings();
  const { key: fr24Key } = getFr24Key(s);

  if (!fr24Key) {
    if (opts.trigger === "scheduler") return { mode: "skipped", reason: "no FR24 key configured" };
    const flights = await db.select().from(flightMovementsTable);
    const synced = Math.min(flights.length, 12);
    await db.update(appSettingsTable).set({
      fr24LastSyncAt: new Date(),
      fr24LastSyncStatus: "demo",
      fr24LastSyncCount: synced,
      fr24ConnectionStatus: "demo",
      updatedAt: new Date(),
    }).where(eq(appSettingsTable.id, "singleton"));
    return {
      mode: "demo",
      eventsGenerated: synced,
      flightsUpdated: synced,
      message: `Demo sync complete — ${synced} flights updated with simulated FR24 actuals.`,
      details: [
        `${synced} flight movements cross-checked with demo FR24 data`,
        "tailNumber and aircraftType enriched from demo ADS-B pool",
        "No real FR24 API key configured — configure to enable live mode",
      ],
      syncedAt: new Date().toISOString(),
    };
  }

  const t0sync = Date.now();
  const result = await callFr24Api(fr24Key, s.airportIcao);
  const msSync = Date.now() - t0sync;
  if (!result.ok) {
    await Promise.all([
      db.update(appSettingsTable).set({
        fr24LastSyncAt: new Date(),
        fr24LastSyncStatus: "failed",
        fr24ConnectionStatus: "failed",
        updatedAt: new Date(),
      }).where(eq(appSettingsTable.id, "singleton")),
      logFr24Call({ endpoint: "/api/live/flight-positions/full", purpose: opts.trigger === "scheduler" ? "scheduler-sync" : "sync", success: false, httpStatus: result.status, estimatedCredits: 0, errorMessage: result.error, responseTimeMs: msSync }),
    ]);
    return { mode: "failed", message: `FR24 sync failed: ${result.error}`, httpStatus: result.status };
  }

  // Parse FR24 response — structure varies by API version
  const raw = result.data as Record<string, unknown>;
  const rows: unknown[] = Array.isArray(raw)
    ? raw
    : Array.isArray(raw?.data) ? raw.data as unknown[]
    : Array.isArray(raw?.result) ? raw.result as unknown[]
    : (raw?.result as Record<string, unknown>)?.response
      ? ((raw.result as Record<string, unknown>).response as Record<string, unknown>)?.data
        ? (((raw.result as Record<string, unknown>).response as Record<string, unknown>).data as Record<string, unknown>)?.rows as unknown[] ?? []
        : []
      : [];

  const airportIcao = s.airportIcao.toUpperCase();
  const airportIata = s.airportIata.toUpperCase();
  let eventsGenerated = 0;
  let fieldsWritten = 0;
  let matchAttempts = 0;

  // ICAO airline code → possible IATA flight-number prefixes as published at YLW.
  // Regional carriers fly under a mainline code: WestJet Encore (WEN) → WS,
  // Jazz (JZA) → AC (Air Canada Express, how YLW publishes it; QK kept as fallback).
  const ICAO_TO_IATA: Record<string, string[]> = {
    WJA: ["WS"], WEN: ["WS"], ACA: ["AC"], JZA: ["AC", "QK"], RGE: ["AC", "RV"],
    PCO: ["8P"], FLE: ["F8"], TSC: ["TS"], SWG: ["WG"], POE: ["PD"],
    GLR: ["9M"], ASA: ["AS"], UAL: ["UA"], DAL: ["DL"], AAL: ["AA"],
    SWA: ["WN"], JIA: ["AA"], SKW: ["AA", "UA", "DL"], ENY: ["AA"], QXE: ["AS"],
  };

  function candidateFlightNumbers(callsign: string): string[] {
    const cs = callsign.toUpperCase();
    const m = cs.match(/^([A-Z]{2,3})(\d+[A-Z]?)$/);
    if (!m) return [cs];
    const [, prefix, digits] = m;
    const candidates = new Set<string>([cs]);
    if (prefix.length === 3 && ICAO_TO_IATA[prefix]) {
      for (const iata of ICAO_TO_IATA[prefix]) candidates.add(`${iata}${digits}`);
    }
    if (prefix.length === 2) candidates.add(`${prefix}${digits}`);
    return [...candidates];
  }

  for (const row of rows) {
    const ac = row as Record<string, unknown>;
    const callsign = String(ac.callsign ?? ac.flight ?? "").trim().replace(/\s+/g, "").toUpperCase();
    if (!callsign) continue;
    matchAttempts++;

    const origIcao = String(ac.orig_icao ?? "").toUpperCase();
    const destIcao = String(ac.dest_icao ?? "").toUpperCase();
    const origIata = String(ac.orig_iata ?? "").toUpperCase();
    const destIata = String(ac.dest_iata ?? "").toUpperCase();
    const isArrival = destIcao === airportIcao || destIata === airportIata;
    const isDeparture = origIcao === airportIcao || origIata === airportIata;
    // Require explicit direction signal — never default; ambiguous rows are skipped
    if (!isArrival && !isDeparture) continue;

    // FR24's `flight` field is the published IATA flight number (e.g. "AC8282"),
    // which is the most reliable match key. The `callsign` (e.g. "JZA282") often
    // uses the operating carrier's ICAO code and a different number, so we derive
    // candidates from both and union them.
    const flightNum = String(ac.flight ?? "").trim().replace(/\s+/g, "").toUpperCase();
    const candidates = [...new Set([
      ...(flightNum ? candidateFlightNumbers(flightNum) : []),
      ...candidateFlightNumbers(callsign),
    ])];
    const matches = await db.select().from(flightMovementsTable)
      .where(and(
        inArray(flightMovementsTable.flightNumber, candidates),
        eq(flightMovementsTable.direction, isArrival ? "ARR" : "DEP"),
      ));

    if (matches.length === 0) continue;
    // Pick the nearest flight by scheduled time (within ±6h) to avoid stamping yesterday's row
    const nowMs = Date.now();
    const flight = matches
      .map((f) => ({ f, deltaMs: Math.abs(new Date(f.scheduledTime).getTime() - nowMs) }))
      .sort((a, b) => a.deltaMs - b.deltaMs)[0];
    if (!flight || flight.deltaMs > 6 * 60 * 60 * 1000) continue;

    const update: Partial<typeof flightMovementsTable.$inferInsert> = {};
    const reg = ac.reg ? String(ac.reg).trim() : "";
    const acType = ac.type ? String(ac.type).trim() : ac.aircraft ? String(ac.aircraft).trim() : "";
    if (reg && reg !== flight.f.tailNumber) update.tailNumber = reg;
    if (acType && acType !== flight.f.aircraftType) update.aircraftType = acType;

    // FR24 matched this flight — always mark it as FR24-seen so the UI can
    // attribute the contribution, independent of which fields FR24 owns.
    const nowIso = new Date().toISOString();
    update.fr24Seen = true;
    update.fr24LastSeenAt = nowIso;

    // Track whether we wrote an FR24-owned field (status/estimated/actual)
    // — only those fields claim FR24_LIVE ownership; tail/type are enrichment only.
    let claimedOwnership = false;

    const eta = ac.eta ? String(ac.eta) : "";
    // FR24 ETA is authoritative for in-progress flights. We update the estimate
    // even if a (possibly premature/stale) actualTime exists, as long as the
    // flight has not reached a terminal state — never overwrite the actual itself.
    const isTerminal = ["LANDED", "DEPARTED", "ON_BLOCK", "CANCELLED", "DIVERTED"].includes(flight.f.status);
    if (isArrival && eta && !isTerminal && flight.f.dataSource !== "MANUAL") {
      const etaDate = new Date(eta);
      if (!isNaN(etaDate.getTime())) {
        const etaIso = etaDate.toISOString();
        if (etaIso !== flight.f.estimatedTime) {
          update.estimatedTime = etaIso;
          claimedOwnership = true;
          if (flight.f.status === "SCHEDULED") update.status = "ESTIMATED";
        }
        // A non-terminal flight must not carry an actual time. Clear any
        // premature/stale actual (e.g. the YLW feed's estimate-as-actual fallback)
        // so the Actual column stays empty until landing is confirmed.
        if (flight.f.actualTime) {
          update.actualTime = null;
          claimedOwnership = true;
        }
      }
    }

    if (claimedOwnership) {
      // Only stamp FR24_LIVE when we wrote an authoritative field. Tail/type-only
      // updates leave dataSource intact so YLW's terminal status (LANDED/DEPARTED/CANCELLED)
      // can still progress the row.
      update.dataSource = "FR24_LIVE";
    }
    update.updatedAt = new Date();

    await db.update(flightMovementsTable)
      .set(update)
      .where(eq(flightMovementsTable.id, flight.f.id));
    eventsGenerated++;
    // Count meaningful data fields written (exclude bookkeeping: fr24Seen,
    // fr24LastSeenAt, updatedAt, and dataSource when ownership claimed).
    const bookkeeping = 3 + (claimedOwnership ? 1 : 0);
    fieldsWritten += Math.max(0, Object.keys(update).length - bookkeeping);
  }

  // ── Phase 2: authoritative actuals via FR24 flight-summary ──────────────────
  // Live positions provide an ETA but never a confirmed landing/takeoff time, so
  // actuals would otherwise lag the YLW feed (or show a premature estimate-as-actual).
  // The flight-summary API returns real datetime_landed/datetime_takeoff, which per
  // the source strategy (ATA/ATD: FR24 first) is authoritative. Throttled to bound
  // credits; the manual sync button always forces an immediate reconcile.
  let actualsMatched = 0, actualsUpdated = 0;
  const summaryElapsedSec = (Date.now() - fr24SummaryLastRunMs) / 1000;
  if (opts.trigger === "manual" || summaryElapsedSec >= 120) {
    fr24SummaryLastRunMs = Date.now();
    const rec = await reconcileFr24Actuals(s, fr24Key);
    actualsMatched = rec.matched;
    actualsUpdated = rec.updated;
  }

  await Promise.all([
    db.update(appSettingsTable).set({
      fr24LastSyncAt: new Date(),
      fr24LastSyncStatus: "success",
      fr24LastSyncCount: eventsGenerated + actualsUpdated,
      fr24ConnectionStatus: "live",
      updatedAt: new Date(),
    }).where(eq(appSettingsTable.id, "singleton")),
    logFr24Call({ endpoint: "/api/live/flight-positions/full", purpose: opts.trigger === "scheduler" ? "scheduler-sync" : "sync", success: true, httpStatus: result.status, estimatedCredits: 1, responseTimeMs: msSync, meta: { aircraftInResponse: rows.length, eventsGenerated, fieldsWritten } }),
  ]);

  return {
    mode: "live",
    aircraftInResponse: rows.length,
    eventsGenerated,
    fieldsWritten,
    actualsMatched,
    actualsUpdated,
    message: `FR24 live sync complete — ${rows.length} aircraft seen near ${s.airportIcao}, ${matchAttempts} with callsigns, ${eventsGenerated} flights updated (${fieldsWritten} fields)`
      + (actualsMatched || actualsUpdated ? `; ${actualsUpdated} actuals reconciled from flight-summary (${actualsMatched} matched)` : "")
      + ".",
    syncedAt: new Date().toISOString(),
  };
}

// ── FR24 auto-scheduler ────────────────────────────────────────────────────
let fr24SyncInFlight = false;
let fr24SchedulerTimer: NodeJS.Timeout | null = null;

router.post("/fr24/sync", async (_req, res) => {
  if (fr24SyncInFlight) {
    return res.status(409).json({ mode: "busy", message: "An FR24 sync is already in progress. Try again in a moment." });
  }
  fr24SyncInFlight = true;
  try {
    const result = await runFr24Sync({ trigger: "manual" });
    if (result.mode === "failed") return res.status(502).json(result);
    return res.json(result);
  } finally {
    fr24SyncInFlight = false;
  }
});

// ── FR24 historical backfill (Flight Summary API) ────────────────────────────
// FR24's paid subscription exposes /api/flight-summary/full, which returns one
// row per completed flight leg (with real takeoff/landing times) for an airport
// and date range. We use it to populate past dates so the dashboard date picker
// shows real history instead of "no flights for this date".

const FR24_AIRLINE_NAMES: Record<string, string> = {
  AC: "Air Canada", WS: "WestJet", "8P": "Pacific Coastal Airlines", QK: "Jazz Aviation",
  PD: "Porter Airlines", F8: "Flair Airlines", TS: "Air Transat", WG: "Sunwing",
  UA: "United Airlines", DL: "Delta", AA: "American Airlines", AS: "Alaska Airlines",
  WN: "Southwest", RV: "Air Canada Rouge", "9M": "Central Mountain Air", B6: "JetBlue",
};

interface Fr24SummaryRow {
  flight?: string | null;
  callsign?: string | null;
  operating_as?: string | null;
  painted_as?: string | null;
  type?: string | null;
  reg?: string | null;
  orig_icao?: string | null;
  orig_iata?: string | null;
  dest_icao?: string | null;
  dest_iata?: string | null;
  datetime_takeoff?: string | null;
  datetime_landed?: string | null;
  category?: string | null;
  hex?: string | null;
  flight_ended?: boolean | null;
}

function ylwDayOf(iso: string): string {
  return new Intl.DateTimeFormat("en-CA", { timeZone: "America/Vancouver" }).format(new Date(iso));
}

async function fetchFr24FlightSummary(
  apiKey: string,
  icao: string,
  fromISO: string,
  toISO: string,
): Promise<{ ok: boolean; status: number; rows: Fr24SummaryRow[]; error?: string }> {
  try {
    const qs = new URLSearchParams({
      airports: `both:${icao}`,
      flight_datetime_from: fromISO,
      flight_datetime_to: toISO,
    });
    const url = `${FR24_LIVE_BASE}/api/flight-summary/full?${qs.toString()}`;
    const res = await fetch(url, {
      headers: { Authorization: `Bearer ${apiKey}`, Accept: "application/json", "Accept-Version": "v1" },
      signal: AbortSignal.timeout(20000),
    });
    if (!res.ok) {
      const body = await res.text().catch(() => "");
      return { ok: false, status: res.status, rows: [], error: `HTTP ${res.status}: ${body.substring(0, 160)}` };
    }
    const data = (await res.json()) as { data?: Fr24SummaryRow[] };
    return { ok: true, status: res.status, rows: Array.isArray(data?.data) ? data.data : [] };
  } catch (err) {
    return { ok: false, status: 0, rows: [], error: err instanceof Error ? err.message : "Unknown error" };
  }
}

function summaryRowToMovement(
  r: Fr24SummaryRow,
  airportIcao: string,
  airportIata: string,
): { flightNumber: string; airline: string; airlineIata: string; direction: "ARR" | "DEP"; origin: string; destination: string; scheduledTime: string; actualTime: string; status: string; tailNumber: string | null; aircraftType: string | null } | null {
  const flight = (r.flight ?? "").trim().toUpperCase();
  if (!flight) return null;
  const isArr = (r.dest_icao ?? "").toUpperCase() === airportIcao;
  const isDep = (r.orig_icao ?? "").toUpperCase() === airportIcao;
  if (!isArr && !isDep) return null;

  const airlineIata = flight.slice(0, 2).toUpperCase();
  if (!isCommercial({ airlineIata, callsign: r.callsign, aircraftType: r.type, flightNumber: flight, registration: r.reg })) {
    return null;
  }

  if (isArr) {
    const t = r.datetime_landed;
    if (!t) return null;
    return {
      flightNumber: flight, airline: FR24_AIRLINE_NAMES[airlineIata] ?? r.operating_as ?? airlineIata, airlineIata,
      direction: "ARR", origin: (r.orig_iata ?? r.orig_icao ?? "???").toUpperCase(), destination: airportIata,
      scheduledTime: t, actualTime: t, status: "LANDED", tailNumber: r.reg ?? null, aircraftType: r.type ?? null,
    };
  }
  const t = r.datetime_takeoff;
  if (!t) return null;
  return {
    flightNumber: flight, airline: FR24_AIRLINE_NAMES[airlineIata] ?? r.operating_as ?? airlineIata, airlineIata,
    direction: "DEP", origin: airportIata, destination: (r.dest_iata ?? r.dest_icao ?? "???").toUpperCase(),
    scheduledTime: t, actualTime: t, status: "DEPARTED", tailNumber: r.reg ?? null, aircraftType: r.type ?? null,
  };
}

let fr24SummaryLastRunMs = 0;

// Reconcile authoritative actual landing/takeoff times from the FR24 flight-summary
// API for recently-completed legs. Live positions only give an ETA and never a
// confirmed actual, so without this the board's Actual column lags the YLW feed (or
// shows a premature estimate-as-actual). Per the source strategy FR24 is the #1
// source for ATA/ATD, so summary actuals override YLW-derived values — never MANUAL.
async function reconcileFr24Actuals(
  s: Awaited<ReturnType<typeof getSettings>>,
  fr24Key: string,
): Promise<{ matched: number; updated: number; rows: number }> {
  const airportIcao = s.airportIcao.toUpperCase();
  const airportIata = s.airportIata.toUpperCase();
  // Rolling window covering recently-completed legs (last 5h) up to now.
  const now = Date.now();
  const fromISO = new Date(now - 5 * 60 * 60 * 1000).toISOString().slice(0, 19);
  const toISO = new Date(now).toISOString().slice(0, 19);

  const t0 = Date.now();
  const resp = await fetchFr24FlightSummary(fr24Key, airportIcao, fromISO, toISO);
  await logFr24Call({
    endpoint: "/api/flight-summary/full", purpose: "actuals-reconcile", success: resp.ok,
    httpStatus: resp.status, estimatedCredits: resp.rows.length, responseTimeMs: Date.now() - t0,
    meta: { rows: resp.rows.length, window: `${fromISO}..${toISO}` },
  });
  if (!resp.ok) return { matched: 0, updated: 0, rows: 0 };

  let matched = 0, updated = 0;
  for (const r of resp.rows) {
    const m = summaryRowToMovement(r, airportIcao, airportIata);
    if (!m) continue;
    const actualMs = new Date(m.actualTime).getTime();
    if (isNaN(actualMs)) continue;

    // Match by published flight number + direction, then pick the scheduled row
    // closest to the actual time (handles legs crossing the Pacific midnight).
    const cands = await db.select().from(flightMovementsTable)
      .where(and(
        eq(flightMovementsTable.flightNumber, m.flightNumber),
        eq(flightMovementsTable.direction, m.direction),
      ));
    if (cands.length === 0) continue;
    // Prefer a candidate whose tail matches FR24's reg, then the scheduled row
    // closest to the actual time — disambiguates repeated same-number legs.
    const reg = m.tailNumber?.toUpperCase() ?? null;
    const target = cands
      .map((f) => ({
        f,
        delta: Math.abs(new Date(f.scheduledTime).getTime() - actualMs),
        regMiss: reg && f.tailNumber && f.tailNumber.toUpperCase() === reg ? 0 : 1,
      }))
      .sort((a, b) => a.regMiss - b.regMiss || a.delta - b.delta)[0];
    if (!target || target.delta > 12 * 60 * 60 * 1000) continue;
    matched++;

    const f = target.f;
    if (f.dataSource === "MANUAL") continue; // never override manual entries

    const delayMinutes = Math.round((actualMs - new Date(f.scheduledTime).getTime()) / 60000);
    // Already fully authoritative AND delay is consistent — nothing to do. A stale
    // delay (e.g. left behind by an earlier feed overwrite) still falls through so
    // reconcile can self-heal it back to the FR24-actual-derived value.
    if (f.status === m.status && f.actualTime === m.actualTime && f.delayMinutes === delayMinutes) continue;
    await db.update(flightMovementsTable).set({
      actualTime: m.actualTime,
      status: m.status,
      dataSource: "FR24_LIVE",
      tailNumber: f.tailNumber ?? m.tailNumber,
      aircraftType: f.aircraftType ?? m.aircraftType,
      delayMinutes,
      fr24Seen: true,
      fr24LastSeenAt: new Date().toISOString(),
      updatedAt: new Date(),
    }).where(eq(flightMovementsTable.id, f.id));
    updated++;
  }
  return { matched, updated, rows: resp.rows.length };
}

let fr24BackfillInFlight = false;

async function runFr24Backfill(opts: { fromDate: string; toDate: string }): Promise<{
  mode: "live" | "demo" | "failed";
  message: string;
  daysQueried?: number;
  rowsSeen?: number;
  inserted?: number;
  updated?: number;
  skipped?: number;
  nonCommercial?: number;
  errors?: string[];
}> {
  const s = await getSettings();
  const { key: fr24Key } = getFr24Key(s);
  if (!fr24Key) {
    return { mode: "demo", message: "No FR24 API key configured — historical backfill requires a live FR24 subscription key." };
  }
  const airportIcao = s.airportIcao.toUpperCase();
  const airportIata = s.airportIata.toUpperCase();

  // Iterate UTC calendar days covering the requested Pacific range (extend by one
  // UTC day on each side so flights near the Pacific midnight boundary are included).
  const start = new Date(`${opts.fromDate}T00:00:00Z`);
  start.setUTCDate(start.getUTCDate() - 1);
  const end = new Date(`${opts.toDate}T00:00:00Z`);
  end.setUTCDate(end.getUTCDate() + 1);

  const existing = await db.select().from(flightMovementsTable);
  const existingKey = new Set(
    existing.map((f) => `${f.flightNumber}|${f.direction}|${ylwDayOf(f.scheduledTime)}`),
  );
  const existingById = new Map(
    existing.map((f) => [`${f.flightNumber}|${f.direction}|${ylwDayOf(f.scheduledTime)}`, f]),
  );

  let daysQueried = 0, rowsSeen = 0, inserted = 0, updated = 0, skipped = 0, nonCommercial = 0;
  const errors: string[] = [];
  const seenThisRun = new Set<string>();

  for (let d = new Date(start); d <= end; d.setUTCDate(d.getUTCDate() + 1)) {
    const dayStr = d.toISOString().slice(0, 10);
    const fromISO = `${dayStr}T00:00:00`;
    const toISO = `${dayStr}T23:59:59`;
    const t0 = Date.now();
    const resp = await fetchFr24FlightSummary(fr24Key, airportIcao, fromISO, toISO);
    daysQueried++;
    await logFr24Call({
      endpoint: "/api/flight-summary/full", purpose: "backfill", success: resp.ok,
      httpStatus: resp.status, estimatedCredits: resp.rows.length, responseTimeMs: Date.now() - t0,
      meta: { day: dayStr, rows: resp.rows.length },
    });
    if (!resp.ok) {
      errors.push(`${dayStr}: ${resp.error ?? "request failed"}`);
      continue;
    }
    rowsSeen += resp.rows.length;

    for (const r of resp.rows) {
      const m = summaryRowToMovement(r, airportIcao, airportIata);
      if (!m) { nonCommercial++; continue; }
      const ylwDay = ylwDayOf(m.scheduledTime);
      // Only backfill into the requested Pacific window.
      if (ylwDay < opts.fromDate || ylwDay > opts.toDate) { skipped++; continue; }
      const key = `${m.flightNumber}|${m.direction}|${ylwDay}`;
      if (seenThisRun.has(key)) { skipped++; continue; }
      seenThisRun.add(key);

      const prior = existingById.get(key);
      if (prior) {
        // Don't clobber authoritative same-source data (YLW feed / live FR24 / manual);
        // only refresh rows we previously backfilled.
        if (prior.dataSource === "FR24_HISTORIC") {
          await db.update(flightMovementsTable).set({
            actualTime: m.actualTime, status: m.status,
            tailNumber: m.tailNumber ?? prior.tailNumber, aircraftType: m.aircraftType ?? prior.aircraftType,
            fr24Seen: true, fr24LastSeenAt: new Date().toISOString(), updatedAt: new Date(),
          }).where(eq(flightMovementsTable.id, prior.id));
          updated++;
        } else {
          skipped++;
        }
        continue;
      }
      if (existingKey.has(key)) { skipped++; continue; }
      await db.insert(flightMovementsTable).values({
        id: randomUUID(),
        flightNumber: m.flightNumber, airline: m.airline, airlineIata: m.airlineIata,
        direction: m.direction, origin: m.origin, destination: m.destination,
        scheduledTime: m.scheduledTime, estimatedTime: null, actualTime: m.actualTime,
        tailNumber: m.tailNumber, aircraftType: m.aircraftType, status: m.status,
        dataSource: "FR24_HISTORIC", fr24Seen: true, fr24LastSeenAt: new Date().toISOString(),
        dataQualityScore: 80, delayMinutes: null,
      });
      inserted++;
    }
  }

  const ok = errors.length === 0 || inserted + updated > 0;
  return {
    mode: ok ? "live" : "failed",
    message: ok
      ? `FR24 historical backfill complete — ${inserted} inserted, ${updated} updated across ${opts.fromDate} → ${opts.toDate} (${rowsSeen} legs seen, ${nonCommercial} non-commercial skipped).`
      : `FR24 backfill failed: ${errors.slice(0, 3).join("; ")}`,
    daysQueried, rowsSeen, inserted, updated, skipped, nonCommercial,
    errors: errors.length ? errors.slice(0, 10) : undefined,
  };
}

router.post("/fr24/backfill", async (req, res) => {
  if (fr24BackfillInFlight) {
    return res.status(409).json({ mode: "busy", message: "An FR24 backfill is already in progress." });
  }
  const body = (req.body ?? {}) as { from?: string; to?: string; days?: number };
  // Reject malformed AND impossible calendar dates (e.g. 2026-99-99) up front.
  const isValidYmd = (s: string): boolean => {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
    const d = new Date(`${s}T00:00:00Z`);
    return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === s;
  };
  if (body.from !== undefined && !isValidYmd(body.from)) {
    return res.status(400).json({ mode: "failed", message: `Invalid "from" date: ${body.from} (expected a real YYYY-MM-DD).` });
  }
  if (body.to !== undefined && !isValidYmd(body.to)) {
    return res.status(400).json({ mode: "failed", message: `Invalid "to" date: ${body.to} (expected a real YYYY-MM-DD).` });
  }

  const todayYlw = new Intl.DateTimeFormat("en-CA", { timeZone: "America/Vancouver" }).format(new Date());
  let toDate = body.to ?? todayYlw;
  let fromDate: string;
  if (body.from) {
    fromDate = body.from;
  } else {
    const days = Math.min(Math.max(Number(body.days) || 30, 1), 90);
    const dt = new Date(`${toDate}T12:00:00Z`);
    dt.setUTCDate(dt.getUTCDate() - (days - 1));
    fromDate = dt.toISOString().slice(0, 10);
  }
  if (fromDate > toDate) [fromDate, toDate] = [toDate, fromDate];
  // Cap the inclusive span to 90 days to bound credit usage.
  const diffDays = (new Date(`${toDate}T00:00:00Z`).getTime() - new Date(`${fromDate}T00:00:00Z`).getTime()) / 86400000;
  const inclusiveDays = diffDays + 1;
  if (inclusiveDays > 90) {
    const dt = new Date(`${toDate}T12:00:00Z`);
    dt.setUTCDate(dt.getUTCDate() - 89);
    fromDate = dt.toISOString().slice(0, 10);
  }

  fr24BackfillInFlight = true;
  try {
    const result = await runFr24Backfill({ fromDate, toDate });
    if (result.mode === "failed") return res.status(502).json(result);
    return res.json(result);
  } catch (err) {
    req.log.error({ err }, "FR24 backfill crashed");
    return res.status(500).json({ mode: "failed", message: err instanceof Error ? err.message : "Backfill crashed" });
  } finally {
    fr24BackfillInFlight = false;
  }
});

function withinOperatingHours(startHHMM: string, endHHMM: string, tz = "America/Vancouver"): boolean {
  const now = new Date();
  const hhmm = new Intl.DateTimeFormat("en-CA", { timeZone: tz, hour: "2-digit", minute: "2-digit", hour12: false }).format(now);
  const [h, m] = hhmm.split(":").map(Number);
  const cur = h * 60 + m;
  const [sh, sm] = startHHMM.split(":").map(Number);
  const [eh, em] = endHHMM.split(":").map(Number);
  const start = sh * 60 + sm;
  const end = eh * 60 + em;
  return cur >= start && cur <= end;
}

async function runFr24SyncGuarded(): Promise<void> {
  if (fr24SyncInFlight) return;
  fr24SyncInFlight = true;
  try {
    const s = await getSettings();
    if (!withinOperatingHours(s.fr24OperatingHoursStart ?? "06:00", s.fr24OperatingHoursEnd ?? "23:00")) return;
    const res = await runFr24Sync({ trigger: "scheduler" });
    if (res.mode === "live") {
      logger.info({ aircraft: res.aircraftInResponse, updated: res.eventsGenerated, fields: res.fieldsWritten }, "FR24 scheduled sync");
    } else if (res.mode === "failed") {
      logger.warn({ msg: res.message }, "FR24 scheduled sync failed");
    }
  } catch (err) {
    logger.error({ err }, "FR24 scheduler crashed");
  } finally {
    fr24SyncInFlight = false;
  }
}

export function startFr24Scheduler(): void {
  if (fr24SchedulerTimer) return;
  // Initial run on boot (do not block app startup)
  setTimeout(() => void runFr24SyncGuarded(), 15_000);
  // Poll every pollingIntervalSeconds from settings; recheck the value on each tick
  fr24SchedulerTimer = setInterval(async () => {
    try {
      const s = await getSettings();
      const intervalSec = Math.max(45, s.fr24PollingIntervalSeconds ?? 60);
      const elapsed = (Date.now() - (s.fr24LastSyncAt?.getTime() ?? 0)) / 1000;
      if (elapsed >= intervalSec) void runFr24SyncGuarded();
    } catch { /* ignore */ }
  }, 30_000);
}

// ── FR24 usage / credit tracking routes ──────────────────────────────────────

router.get("/fr24/usage/summary", async (_req, res) => {
  const [settings, logs] = await Promise.all([
    getSettings(),
    db.select().from(fr24UsageLogTable).orderBy(desc(fr24UsageLogTable.calledAt)),
  ]);
  const startingCredits = settings.fr24StartingCredits ?? 1210000;
  const totalUsed = logs.reduce((sum, l) => sum + (l.estimatedCredits ?? 0), 0);
  const remaining = startingCredits - totalUsed;
  const dailyWarning = settings.fr24DailyWarningThreshold ?? 50000;
  const remainingWarning = settings.fr24RemainingWarningThreshold ?? 100000;

  const todayStr = new Date().toISOString().slice(0, 10);
  const todayLogs = logs.filter((l) => l.calledAt.toISOString().slice(0, 10) === todayStr);
  const todayUsed = todayLogs.reduce((sum, l) => sum + (l.estimatedCredits ?? 0), 0);

  const successCount = logs.filter((l) => l.success).length;
  const failCount = logs.filter((l) => !l.success).length;

  res.json({
    startingCredits,
    totalUsed,
    remaining,
    remainingPct: startingCredits > 0 ? Math.round((remaining / startingCredits) * 1000) / 10 : 0,
    todayUsed,
    totalCalls: logs.length,
    successCount,
    failCount,
    warnings: {
      dailyExceeded: todayUsed >= dailyWarning,
      remainingLow: remaining <= remainingWarning,
      dailyWarningThreshold: dailyWarning,
      remainingWarningThreshold: remainingWarning,
    },
  });
});

router.get("/fr24/usage/daily", async (req, res) => {
  const days = Math.min(90, Math.max(1, parseInt(String(req.query.days ?? "30"), 10)));
  const since = new Date();
  since.setDate(since.getDate() - days);

  const logs = await db.select().from(fr24UsageLogTable)
    .where(gte(fr24UsageLogTable.calledAt, since))
    .orderBy(desc(fr24UsageLogTable.calledAt));

  const byDay: Record<string, { date: string; calls: number; credits: number; successes: number; failures: number; endpoints: Record<string, number> }> = {};
  for (const l of logs) {
    const d = l.calledAt.toISOString().slice(0, 10);
    if (!byDay[d]) byDay[d] = { date: d, calls: 0, credits: 0, successes: 0, failures: 0, endpoints: {} };
    byDay[d].calls++;
    byDay[d].credits += l.estimatedCredits ?? 0;
    if (l.success) byDay[d].successes++; else byDay[d].failures++;
    const ep = l.endpoint.split("?")[0];
    byDay[d].endpoints[ep] = (byDay[d].endpoints[ep] ?? 0) + (l.estimatedCredits ?? 0);
  }

  const rows = Object.values(byDay).sort((a, b) => b.date.localeCompare(a.date));
  res.json({ days, rows, totalRows: rows.length });
});

router.get("/fr24/usage/log", async (req, res) => {
  const limit = Math.min(500, Math.max(1, parseInt(String(req.query.limit ?? "100"), 10)));
  const offset = Math.max(0, parseInt(String(req.query.offset ?? "0"), 10));
  const logs = await db.select().from(fr24UsageLogTable)
    .orderBy(desc(fr24UsageLogTable.calledAt))
    .limit(limit)
    .offset(offset);
  const [{ count }] = await db.select({ count: sql<number>`count(*)` }).from(fr24UsageLogTable);
  res.json({ logs, total: Number(count), limit, offset });
});

router.get("/fr24/usage/export", async (_req, res) => {
  const logs = await db.select().from(fr24UsageLogTable).orderBy(desc(fr24UsageLogTable.calledAt));
  const lines = ["timestamp,endpoint,purpose,success,http_status,estimated_credits,response_time_ms,error_message"];
  for (const l of logs) {
    lines.push([
      l.calledAt.toISOString(),
      `"${l.endpoint}"`,
      `"${l.purpose}"`,
      l.success ? "1" : "0",
      l.httpStatus ?? "",
      l.estimatedCredits ?? 0,
      l.responseTimeMs ?? "",
      l.errorMessage ? `"${l.errorMessage.replace(/"/g, "'")}"` : "",
    ].join(","));
  }
  res.setHeader("Content-Type", "text/csv");
  res.setHeader("Content-Disposition", `attachment; filename="fr24-usage-${new Date().toISOString().slice(0, 10)}.csv"`);
  res.send(lines.join("\n"));
});

router.post("/fr24/usage/reset-balance", async (req, res) => {
  const raw = req.body as Record<string, unknown>;
  const startingCredits = typeof raw.startingCredits === "number" ? Math.max(0, Math.round(raw.startingCredits)) : 1210000;
  const dailyWarning = typeof raw.dailyWarningThreshold === "number" ? raw.dailyWarningThreshold : undefined;
  const remainingWarning = typeof raw.remainingWarningThreshold === "number" ? raw.remainingWarningThreshold : undefined;

  const update: Record<string, unknown> = { fr24StartingCredits: startingCredits, updatedAt: new Date() };
  if (dailyWarning !== undefined) update.fr24DailyWarningThreshold = dailyWarning;
  if (remainingWarning !== undefined) update.fr24RemainingWarningThreshold = remainingWarning;

  await db.update(appSettingsTable).set(update).where(eq(appSettingsTable.id, "singleton"));
  res.json({ ok: true, startingCredits });
});

// ── ADS-B helpers ───────────────────────────────────────────────────────────

function generateSyncId() {
  return `sync_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

function inferStatus(altBaro: number | null, groundSpeed: number | null, distanceNm: number | null): string {
  if (altBaro === null) return "UNKNOWN";
  if (altBaro > 3000) return "AIRBORNE";
  if (altBaro <= 50 && (groundSpeed ?? 0) < 30) return "ON_GROUND";
  if (altBaro <= 2500 && (groundSpeed ?? 0) > 60 && distanceNm !== null && distanceNm < 15) return "LANDING";
  if (altBaro <= 2500 && (groundSpeed ?? 0) > 60 && distanceNm !== null && distanceNm < 15) return "DEPARTING";
  if ((groundSpeed ?? 0) < 30) return "TAXIING";
  return "AIRBORNE";
}

function bearingDirection(lat1: number, lon1: number, lat2: number, lon2: number): string {
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const lat1R = (lat1 * Math.PI) / 180;
  const lat2R = (lat2 * Math.PI) / 180;
  const y = Math.sin(dLon) * Math.cos(lat2R);
  const x = Math.cos(lat1R) * Math.sin(lat2R) - Math.sin(lat1R) * Math.cos(lat2R) * Math.cos(dLon);
  const bearing = ((Math.atan2(y, x) * 180) / Math.PI + 360) % 360;
  const dirs = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
  return dirs[Math.round(bearing / 45) % 8];
}

async function getAdsbSettings() {
  let [s] = await db.select().from(appSettingsTable).where(eq(appSettingsTable.id, "singleton"));
  if (!s) {
    await db.insert(appSettingsTable).values({ id: "singleton" });
    [s] = await db.select().from(appSettingsTable).where(eq(appSettingsTable.id, "singleton"));
  }
  return s;
}

function adsbStatusSummary(s: Awaited<ReturnType<typeof getAdsbSettings>>) {
  const envKey = process.env.ADSBX_API_KEY?.trim() ?? process.env.ADSB_API_KEY?.trim();
  const hasKey = !!(s.adsbxApiKey || envKey);
  return {
    configured: hasKey,
    keySource: s.adsbxApiKey ? "db" : envKey ? "env" : "none",
    provider: s.adsbxProvider ?? "adsbexchange",
    connectionStatus: (s.adsbxConnectionStatus ?? "demo") as "demo" | "configured" | "live" | "failed",
    lastSyncAt: s.adsbxLastSyncAt?.toISOString() ?? null,
    lastSyncStatus: s.adsbxLastSyncStatus ?? null,
    lastSyncCount: s.adsbxLastSyncCount ?? null,
    airportIata: s.airportIata,
    airportIcao: s.airportIcao,
    lat: parseFloat(s.adsbxLat ?? "49.9561"),
    lon: parseFloat(s.adsbxLon ?? "-119.3778"),
    radiusNm: s.adsbxRadiusNm ?? 25,
    pollingIntervalSeconds: s.adsbxPollingIntervalSeconds ?? 60,
    globeUrl: `https://globe.adsbexchange.com/?airport=${(s.airportIcao ?? "CYLW").toLowerCase()}`,
    productionApiTemplate: "GET https://adsbexchange-com1.p.rapidapi.com/v2/lat/{lat}/lon/{lon}/dist/{radius}/",
  };
}

// Build demo ADS-B observation set from current flight movements
async function buildDemoObservations(s: Awaited<ReturnType<typeof getAdsbSettings>>, syncId: string) {
  const lat = parseFloat(s.adsbxLat ?? "49.9561");
  const lon = parseFloat(s.adsbxLon ?? "-119.3778");
  const radiusNm = s.adsbxRadiusNm ?? 25;
  const flights = await db.select().from(flightMovementsTable);

  const knownHex: Record<string, { hex: string; reg: string; type: string }> = {
    "WS525":  { hex: "c07aee", reg: "C-GWCM", type: "B737" },
    "AC8268": { hex: "c02a31", reg: "C-GGNY", type: "DH8D" },
    "WS181":  { hex: "c07b22", reg: "C-GWBF", type: "B737" },
    "AC8391": { hex: "c04f89", reg: "C-FGDP", type: "B738" },
    "8P691":  { hex: "c0c3de", reg: "C-GPCL", type: "PC12" },
    "AC8819": { hex: "c04f89", reg: "C-FGDP", type: "B738" },
    "WS3305": { hex: "c07bee", reg: "C-FWSL", type: "B737" },
  };

  // Extra unmatched demo aircraft (won't match any scheduled flight)
  const extraAircraft = [
    { callsign: "C-FXYZ", hex: "c09abc", reg: "C-FXYZ", type: "C172", altBaro: 4500, speed: 110, track: 230 },
    { callsign: "CGF221", hex: "c0def1", reg: "C-GCGF", type: "BE20", altBaro: 18000, speed: 280, track: 145 },
  ];

  const observations: typeof adsbObservationsTable.$inferInsert[] = [];
  const rand = seededRand(Date.now() % 10000);

  const activeFlights = flights
    .filter((f) => ["AIRBORNE", "ESTIMATED", "SCHEDULED", "LANDED", "ON_BLOCK"].includes(f.status))
    .slice(0, 7);

  for (let i = 0; i < activeFlights.length; i++) {
    const f = activeFlights[i];
    const r = seededRand(i + 50);
    const angle = r() * 2 * Math.PI;
    const dist = r() * radiusNm * 0.6;
    const acLat = lat + (dist / 60) * Math.cos(angle);
    const acLon = lon + (dist / (60 * Math.cos((lat * Math.PI) / 180))) * Math.sin(angle);
    const known = knownHex[f.flightNumber.trim()] ?? { hex: `c0${Math.floor(rand() * 0xffff).toString(16).padStart(4, "0")}`, reg: f.tailNumber ?? `C-F${String.fromCharCode(65 + i)}BC`, type: f.aircraftType ?? "B737" };
    const altBaro = f.status === "ON_BLOCK" || f.status === "LANDED" ? Math.floor(rand() * 50) : Math.floor(1000 + rand() * 30000);
    const speed = altBaro < 100 ? Math.floor(rand() * 25) : Math.floor(150 + rand() * 350);
    const distNm = distanceNm(lat, lon, acLat, acLon);

    observations.push({
      syncId,
      icaoHex: known.hex,
      callsign: f.flightNumber.trim(),
      registration: known.reg,
      aircraftType: known.type,
      altBaro,
      altGeom: altBaro + Math.floor(rand() * 200),
      groundSpeed: speed,
      track: Math.floor(rand() * 360),
      verticalRate: altBaro < 100 ? 0 : (rand() > 0.5 ? Math.floor(rand() * 2000) : -Math.floor(rand() * 2000)),
      squawk: `${Math.floor(1000 + rand() * 6999)}`,
      lat: acLat,
      lon: acLon,
      distanceNm: distNm,
      directionFromAirport: bearingDirection(lat, lon, acLat, acLon),
      airportContext: "CYLW",
      lastSeenTs: new Date(Date.now() - Math.floor(rand() * 30000)),
      inferredStatus: inferStatus(altBaro, speed, distNm),
      source: "demo",
      rawPayload: { hex: known.hex, flight: f.flightNumber.trim(), r: known.reg, t: known.type, alt_baro: altBaro, gs: speed },
    });
  }

  // Add extra unmatched aircraft
  for (const ex of extraAircraft) {
    const angle = rand() * 2 * Math.PI;
    const dist = (5 + rand() * 20);
    const acLat = lat + (dist / 60) * Math.cos(angle);
    const acLon = lon + (dist / (60 * Math.cos((lat * Math.PI) / 180))) * Math.sin(angle);
    const distNm2 = distanceNm(lat, lon, acLat, acLon);
    observations.push({
      syncId,
      icaoHex: ex.hex,
      callsign: ex.callsign,
      registration: ex.reg,
      aircraftType: ex.type,
      altBaro: ex.altBaro,
      altGeom: ex.altBaro + 150,
      groundSpeed: ex.speed,
      track: ex.track,
      verticalRate: ex.altBaro > 500 ? Math.floor(rand() * 1500) : 0,
      squawk: `${Math.floor(1000 + rand() * 6999)}`,
      lat: acLat,
      lon: acLon,
      distanceNm: distNm2,
      directionFromAirport: bearingDirection(lat, lon, acLat, acLon),
      airportContext: "CYLW",
      lastSeenTs: new Date(Date.now() - Math.floor(rand() * 60000)),
      inferredStatus: inferStatus(ex.altBaro, ex.speed, distNm2),
      source: "demo",
      rawPayload: { hex: ex.hex, flight: ex.callsign, r: ex.reg, t: ex.type },
    });
  }

  return observations;
}

// Match observations to flight movements
async function matchObservations(observations: typeof adsbObservationsTable.$inferSelect[]) {
  const flights = await db.select().from(flightMovementsTable);
  const matches: typeof adsbMatchesTable.$inferInsert[] = [];

  for (const obs of observations) {
    let bestFlight: typeof flightMovementsTable.$inferSelect | null = null;
    let matchType: "exact" | "probable" | "possible" | "unmatched" = "unmatched";
    let matchScore = 0;
    const reasons: string[] = [];
    let callsignMatch = false;
    let timeWindowMatch = false;
    let proximityMatch = false;
    let airlineMatch = false;

    const callsign = (obs.callsign ?? "").trim().replace(/\s+/g, "");

    // Exact callsign match
    if (callsign) {
      const exact = flights.find((f) => f.flightNumber.trim() === callsign);
      if (exact) {
        bestFlight = exact;
        callsignMatch = true;
        matchScore = 95;
        matchType = "exact";
        reasons.push("Callsign exactly matches flight number");
      }
    }

    // Airline prefix match (e.g. "WS" from "WS525")
    if (!bestFlight && callsign.length >= 2) {
      const airlinePrefix = callsign.replace(/[0-9]+$/, "");
      if (airlinePrefix.length >= 2) {
        const airlineFlights = flights.filter((f) => f.flightNumber.trim().startsWith(airlinePrefix));
        if (airlineFlights.length === 1) {
          bestFlight = airlineFlights[0];
          airlineMatch = true;
          matchScore = 55;
          matchType = "possible";
          reasons.push(`Airline prefix "${airlinePrefix}" matches one flight`);
        } else if (airlineFlights.length > 1) {
          // Pick closest by proximity if available
          airlineMatch = true;
          matchScore = 40;
          matchType = "possible";
          reasons.push(`Airline prefix "${airlinePrefix}" matches ${airlineFlights.length} flights — ambiguous`);
          bestFlight = airlineFlights[0];
        }
      }
    }

    // Proximity bonus
    if (obs.distanceNm !== null && obs.distanceNm < 5) {
      proximityMatch = true;
      matchScore = Math.min(100, matchScore + 10);
      reasons.push(`Aircraft is ${obs.distanceNm.toFixed(1)} nm from airport`);
    }

    // Status bonus
    if (obs.inferredStatus && bestFlight) {
      if ((obs.inferredStatus === "LANDING" && bestFlight.direction === "ARR") ||
          (obs.inferredStatus === "DEPARTING" && bestFlight.direction === "DEP")) {
        matchScore = Math.min(100, matchScore + 5);
        reasons.push("Inferred direction matches flight direction");
      }
    }

    // Final type classification
    if (matchScore >= 90) matchType = "exact";
    else if (matchScore >= 65) matchType = "probable";
    else if (matchScore >= 35) matchType = "possible";
    else matchType = "unmatched";

    matches.push({
      observationId: obs.id,
      flightMovementId: bestFlight?.id ?? null,
      matchType,
      matchScore,
      matchReasons: reasons,
      callsignMatch,
      timeWindowMatch,
      proximityMatch,
      airlineMatch,
      manualReview: matchType === "unmatched",
    });
  }

  return matches;
}

// ── ADS-B routes ─────────────────────────────────────────────────────────────

router.get("/adsb/status", async (_req, res) => {
  const s = await getAdsbSettings();
  return res.json(adsbStatusSummary(s));
});

router.post("/adsb/configure", async (req, res) => {
  const raw = req.body as Record<string, unknown>;
  await getAdsbSettings();

  const update: Record<string, unknown> = { updatedAt: new Date() };
  if (typeof raw.apiKey === "string" && raw.apiKey.length >= 4) {
    update.adsbxApiKey = raw.apiKey;
    update.adsbxConnectionStatus = "configured";
  }
  if (typeof raw.provider === "string") update.adsbxProvider = raw.provider;
  if (typeof raw.radiusNm === "number") update.adsbxRadiusNm = Math.max(5, Math.min(250, raw.radiusNm));
  if (typeof raw.lat === "string" && raw.lat) update.adsbxLat = raw.lat;
  if (typeof raw.lon === "string" && raw.lon) update.adsbxLon = raw.lon;
  if (typeof raw.pollingIntervalSeconds === "number") update.adsbxPollingIntervalSeconds = Math.max(10, Math.min(3600, raw.pollingIntervalSeconds));

  await db.update(appSettingsTable).set(update).where(eq(appSettingsTable.id, "singleton"));
  const s = await getAdsbSettings();
  return res.json({ saved: true, ...adsbStatusSummary(s) });
});

router.post("/adsb/test-connection", async (_req, res) => {
  const s = await getAdsbSettings();
  const envKey = process.env.ADSBX_API_KEY?.trim() ?? process.env.ADSB_API_KEY?.trim();
  const apiKey = s.adsbxApiKey || envKey;

  if (!apiKey) {
    return res.json({
      success: false,
      mode: "demo",
      message: "No ADS-B API key configured. Running in demo mode with simulated observations.",
      hint: "Add your ADS-B Exchange RapidAPI key via the Configure form to enable live data.",
    });
  }

  // Attempt live call: ADS-B Exchange via RapidAPI
  try {
    const lat = s.adsbxLat ?? "49.9561";
    const lon = s.adsbxLon ?? "-119.3778";
    const dist = s.adsbxRadiusNm ?? 25;
    const url = `https://adsbexchange-com1.p.rapidapi.com/v2/lat/${lat}/lon/${lon}/dist/${dist}/`;
    const resp = await fetch(url, {
      headers: {
        "X-RapidAPI-Key": apiKey,
        "X-RapidAPI-Host": "adsbexchange-com1.p.rapidapi.com",
      },
      signal: AbortSignal.timeout(8000),
    });
    if (!resp.ok) {
      const body = await resp.text().catch(() => "");
      let hint = "Verify your ADS-B Exchange RapidAPI key and subscription.";
      if (resp.status === 401 || resp.status === 403) hint = "Key rejected — check your RapidAPI key and that the ADS-B Exchange API is subscribed.";
      if (resp.status === 402) hint = "Key valid but no active RapidAPI subscription for ADS-B Exchange.";
      await db.update(appSettingsTable).set({ adsbxConnectionStatus: "failed", updatedAt: new Date() }).where(eq(appSettingsTable.id, "singleton"));
      return res.json({ success: false, mode: "failed", message: `ADS-B API returned HTTP ${resp.status}: ${body.slice(0, 100)}`, httpStatus: resp.status, hint });
    }
    const data = await resp.json() as Record<string, unknown>;
    const acList = (data.ac ?? data.aircraft ?? data.result ?? []) as unknown[];
    await db.update(appSettingsTable).set({ adsbxConnectionStatus: "live", updatedAt: new Date() }).where(eq(appSettingsTable.id, "singleton"));
    return res.json({ success: true, mode: "live", message: `ADS-B connection successful — ${Array.isArray(acList) ? acList.length : "?"} aircraft returned near ${s.airportIcao}.`, aircraftCount: Array.isArray(acList) ? acList.length : null });
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Unknown error";
    await db.update(appSettingsTable).set({ adsbxConnectionStatus: "failed", updatedAt: new Date() }).where(eq(appSettingsTable.id, "singleton"));
    return res.json({ success: false, mode: "failed", message: `ADS-B connection error: ${msg}`, httpStatus: 0, hint: "Network/timeout error. Check API endpoint and key." });
  }
});

router.post("/adsb/sync", async (_req, res) => {
  const s = await getAdsbSettings();
  const envKey = process.env.ADSBX_API_KEY?.trim() ?? process.env.ADSB_API_KEY?.trim();
  const apiKey = s.adsbxApiKey || envKey;
  const syncId = generateSyncId();

  let observationsToInsert: typeof adsbObservationsTable.$inferInsert[];
  let mode: "live" | "demo" = "demo";

  if (apiKey) {
    try {
      const lat = s.adsbxLat ?? "49.9561";
      const lon = s.adsbxLon ?? "-119.3778";
      const dist = s.adsbxRadiusNm ?? 25;
      const url = `https://adsbexchange-com1.p.rapidapi.com/v2/lat/${lat}/lon/${lon}/dist/${dist}/`;
      const resp = await fetch(url, {
        headers: { "X-RapidAPI-Key": apiKey, "X-RapidAPI-Host": "adsbexchange-com1.p.rapidapi.com" },
        signal: AbortSignal.timeout(10000),
      });
      if (resp.ok) {
        const data = await resp.json() as Record<string, unknown>;
        const acList = (data.ac ?? data.aircraft ?? []) as Record<string, unknown>[];
        const cylwLat = parseFloat(lat);
        const cylwLon = parseFloat(lon);
        observationsToInsert = acList.map((ac) => {
          const acLat = typeof ac.lat === "number" ? ac.lat : null;
          const acLon = typeof ac.lon === "number" ? ac.lon : null;
          const altBaro = typeof ac.alt_baro === "number" ? ac.alt_baro : null;
          const speed = typeof ac.gs === "number" ? ac.gs : null;
          const distNm = acLat !== null && acLon !== null ? distanceNm(cylwLat, cylwLon, acLat, acLon) : null;
          return {
            syncId,
            icaoHex: String(ac.hex ?? ""),
            callsign: ac.flight ? String(ac.flight).trim().replace(/\s+/g, "") : null,
            registration: ac.r ? String(ac.r) : null,
            aircraftType: ac.t ? String(ac.t) : null,
            altBaro,
            altGeom: typeof ac.alt_geom === "number" ? ac.alt_geom : null,
            groundSpeed: speed,
            track: typeof ac.track === "number" ? ac.track : null,
            verticalRate: typeof ac.baro_rate === "number" ? ac.baro_rate : null,
            squawk: ac.squawk ? String(ac.squawk) : null,
            lat: acLat,
            lon: acLon,
            distanceNm: distNm,
            directionFromAirport: acLat !== null && acLon !== null ? bearingDirection(cylwLat, cylwLon, acLat, acLon) : null,
            airportContext: s.airportIcao ?? "CYLW",
            lastSeenTs: new Date(Date.now() - (typeof ac.seen === "number" ? ac.seen * 1000 : 0)),
            inferredStatus: inferStatus(altBaro, speed, distNm),
            source: "adsbexchange",
            rawPayload: ac,
          };
        });
        mode = "live";
      } else {
        observationsToInsert = await buildDemoObservations(s, syncId);
      }
    } catch {
      observationsToInsert = await buildDemoObservations(s, syncId);
    }
  } else {
    observationsToInsert = await buildDemoObservations(s, syncId);
  }

  // Insert observations
  const inserted = await db.insert(adsbObservationsTable).values(observationsToInsert).returning();

  // Run matching
  const matchRecords = await matchObservations(inserted);
  if (matchRecords.length > 0) {
    await db.insert(adsbMatchesTable).values(matchRecords);
  }

  const matchedCount = matchRecords.filter((m) => m.matchType !== "unmatched").length;
  const unmatchedCount = matchRecords.filter((m) => m.matchType === "unmatched").length;

  await db.update(appSettingsTable).set({
    adsbxLastSyncAt: new Date(),
    adsbxLastSyncStatus: mode,
    adsbxLastSyncCount: inserted.length,
    adsbxConnectionStatus: mode,
    updatedAt: new Date(),
  }).where(eq(appSettingsTable.id, "singleton"));

  return res.json({
    mode,
    syncId,
    aircraftObserved: inserted.length,
    matched: matchedCount,
    unmatched: unmatchedCount,
    message: `ADS-B ${mode} sync complete — ${inserted.length} aircraft observed, ${matchedCount} matched to movements, ${unmatchedCount} unmatched.`,
    syncedAt: new Date().toISOString(),
  });
});

router.get("/adsb/aircraft-nearby", async (req, res) => {
  const s = await getAdsbSettings();
  const limit = Math.min(parseInt(String(req.query["limit"] ?? "100"), 10), 500);
  const commercialOnly = req.query["commercial_only"] !== "false";

  // Get latest sync_id to show only most recent sync's aircraft
  const latestSync = await db.select({ syncId: adsbObservationsTable.syncId })
    .from(adsbObservationsTable)
    .orderBy(desc(adsbObservationsTable.createdAt))
    .limit(1);

  const latestSyncId = latestSync[0]?.syncId ?? null;

  let observations = latestSyncId
    ? await db.select().from(adsbObservationsTable)
        .where(eq(adsbObservationsTable.syncId, latestSyncId))
        .orderBy(desc(adsbObservationsTable.createdAt))
        .limit(limit)
    : await db.select().from(adsbObservationsTable)
        .orderBy(desc(adsbObservationsTable.createdAt))
        .limit(limit);

  // Get matches for these observations
  const obsIds = observations.map((o) => o.id);
  const allMatches = obsIds.length > 0
    ? await db.select().from(adsbMatchesTable)
    : [];

  const matchMap = new Map<number, typeof adsbMatchesTable.$inferSelect>();
  for (const m of allMatches) {
    if (!matchMap.has(m.observationId)) matchMap.set(m.observationId, m);
  }

  // Get matched flight numbers
  const matchedFlightIds = allMatches.map((m) => m.flightMovementId).filter(Boolean) as string[];
  const flights = matchedFlightIds.length > 0
    ? await db.select().from(flightMovementsTable)
    : [];
  const flightMap = new Map<string, typeof flightMovementsTable.$inferSelect>();
  for (const f of flights) flightMap.set(f.id, f);

  let result = observations.map((obs) => {
    const match = matchMap.get(obs.id);
    const flight = match?.flightMovementId ? flightMap.get(match.flightMovementId) : null;
    return {
      id: obs.id,
      syncId: obs.syncId,
      icaoHex: obs.icaoHex,
      callsign: obs.callsign,
      registration: obs.registration,
      aircraftType: obs.aircraftType,
      altBaro: obs.altBaro,
      groundSpeed: obs.groundSpeed,
      track: obs.track,
      verticalRate: obs.verticalRate,
      squawk: obs.squawk,
      lat: obs.lat,
      lon: obs.lon,
      distanceNm: obs.distanceNm,
      directionFromAirport: obs.directionFromAirport,
      lastSeenTs: obs.lastSeenTs,
      inferredStatus: obs.inferredStatus,
      source: obs.source,
      matchType: match?.matchType ?? "unmatched",
      matchScore: match?.matchScore ?? 0,
      matchedFlightNumber: flight?.flightNumber ?? null,
      matchedFlightId: flight?.id ?? null,
      matchedAirline: flight?.airline ?? null,
      matchedDirection: flight?.direction ?? null,
      seenSecondsAgo: obs.lastSeenTs ? Math.round((Date.now() - obs.lastSeenTs.getTime()) / 1000) : null,
    };
  });

  if (commercialOnly) {
    result = result.filter((r) => {
      if (r.matchType !== "unmatched") return true;
      const cs = (r.callsign ?? "").trim();
      if (!cs || cs.length < 3) return false;
      const prefix = cs.replace(/[0-9]+$/, "");
      return isCommercial({ airlineIata: prefix, flightNumber: cs, aircraftType: r.aircraftType ?? undefined });
    });
  }

  return res.json({
    aircraft: result,
    total: result.length,
    matched: result.filter((r) => r.matchType !== "unmatched").length,
    unmatched: result.filter((r) => r.matchType === "unmatched").length,
    airportIcao: s.airportIcao,
    airportLat: parseFloat(s.adsbxLat ?? "49.9561"),
    airportLon: parseFloat(s.adsbxLon ?? "-119.3778"),
    syncId: latestSyncId,
    source: s.adsbxConnectionStatus ?? "demo",
  });
});

router.get("/adsb/unmatched", async (_req, res) => {
  // Get recent unmatched observations
  const recent = await db.select()
    .from(adsbObservationsTable)
    .orderBy(desc(adsbObservationsTable.createdAt))
    .limit(100);

  const obsIds = recent.map((o) => o.id);
  const allMatches = obsIds.length > 0
    ? await db.select().from(adsbMatchesTable)
    : [];

  const unmatchedMatchIds = new Set(
    allMatches.filter((m) => m.matchType === "unmatched").map((m) => m.observationId)
  );

  const matchedIds = new Set(
    allMatches.filter((m) => m.matchType !== "unmatched").map((m) => m.observationId)
  );

  const unmatched = recent.filter((o) => unmatchedMatchIds.has(o.id) || (!matchedIds.has(o.id) && allMatches.some((m) => m.observationId === o.id)));

  return res.json({
    unmatched: unmatched.map((obs) => ({
      id: obs.id,
      syncId: obs.syncId,
      icaoHex: obs.icaoHex,
      callsign: obs.callsign,
      registration: obs.registration,
      aircraftType: obs.aircraftType,
      altBaro: obs.altBaro,
      groundSpeed: obs.groundSpeed,
      distanceNm: obs.distanceNm,
      inferredStatus: obs.inferredStatus,
      source: obs.source,
      lastSeenTs: obs.lastSeenTs,
      reviewReason: "No matching scheduled flight found",
    })),
    total: unmatched.length,
  });
});

router.get("/adsb/matches", async (_req, res) => {
  const matches = await db.select()
    .from(adsbMatchesTable)
    .orderBy(desc(adsbMatchesTable.createdAt))
    .limit(100);

  const obsIds = [...new Set(matches.map((m) => m.observationId))];
  const flightIds = [...new Set(matches.map((m) => m.flightMovementId).filter(Boolean))] as string[];

  const observations = obsIds.length > 0
    ? await db.select().from(adsbObservationsTable)
    : [];
  const flights = flightIds.length > 0
    ? await db.select().from(flightMovementsTable)
    : [];

  const obsMap = new Map<number, typeof adsbObservationsTable.$inferSelect>();
  for (const o of observations) obsMap.set(o.id, o);
  const flightMap = new Map<string, typeof flightMovementsTable.$inferSelect>();
  for (const f of flights) flightMap.set(f.id, f);

  return res.json({
    matches: matches.map((m) => {
      const obs = obsMap.get(m.observationId);
      const flight = m.flightMovementId ? flightMap.get(m.flightMovementId) : null;
      return {
        id: m.id,
        matchType: m.matchType,
        matchScore: m.matchScore,
        matchReasons: m.matchReasons,
        callsignMatch: m.callsignMatch,
        proximityMatch: m.proximityMatch,
        airlineMatch: m.airlineMatch,
        manualReview: m.manualReview,
        observation: obs ? { callsign: obs.callsign, icaoHex: obs.icaoHex, registration: obs.registration, aircraftType: obs.aircraftType, altBaro: obs.altBaro, distanceNm: obs.distanceNm, inferredStatus: obs.inferredStatus, source: obs.source } : null,
        flight: flight ? { flightNumber: flight.flightNumber, direction: flight.direction, airline: flight.airline, status: flight.status } : null,
      };
    }),
    total: matches.length,
    byType: {
      exact: matches.filter((m) => m.matchType === "exact").length,
      probable: matches.filter((m) => m.matchType === "probable").length,
      possible: matches.filter((m) => m.matchType === "possible").length,
      unmatched: matches.filter((m) => m.matchType === "unmatched").length,
    },
  });
});

// ── ADS-B Historical Analysis Routes ────────────────────────────────────────

router.get("/adsb/history/recent", async (req, res) => {
  const limit = Math.min(parseInt(String(req.query["limit"] ?? "100"), 10), 1000);
  const offset = Math.max(parseInt(String(req.query["offset"] ?? "0"), 10), 0);
  const icao = req.query["icao"] ? String(req.query["icao"]).toLowerCase() : null;
  const callsign = req.query["callsign"] ? String(req.query["callsign"]).toUpperCase() : null;
  const sourceFilter = req.query["source"] ? String(req.query["source"]) : null;
  const since = req.query["since"] ? new Date(String(req.query["since"])) : null;
  const until = req.query["until"] ? new Date(String(req.query["until"])) : null;

  let query = db.select().from(adsbObservationsTable).$dynamic();

  const conditions = [];
  if (icao) conditions.push(eq(adsbObservationsTable.icaoHex, icao));
  if (callsign) conditions.push(eq(adsbObservationsTable.callsign, callsign));
  if (sourceFilter && sourceFilter !== "all") conditions.push(eq(adsbObservationsTable.source, sourceFilter));
  if (since && !isNaN(since.getTime())) conditions.push(gte(adsbObservationsTable.createdAt, since));
  if (until && !isNaN(until.getTime())) {
    const { lte } = await import("drizzle-orm");
    conditions.push(lte(adsbObservationsTable.createdAt, until));
  }

  const { and } = await import("drizzle-orm");
  if (conditions.length > 0) query = query.where(and(...conditions) as ReturnType<typeof and>);

  const rows = await query
    .orderBy(desc(adsbObservationsTable.createdAt))
    .limit(limit)
    .offset(offset);

  const total = await db.select({ count: sql`count(*)::int` }).from(adsbObservationsTable);

  return res.json({
    observations: rows,
    total: Number(total[0]?.count ?? 0),
    limit,
    offset,
  });
});

router.get("/adsb/history/track/:icao", async (req, res) => {
  const icaoHex = req.params["icao"]?.toLowerCase() ?? "";
  const since = req.query["since"] ? new Date(String(req.query["since"])) : new Date(Date.now() - 24 * 3600 * 1000);
  const until = req.query["until"] ? new Date(String(req.query["until"])) : new Date();

  const rows = await db.select({
    id: adsbObservationsTable.id,
    syncId: adsbObservationsTable.syncId,
    icaoHex: adsbObservationsTable.icaoHex,
    callsign: adsbObservationsTable.callsign,
    registration: adsbObservationsTable.registration,
    aircraftType: adsbObservationsTable.aircraftType,
    lat: adsbObservationsTable.lat,
    lon: adsbObservationsTable.lon,
    altBaro: adsbObservationsTable.altBaro,
    groundSpeed: adsbObservationsTable.groundSpeed,
    track: adsbObservationsTable.track,
    verticalRate: adsbObservationsTable.verticalRate,
    distanceNm: adsbObservationsTable.distanceNm,
    directionFromAirport: adsbObservationsTable.directionFromAirport,
    inferredStatus: adsbObservationsTable.inferredStatus,
    lastSeenTs: adsbObservationsTable.lastSeenTs,
    createdAt: adsbObservationsTable.createdAt,
  })
    .from(adsbObservationsTable)
    .where(
      sql`${adsbObservationsTable.icaoHex} = ${icaoHex}
        AND ${adsbObservationsTable.createdAt} >= ${since}
        AND ${adsbObservationsTable.createdAt} <= ${until}`
    )
    .orderBy(adsbObservationsTable.createdAt);

  return res.json({ icaoHex, track: rows, count: rows.length, since: since.toISOString(), until: until.toISOString() });
});

router.get("/adsb/history/daily-counts", async (req, res) => {
  const days = Math.min(parseInt(String(req.query["days"] ?? "30"), 10), 90);
  const since = new Date(Date.now() - days * 24 * 3600 * 1000);

  const rows = await db.execute(
    sql`SELECT
      DATE(created_at) as date,
      COUNT(*) as total_observations,
      COUNT(DISTINCT icao_hex) as unique_aircraft,
      COUNT(DISTINCT sync_id) as sync_count,
      COUNT(*) FILTER (WHERE source = 'demo') as demo_count,
      COUNT(*) FILTER (WHERE source = 'adsbexchange') as live_count
    FROM adsb_observations
    WHERE created_at >= ${since}
    GROUP BY DATE(created_at)
    ORDER BY DATE(created_at) DESC`
  );

  return res.json({ days, dailyCounts: rows.rows, since: since.toISOString() });
});

router.get("/adsb/history/unmatched", async (req, res) => {
  const limit = Math.min(parseInt(String(req.query["limit"] ?? "100"), 10), 500);
  const offset = Math.max(parseInt(String(req.query["offset"] ?? "0"), 10), 0);
  const days = Math.min(parseInt(String(req.query["days"] ?? "7"), 10), 90);
  const since = new Date(Date.now() - days * 24 * 3600 * 1000);

  const rows = await db.execute(
    sql`SELECT o.*, m.match_type, m.match_score
    FROM adsb_observations o
    LEFT JOIN adsb_matches m ON m.observation_id = o.id
    WHERE (m.match_type = 'unmatched' OR m.id IS NULL)
      AND o.created_at >= ${since}
    ORDER BY o.created_at DESC
    LIMIT ${limit} OFFSET ${offset}`
  );

  return res.json({ unmatched: rows.rows, count: rows.rows.length, limit, offset, days });
});

router.get("/adsb/history/export", async (req, res) => {
  const format = String(req.query["format"] ?? "csv");
  const days = Math.min(parseInt(String(req.query["days"] ?? "30"), 10), 90);
  const since = new Date(Date.now() - days * 24 * 3600 * 1000);
  const icao = req.query["icao"] ? String(req.query["icao"]).toLowerCase() : null;
  const callsign = req.query["callsign"] ? String(req.query["callsign"]).toUpperCase() : null;

  let whereClause = sql`created_at >= ${since}`;
  if (icao) whereClause = sql`${whereClause} AND icao_hex = ${icao}`;
  if (callsign) whereClause = sql`${whereClause} AND callsign = ${callsign}`;

  const rows = await db.execute(
    sql`SELECT id, sync_id, icao_hex, callsign, registration, aircraft_type,
      alt_baro, ground_speed, track, vertical_rate, squawk,
      lat, lon, distance_nm, direction_from_airport, airport_context,
      inferred_status, source, last_seen_ts, created_at
    FROM adsb_observations
    WHERE ${whereClause}
    ORDER BY created_at DESC
    LIMIT 10000`
  );

  if (format === "json") {
    res.setHeader("Content-Disposition", `attachment; filename="adsb_history_${days}d.json"`);
    return res.json({ rows: rows.rows, count: rows.rows.length, exportedAt: new Date().toISOString() });
  }

  // CSV
  const cols = ["id","sync_id","icao_hex","callsign","registration","aircraft_type","alt_baro","ground_speed","track","vertical_rate","squawk","lat","lon","distance_nm","direction_from_airport","airport_context","inferred_status","source","last_seen_ts","created_at"];
  const csv = [
    cols.join(","),
    ...rows.rows.map((r) => cols.map((c) => {
      const v = (r as Record<string, unknown>)[c];
      if (v === null || v === undefined) return "";
      const s = String(v);
      return s.includes(",") || s.includes('"') || s.includes("\n") ? `"${s.replace(/"/g, '""')}"` : s;
    }).join(",")),
  ].join("\n");

  res.setHeader("Content-Type", "text/csv");
  res.setHeader("Content-Disposition", `attachment; filename="adsb_history_${days}d.csv"`);
  return res.send(csv);
});

router.post("/adsb/history/purge", async (req, res) => {
  const s = await getAdsbSettings();
  const retentionDays = s.adsbxHistoryRetentionDays ?? 90;
  const cutoff = new Date(Date.now() - retentionDays * 24 * 3600 * 1000);

  const deleted = await db.execute(
    sql`DELETE FROM adsb_observations WHERE created_at < ${cutoff}`
  );

  return res.json({
    purged: deleted.rowCount ?? 0,
    retentionDays,
    cutoff: cutoff.toISOString(),
    message: `Purged ADS-B observations older than ${retentionDays} days.`,
  });
});

export default router;
