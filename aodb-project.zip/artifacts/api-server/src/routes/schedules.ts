import { Router } from "express";
import { db } from "@workspace/db";
import {
  staticScheduleImportsTable,
  staticScheduleMovementsTable,
} from "@workspace/db";
import { eq, and, desc, count, sql } from "drizzle-orm";
import { COMMERCIAL_AIRLINE_IATA } from "../lib/commercial";
import crypto from "crypto";

const router = Router();

// ── Types ────────────────────────────────────────────────────────────────────

interface CsvRow {
  [key: string]: string;
}

interface ParsedMovement {
  direction: "ARR" | "DEP";
  flightNumber: string;
  airlineIata: string;
  airlineName: string | null;
  scheduledTime: string;
  origin: string | null;
  destination: string | null;
  city: string | null;
  aircraftType: string | null;
  aircraftGroup: string | null;
  seats: number | null;
  plannedPax: number | null;
  flightType: string | null;
  flightNature: string | null;
  sector: string | null;
  status: string | null;
  codeshares: string | null;
  tailNumber: string | null;
  passengerHandling: string | null;
  isCommercial: boolean;
  rawPayload: CsvRow;
}

// ── CSV Parser ────────────────────────────────────────────────────────────────

function parseCsvRow(line: string, headers: string[]): CsvRow {
  const values: string[] = [];
  let current = "";
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      inQuotes = !inQuotes;
    } else if (ch === ";" && !inQuotes) {
      values.push(current.trim());
      current = "";
    } else {
      current += ch;
    }
  }
  values.push(current.trim());
  const row: CsvRow = {};
  headers.forEach((h, idx) => {
    row[h] = (values[idx] ?? "").trim();
  });
  return row;
}

function parseIntSafe(v: string | undefined): number | null {
  if (!v || v === "" || v === "-") return null;
  const n = parseInt(v.replace(/[^0-9]/g, ""), 10);
  return isNaN(n) ? null : n;
}

function isCommercialFlightType(flightType: string, airlineIata: string): boolean {
  const ft = (flightType ?? "").toUpperCase().trim();
  if (ft === "J" || ft === "C" || ft === "P") return true;
  return COMMERCIAL_AIRLINE_IATA.has(airlineIata.toUpperCase().trim());
}

function extractMovements(row: CsvRow): ParsedMovement[] {
  const movements: ParsedMovement[] = [];

  const arrTime = (row["ArrivalScheduleTime"] ?? "").trim();
  const depTime = (row["DepartureScheduleTime"] ?? "").trim();

  if (arrTime && arrTime !== "-" && arrTime !== "0") {
    const airline = (row["ArrivalAirline"] ?? "").trim().toUpperCase();
    const flightNum = (row["ArrivalFlightNumber"] ?? "").trim();
    const flightNumber = airline + flightNum;
    const flightType = (row["ArrivalFlightType"] ?? "").trim();
    const commercial = isCommercialFlightType(flightType, airline);

    if (airline && flightNum) {
      movements.push({
        direction: "ARR",
        flightNumber,
        airlineIata: airline,
        airlineName: (row["ArrivalAirline description"] ?? row["ArrivalAirlineDescription"] ?? "").trim() || null,
        scheduledTime: arrTime,
        origin: (row["ArrivalOrigin"] ?? "").trim() || null,
        destination: "YLW",
        city: (row["ArrivalCity"] ?? "").trim() || null,
        aircraftType: (row["ArrivalAircraftType"] ?? "").trim() || null,
        aircraftGroup: (row["ArrivalAircraftGroup"] ?? "").trim() || null,
        seats: parseIntSafe(row["ArrivalSeats"]),
        plannedPax: parseIntSafe(row["ArrivalPax"]),
        flightType,
        flightNature: (row["ArrivalFlightNature"] ?? "").trim() || null,
        sector: (row["ArrivalSector"] ?? "").trim() || null,
        status: (row["ArrivalStatus"] ?? "").trim() || null,
        codeshares: (row["ArrivalCodeshares"] ?? "").trim() || null,
        tailNumber: (row["ArrivalTailnumber"] ?? row["ArrivalTailNumber"] ?? "").trim() || null,
        passengerHandling: (row["ArrivalPassengerHandling"] ?? "").trim() || null,
        isCommercial: commercial,
        rawPayload: row,
      });
    }
  }

  if (depTime && depTime !== "-" && depTime !== "0") {
    const airline = (row["DepartureAirline"] ?? "").trim().toUpperCase();
    const flightNum = (row["DepartureFlightNumber"] ?? "").trim();
    const flightNumber = airline + flightNum;
    const flightType = (row["DepartureFlightType"] ?? "").trim();
    const commercial = isCommercialFlightType(flightType, airline);

    if (airline && flightNum) {
      movements.push({
        direction: "DEP",
        flightNumber,
        airlineIata: airline,
        airlineName: (row["DepartureAirline description"] ?? row["DepartureAirlineDescription"] ?? "").trim() || null,
        scheduledTime: depTime,
        origin: "YLW",
        destination: (row["DepartureOrigin"] ?? "").trim() || null,
        city: (row["DepartureCity"] ?? "").trim() || null,
        aircraftType: (row["DepartureAircraftType"] ?? "").trim() || null,
        aircraftGroup: (row["DepartureAircraftGroup"] ?? "").trim() || null,
        seats: parseIntSafe(row["DepartureSeats"]),
        plannedPax: parseIntSafe(row["DeparturePax"]),
        flightType,
        flightNature: (row["DepartureFlightNature"] ?? "").trim() || null,
        sector: (row["DepartureSector"] ?? "").trim() || null,
        status: (row["DepartureStatus"] ?? "").trim() || null,
        codeshares: (row["DepartureCodeshares"] ?? "").trim() || null,
        tailNumber: (row["DepartureTailnumber"] ?? row["DepartureTailNumber"] ?? "").trim() || null,
        passengerHandling: (row["DeparturePassengerHandling"] ?? "").trim() || null,
        isCommercial: commercial,
        rawPayload: row,
      });
    }
  }

  return movements;
}

// ── Demo seed ─────────────────────────────────────────────────────────────────

const DEMO_MOVEMENTS: Omit<ParsedMovement, "rawPayload">[] = [
  { direction: "ARR", flightNumber: "AC8271", airlineIata: "AC", airlineName: "Air Canada", scheduledTime: "2026-05-01T06:40:00", origin: "YVR", destination: "YLW", city: "Vancouver", aircraftType: "DH4", aircraftGroup: "Turboprop", seats: 78, plannedPax: 65, flightType: "J", flightNature: "S", sector: "D", status: "SCH", codeshares: null, tailNumber: null, passengerHandling: "Y", isCommercial: true },
  { direction: "DEP", flightNumber: "AC8272", airlineIata: "AC", airlineName: "Air Canada", scheduledTime: "2026-05-01T07:30:00", origin: "YLW", destination: "YVR", city: "Vancouver", aircraftType: "DH4", aircraftGroup: "Turboprop", seats: 78, plannedPax: 72, flightType: "J", flightNature: "S", sector: "D", status: "SCH", codeshares: null, tailNumber: null, passengerHandling: "Y", isCommercial: true },
  { direction: "ARR", flightNumber: "WS3560", airlineIata: "WS", airlineName: "WestJet", scheduledTime: "2026-05-01T08:15:00", origin: "YYC", destination: "YLW", city: "Calgary", aircraftType: "73H", aircraftGroup: "Narrowbody", seats: 168, plannedPax: 145, flightType: "J", flightNature: "S", sector: "D", status: "SCH", codeshares: null, tailNumber: null, passengerHandling: "Y", isCommercial: true },
  { direction: "DEP", flightNumber: "WS3561", airlineIata: "WS", airlineName: "WestJet", scheduledTime: "2026-05-01T09:05:00", origin: "YLW", destination: "YYC", city: "Calgary", aircraftType: "73H", aircraftGroup: "Narrowbody", seats: 168, plannedPax: 152, flightType: "J", flightNature: "S", sector: "D", status: "SCH", codeshares: null, tailNumber: null, passengerHandling: "Y", isCommercial: true },
  { direction: "ARR", flightNumber: "AC205", airlineIata: "AC", airlineName: "Air Canada", scheduledTime: "2026-05-01T10:30:00", origin: "YYZ", destination: "YLW", city: "Toronto", aircraftType: "E75", aircraftGroup: "Narrowbody", seats: 76, plannedPax: 68, flightType: "J", flightNature: "S", sector: "L", status: "SCH", codeshares: "AC8269", tailNumber: null, passengerHandling: "Y", isCommercial: true },
  { direction: "DEP", flightNumber: "AC206", airlineIata: "AC", airlineName: "Air Canada", scheduledTime: "2026-05-01T11:20:00", origin: "YLW", destination: "YYZ", city: "Toronto", aircraftType: "E75", aircraftGroup: "Narrowbody", seats: 76, plannedPax: 71, flightType: "J", flightNature: "S", sector: "L", status: "SCH", codeshares: "AC8270", tailNumber: null, passengerHandling: "Y", isCommercial: true },
  { direction: "ARR", flightNumber: "8P241", airlineIata: "8P", airlineName: "Pacific Coastal Airlines", scheduledTime: "2026-05-01T12:00:00", origin: "YXC", destination: "YLW", city: "Cranbrook", aircraftType: "SWM", aircraftGroup: "Turboprop", seats: 19, plannedPax: 14, flightType: "J", flightNature: "S", sector: "D", status: "SCH", codeshares: null, tailNumber: null, passengerHandling: "Y", isCommercial: true },
  { direction: "DEP", flightNumber: "8P242", airlineIata: "8P", airlineName: "Pacific Coastal Airlines", scheduledTime: "2026-05-01T12:45:00", origin: "YLW", destination: "YXC", city: "Cranbrook", aircraftType: "SWM", aircraftGroup: "Turboprop", seats: 19, plannedPax: 11, flightType: "J", flightNature: "S", sector: "D", status: "SCH", codeshares: null, tailNumber: null, passengerHandling: "Y", isCommercial: true },
  { direction: "ARR", flightNumber: "WS830", airlineIata: "WS", airlineName: "WestJet", scheduledTime: "2026-05-01T14:20:00", origin: "YEG", destination: "YLW", city: "Edmonton", aircraftType: "73H", aircraftGroup: "Narrowbody", seats: 168, plannedPax: 132, flightType: "J", flightNature: "S", sector: "D", status: "SCH", codeshares: null, tailNumber: null, passengerHandling: "Y", isCommercial: true },
  { direction: "DEP", flightNumber: "WS831", airlineIata: "WS", airlineName: "WestJet", scheduledTime: "2026-05-01T15:10:00", origin: "YLW", destination: "YEG", city: "Edmonton", aircraftType: "73H", aircraftGroup: "Narrowbody", seats: 168, plannedPax: 141, flightType: "J", flightNature: "S", sector: "D", status: "SCH", codeshares: null, tailNumber: null, passengerHandling: "Y", isCommercial: true },
  { direction: "ARR", flightNumber: "F8801", airlineIata: "F8", airlineName: "Flair Airlines", scheduledTime: "2026-05-01T16:55:00", origin: "YYZ", destination: "YLW", city: "Toronto", aircraftType: "73H", aircraftGroup: "Narrowbody", seats: 189, plannedPax: 178, flightType: "J", flightNature: "S", sector: "L", status: "SCH", codeshares: null, tailNumber: null, passengerHandling: "Y", isCommercial: true },
  { direction: "DEP", flightNumber: "F8802", airlineIata: "F8", airlineName: "Flair Airlines", scheduledTime: "2026-05-01T17:45:00", origin: "YLW", destination: "YYZ", city: "Toronto", aircraftType: "73H", aircraftGroup: "Narrowbody", seats: 189, plannedPax: 183, flightType: "J", flightNature: "S", sector: "L", status: "SCH", codeshares: null, tailNumber: null, passengerHandling: "Y", isCommercial: true },
];

async function seedDemoSchedule() {
  const existing = await db.select().from(staticScheduleImportsTable).limit(1);
  if (existing.length > 0) return;

  const importId = crypto.randomUUID();
  await db.insert(staticScheduleImportsTable).values({
    id: importId,
    filename: "turnRoundHandlings_Period_2026-05-01_2026-06-30.csv (demo sample)",
    periodStart: "2026-05-01",
    periodEnd: "2026-06-30",
    isActive: true,
    version: 1,
    totalRows: DEMO_MOVEMENTS.length,
    arrivalCount: DEMO_MOVEMENTS.filter((m) => m.direction === "ARR").length,
    departureCount: DEMO_MOVEMENTS.filter((m) => m.direction === "DEP").length,
    skippedCount: 0,
    commercialCount: DEMO_MOVEMENTS.filter((m) => m.isCommercial).length,
    notes: "Auto-seeded demo sample — 12 representative YLW commercial movements for 2026-05-01. Upload the real CSV to replace.",
  });

  const rows = DEMO_MOVEMENTS.map((m) => ({
    id: crypto.randomUUID(),
    importId,
    direction: m.direction,
    flightNumber: m.flightNumber,
    airlineIata: m.airlineIata,
    airlineName: m.airlineName ?? null,
    scheduledTime: m.scheduledTime,
    origin: m.origin ?? null,
    destination: m.destination ?? null,
    city: m.city ?? null,
    aircraftType: m.aircraftType ?? null,
    aircraftGroup: m.aircraftGroup ?? null,
    seats: m.seats ?? null,
    plannedPax: m.plannedPax ?? null,
    flightType: m.flightType ?? null,
    flightNature: m.flightNature ?? null,
    sector: m.sector ?? null,
    status: m.status ?? null,
    codeshares: m.codeshares ?? null,
    tailNumber: m.tailNumber ?? null,
    passengerHandling: m.passengerHandling ?? null,
    isCommercial: m.isCommercial,
    rawPayload: { demo: true } as Record<string, unknown>,
    linkedMovementId: null,
    fr24MatchStatus: "pending",
    fr24ActualTime: null,
    fr24TailNumber: null,
    fr24AircraftType: null,
    varianceMinutes: null,
  }));

  await db.insert(staticScheduleMovementsTable).values(rows);
}

// Run demo seed on startup
seedDemoSchedule().catch(() => {});

// ── GET /schedules/static/status ──────────────────────────────────────────────

router.get("/static/status", async (req, res) => {
  const allImports = await db
    .select()
    .from(staticScheduleImportsTable)
    .orderBy(desc(staticScheduleImportsTable.importedAt));

  const activeImport = allImports.find((i) => i.isActive) ?? null;

  const mode = activeImport ? "static_schedule_fr24" : "fr24_only";

  res.json({
    hasActiveSchedule: !!activeImport,
    activeImport,
    allImports,
    mode,
  });
});

// ── POST /schedules/static/import ────────────────────────────────────────────

router.post("/static/import", async (req, res) => {
  const { csv, filename, periodStart, periodEnd, replace, notes } = req.body as {
    csv: string;
    filename: string;
    periodStart: string;
    periodEnd: string;
    replace?: boolean;
    notes?: string;
  };

  if (!csv || typeof csv !== "string") {
    res.status(400).json({ error: "csv field is required and must be a string" });
    return;
  }
  if (!filename || !periodStart || !periodEnd) {
    res.status(400).json({ error: "filename, periodStart, and periodEnd are required" });
    return;
  }

  const errors: string[] = [];
  const warnings: string[] = [];

  const lines = csv.split(/\r?\n/).filter((l) => l.trim().length > 0);
  if (lines.length < 2) {
    res.status(400).json({ error: "CSV must have at least a header row and one data row" });
    return;
  }

  const rawHeaders = lines[0].split(";").map((h) => h.trim().replace(/^"|"$/g, ""));

  const movements: ParsedMovement[] = [];
  let skippedCount = 0;
  let totalRows = 0;

  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    totalRows++;

    let row: CsvRow;
    try {
      row = parseCsvRow(line, rawHeaders);
    } catch {
      errors.push(`Row ${i + 1}: parse error`);
      skippedCount++;
      continue;
    }

    const rowMovements = extractMovements(row);
    if (rowMovements.length === 0) {
      skippedCount++;
    } else {
      movements.push(...rowMovements);
    }

    if (errors.length > 20) {
      warnings.push(`Stopped collecting errors after 20. Total rows processed: ${i}`);
      break;
    }
  }

  const arrivalCount = movements.filter((m) => m.direction === "ARR").length;
  const departureCount = movements.filter((m) => m.direction === "DEP").length;
  const commercialCount = movements.filter((m) => m.isCommercial).length;

  if (movements.length === 0) {
    res.status(400).json({
      error: "No valid movements found in CSV. Check that ArrivalScheduleTime or DepartureScheduleTime columns are populated.",
    });
    return;
  }

  const allImports = await db.select().from(staticScheduleImportsTable).orderBy(desc(staticScheduleImportsTable.importedAt));
  const latestVersion = allImports.length > 0 ? Math.max(...allImports.map((i) => i.version)) : 0;
  const newVersion = latestVersion + 1;

  if (replace) {
    await db
      .update(staticScheduleImportsTable)
      .set({ isActive: false })
      .where(eq(staticScheduleImportsTable.isActive, true));
  }

  const importId = crypto.randomUUID();
  await db.insert(staticScheduleImportsTable).values({
    id: importId,
    filename,
    periodStart,
    periodEnd,
    isActive: true,
    version: newVersion,
    totalRows,
    arrivalCount,
    departureCount,
    skippedCount,
    commercialCount,
    notes: notes ?? null,
  });

  const batchSize = 200;
  for (let b = 0; b < movements.length; b += batchSize) {
    const batch = movements.slice(b, b + batchSize);
    await db.insert(staticScheduleMovementsTable).values(
      batch.map((m) => ({
        id: crypto.randomUUID(),
        importId,
        direction: m.direction,
        flightNumber: m.flightNumber,
        airlineIata: m.airlineIata,
        airlineName: m.airlineName ?? null,
        scheduledTime: m.scheduledTime,
        origin: m.origin ?? null,
        destination: m.destination ?? null,
        city: m.city ?? null,
        aircraftType: m.aircraftType ?? null,
        aircraftGroup: m.aircraftGroup ?? null,
        seats: m.seats ?? null,
        plannedPax: m.plannedPax ?? null,
        flightType: m.flightType ?? null,
        flightNature: m.flightNature ?? null,
        sector: m.sector ?? null,
        status: m.status ?? null,
        codeshares: m.codeshares ?? null,
        tailNumber: m.tailNumber ?? null,
        passengerHandling: m.passengerHandling ?? null,
        isCommercial: m.isCommercial,
        rawPayload: m.rawPayload as Record<string, unknown>,
        linkedMovementId: null,
        fr24MatchStatus: "pending",
        fr24ActualTime: null,
        fr24TailNumber: null,
        fr24AircraftType: null,
        varianceMinutes: null,
      }))
    );
  }

  res.json({
    success: true,
    importId,
    filename,
    periodStart,
    periodEnd,
    version: newVersion,
    totalRows,
    arrivalCount,
    departureCount,
    skippedCount,
    commercialCount,
    errors,
    warnings,
  });
});

// ── GET /schedules/static/movements ──────────────────────────────────────────

router.get("/static/movements", async (req, res) => {
  const activeImport = await db
    .select()
    .from(staticScheduleImportsTable)
    .where(eq(staticScheduleImportsTable.isActive, true))
    .limit(1);

  if (!activeImport.length) {
    res.json({ movements: [], total: 0, page: 1, limit: 50, import: null });
    return;
  }

  const imp = activeImport[0];
  const page = Math.max(1, parseInt(String(req.query.page ?? "1"), 10));
  const limit = Math.min(200, Math.max(1, parseInt(String(req.query.limit ?? "50"), 10)));
  const offset = (page - 1) * limit;

  const conditions = [eq(staticScheduleMovementsTable.importId, imp.id)];

  const commercialOnly = req.query.commercial_only;
  if (commercialOnly === "true" || commercialOnly === "1") {
    conditions.push(eq(staticScheduleMovementsTable.isCommercial, true));
  }

  const direction = req.query.direction as string | undefined;
  if (direction === "ARR" || direction === "DEP") {
    conditions.push(eq(staticScheduleMovementsTable.direction, direction));
  }

  const airline = req.query.airline as string | undefined;
  if (airline) {
    conditions.push(eq(staticScheduleMovementsTable.airlineIata, airline.toUpperCase()));
  }

  const date = req.query.date as string | undefined;
  if (date) {
    conditions.push(sql`${staticScheduleMovementsTable.scheduledTime}::text LIKE ${date + "%"}`);
  }

  const [totalResult] = await db
    .select({ count: count() })
    .from(staticScheduleMovementsTable)
    .where(and(...conditions));

  const movements = await db
    .select()
    .from(staticScheduleMovementsTable)
    .where(and(...conditions))
    .orderBy(staticScheduleMovementsTable.scheduledTime)
    .limit(limit)
    .offset(offset);

  res.json({
    movements,
    total: Number(totalResult.count),
    page,
    limit,
    import: imp,
  });
});

// ── GET /schedules/static/variance ───────────────────────────────────────────

router.get("/static/variance", async (req, res) => {
  const activeImport = await db
    .select()
    .from(staticScheduleImportsTable)
    .where(eq(staticScheduleImportsTable.isActive, true))
    .limit(1);

  if (!activeImport.length) {
    res.json({
      rows: [],
      summary: { total: 0, matched: 0, onTime: 0, delayed: 0, early: 0, unmatched: 0, avgVarianceMinutes: 0 },
    });
    return;
  }

  const movements = await db
    .select()
    .from(staticScheduleMovementsTable)
    .where(
      and(
        eq(staticScheduleMovementsTable.importId, activeImport[0].id),
        eq(staticScheduleMovementsTable.isCommercial, true)
      )
    )
    .orderBy(staticScheduleMovementsTable.scheduledTime)
    .limit(500);

  const rows = movements.map((m) => {
    const matched = m.fr24MatchStatus === "matched";
    const variance = m.varianceMinutes;
    let confidence = 0;
    if (matched) {
      confidence = variance !== null && Math.abs(variance) <= 5 ? 95 : Math.abs(variance ?? 999) <= 15 ? 80 : 60;
    }
    return {
      flightNumber: m.flightNumber,
      direction: m.direction,
      scheduledTime: m.scheduledTime,
      fr24ActualTime: m.fr24ActualTime ?? null,
      varianceMinutes: variance ?? null,
      fr24MatchStatus: m.fr24MatchStatus ?? "pending",
      confidence,
    };
  });

  const matched = rows.filter((r) => r.fr24MatchStatus === "matched").length;
  const unmatched = rows.filter((r) => r.fr24MatchStatus === "pending" || r.fr24MatchStatus === "unmatched").length;
  const onTime = rows.filter((r) => r.varianceMinutes !== null && Math.abs(r.varianceMinutes) <= 5).length;
  const delayed = rows.filter((r) => r.varianceMinutes !== null && r.varianceMinutes > 5).length;
  const early = rows.filter((r) => r.varianceMinutes !== null && r.varianceMinutes < -5).length;
  const variances = rows.filter((r) => r.varianceMinutes !== null).map((r) => r.varianceMinutes as number);
  const avgVarianceMinutes = variances.length ? variances.reduce((a, b) => a + b, 0) / variances.length : 0;

  res.json({
    rows,
    summary: {
      total: rows.length,
      matched,
      onTime,
      delayed,
      early,
      unmatched,
      avgVarianceMinutes: Math.round(avgVarianceMinutes * 10) / 10,
    },
  });
});

export default router;
