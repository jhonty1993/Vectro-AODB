import { Router } from "express";
import { db } from "@workspace/db";
import { flightMovementsTable, flightEventsTable } from "@workspace/db";

const router = Router();

function toISO(t: Date | string): string {
  return typeof t === "string" ? t : t.toISOString();
}

router.get("/overview", async (_req, res) => {
  const flights = await db.select().from(flightMovementsTable);
  const total = flights.length;
  const highQuality = flights.filter((f) => f.dataQualityScore >= 80).length;
  const mediumQuality = flights.filter((f) => f.dataQualityScore >= 60 && f.dataQualityScore < 80).length;
  const lowQuality = flights.filter((f) => f.dataQualityScore < 60).length;
  const averageScore = total > 0 ? Math.round((flights.reduce((sum, f) => sum + f.dataQualityScore, 0) / total) * 10) / 10 : 0;
  const missingTailNumber = flights.filter((f) => !f.tailNumber).length;
  const missingActualTime = flights.filter((f) => !f.actualTime && ["LANDED", "ON_BLOCK", "DEPARTED"].includes(f.status)).length;

  const events = await db.select().from(flightEventsTable);
  const sourceMap: Record<string, number> = {};
  for (const e of events) {
    sourceMap[e.source] = (sourceMap[e.source] ?? 0) + 1;
  }
  const sourceBreakdown = Object.entries(sourceMap).map(([source, count]) => ({ source, count }));

  res.json({
    averageScore,
    totalFlights: total,
    highQuality,
    mediumQuality,
    lowQuality,
    conflictingTimestamps: 0,
    missingTailNumber,
    missingActualTime,
    sourceBreakdown,
  });
});

router.get("/audit-log", async (_req, res) => {
  const allEvents = await db.select().from(flightEventsTable).orderBy(flightEventsTable.createdAt);
  const allFlights = await db.select().from(flightMovementsTable);
  const flightMap = Object.fromEntries(allFlights.map((f) => [f.id, f]));

  const manualEvents = allEvents.filter((e) => e.source === "MANUAL" || (e.operator && e.operator !== "System"));
  const auditEntries = manualEvents.map((e) => ({
    id: e.id,
    flightId: e.flightId,
    flightNumber: flightMap[e.flightId]?.flightNumber ?? "UNKNOWN",
    action: e.eventType,
    operator: e.operator ?? "System",
    reason: e.reason ?? "",
    fieldChanged: null as string | null,
    oldValue: null as string | null,
    newValue: null as string | null,
    createdAt: toISO(e.createdAt),
  }));

  res.json(auditEntries);
});

export default router;
