// Commercial flight classification helper
// Determines whether an aircraft/flight is a commercial scheduled/charter airline
// versus general aviation, private, military, training, or helicopter.

export const COMMERCIAL_AIRLINE_IATA = new Set([
  // Canada
  "AC", "WS", "PD", "8P", "TS", "F8", "WG", "3J", "XG", "QB",
  "SY", "MO", "WO", "ZX", "PB",
  // US majors
  "UA", "AA", "DL", "WN", "AS", "B6", "NK", "G4", "SY", "F9",
  // International scheduled
  "BA", "LH", "AF", "KL", "EK", "QR", "TK", "LX", "AY", "SK",
  "OS", "IB", "VY", "U2", "FR", "AZ", "TP",
  // Cargo/integrators
  "FX", "5X", "CV", "GT",
  // Pacific Coastal and regional
  "YV", "CP", "DY",
]);

// IATA codes that are always commercial regardless of other signals
export const ALWAYS_COMMERCIAL_PREFIXES = ["AC", "WS", "WJ", "8P", "TS", "F8", "PD", "UA", "DL", "AA", "WN", "AS", "B6"];

// Callsign/registration patterns indicating GA or private aircraft
export const GA_REGISTRATION_PATTERNS: RegExp[] = [
  /^C-[A-Z]{4}$/, // Canadian civil registration (C-FABC) — 4 letter suffix = GA
  /^N\d{1,5}[A-Z]{0,2}$/, // US civilian registration
  /^G-[A-Z]{4}$/, // UK civilian
  /^OE-[A-Z]{3}$/, // Austrian
  /^D-[A-Z]{4}$/, // German civil
];

// ICAO aircraft type codes for rotorcraft / helicopters
export const HELICOPTER_TYPE_CODES = new Set([
  "R22", "R44", "R66", "H125", "H130", "H135", "H145", "H155", "H160",
  "EC20", "EC25", "EC30", "EC35", "EC45", "EC55",
  "B06", "B07", "B47", "B222", "B407", "B427", "B430",
  "S61", "S76", "S92", "A109", "A119", "A139", "A169", "A189",
  "MD52", "MD60", "UH60", "AW09", "AW13", "AW69", "AW89",
  "BK17", "NH90", "AS50", "AS55", "AS65",
]);

// ICAO aircraft type codes that always indicate commercial passenger ops at regional airports
export const ALWAYS_COMMERCIAL_TYPES = new Set([
  "B737", "B738", "B739", "B73X", "B738",
  "B737-800", "B737-700", "B737-MAX8", "B737-MAX9",
  "A319", "A320", "A321", "A319-100", "A320-200", "A321-200",
  "B787", "B788", "B789", "B78X",
  "A220", "BCS1", "BCS3",
  "DH8D", "DHC-8", "DHC-8-402", "DHC-8-300",
  "AT45", "AT75", "ATR4", "ATR7",
  "CRJ2", "CRJ7", "CRJ9", "CRJX",
  "E170", "E175", "E190", "E195",
]);

// Military callsign 3-letter prefixes
export const MILITARY_CALLSIGN_PREFIXES = new Set([
  "RCH", "RCH", "JAKE", "ROCKY", "BOXER", "REACH", // USAF
  "CFC", "CANAF", "MAGIC", "DUKE", // Canadian Forces
  "RRR", "ASCOT", // RAF
  "CNV", "VMR", // US Navy/Marines
]);

export type CommercialClass =
  | "commercial_scheduled"
  | "commercial_cargo"
  | "commercial_charter"
  | "ga"
  | "military"
  | "helicopter"
  | "training"
  | "unknown";

export interface CommercialClassification {
  isCommercial: boolean;
  class: CommercialClass;
  reason: string;
}

export function classifyFlight(params: {
  airlineIata?: string | null;
  callsign?: string | null;
  aircraftType?: string | null;
  flightNumber?: string | null;
  registration?: string | null;
}): CommercialClassification {
  const { airlineIata, callsign, aircraftType, flightNumber, registration } = params;

  // Rotorcraft: always non-commercial on main board
  if (aircraftType) {
    const t = aircraftType.replace(/[-\s]/g, "").toUpperCase();
    if (HELICOPTER_TYPE_CODES.has(t) || HELICOPTER_TYPE_CODES.has(aircraftType.toUpperCase())) {
      return { isCommercial: false, class: "helicopter", reason: "Helicopter/rotorcraft type" };
    }
  }

  // Aircraft type always implies commercial
  if (aircraftType && ALWAYS_COMMERCIAL_TYPES.has(aircraftType)) {
    return { isCommercial: true, class: "commercial_scheduled", reason: "Commercial aircraft type" };
  }

  // Military callsign
  if (callsign) {
    const upper = callsign.toUpperCase();
    const pre3 = upper.slice(0, 3);
    const pre4 = upper.slice(0, 4);
    if (MILITARY_CALLSIGN_PREFIXES.has(pre3) || MILITARY_CALLSIGN_PREFIXES.has(pre4)) {
      return { isCommercial: false, class: "military", reason: "Military callsign prefix" };
    }
  }

  // Known commercial IATA airline code
  if (airlineIata && COMMERCIAL_AIRLINE_IATA.has(airlineIata.toUpperCase())) {
    return { isCommercial: true, class: "commercial_scheduled", reason: `Commercial IATA code: ${airlineIata}` };
  }

  // Always-commercial prefixes in flight number
  if (flightNumber) {
    const fn = flightNumber.trim().toUpperCase();
    for (const prefix of ALWAYS_COMMERCIAL_PREFIXES) {
      if (fn.startsWith(prefix) && /\d/.test(fn[prefix.length] ?? "")) {
        return { isCommercial: true, class: "commercial_scheduled", reason: `Flight number matches commercial prefix: ${prefix}` };
      }
    }
  }

  // GA registration pattern on callsign
  if (callsign) {
    for (const pattern of GA_REGISTRATION_PATTERNS) {
      if (pattern.test(callsign.toUpperCase())) {
        return { isCommercial: false, class: "ga", reason: "Callsign matches GA registration pattern" };
      }
    }
  }

  // GA registration pattern on registration
  if (registration) {
    for (const pattern of GA_REGISTRATION_PATTERNS) {
      if (pattern.test(registration.toUpperCase())) {
        return { isCommercial: false, class: "ga", reason: "Registration matches GA pattern" };
      }
    }
  }

  // Training flight keywords
  if (flightNumber && /^(TRN|TRAIN|TRNG|SCH)/i.test(flightNumber)) {
    return { isCommercial: false, class: "training", reason: "Training flight number prefix" };
  }

  // 2-letter IATA + digits in flight number = likely commercial
  if (flightNumber) {
    const m = flightNumber.trim().toUpperCase().match(/^([A-Z]{2})(\d+)/);
    if (m) {
      return { isCommercial: true, class: "commercial_scheduled", reason: `IATA format flight number` };
    }
    // 3-letter ICAO airline + digits = likely commercial
    const m2 = flightNumber.trim().toUpperCase().match(/^([A-Z]{3})(\d+)/);
    if (m2) {
      return { isCommercial: true, class: "commercial_scheduled", reason: `ICAO format flight number` };
    }
  }

  return { isCommercial: false, class: "unknown", reason: "Insufficient data to classify" };
}

export function isCommercial(params: {
  airlineIata?: string | null;
  callsign?: string | null;
  aircraftType?: string | null;
  flightNumber?: string | null;
  registration?: string | null;
}): boolean {
  return classifyFlight(params).isCommercial;
}

// Source strategy definitions for commercial-only MVP
export const SOURCE_STRATEGY = {
  operationalScope: "COMMERCIAL_ONLY_MVP" as const,
  description: "Focus on commercial airline/cargo/charter movements only. GA, private, training, and military are excluded from the main operations board.",
  sources: {
    cirium: {
      role: "future_schedules",
      label: "Future Scheduled Commercial Flights",
      description: "Authoritative source for upcoming commercial flight schedules. Used for STA/STD, airline, route, and planned equipment. Polled every 10 minutes for next 48 hours.",
      pollingIntervalMinutes: 10,
      lookAheadHours: 48,
      priority: "schedule",
      fields: ["flightNumber", "airline", "origin", "destination", "scheduledTime (STA/STD)", "estimatedTime", "cancelledStatus", "aircraftType (planned)"],
      includeFilter: "Commercial scheduled, cargo, and charter flights operating into/out of CYLW/YLW",
    },
    fr24: {
      role: "live_actuals",
      label: "Live Day-of-Operations Actuals",
      description: "Primary source for actual commercial movement truth. Matches live ADS-B/MLAT tracking to Cirium commercial schedule by flight number, airline, route, and time window.",
      priority: "actuals",
      fields: ["actualDeparture (ATD)", "airborne", "actualArrival (ATA/landing)", "tailNumber", "aircraftType (actual)", "runway", "diversionConfirmed"],
      matchingLogic: "Match by flight number + airline IATA + ±2h time window. Confidence scoring applied.",
      includeFilter: "Only flights matching a Cirium commercial schedule or with known commercial IATA callsign",
    },
    adsb: {
      role: "secondary_verification",
      label: "Secondary ADS-B Verification",
      description: "Corroborates FR24 actuals for commercial flights already in the schedule. Does not create main board movement records from unmatched aircraft. Non-commercial aircraft go to the ADS-B Review Queue only.",
      priority: "verification",
      fields: ["icaoHex", "callsign", "registration", "altBaro", "groundSpeed", "inferredStatus"],
      mainBoardFilter: "Only ADS-B observations matched (exact/probable) to a Cirium commercial flight. Unmatched go to review queue.",
      reviewQueue: "Unmatched ADS-B aircraft visible in ADS-B Exchange → Unmatched Review Queue for optional human promotion",
    },
    airportFeed: {
      role: "status_overlay",
      label: "Airport JSON Feed (Future Phase)",
      description: "Provides passenger-facing status and estimated times overlaid on the commercial schedule. Allocation fields (stand, gate, belt) are not used in the current MVP.",
      priority: "supplemental",
      fields: ["status", "estimatedTime", "passengerStatus"],
      note: "Airport feed integration is planned for Phase 2. Stand, gate, and belt allocation are excluded from the Commercial AODB MVP.",
    },
  },
  exclusions: [
    "General aviation (VFR/IFR GA) — registration-pattern callsigns, no IATA prefix",
    "Private/charter flights without IATA airline code",
    "Training flights (TRN/TRNG prefix or flight school operators)",
    "Military flights (RCH/CANAF/etc. prefixes)",
    "Helicopters (rotorcraft ICAO type codes)",
    "Unmatched ADS-B aircraft with no Cirium/FR24 commercial match",
    "Unknown callsigns — callsign = BLOCKED, UNKNOWN, or null with no IATA code",
  ],
} as const;
