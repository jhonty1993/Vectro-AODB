import { randomUUID } from "crypto";
import type {
  FlightMovement,
  AircraftRegistry,
  BillingCustomer,
  ItemCode,
  RatePlan,
  RateRule,
  InsertBillableCharge,
  InsertBillingAlert,
  InsertBillingDecision,
} from "@workspace/db";

export type AlertLevel = "green" | "blue" | "yellow" | "purple" | "red" | "black";
export type RouteType = "domestic" | "transborder" | "international";

// Canadian airports YLW commonly connects to (domestic).
const CANADIAN_AIRPORTS = new Set([
  "YVR", "YYC", "YEG", "YYZ", "YUL", "YXS", "YXC", "YYJ", "YYF", "YLW",
  "YQQ", "YCD", "YKA", "YXX", "YWL", "YPR", "YZF", "YQR", "YWG", "YOW",
  "YHZ", "YQU", "YCG", "YBL", "YZP", "YPW",
]);

// US airports (transborder).
const US_AIRPORTS = new Set([
  "SEA", "LAX", "SFO", "DEN", "PHX", "LAS", "PDX", "OAK", "SAN", "SJC",
  "ORD", "DFW", "JFK", "EWR", "BOS", "IAH", "MSP", "SLC", "HNL", "MCO",
]);

export function classifyRoute(movement: Pick<FlightMovement, "direction" | "origin" | "destination">): RouteType {
  const other = (movement.direction === "ARR" ? movement.origin : movement.destination || "").toUpperCase();
  if (CANADIAN_AIRPORTS.has(other)) return "domestic";
  if (US_AIRPORTS.has(other)) return "transborder";
  return "international";
}

// MTOW fallback (kg) by aircraft type when no registry match exists.
const MTOW_FALLBACK: Array<[RegExp, number, string]> = [
  [/MAX\s?8|MAX8/i, 82191, "TURBOFAN"],
  [/737-?9|B?739/i, 84000, "TURBOFAN"],
  [/737-?8|B?738/i, 79016, "TURBOFAN"],
  [/737-?7|B?737/i, 70080, "TURBOFAN"],
  [/A?320/i, 73500, "TURBOFAN"],
  [/A?319/i, 64000, "TURBOFAN"],
  [/A?321/i, 89000, "TURBOFAN"],
  [/CRJ-?9|CRJ9/i, 36514, "TURBOFAN"],
  [/CRJ-?2|CRJ2/i, 24040, "TURBOFAN"],
  [/CRJ/i, 34000, "TURBOFAN"],
  [/E?RJ-?175|E175/i, 38600, "TURBOFAN"],
  [/E?RJ-?190|E190/i, 51800, "TURBOFAN"],
  [/DHC-?8|DH8|Q400|DASH\s?8/i, 29257, "TURBOPROP"],
  [/SAAB|SF34/i, 13500, "TURBOPROP"],
  [/BEECH|B190|1900/i, 7765, "TURBOPROP"],
  [/PC-?12|PC12/i, 4740, "TURBOPROP"],
  [/CESSNA|C208|CARAVAN/i, 3995, "TURBOPROP"],
];

export function lookupAircraft(
  movement: Pick<FlightMovement, "tailNumber" | "aircraftType">,
  registry: AircraftRegistry[],
): { mtowKg: number | null; engineType: string | null; matchedTail: boolean } {
  if (movement.tailNumber) {
    const hit = registry.find((a) => a.tailNumber === movement.tailNumber);
    if (hit) return { mtowKg: hit.mtowKg, engineType: hit.engineType, matchedTail: true };
  }
  const type = movement.aircraftType || "";
  for (const [re, mtow, engine] of MTOW_FALLBACK) {
    if (re.test(type)) return { mtowKg: mtow, engineType: engine, matchedTail: false };
  }
  return { mtowKg: null, engineType: null, matchedTail: false };
}

export function findCustomer(
  movement: Pick<FlightMovement, "airlineIata" | "airline">,
  customers: BillingCustomer[],
): BillingCustomer | null {
  if (movement.airlineIata) {
    const byIata = customers.find(
      (c) => c.iataCode?.toUpperCase() === movement.airlineIata.toUpperCase() && c.status === "active",
    );
    if (byIata) return byIata;
  }
  if (movement.airline) {
    const byName = customers.find(
      (c) => c.name.toLowerCase() === movement.airline.toLowerCase() && c.status === "active",
    );
    if (byName) return byName;
  }
  return null;
}

function isEffective(rule: { effectiveFrom: string; effectiveTo: string | null }, onDate: string): boolean {
  if (rule.effectiveFrom && onDate < rule.effectiveFrom) return false;
  if (rule.effectiveTo && onDate > rule.effectiveTo) return false;
  return true;
}

export interface RuleMatchContext {
  routeType: RouteType;
  engineType: string | null;
  mtowKg: number | null;
  direction: string;
  airlineIata: string | null;
  customerType: string | null;
  onDate: string; // YYYY-MM-DD
}

export interface RuleMatch {
  rule: RateRule;
  reasons: string[];
}

// Returns the highest-priority matching landing-fee rule and the human-readable reasons.
export function matchRateRule(
  rules: RateRule[],
  itemCodeId: string,
  ctx: RuleMatchContext,
): RuleMatch | null {
  const candidates = rules
    .filter((r) => r.active && r.itemCodeId === itemCodeId && isEffective(r, ctx.onDate))
    .filter((r) => {
      if (r.routeType !== "any" && r.routeType !== ctx.routeType) return false;
      if (r.engineType !== "any" && ctx.engineType && r.engineType !== ctx.engineType) return false;
      if (r.direction !== "any" && r.direction !== ctx.direction) return false;
      if (r.customerType !== "any" && ctx.customerType && r.customerType !== ctx.customerType) return false;
      if (r.airlineIata && r.airlineIata.toUpperCase() !== (ctx.airlineIata || "").toUpperCase()) return false;
      if (r.minMtowKg != null && (ctx.mtowKg == null || ctx.mtowKg < r.minMtowKg)) return false;
      if (r.maxMtowKg != null && (ctx.mtowKg == null || ctx.mtowKg > r.maxMtowKg)) return false;
      return true;
    });

  if (candidates.length === 0) return null;

  // Specificity: airline-specific > narrower conditions; then priority; then most recent effectiveFrom.
  candidates.sort((a, b) => {
    const aSpec = (a.airlineIata ? 4 : 0) + (a.routeType !== "any" ? 1 : 0) + (a.engineType !== "any" ? 1 : 0);
    const bSpec = (b.airlineIata ? 4 : 0) + (b.routeType !== "any" ? 1 : 0) + (b.engineType !== "any" ? 1 : 0);
    if (bSpec !== aSpec) return bSpec - aSpec;
    if (b.priority !== a.priority) return b.priority - a.priority;
    return (b.effectiveFrom || "").localeCompare(a.effectiveFrom || "");
  });

  const rule = candidates[0];
  const reasons: string[] = [];
  reasons.push(`Route type ${rule.routeType === "any" ? "any" : rule.routeType} matched (${ctx.routeType}).`);
  if (rule.engineType !== "any") reasons.push(`Engine type ${rule.engineType} matched.`);
  if (rule.airlineIata) reasons.push(`Airline-specific rule for ${rule.airlineIata}.`);
  if (rule.minMtowKg != null || rule.maxMtowKg != null) {
    reasons.push(
      `MTOW ${(ctx.mtowKg ?? 0).toLocaleString()} kg within [${rule.minMtowKg ?? 0}, ${rule.maxMtowKg ?? "∞"}].`,
    );
  }
  reasons.push(`Effective ${rule.effectiveFrom}${rule.effectiveTo ? ` → ${rule.effectiveTo}` : " (open)"}, priority ${rule.priority}.`);
  return { rule, reasons };
}

export interface RatingResult {
  charge: InsertBillableCharge;
  alerts: Omit<InsertBillingAlert, "chargeId">[];
  decisions: Omit<InsertBillingDecision, "chargeId">[];
}

export interface RatingCatalog {
  registry: AircraftRegistry[];
  customers: BillingCustomer[];
  ratePlan: RatePlan;
  rules: RateRule[];
  landingItemCode: ItemCode;
}

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

// Rate a single movement into a landing-fee charge with full provenance + alerts.
export function rateMovementToLandingCharge(
  movement: FlightMovement,
  catalog: RatingCatalog,
  operator = "system",
): RatingResult {
  const onDate = (movement.scheduledTime || new Date().toISOString()).slice(0, 10);
  const routeType = classifyRoute(movement);
  const { mtowKg, engineType, matchedTail } = lookupAircraft(movement, catalog.registry);
  const customer = findCustomer(movement, catalog.customers);

  const alerts: Omit<InsertBillingAlert, "chargeId">[] = [];
  const decisions: Omit<InsertBillingDecision, "chargeId">[] = [];
  let confidence = 100;
  let alertLevel: AlertLevel = "green";
  const escalate = (lvl: AlertLevel) => {
    const order: AlertLevel[] = ["green", "blue", "yellow", "purple", "red", "black"];
    if (order.indexOf(lvl) > order.indexOf(alertLevel)) alertLevel = lvl;
  };

  decisions.push({
    id: randomUUID(),
    action: "RATED",
    detail: `Rating ${movement.flightNumber} (${movement.direction}) on ${onDate}: route=${routeType}, engine=${engineType ?? "unknown"}, MTOW=${mtowKg ?? "unknown"}kg.`,
    payload: { routeType, engineType, mtowKg, matchedTail },
    operator,
  });

  if (customer) {
    decisions.push({
      id: randomUUID(),
      action: "CUSTOMER_MAPPED",
      detail: `Mapped to customer ${customer.name} (${customer.code}) via ${movement.airlineIata}.`,
      payload: { customerId: customer.id },
      operator,
    });
  } else {
    confidence -= 35;
    escalate("red");
    alerts.push({
      id: randomUUID(),
      level: "red",
      code: "NO_CUSTOMER_MAPPING",
      message: `No billing customer mapped for airline ${movement.airline} (${movement.airlineIata}).`,
      resolved: false,
    });
  }

  if (mtowKg == null) {
    confidence -= 25;
    escalate("yellow");
    alerts.push({
      id: randomUUID(),
      level: "yellow",
      code: "MTOW_MISSING",
      message: `MTOW could not be determined for ${movement.aircraftType ?? "unknown type"} (tail ${movement.tailNumber ?? "?"}).`,
      resolved: false,
    });
  } else if (!matchedTail) {
    confidence -= 8;
    escalate("blue");
    alerts.push({
      id: randomUUID(),
      level: "blue",
      code: "LOW_CONFIDENCE",
      message: `MTOW estimated from aircraft type (${movement.aircraftType}); no tail registry match.`,
      resolved: false,
    });
  }

  const match = matchRateRule(catalog.rules, catalog.landingItemCode.id, {
    routeType,
    engineType,
    mtowKg,
    direction: movement.direction,
    airlineIata: movement.airlineIata ?? null,
    customerType: customer?.type ?? null,
    onDate,
  });

  let quantity = 0;
  let unitRate = 0;
  let amount = 0;
  let ratePlanId: string | null = null;
  let rateRuleId: string | null = null;
  let status: InsertBillableCharge["status"] = "pending";

  if (match) {
    ratePlanId = catalog.ratePlan.id;
    rateRuleId = match.rule.id;
    unitRate = match.rule.rateAmount;
    if (match.rule.calcMethod === "per_mtow_tonne") {
      quantity = round2((mtowKg ?? 0) / 1000);
      amount = round2(quantity * unitRate);
    } else if (match.rule.calcMethod === "per_pax") {
      quantity = movement.paxCount ?? 0;
      amount = round2(quantity * unitRate);
    } else {
      quantity = 1;
      amount = round2(unitRate);
    }
    if (match.rule.minCharge != null && amount < match.rule.minCharge) {
      amount = round2(match.rule.minCharge);
      escalate("blue");
      alerts.push({
        id: randomUUID(),
        level: "blue",
        code: "MIN_CHARGE_APPLIED",
        message: `Computed amount below minimum; minimum charge of ${match.rule.minCharge} ${match.rule.currency} applied.`,
        resolved: false,
      });
    }
    if (match.rule.maxCharge != null && amount > match.rule.maxCharge) {
      amount = round2(match.rule.maxCharge);
    }
    decisions.push({
      id: randomUUID(),
      action: "RULE_MATCHED",
      detail: `Rule "${match.rule.name}" matched. ${match.reasons.join(" ")}`,
      payload: { ruleId: match.rule.id, reasons: match.reasons, calcMethod: match.rule.calcMethod, quantity, unitRate },
      operator,
    });
    // Ready only when both customer and rule are present and MTOW known.
    status = customer && mtowKg != null ? "ready" : "pending";
  } else {
    confidence -= 40;
    escalate("purple");
    alerts.push({
      id: randomUUID(),
      level: "purple",
      code: "NO_RATE_RULE",
      message: `No effective landing-fee rate rule matched (route=${routeType}, engine=${engineType ?? "?"}, MTOW=${mtowKg ?? "?"}).`,
      resolved: false,
    });
  }

  confidence = Math.max(0, Math.min(100, confidence));

  for (const a of alerts) {
    decisions.push({
      id: randomUUID(),
      action: "ALERT_RAISED",
      detail: `[${(a.level ?? "yellow").toUpperCase()}] ${a.code}: ${a.message}`,
      payload: { code: a.code, level: a.level },
      operator,
    });
  }

  const charge: InsertBillableCharge = {
    id: randomUUID(),
    movementId: movement.id,
    customerId: customer?.id ?? null,
    itemCodeId: catalog.landingItemCode.id,
    ratePlanId,
    rateRuleId,
    description: `Landing fee — ${movement.flightNumber} ${movement.airlineIata}/${routeType} ${movement.aircraftType ?? ""}`.trim(),
    quantity,
    unitRate,
    amount,
    currency: match?.rule.currency ?? catalog.ratePlan.currency,
    status,
    alertLevel,
    confidenceScore: confidence,
    holdReason: null,
    discardReason: null,
    invoiceBatchId: null,
    invoiceId: null,
    chargeDate: onDate,
    source: "auto_rated",
  };

  return { charge, alerts, decisions };
}
