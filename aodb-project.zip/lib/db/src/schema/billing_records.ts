import { pgTable, text, real, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const billingRecordsTable = pgTable("billing_records", {
  id: text("id").primaryKey(),
  flightId: text("flight_id").notNull(),
  flightNumber: text("flight_number").notNull(),
  airline: text("airline").notNull(),
  tailNumber: text("tail_number"),
  aircraftType: text("aircraft_type"),
  mtowKg: real("mtow_kg"),
  engineType: text("engine_type"),
  isInternational: boolean("is_international").notNull().default(false),
  landingTime: text("landing_time"),
  paxCount: integer("pax_count"),
  calculatedLandingFee: real("calculated_landing_fee"),
  aifEstimate: real("aif_estimate"),
  tariffVersion: text("tariff_version"),
  reconciliationStatus: text("reconciliation_status").notNull().default("PENDING"),
  flags: text("flags").array().notNull().default([]),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertBillingSchema = createInsertSchema(billingRecordsTable).omit({ createdAt: true });
export type InsertBilling = z.infer<typeof insertBillingSchema>;
export type BillingRecord = typeof billingRecordsTable.$inferSelect;
