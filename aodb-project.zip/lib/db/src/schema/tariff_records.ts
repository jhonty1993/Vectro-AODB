import { pgTable, text, real, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const tariffRecordsTable = pgTable("tariff_records", {
  id: text("id").primaryKey(),
  version: text("version").notNull(),
  effectiveDate: text("effective_date").notNull(),
  expiryDate: text("expiry_date"),
  landingFeeDomesticPerTonne: real("landing_fee_domestic_per_tonne").notNull(),
  landingFeeIntlPerTonne: real("landing_fee_intl_per_tonne").notNull(),
  aifDomestic: real("aif_domestic").notNull(),
  aifIntl: real("aif_intl").notNull(),
  noiseChargeCategory1: real("noise_charge_category_1").notNull(),
  noiseChargeCategory2: real("noise_charge_category_2").notNull(),
  currency: text("currency").notNull().default("CAD"),
  isActive: boolean("is_active").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertTariffSchema = createInsertSchema(tariffRecordsTable).omit({ createdAt: true });
export type InsertTariff = z.infer<typeof insertTariffSchema>;
export type TariffRecord = typeof tariffRecordsTable.$inferSelect;
