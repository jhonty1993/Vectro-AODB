import { pgTable, text, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const staticScheduleImportsTable = pgTable("static_schedule_imports", {
  id: text("id").primaryKey(),
  filename: text("filename").notNull(),
  periodStart: text("period_start").notNull(),
  periodEnd: text("period_end").notNull(),
  importedAt: timestamp("imported_at").notNull().defaultNow(),
  isActive: boolean("is_active").notNull().default(false),
  version: integer("version").notNull().default(1),
  totalRows: integer("total_rows").notNull().default(0),
  arrivalCount: integer("arrival_count").notNull().default(0),
  departureCount: integer("departure_count").notNull().default(0),
  skippedCount: integer("skipped_count").notNull().default(0),
  commercialCount: integer("commercial_count").notNull().default(0),
  notes: text("notes"),
});

export const insertStaticScheduleImportSchema = createInsertSchema(staticScheduleImportsTable).omit({ importedAt: true });
export type InsertStaticScheduleImport = z.infer<typeof insertStaticScheduleImportSchema>;
export type StaticScheduleImport = typeof staticScheduleImportsTable.$inferSelect;
