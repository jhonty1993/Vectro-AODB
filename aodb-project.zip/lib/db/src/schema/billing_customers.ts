import { pgTable, text, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const billingCustomersTable = pgTable("billing_customers", {
  id: text("id").primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  type: text("type").notNull().default("airline"), // airline | handler | ga | cargo | other
  iataCode: text("iata_code"),
  icaoCode: text("icao_code"),
  contactName: text("contact_name"),
  contactEmail: text("contact_email"),
  billingAddress: text("billing_address"),
  paymentTermsDays: integer("payment_terms_days").notNull().default(30),
  currency: text("currency").notNull().default("CAD"),
  status: text("status").notNull().default("active"), // active | inactive
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertBillingCustomerSchema = createInsertSchema(billingCustomersTable).omit({
  createdAt: true,
  updatedAt: true,
});
export type InsertBillingCustomer = z.infer<typeof insertBillingCustomerSchema>;
export type BillingCustomer = typeof billingCustomersTable.$inferSelect;
