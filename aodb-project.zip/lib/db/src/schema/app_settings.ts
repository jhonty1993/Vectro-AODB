import { pgTable, text, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const appSettingsTable = pgTable("app_settings", {
  id: text("id").primaryKey().default("singleton"),
  airportIata: text("airport_iata").notNull().default("YLW"),
  airportIcao: text("airport_icao").notNull().default("CYLW"),
  airportName: text("airport_name").notNull().default("Kelowna International Airport"),
  fr24ApiKey: text("fr24_api_key"),
  fr24PollingIntervalSeconds: integer("fr24_polling_interval_seconds").default(60),
  fr24OperatingHoursStart: text("fr24_operating_hours_start").default("06:00"),
  fr24OperatingHoursEnd: text("fr24_operating_hours_end").default("23:00"),
  fr24RadiusNm: integer("fr24_radius_nm").default(50),
  fr24LastSyncAt: timestamp("fr24_last_sync_at"),
  fr24LastSyncStatus: text("fr24_last_sync_status"),
  fr24LastSyncCount: integer("fr24_last_sync_count"),
  fr24ConnectionStatus: text("fr24_connection_status").default("demo"),
  adsbxApiKey: text("adsbx_api_key"),
  adsbxProvider: text("adsbx_provider").default("adsbexchange"),
  adsbxRadiusNm: integer("adsbx_radius_nm").default(25),
  adsbxLat: text("adsbx_lat").default("49.9561"),
  adsbxLon: text("adsbx_lon").default("-119.3778"),
  adsbxPollingIntervalSeconds: integer("adsbx_polling_interval_seconds").default(60),
  adsbxConnectionStatus: text("adsbx_connection_status").default("demo"),
  adsbxLastSyncAt: timestamp("adsbx_last_sync_at"),
  adsbxLastSyncStatus: text("adsbx_last_sync_status"),
  adsbxLastSyncCount: integer("adsbx_last_sync_count"),
  pollingIntervalSeconds: integer("polling_interval_seconds").notNull().default(60),
  rmsWebhookUrl: text("rms_webhook_url"),
  billingApiUrl: text("billing_api_url"),
  notificationEmails: text("notification_emails"),
  commercialOnlyMode: boolean("commercial_only_mode").notNull().default(true),
  environmentMode: text("environment_mode").notNull().default("DEMO"),
  boundingBoxNorth: text("bounding_box_north"),
  boundingBoxSouth: text("bounding_box_south"),
  boundingBoxEast: text("bounding_box_east"),
  boundingBoxWest: text("bounding_box_west"),
  fr24StartingCredits: integer("fr24_starting_credits").default(1210000),
  fr24DailyWarningThreshold: integer("fr24_daily_warning_threshold").default(50000),
  fr24RemainingWarningThreshold: integer("fr24_remaining_warning_threshold").default(100000),
  fr24PerEndpointCosts: text("fr24_per_endpoint_costs"),
  adsbxHistoryRetentionDays: integer("adsbx_history_retention_days").default(90),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertAppSettingsSchema = createInsertSchema(appSettingsTable);
export type InsertAppSettings = z.infer<typeof insertAppSettingsSchema>;
export type AppSettings = typeof appSettingsTable.$inferSelect;
