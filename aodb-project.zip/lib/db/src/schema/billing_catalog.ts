import { pgTable, text, real, boolean, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

// Chargeable item / GL line definition (e.g. landing fee, parking, terminal).
export const itemCodesTable = pgTable("item_codes", {
  id: text("id").primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  description: text("description"),
  category: text("category").notNull().default("other"), // landing | parking | passenger | terminal | security | other
  unit: text("unit").notNull().default("flat"), // per_mtow_tonne | per_pax | per_stay | per_quarter_hour | flat
  glAccount: text("gl_account"),
  taxable: boolean("taxable").notNull().default(true),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertItemCodeSchema = createInsertSchema(itemCodesTable).omit({
  createdAt: true,
  updatedAt: true,
});
export type InsertItemCode = z.infer<typeof insertItemCodeSchema>;
export type ItemCode = typeof itemCodesTable.$inferSelect;

// A versioned, effective-dated collection of rate rules.
export const ratePlansTable = pgTable("rate_plans", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  effectiveFrom: text("effective_from").notNull(),
  effectiveTo: text("effective_to"),
  currency: text("currency").notNull().default("CAD"),
  status: text("status").notNull().default("active"), // active | draft | archived
  isDefault: boolean("is_default").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertRatePlanSchema = createInsertSchema(ratePlansTable).omit({
  createdAt: true,
  updatedAt: true,
});
export type InsertRatePlan = z.infer<typeof insertRatePlanSchema>;
export type RatePlan = typeof ratePlansTable.$inferSelect;

// An effective-dated, condition-matched pricing rule belonging to a rate plan.
export const rateRulesTable = pgTable("rate_rules", {
  id: text("id").primaryKey(),
  ratePlanId: text("rate_plan_id").notNull(),
  itemCodeId: text("item_code_id").notNull(),
  name: text("name").notNull(),
  priority: integer("priority").notNull().default(100), // higher wins
  effectiveFrom: text("effective_from").notNull(),
  effectiveTo: text("effective_to"),
  // Match conditions ("any"/null means no constraint on that dimension)
  routeType: text("route_type").notNull().default("any"), // domestic | transborder | international | any
  engineType: text("engine_type").notNull().default("any"), // TURBOFAN | TURBOPROP | PISTON | any
  customerType: text("customer_type").notNull().default("any"), // airline | handler | ga | cargo | any
  direction: text("direction").notNull().default("any"), // ARR | DEP | any
  airlineIata: text("airline_iata"), // specific airline override
  minMtowKg: real("min_mtow_kg"),
  maxMtowKg: real("max_mtow_kg"),
  // Pricing
  calcMethod: text("calc_method").notNull().default("per_mtow_tonne"), // per_mtow_tonne | flat | per_pax | per_quarter_hour
  rateAmount: real("rate_amount").notNull().default(0),
  minCharge: real("min_charge"),
  maxCharge: real("max_charge"),
  currency: text("currency").notNull().default("CAD"),
  notes: text("notes"),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertRateRuleSchema = createInsertSchema(rateRulesTable).omit({
  createdAt: true,
  updatedAt: true,
});
export type InsertRateRule = z.infer<typeof insertRateRuleSchema>;
export type RateRule = typeof rateRulesTable.$inferSelect;
