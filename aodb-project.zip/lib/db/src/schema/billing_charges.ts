import { pgTable, text, real, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

// A single rated/billable line derived from a movement (or parking/recurring source).
export const billableChargesTable = pgTable("billable_charges", {
  id: text("id").primaryKey(),
  movementId: text("movement_id"), // FK flight_movements (nullable for non-movement charges)
  customerId: text("customer_id"), // nullable when customer mapping is missing
  itemCodeId: text("item_code_id").notNull(),
  ratePlanId: text("rate_plan_id"), // provenance
  rateRuleId: text("rate_rule_id"), // provenance
  description: text("description").notNull(),
  quantity: real("quantity").notNull().default(1),
  unitRate: real("unit_rate").notNull().default(0),
  amount: real("amount").notNull().default(0),
  currency: text("currency").notNull().default("CAD"),
  status: text("status").notNull().default("pending"), // pending | held | discarded | ready | invoiced | credited
  alertLevel: text("alert_level").notNull().default("green"), // green | blue | yellow | purple | red | black
  confidenceScore: real("confidence_score").notNull().default(100),
  holdReason: text("hold_reason"),
  discardReason: text("discard_reason"),
  invoiceBatchId: text("invoice_batch_id"),
  invoiceId: text("invoice_id"),
  chargeDate: text("charge_date").notNull(),
  source: text("source").notNull().default("auto_rated"), // auto_rated | manual | parking | recurring
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertBillableChargeSchema = createInsertSchema(billableChargesTable).omit({
  createdAt: true,
  updatedAt: true,
});
export type InsertBillableCharge = z.infer<typeof insertBillableChargeSchema>;
export type BillableCharge = typeof billableChargesTable.$inferSelect;

// Structured alert raised against a charge (richer than a color status).
export const billingAlertsTable = pgTable("billing_alerts", {
  id: text("id").primaryKey(),
  chargeId: text("charge_id").notNull(),
  level: text("level").notNull().default("yellow"), // green | blue | yellow | purple | red | black
  code: text("code").notNull(), // NO_CUSTOMER_MAPPING | NO_RATE_RULE | MTOW_MISSING | LOW_CONFIDENCE | DUPLICATE_SUSPECTED | MIN_CHARGE_APPLIED | MANUAL_OVERRIDE
  message: text("message").notNull(),
  resolved: boolean("resolved").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertBillingAlertSchema = createInsertSchema(billingAlertsTable).omit({
  createdAt: true,
});
export type InsertBillingAlert = z.infer<typeof insertBillingAlertSchema>;
export type BillingAlert = typeof billingAlertsTable.$inferSelect;

// Immutable provenance/audit trail of every billing decision on a charge.
export const billingDecisionLogTable = pgTable("billing_decision_log", {
  id: text("id").primaryKey(),
  chargeId: text("charge_id").notNull(),
  action: text("action").notNull(), // RATED | RULE_MATCHED | CUSTOMER_MAPPED | ALERT_RAISED | HELD | DISCARDED | READIED | INVOICED | CREDITED
  detail: text("detail").notNull(),
  payload: jsonb("payload"),
  operator: text("operator"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertBillingDecisionSchema = createInsertSchema(billingDecisionLogTable).omit({
  createdAt: true,
});
export type InsertBillingDecision = z.infer<typeof insertBillingDecisionSchema>;
export type BillingDecision = typeof billingDecisionLogTable.$inferSelect;
