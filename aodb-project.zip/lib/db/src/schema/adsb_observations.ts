import { pgTable, serial, text, integer, real, timestamp, jsonb } from "drizzle-orm/pg-core";

export const adsbObservationsTable = pgTable("adsb_observations", {
  id: serial("id").primaryKey(),
  syncId: text("sync_id").notNull(),
  icaoHex: text("icao_hex").notNull(),
  callsign: text("callsign"),
  registration: text("registration"),
  aircraftType: text("aircraft_type"),
  altBaro: integer("alt_baro"),
  altGeom: integer("alt_geom"),
  groundSpeed: real("ground_speed"),
  track: real("track"),
  verticalRate: real("vertical_rate"),
  squawk: text("squawk"),
  lat: real("lat"),
  lon: real("lon"),
  distanceNm: real("distance_nm"),
  directionFromAirport: text("direction_from_airport"),
  airportContext: text("airport_context"),
  lastSeenTs: timestamp("last_seen_ts"),
  inferredStatus: text("inferred_status"),
  source: text("source").notNull().default("adsbexchange"),
  rawPayload: jsonb("raw_payload"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type AdsbObservation = typeof adsbObservationsTable.$inferSelect;
export type InsertAdsbObservation = typeof adsbObservationsTable.$inferInsert;
