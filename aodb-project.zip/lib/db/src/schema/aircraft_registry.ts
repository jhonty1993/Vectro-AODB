import { pgTable, text, real, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const aircraftRegistryTable = pgTable("aircraft_registry", {
  id: text("id").primaryKey(),
  tailNumber: text("tail_number").notNull().unique(),
  aircraftType: text("aircraft_type").notNull(),
  mtowKg: real("mtow_kg").notNull(),
  engineType: text("engine_type").notNull(),
  seats: integer("seats"),
  noiseCategory: text("noise_category"),
  airline: text("airline"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertAircraftSchema = createInsertSchema(aircraftRegistryTable).omit({ createdAt: true, updatedAt: true });
export type InsertAircraft = z.infer<typeof insertAircraftSchema>;
export type AircraftRegistry = typeof aircraftRegistryTable.$inferSelect;
