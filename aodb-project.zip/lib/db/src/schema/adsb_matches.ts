import { pgTable, serial, text, integer, real, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";

export const adsbMatchesTable = pgTable("adsb_matches", {
  id: serial("id").primaryKey(),
  observationId: integer("observation_id").notNull(),
  flightMovementId: text("flight_movement_id"),
  matchType: text("match_type").notNull().default("unmatched"),
  matchScore: real("match_score").notNull().default(0),
  matchReasons: jsonb("match_reasons"),
  callsignMatch: boolean("callsign_match").notNull().default(false),
  timeWindowMatch: boolean("time_window_match").notNull().default(false),
  proximityMatch: boolean("proximity_match").notNull().default(false),
  airlineMatch: boolean("airline_match").notNull().default(false),
  manualReview: boolean("manual_review").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type AdsbMatch = typeof adsbMatchesTable.$inferSelect;
export type InsertAdsbMatch = typeof adsbMatchesTable.$inferInsert;
