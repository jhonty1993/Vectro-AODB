import { pgTable, text, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const fr24UsageLogTable = pgTable("fr24_usage_log", {
  id: text("id").primaryKey(),
  calledAt: timestamp("called_at").notNull().defaultNow(),
  endpoint: text("endpoint").notNull(),
  purpose: text("purpose").notNull(),
  success: boolean("success").notNull(),
  httpStatus: integer("http_status"),
  estimatedCredits: integer("estimated_credits").notNull().default(0),
  errorMessage: text("error_message"),
  responseTimeMs: integer("response_time_ms"),
  meta: jsonb("meta"),
});

export const insertFr24UsageLogSchema = createInsertSchema(fr24UsageLogTable).omit({ calledAt: true });
export type InsertFr24UsageLog = z.infer<typeof insertFr24UsageLogSchema>;
export type Fr24UsageLog = typeof fr24UsageLogTable.$inferSelect;
