import { pgTable, text, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { staticScheduleImportsTable } from "./static_schedule_imports";

export const staticScheduleMovementsTable = pgTable("static_schedule_movements", {
  id: text("id").primaryKey(),
  importId: text("import_id").notNull().references(() => staticScheduleImportsTable.id, { onDelete: "cascade" }),
  direction: text("direction").notNull(),
  flightNumber: text("flight_number").notNull(),
  airlineIata: text("airline_iata").notNull(),
  airlineName: text("airline_name"),
  scheduledTime: text("scheduled_time").notNull(),
  origin: text("origin"),
  destination: text("destination"),
  city: text("city"),
  aircraftType: text("aircraft_type"),
  aircraftGroup: text("aircraft_group"),
  seats: integer("seats"),
  plannedPax: integer("planned_pax"),
  flightType: text("flight_type"),
  flightNature: text("flight_nature"),
  sector: text("sector"),
  status: text("status"),
  codeshares: text("codeshares"),
  tailNumber: text("tail_number"),
  stand: text("stand"),
  gate: text("gate"),
  passengerHandling: text("passenger_handling"),
  isCommercial: boolean("is_commercial").notNull().default(true),
  rawPayload: jsonb("raw_payload").notNull(),
  linkedMovementId: text("linked_movement_id"),
  fr24MatchStatus: text("fr24_match_status").default("pending"),
  fr24ActualTime: text("fr24_actual_time"),
  fr24TailNumber: text("fr24_tail_number"),
  fr24AircraftType: text("fr24_aircraft_type"),
  varianceMinutes: integer("variance_minutes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertStaticScheduleMovementSchema = createInsertSchema(staticScheduleMovementsTable).omit({ createdAt: true });
export type InsertStaticScheduleMovement = z.infer<typeof insertStaticScheduleMovementSchema>;
export type StaticScheduleMovement = typeof staticScheduleMovementsTable.$inferSelect;
