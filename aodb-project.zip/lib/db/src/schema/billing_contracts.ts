import { pgTable, text, real, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

// An aircraft parking/apron stay, chargeable by duration.
export const parkingStaysTable = pgTable("parking_stays", {
  id: text("id").primaryKey(),
  arrivalMovementId: text("arrival_movement_id"),
  departureMovementId: text("departure_movement_id"),
  customerId: text("customer_id"),
  tailNumber: text("tail_number"),
  stand: text("stand"),
  arrivalTime: text("arrival_time"),
  departureTime: text("departure_time"),
  durationMinutes: integer("duration_minutes").notNull().default(0),
  freeMinutes: integer("free_minutes").notNull().default(0),
  chargeableMinutes: integer("chargeable_minutes").notNull().default(0),
  status: text("status").notNull().default("active"), // active | closed | charged
  chargeId: text("charge_id"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertParkingStaySchema = createInsertSchema(parkingStaysTable).omit({
  createdAt: true,
  updatedAt: true,
});
export type InsertParkingStay = z.infer<typeof insertParkingStaySchema>;
export type ParkingStay = typeof parkingStaysTable.$inferSelect;

// A recurring (non-movement) revenue agreement, e.g. office lease or monthly handling fee.
export const recurringContractsTable = pgTable("recurring_contracts", {
  id: text("id").primaryKey(),
  customerId: text("customer_id").notNull(),
  itemCodeId: text("item_code_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  amount: real("amount").notNull().default(0),
  currency: text("currency").notNull().default("CAD"),
  frequency: text("frequency").notNull().default("monthly"), // monthly | quarterly | annual
  nextRunDate: text("next_run_date"),
  lastRunDate: text("last_run_date"),
  effectiveFrom: text("effective_from"),
  effectiveTo: text("effective_to"),
  status: text("status").notNull().default("active"), // active | paused | ended
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertRecurringContractSchema = createInsertSchema(recurringContractsTable).omit({
  createdAt: true,
  updatedAt: true,
});
export type InsertRecurringContract = z.infer<typeof insertRecurringContractSchema>;
export type RecurringContract = typeof recurringContractsTable.$inferSelect;
