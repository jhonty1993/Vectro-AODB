import { pgTable, text, integer, real, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const flightMovementsTable = pgTable("flight_movements", {
  id: text("id").primaryKey(),
  flightNumber: text("flight_number").notNull(),
  airline: text("airline").notNull(),
  airlineIata: text("airline_iata").notNull(),
  direction: text("direction").notNull(),
  origin: text("origin").notNull(),
  destination: text("destination").notNull(),
  scheduledTime: text("scheduled_time").notNull(),
  estimatedTime: text("estimated_time"),
  actualTime: text("actual_time"),
  tailNumber: text("tail_number"),
  aircraftType: text("aircraft_type"),
  stand: text("stand"),
  gate: text("gate"),
  belt: text("belt"),
  runway: text("runway"),
  checkinCounters: text("checkin_counters"),
  status: text("status").notNull().default("SCHEDULED"),
  dataSource: text("data_source"),
  fr24Seen: boolean("fr24_seen").notNull().default(false),
  fr24LastSeenAt: text("fr24_last_seen_at"),
  dataQualityScore: real("data_quality_score").notNull().default(100),
  delayMinutes: integer("delay_minutes"),
  paxCount: integer("pax_count"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertFlightMovementSchema = createInsertSchema(flightMovementsTable).omit({ createdAt: true, updatedAt: true });
export type InsertFlightMovement = z.infer<typeof insertFlightMovementSchema>;
export type FlightMovement = typeof flightMovementsTable.$inferSelect;
