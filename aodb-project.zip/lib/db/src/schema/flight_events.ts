import { pgTable, text, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const flightEventsTable = pgTable("flight_events", {
  id: text("id").primaryKey(),
  flightId: text("flight_id").notNull(),
  eventType: text("event_type").notNull(),
  eventTime: text("event_time").notNull(),
  source: text("source").notNull(),
  operator: text("operator"),
  reason: text("reason"),
  payload: jsonb("payload"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertFlightEventSchema = createInsertSchema(flightEventsTable).omit({ createdAt: true });
export type InsertFlightEvent = z.infer<typeof insertFlightEventSchema>;
export type FlightEvent = typeof flightEventsTable.$inferSelect;
