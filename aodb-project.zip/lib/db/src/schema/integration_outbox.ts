import { pgTable, text, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const integrationOutboxTable = pgTable("integration_outbox", {
  id: text("id").primaryKey(),
  flightId: text("flight_id").notNull(),
  flightNumber: text("flight_number").notNull(),
  eventType: text("event_type").notNull(),
  destination: text("destination").notNull(), // RMS | BILLING
  status: text("status").notNull().default("QUEUED"),
  payload: jsonb("payload"),
  sentAt: text("sent_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertOutboxSchema = createInsertSchema(integrationOutboxTable).omit({ createdAt: true });
export type InsertOutbox = z.infer<typeof insertOutboxSchema>;
export type IntegrationOutbox = typeof integrationOutboxTable.$inferSelect;
