import { pgTable, text, real, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

// A run that groups selected ready charges for invoicing.
export const invoiceBatchesTable = pgTable("invoice_batches", {
  id: text("id").primaryKey(),
  batchNumber: text("batch_number").notNull().unique(),
  status: text("status").notNull().default("open"), // open | finalized | exported
  periodStart: text("period_start"),
  periodEnd: text("period_end"),
  chargeCount: integer("charge_count").notNull().default(0),
  invoiceCount: integer("invoice_count").notNull().default(0),
  totalAmount: real("total_amount").notNull().default(0),
  currency: text("currency").notNull().default("CAD"),
  createdBy: text("created_by"),
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertInvoiceBatchSchema = createInsertSchema(invoiceBatchesTable).omit({
  createdAt: true,
  updatedAt: true,
});
export type InsertInvoiceBatch = z.infer<typeof insertInvoiceBatchSchema>;
export type InvoiceBatch = typeof invoiceBatchesTable.$inferSelect;

// A per-customer invoice produced within a batch.
export const invoicesTable = pgTable("invoices", {
  id: text("id").primaryKey(),
  invoiceNumber: text("invoice_number").notNull().unique(),
  batchId: text("batch_id").notNull(),
  customerId: text("customer_id").notNull(),
  status: text("status").notNull().default("draft"), // draft | issued | paid | credited | void
  issueDate: text("issue_date"),
  dueDate: text("due_date"),
  subtotal: real("subtotal").notNull().default(0),
  taxAmount: real("tax_amount").notNull().default(0),
  total: real("total").notNull().default(0),
  currency: text("currency").notNull().default("CAD"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertInvoiceSchema = createInsertSchema(invoicesTable).omit({
  createdAt: true,
  updatedAt: true,
});
export type InsertInvoice = z.infer<typeof insertInvoiceSchema>;
export type Invoice = typeof invoicesTable.$inferSelect;

// A single line on an invoice, traceable back to a charge.
export const invoiceLinesTable = pgTable("invoice_lines", {
  id: text("id").primaryKey(),
  invoiceId: text("invoice_id").notNull(),
  chargeId: text("charge_id"),
  itemCodeId: text("item_code_id").notNull(),
  description: text("description").notNull(),
  quantity: real("quantity").notNull().default(1),
  unitRate: real("unit_rate").notNull().default(0),
  amount: real("amount").notNull().default(0),
  taxRate: real("tax_rate").notNull().default(0),
  taxAmount: real("tax_amount").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertInvoiceLineSchema = createInsertSchema(invoiceLinesTable).omit({
  createdAt: true,
});
export type InsertInvoiceLine = z.infer<typeof insertInvoiceLineSchema>;
export type InvoiceLine = typeof invoiceLinesTable.$inferSelect;
